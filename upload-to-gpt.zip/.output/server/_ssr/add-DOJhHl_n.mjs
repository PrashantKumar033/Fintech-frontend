import { i as CreateMemberPage } from "./router-B644QERq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/add-DOJhHl_n.js
var SplitComponent = CreateMemberPage;
//#endregion
export { SplitComponent as component };
