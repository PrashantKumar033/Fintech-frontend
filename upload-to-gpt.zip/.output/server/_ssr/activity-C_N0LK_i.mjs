import { r as __toESM } from "../_runtime.mjs";
import { s as getSession } from "./auth-api-CJcoiRrI.mjs";
import { i as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { At as FileClock, F as RefreshCw } from "../_libs/lucide-react.mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as ServiceNotice, t as BusinessPage } from "./business-page-CLA-Unc5.mjs";
import { n as operationsApi, r as operationsMessage } from "./operations-api-BInDpxzN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/activity-C_N0LK_i.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ActivityPage() {
	const navigate = useNavigate();
	const [session, setSession] = (0, import_react.useState)(null);
	const [logs, setLogs] = (0, import_react.useState)(null);
	const [status, setStatus] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)("");
	async function load(token, selected = status) {
		setLoading(true);
		setError("");
		try {
			setLogs(await operationsApi.audits(token, {
				page: 1,
				limit: 50,
				status: selected || void 0
			}));
		} catch (e) {
			setError(operationsMessage(e));
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		const value = getSession();
		if (!value) {
			navigate({ to: "/login" });
			return;
		}
		setSession(value);
		load(value.accessToken, "");
	}, [navigate]);
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "animate-spin text-primary" })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BusinessPage, {
		identity: session.identity,
		active: "reports",
		eyebrow: "Audit service",
		title: "Account activity",
		description: "A secure record of actions performed through your UMOBIPAY account.",
		children: [error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceNotice, {
				ok: false,
				children: error
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "overflow-hidden rounded-2xl border border-border bg-card shadow-soft",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between border-b border-border p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-extrabold text-secondary",
					children: "Security & service activity"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Latest 50 audit events"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: status,
					onChange: (e) => {
						const value = e.target.value;
						setStatus(value);
						load(session.accessToken, value);
					},
					className: "rounded-xl border border-border bg-background px-4 py-2.5 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "All events"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "SUCCESS",
							children: "Successful"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "FAILED",
							children: "Failed"
						})
					]
				})]
			}), loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid h-64 place-items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "animate-spin text-primary" })
			}) : logs?.data.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y divide-border",
				children: logs.data.map((log) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "flex flex-col gap-3 p-5 sm:flex-row sm:items-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `grid h-10 w-10 place-items-center rounded-xl ${log.status === "SUCCESS" ? "bg-emerald-50 text-emerald-600" : "bg-red-50 text-red-600"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileClock, { size: 18 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-bold text-secondary",
								children: log.action.replaceAll("_", " ")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "truncate text-xs text-muted-foreground",
								children: [
									log.service,
									" · ",
									log.httpMethod || "EVENT",
									" ",
									log.endpoint || ""
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sm:text-right",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `text-xs font-extrabold ${log.status === "SUCCESS" ? "text-emerald-600" : "text-red-600"}`,
								children: log.status
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: new Date(log.createdAt).toLocaleString("en-IN")
							})]
						})
					]
				}, log.id))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid h-64 place-items-center text-sm text-muted-foreground",
				children: "No audit activity found."
			})]
		})]
	});
}
//#endregion
export { ActivityPage as component };
