import { r as __toESM } from "../_runtime.mjs";
import { c as getSession } from "./role-hierarchy-B8AZOwBW.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { d as UserPlus, x as Store } from "../_libs/lucide-react.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-B_1VDSsy.mjs";
import { t as distributorApi } from "./distributor-api-BY5rX4_z.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/retailers-BuNv1Bzk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RetailersPage() {
	const session = getSession();
	const [rows, setRows] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (session) distributorApi.retailers(session.identity.id).then((value) => setRows(Array.isArray(value) ? value : [])).catch((reason) => setError(reason instanceof Error ? reason.message : "Retailers could not be loaded.")).finally(() => setLoading(false));
	}, [session?.identity.id]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "merchants",
		eyebrow: "Network",
		title: "Retailer management",
		description: "Create retailers and view the hierarchy records assigned below this Distributor.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-5 flex justify-end",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: "/distributor/retailers/add",
				className: "flex items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-white",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { size: 17 }), " Add retailer"]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 rounded-xl bg-red-50 p-3 text-sm text-red-700",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-x-auto",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[620px] text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Retailer identity"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Service"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Assigned"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border/60",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "p-3 font-bold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mr-2 inline-grid h-8 w-8 place-items-center rounded-lg bg-primary/10 text-primary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Store, { size: 15 })
									}), row.childUserId || row.id || "—"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3",
									children: row.serviceType || "All services"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3 font-bold",
									children: row.isActive === false ? "INACTIVE" : "ACTIVE"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3",
									children: row.createdAt ? new Date(row.createdAt).toLocaleDateString("en-IN") : "—"
								})
							]
						}, row.id || index)) })]
					}),
					!loading && !rows.length && !error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-12 text-center text-sm text-muted-foreground",
						children: "No retailer hierarchy records found. Create the first Retailer account."
					}),
					loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-12 text-center text-sm text-muted-foreground",
						children: "Loading retailer network..."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 rounded-xl bg-muted p-3 text-xs text-muted-foreground",
				children: "Full retailer profile, KYC and status controls will activate when the backend exposes protected child-identity detail endpoints."
			})
		] })]
	});
}
//#endregion
export { RetailersPage as component };
