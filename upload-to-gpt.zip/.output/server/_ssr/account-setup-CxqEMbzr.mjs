import { r as AdminIdentitySetup } from "./router-B644QERq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-setup-CxqEMbzr.js
var SplitComponent = AdminIdentitySetup;
//#endregion
export { SplitComponent as component };
