import { r as authenticatedRequest } from "./auth-api-CJcoiRrI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/distributor-api-G-WPYZyn.js
var distributorApi = {
	balances: (identityId) => authenticatedRequest(`/wallet/balances/${encodeURIComponent(identityId)}`),
	transactions: (query = "page=1&limit=50") => authenticatedRequest(`/aeps/transactions?${query}`),
	retailers: (identityId) => authenticatedRequest(`/commission-hierarchy/parent/${encodeURIComponent(identityId)}/children`),
	audits: () => authenticatedRequest("/audit/me?page=1&limit=50"),
	commissions: () => authenticatedRequest("/commission-distributions/distributions")
};
//#endregion
export { distributorApi as t };
