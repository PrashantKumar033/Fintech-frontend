import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { rn as Banknote } from "../_libs/lucide-react.mjs";
import { t as DistributorModulePlaceholder } from "./module-placeholder-rnmCUeSq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cash-withdrawal-C-NaXCNh.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DistributorModulePlaceholder, {
	active: "transactions",
	icon: Banknote,
	title: "Cash withdrawal monitoring",
	description: "Review-focused Distributor workspace for cash-withdrawal activity."
});
//#endregion
export { SplitComponent as component };
