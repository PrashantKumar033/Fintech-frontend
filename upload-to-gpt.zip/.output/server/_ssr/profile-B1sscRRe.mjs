import { d as Profile } from "./router-BahmeVh9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-B1sscRRe.js
var SplitComponent = Profile;
//#endregion
export { SplitComponent as component };
