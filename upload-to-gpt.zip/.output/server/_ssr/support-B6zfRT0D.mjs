import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { bt as Headphones } from "../_libs/lucide-react.mjs";
import { t as MasterDistributorModulePlaceholder } from "./module-placeholder-CYYFwolg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/support-B6zfRT0D.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MasterDistributorModulePlaceholder, {
		active: "settings",
		icon: Headphones,
		title: "Support tickets",
		description: "Raise and monitor operational support requests.",
		pending: "A ticket lifecycle API is not present in the current backend."
	});
}
//#endregion
export { Page as component };
