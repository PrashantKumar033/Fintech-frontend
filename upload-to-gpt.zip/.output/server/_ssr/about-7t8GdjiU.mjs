import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { P as Rocket, T as ShieldCheck, _ as Target, bt as Headphones, ln as ArrowRight, on as Award, t as Zap, tt as MapPinned, x as Sparkles, yt as Heart } from "../_libs/lucide-react.mjs";
import { n as SiteNav, t as SiteFooter } from "./site-footer-BVtbrO9E.mjs";
import { t as about_team_default } from "./about-team-B3yE-m2r.mjs";
import { t as phone_mock_default } from "./phone-mock-yJTrDaUx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-7t8GdjiU.js
var import_jsx_runtime = require_jsx_runtime();
var values = [
	{
		icon: Target,
		title: "Purpose-first",
		desc: "Every feature we build starts with a real retailer's problem."
	},
	{
		icon: Heart,
		title: "People-obsessed",
		desc: "We treat every customer like our first — priority support, always."
	},
	{
		icon: ShieldCheck,
		title: "Trust as default",
		desc: "RBI-aligned, PCI-DSS handled, encryption end-to-end."
	},
	{
		icon: Sparkles,
		title: "Craft over speed",
		desc: "Ship carefully. Break nothing. Delight everyone."
	}
];
var features = [
	{
		icon: Zap,
		title: "Easy and fast",
		desc: "A simple retailer experience designed for quick, reliable service."
	},
	{
		icon: MapPinned,
		title: "Pay anywhere",
		desc: "Serve customers across India from one connected business platform."
	},
	{
		icon: ShieldCheck,
		title: "Safe and secure",
		desc: "Security-focused journeys protect every payment and account."
	},
	{
		icon: Headphones,
		title: "Dedicated support",
		desc: "Get help from a team that understands assisted digital banking."
	}
];
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "relative overflow-hidden",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto grid max-w-7xl gap-12 px-6 py-20 lg:grid-cols-2 lg:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-bold uppercase tracking-widest text-primary",
							children: "About Us"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-4 font-display text-5xl font-extrabold leading-tight text-secondary sm:text-6xl",
							children: [
								"Payments that meet",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-primary",
									children: "India, where it is."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-xl text-lg text-foreground/70",
							children: "UMOBIPAY started with a simple belief: bill payments and money transfers shouldn't be complicated. Today we power millions of transactions for retailers, agents and everyday customers."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 grid gap-4 sm:grid-cols-3",
							children: [
								{
									k: "2019",
									v: "Founded"
								},
								{
									k: "28",
									v: "States served"
								},
								{
									k: "5L+",
									v: "Retailers"
								}
							].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-border bg-card p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-2xl font-extrabold text-primary",
									children: s.k
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: s.v
								})]
							}, s.v))
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -inset-4 rounded-[3rem] bg-mint" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative rounded-[2.5rem] p-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: about_team_default,
								alt: "Team collaborating",
								width: 1200,
								height: 900,
								loading: "lazy",
								className: "w-full"
							})
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto max-w-7xl px-6 py-16",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-6 sm:grid-cols-2 lg:grid-cols-4",
					children: features.map((feature) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-3xl border border-border bg-card p-7 text-center shadow-soft",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mx-auto grid h-13 w-13 place-items-center rounded-2xl bg-mint text-secondary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(feature.icon, { size: 23 })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-5 text-lg font-bold text-secondary",
								children: feature.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-6 text-foreground/65",
								children: feature.desc
							})
						]
					}, feature.title))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto max-w-7xl px-6 py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-12 rounded-[2.5rem] bg-secondary p-10 text-secondary-foreground md:grid-cols-3 md:p-16",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rocket, {
								className: "text-primary",
								size: 32
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 font-display text-xl font-bold",
								children: "Our mission"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-secondary-foreground/75",
								children: "Make every rupee move instantly, safely, and affordably — from Tier-1 cities to remote taluks."
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Award, {
								className: "text-primary",
								size: 32
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 font-display text-xl font-bold",
								children: "Our vision"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-secondary-foreground/75",
								children: "To be the payments platform of choice for the next 500 million digital Indians."
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
								className: "text-primary",
								size: 32
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 font-display text-xl font-bold",
								children: "Our promise"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-secondary-foreground/75",
								children: "Zero surprises. Transparent pricing, instant support, real people on the other side."
							})
						] })
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-7xl px-6 py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-2xl text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-bold uppercase tracking-widest text-primary",
						children: "What we stand for"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-4xl font-extrabold text-secondary sm:text-5xl",
						children: "Values we ship every day."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4",
					children: values.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-3xl border border-border bg-card p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-12 w-12 place-items-center rounded-2xl bg-mint text-secondary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(v.icon, { size: 22 })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-5 font-display text-lg font-bold text-secondary",
								children: v.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-foreground/70",
								children: v.desc
							})
						]
					}, v.title))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto max-w-7xl px-6 py-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative overflow-hidden rounded-[2.5rem] bg-mint p-8 sm:p-12 lg:p-16",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid items-center gap-10 lg:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: phone_mock_default,
							alt: "UMOBIPAY mobile payment application",
							className: "mx-auto max-h-[430px] w-full object-contain",
							loading: "lazy"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-bold uppercase tracking-widest text-primary",
								children: "Built for Bharat"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 text-4xl font-extrabold text-secondary sm:text-5xl",
								children: "Effortless transactions. Dependable security."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 max-w-xl leading-7 text-foreground/70",
								children: "Recharge, pay bills, manage assisted banking services and grow your retail business from a single secure workspace."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "/register",
								className: "mt-7 inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3.5 text-sm font-bold text-white shadow-elegant",
								children: ["Become a retailer ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 16 })]
							})
						] })]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { About as component };
