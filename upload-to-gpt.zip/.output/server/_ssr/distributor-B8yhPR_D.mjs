import { a as DistributorDashboard } from "./router-B644QERq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/distributor-B8yhPR_D.js
var SplitComponent = DistributorDashboard;
//#endregion
export { SplitComponent as component };
