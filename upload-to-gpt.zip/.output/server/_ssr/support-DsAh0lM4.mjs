import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { Ct as Headphones } from "../_libs/lucide-react.mjs";
import { t as DistributorModulePlaceholder } from "./module-placeholder-C08qOeOe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/support-DsAh0lM4.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DistributorModulePlaceholder, {
	active: "sms",
	icon: Headphones,
	title: "Support & complaints",
	description: "Track support requests and operational complaints from one dedicated workspace."
});
//#endregion
export { SplitComponent as component };
