import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { A as ScanLine, Et as Flame, Gt as CircleCheck, L as ReceiptText, Lt as Droplet, O as Send, S as Smartphone, T as ShieldCheck, an as BadgeCheck, i as Wifi, ln as ArrowRight, mt as Landmark, rn as Banknote, t as Zap, y as Store, zt as CreditCard } from "../_libs/lucide-react.mjs";
import { n as SiteNav, t as SiteFooter } from "./site-footer-BVtbrO9E.mjs";
import { t as about_team_default } from "./about-team-B3yE-m2r.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/services-C2ksQCeV.js
var import_jsx_runtime = require_jsx_runtime();
var featured = [
	{
		icon: Smartphone,
		title: "Mobile & DTH Recharge",
		desc: "Instant recharges for prepaid mobile, postpaid mobile and DTH services with real-time confirmation and auto-retry support.",
		tags: [
			"All operators",
			"Instant",
			"Auto-retry"
		]
	},
	{
		icon: Send,
		title: "Domestic Money Transfer",
		desc: "Send money to bank accounts all across India with secure transfer options and fast settlement support.",
		tags: [
			"IMPS",
			"NEFT",
			"24×7"
		]
	},
	{
		icon: Zap,
		title: "Utility Bill Payments",
		desc: "Collect and process electricity, water, gas and broadband bills through one unified interface.",
		tags: [
			"Electricity",
			"Water",
			"Gas"
		]
	},
	{
		icon: ReceiptText,
		title: "BBPS & Billers",
		desc: "500+ billers integrated with Bharat Bill Payment System support for seamless customer coverage.",
		tags: [
			"BBPS",
			"500+ billers",
			"Unified"
		]
	},
	{
		icon: Banknote,
		title: "Credit Card & Loan EMI",
		desc: "Support customers with card bill payments and EMI commitments without adding operational friction.",
		tags: [
			"Cards",
			"EMI",
			"Easy pay"
		]
	},
	{
		icon: Landmark,
		title: "Insurance Premiums",
		desc: "Help customers stay active on life, health and vehicle insurance renewals with convenient payments.",
		tags: [
			"Insurance",
			"Renewal",
			"Fast"
		]
	}
];
var categories = [
	{
		icon: CreditCard,
		title: "Credit Card Bills"
	},
	{
		icon: Wifi,
		title: "Broadband & Landline"
	},
	{
		icon: Droplet,
		title: "Water Bills"
	},
	{
		icon: Flame,
		title: "Gas — LPG & PNG"
	},
	{
		icon: ScanLine,
		title: "FASTag Recharge"
	},
	{
		icon: Store,
		title: "Merchant Payments"
	},
	{
		icon: BadgeCheck,
		title: "Education Fees"
	},
	{
		icon: ShieldCheck,
		title: "Secure Transactions"
	}
];
var benefits = [
	"500+ billers on-boarded",
	"Instant confirmation receipts",
	"Refund support for failed transactions",
	"Daily commission settlement",
	"High uptime for peak demand",
	"Multi-channel support for agents"
];
function Services() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative overflow-hidden bg-mint",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-grid opacity-40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto grid max-w-7xl items-center gap-10 px-6 py-14 lg:grid-cols-2 lg:py-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-bold uppercase tracking-widest text-primary",
							children: "Our Services"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-3 max-w-3xl font-display text-5xl font-extrabold text-secondary sm:text-6xl",
							children: ["One platform. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary",
								children: "Every payment."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-2xl text-lg text-foreground/70",
							children: "From a quick recharge to a large utility payment — UMOBIPAY helps you serve every customer need with confidence."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: about_team_default,
						alt: "UMOBIPAY service team",
						className: "mx-auto max-h-72 w-full object-contain"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto max-w-7xl px-6 py-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-6 md:grid-cols-2 xl:grid-cols-3",
					children: featured.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: `relative overflow-hidden rounded-[2rem] p-8 ${i % 2 === 0 ? "bg-secondary text-secondary-foreground" : "bg-card border border-border"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `grid h-14 w-14 place-items-center rounded-2xl ${i % 2 === 0 ? "bg-primary text-primary-foreground" : "bg-mint text-secondary"}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.icon, { size: 24 })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: `mt-6 font-display text-2xl font-bold ${i % 2 === 0 ? "" : "text-secondary"}`,
								children: s.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: `mt-3 min-h-20 text-sm leading-7 ${i % 2 === 0 ? "text-secondary-foreground/80" : "text-foreground/70"}`,
								children: s.desc
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6 flex flex-wrap gap-2",
								children: s.tags.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `rounded-full px-3 py-1 text-xs font-medium ${i % 2 === 0 ? "bg-secondary-foreground/10" : "bg-mint text-secondary"}`,
									children: t
								}, t))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								className: `mt-8 inline-flex items-center gap-2 rounded-full px-5 py-3 text-sm font-semibold ${i % 2 === 0 ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"}`,
								children: ["Explore ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 14 })]
							})
						]
					}, s.title))
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto max-w-7xl px-6 pb-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-[2.5rem] border border-border bg-gradient-to-br from-card via-background to-mint/40 p-10 sm:p-16",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-10 lg:grid-cols-[0.95fr_1.05fr] lg:items-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-bold uppercase tracking-widest text-primary",
								children: "Service Coverage"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-4xl font-extrabold text-secondary",
								children: "Cover every bill and payment your customer walks in with."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 max-w-xl text-base leading-8 text-foreground/75",
								children: "From everyday recharges to premium services, the UMOBIPAY stack gives retailers and agents a single, reliable place to serve more customers."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-6 space-y-3 text-sm text-foreground/80",
								children: benefits.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
											size: 16,
											className: "text-primary"
										}),
										" ",
										b
									]
								}, b))
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 gap-4",
							children: categories.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl bg-background/90 p-6 text-center shadow-sm ring-1 ring-border/60",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mx-auto grid h-12 w-12 place-items-center rounded-xl bg-mint text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(m.icon, { size: 22 })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 font-semibold text-secondary",
									children: m.title
								})]
							}, m.title))
						})]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { Services as component };
