import { i as CreateMemberPage } from "./router-B644QERq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/add-2E8Y-jJh.js
var SplitComponent = CreateMemberPage;
//#endregion
export { SplitComponent as component };
