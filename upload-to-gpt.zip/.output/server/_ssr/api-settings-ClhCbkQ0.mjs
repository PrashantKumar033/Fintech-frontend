import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { F as RefreshCw, Zt as Cable, ct as List, fn as Activity, g as ToggleLeft, tn as Bot } from "../_libs/lucide-react.mjs";
import { t as AdminLayout } from "./admin-layout-CMM4oD2x.mjs";
import { t as AdminFeatureGrid } from "./admin-feature-grid-AUC1V-x-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-settings-ClhCbkQ0.js
var import_jsx_runtime = require_jsx_runtime();
function ApiSettings() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "api",
		eyebrow: "Integrations",
		title: "API settings",
		description: "Provider configuration, balances and routing controls are grouped in a dedicated restricted module.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminFeatureGrid, { features: [
			{
				title: "Provider list",
				description: "View configured payment and banking API providers.",
				icon: List
			},
			{
				title: "API balances",
				description: "Monitor provider balances and availability.",
				icon: Activity
			},
			{
				title: "Automatic switching",
				description: "Control provider failover and priority routing.",
				icon: RefreshCw
			},
			{
				title: "Automation",
				description: "Configure automated provider rules and thresholds.",
				icon: Bot
			},
			{
				title: "Add integration",
				description: "Register a new provider integration securely.",
				icon: Cable
			},
			{
				title: "System switches",
				description: "Enable or disable provider routes by service.",
				icon: ToggleLeft
			}
		] })
	});
}
//#endregion
export { ApiSettings as component };
