import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/section-tabs-Bjjhj9AW.js
var import_jsx_runtime = require_jsx_runtime();
function SectionTabs({ tabs }) {
	if (!tabs.length) return null;
	const current = typeof window === "undefined" ? "" : `${window.location.pathname}${window.location.search}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		"aria-label": "Section navigation",
		className: "mb-6 overflow-x-auto rounded-2xl border border-border bg-white p-2 shadow-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex min-w-max items-center gap-1",
			children: tabs.map((tab, index) => {
				const active = current ? current === tab.href || !tab.href.includes("?") && current.split("?")[0] === tab.href : index === 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: tab.href,
					"aria-current": active ? "page" : void 0,
					className: `whitespace-nowrap rounded-xl px-4 py-2.5 text-xs font-extrabold transition sm:text-sm ${active ? "bg-primary text-white shadow-sm" : "text-secondary hover:bg-muted"}`,
					children: tab.label
				}, tab.href);
			})
		})
	});
}
//#endregion
export { SectionTabs as t };
