import { l as MasterDashboard } from "./router-BahmeVh9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/master-distributor-Cx7GIc7Q.js
var SplitComponent = MasterDashboard;
//#endregion
export { SplitComponent as component };
