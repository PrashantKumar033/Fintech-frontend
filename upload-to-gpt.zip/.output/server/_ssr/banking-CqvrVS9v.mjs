import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { r as ServiceState, t as AdminLayout } from "./admin-layout-CMM4oD2x.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/banking-CqvrVS9v.js
var import_jsx_runtime = require_jsx_runtime();
function Banking() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "banking",
		eyebrow: "Bank service",
		title: "Bank operations",
		description: "Bank verification and administration remain isolated from retailer banking screens.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceState, {
			title: "Bank verification queue",
			description: "The current Super Admin gateway does not expose a bank-review endpoint. This module is ready to connect without using retailer APIs or fabricated data.",
			status: "Admin API pending"
		})
	});
}
//#endregion
export { Banking as component };
