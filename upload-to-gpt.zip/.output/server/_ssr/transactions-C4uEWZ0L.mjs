import { r as __toESM } from "../_runtime.mjs";
import { s as getSession } from "./auth-api-CJcoiRrI.mjs";
import { s as signedInHome, t as credentialsPending } from "./role-hierarchy-DL9K6lWq.mjs";
import { i as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { F as RefreshCw, R as Receipt, Rt as Download, k as Search } from "../_libs/lucide-react.mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as ServiceNotice, t as BusinessPage } from "./business-page-CLA-Unc5.mjs";
import { n as operationsApi, r as operationsMessage } from "./operations-api-BInDpxzN.mjs";
import { t as TransactionDetailDialog } from "./transaction-detail-dialog-BeU8Q7Q4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/transactions-C4uEWZ0L.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TransactionsPage() {
	const initialStatus = typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("status") : "";
	const navigate = useNavigate();
	const [session, setSession] = (0, import_react.useState)(null);
	const [page, setPage] = (0, import_react.useState)(null);
	const [status, setStatus] = (0, import_react.useState)(initialStatus);
	const [query, setQuery] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)("");
	const [selectedReference, setSelectedReference] = (0, import_react.useState)(null);
	async function load(token, selectedStatus = status) {
		setLoading(true);
		setError("");
		try {
			setPage(await operationsApi.transactions(token, {
				page: 1,
				limit: 50,
				status: selectedStatus || void 0
			}));
		} catch (e) {
			setError(operationsMessage(e));
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		const value = getSession();
		if (!value) {
			navigate({ to: "/login" });
			return;
		}
		if (credentialsPending(value.identity)) {
			window.location.replace(signedInHome(value));
			return;
		}
		setSession(value);
		load(value.accessToken, initialStatus);
	}, [navigate]);
	const rows = (0, import_react.useMemo)(() => (page?.data ?? []).filter((item) => `${item.referenceId} ${item.provider} ${item.operation} ${item.rrn ?? ""}`.toLowerCase().includes(query.toLowerCase())), [page, query]);
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "animate-spin text-primary" })
	});
	function exportCsv() {
		const csv = ["Reference,Provider,Operation,Amount,Status,RRN,Created", ...rows.map((row) => [
			row.referenceId,
			row.provider,
			row.operation,
			row.amount,
			row.status,
			row.rrn ?? "",
			row.createdAt
		].map((value) => `"${String(value).replaceAll("\"", "\"\"")}"`).join(","))].join("\n");
		const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
		const anchor = document.createElement("a");
		anchor.href = url;
		anchor.download = "umobipay-transactions.csv";
		anchor.click();
		URL.revokeObjectURL(url);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BusinessPage, {
		identity: session.identity,
		active: "transactions",
		eyebrow: "Transaction service",
		title: "Transaction history",
		description: "Track AEPS provider operations, response status, references and reconciliation indicators.",
		children: [
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceNotice, {
					ok: false,
					children: error
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "overflow-hidden rounded-2xl border border-border bg-card shadow-soft",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-3 border-b border-border p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex min-w-56 flex-1 items-center gap-2 rounded-xl border border-border bg-background px-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { size: 16 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: query,
									onChange: (e) => setQuery(e.target.value),
									placeholder: "Search reference, provider or RRN",
									className: "w-full bg-transparent py-3 text-sm outline-none"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: status,
								onChange: (e) => {
									const value = e.target.value;
									setStatus(value);
									load(session.accessToken, value);
								},
								className: "rounded-xl border border-border bg-background px-4 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "",
									children: "All statuses"
								}), [
									"INITIATED",
									"PROCESSING",
									"SUCCESS",
									"FAILED",
									"PENDING",
									"UNKNOWN",
									"REVERSED"
								].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: value }, value))]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: exportCsv,
								disabled: !rows.length,
								className: "flex items-center gap-2 rounded-xl bg-secondary px-4 py-3 text-xs font-bold text-white disabled:opacity-40",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { size: 15 }), " Export"]
							})
						]
					}),
					loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-64 place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "animate-spin text-primary" })
					}) : rows.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[900px] text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
								className: "bg-muted text-[10px] uppercase text-muted-foreground",
								children: [
									"Reference",
									"Service",
									"Provider",
									"Operation",
									"Amount",
									"Status",
									"RRN",
									"Created"
								].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-5 py-3",
									children: h
								}, h))
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t border-border text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setSelectedReference(row.referenceId),
											className: "font-bold text-primary hover:underline",
											children: row.referenceId
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-4",
										children: row.serviceType
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-4",
										children: row.provider
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-4",
										children: operationLabel(row.operation)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "px-5 py-4 font-extrabold",
										children: ["₹", Number(row.amount).toLocaleString("en-IN", { minimumFractionDigits: 2 })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `rounded-full px-2.5 py-1 text-[10px] font-extrabold ${row.status === "SUCCESS" ? "bg-emerald-50 text-emerald-700" : row.status === "FAILED" ? "bg-red-50 text-red-700" : "bg-amber-50 text-amber-700"}`,
											children: row.status
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-4",
										children: row.rrn || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "px-5 py-4",
										children: new Date(row.createdAt).toLocaleString("en-IN")
									})
								]
							}, row.id)) })]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-64 place-items-center text-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "mx-auto text-muted-foreground" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 font-bold text-secondary",
								children: "No transactions found"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "Completed AEPS activity will appear here."
							})
						] })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-border p-4 text-xs text-muted-foreground",
						children: [page?.total ?? 0, " total provider transactions"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransactionDetailDialog, {
				accessToken: session.accessToken,
				referenceId: selectedReference,
				onClose: () => setSelectedReference(null)
			})
		]
	});
}
function operationLabel(value) {
	return {
		BE: "Balance enquiry",
		MS: "Mini statement",
		CW: "Cash withdrawal",
		AP: "Aadhaar Pay",
		CD: "Cash deposit"
	}[value] || value;
}
//#endregion
export { TransactionsPage as component };
