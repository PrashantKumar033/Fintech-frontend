import { i as AdminSettings } from "./router-BahmeVh9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-zIVaMc9M.js
var SplitComponent = AdminSettings;
//#endregion
export { SplitComponent as component };
