import { o as CreateMemberPage } from "./router-BahmeVh9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/add-DeGd-DCf.js
var SplitComponent = CreateMemberPage;
//#endregion
export { SplitComponent as component };
