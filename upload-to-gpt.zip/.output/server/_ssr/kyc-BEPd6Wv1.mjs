import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { r as ServiceState, t as AdminLayout } from "./admin-layout-CMM4oD2x.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kyc-BEPd6Wv1.js
var import_jsx_runtime = require_jsx_runtime();
function Kyc() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "kyc",
		eyebrow: "Compliance",
		title: "KYC approvals",
		description: "A dedicated administration area for compliance review and approval history.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceState, {
			title: "Compliance review queue",
			description: "The current Super Admin gateway does not expose KYC approval routes. The screen is separated and ready for the verified admin contract when available.",
			status: "Admin API pending"
		})
	});
}
//#endregion
export { Kyc as component };
