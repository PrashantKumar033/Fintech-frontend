//#region node_modules/.nitro/vite/services/ssr/assets/role-hierarchy-DL9K6lWq.js
var targets = {
	SUPER_ADMIN: [
		"SUPER_ADMIN",
		"ADMIN",
		"MASTER_DISTRIBUTOR",
		"DISTRIBUTOR",
		"RETAILER"
	],
	ADMIN: [
		"MASTER_DISTRIBUTOR",
		"DISTRIBUTOR",
		"RETAILER"
	],
	MASTER_DISTRIBUTOR: ["DISTRIBUTOR", "RETAILER"],
	DISTRIBUTOR: ["RETAILER"],
	RETAILER: []
};
function normalizeRole(role) {
	const value = role?.trim().toUpperCase().replace(/[ -]+/g, "_");
	return value && value in targets ? value : null;
}
function registrationTargets(role) {
	const normalized = normalizeRole(role);
	return normalized ? targets[normalized] : [];
}
function isManagementRole(role) {
	const normalized = normalizeRole(role);
	return normalized === "ADMIN" || normalized === "MASTER_DISTRIBUTOR" || normalized === "DISTRIBUTOR";
}
function managementBasePath(role) {
	const normalized = normalizeRole(role);
	if (normalized === "MASTER_DISTRIBUTOR") return "/master-distributor";
	if (normalized === "DISTRIBUTOR") return "/distributor";
	return "/admin";
}
function credentialsPending(identity) {
	return Boolean(identity && (!identity.passwordChangedAt || !identity.mpinChangedAt));
}
function identityVerificationPending(session) {
	if (!session || !credentialsPending(session.identity)) return false;
	return !session.identity.phoneNumber || [
		"ADD_AND_VERIFY_PHONE",
		"VERIFY_PHONE_OTP",
		"ADD_PAN"
	].includes(session.nextStep || "");
}
function signedInHome(session) {
	const role = normalizeRole(session.identity.role);
	if (role === "SUPER_ADMIN") return "/admin";
	if (isManagementRole(role)) {
		const base = managementBasePath(role);
		if (credentialsPending(session.identity)) return identityVerificationPending(session) ? `${base}/account-setup` : `${base}/settings`;
		return base;
	}
	if (role === "RETAILER") {
		if (credentialsPending(session.identity)) return identityVerificationPending(session) ? "/retailer/account-setup" : "/retailer/settings";
		return "/retailer/dashboard";
	}
	return "/login";
}
//#endregion
export { normalizeRole as a, managementBasePath as i, identityVerificationPending as n, registrationTargets as o, isManagementRole as r, signedInHome as s, credentialsPending as t };
