import { r as __toESM } from "../_runtime.mjs";
import { a as asArray } from "./admin-api-DhyC5xn6.mjs";
import { i as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { _t as IndianRupee } from "../_libs/lucide-react.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-CMM4oD2x.mjs";
import { t as masterDistributorApi } from "./master-distributor-api-HgOsfLe7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/commission-nmdzNI0v.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const [rows, setRows] = (0, import_react.useState)([]), [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		masterDistributorApi.commissions().then((v) => setRows(asArray(v))).catch((e) => setError(e instanceof Error ? e.message : "Commission unavailable."));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "commissions",
		eyebrow: "Earnings",
		title: "Commission overview",
		description: "Available commission distribution records for the authenticated scope.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndianRupee, { className: "text-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-xs font-bold uppercase text-muted-foreground",
							children: "Distribution records"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-3xl font-black",
							children: rows.length
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-black",
						children: "Earned commission"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "Earnings ledger API pending."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-black",
						children: "Settlement status"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "Commission settlement API pending."
					})] })
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 rounded-xl bg-amber-50 p-3 text-sm text-amber-800",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPanel, {
				className: "mt-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Global commission editing is intentionally unavailable to this role. Only backend-authorized configuration will be displayed."
				})
			})
		]
	});
}
//#endregion
export { Page as component };
