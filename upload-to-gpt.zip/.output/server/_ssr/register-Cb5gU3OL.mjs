import { r as __toESM } from "../_runtime.mjs";
import { l as logo_default, n as authApi } from "./auth-api-CJcoiRrI.mjs";
import { i as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { Bt as Copy, Gt as CircleCheck, P as Rocket, T as ShieldCheck, dn as ArrowLeft, ln as ArrowRight, st as LoaderCircle } from "../_libs/lucide-react.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as SiteNav, t as SiteFooter } from "./site-footer-BVtbrO9E.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/register-Cb5gU3OL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var labels = [
	"Role",
	"Phone",
	"OTP",
	"PAN",
	"Details"
];
var inputClass = "w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-secondary outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20";
var states = [
	"Andhra Pradesh",
	"Assam",
	"Bihar",
	"Delhi",
	"Gujarat",
	"Haryana",
	"Jharkhand",
	"Karnataka",
	"Kerala",
	"Madhya Pradesh",
	"Maharashtra",
	"Odisha",
	"Punjab",
	"Rajasthan",
	"Tamil Nadu",
	"Telangana",
	"Uttar Pradesh",
	"West Bengal"
];
var initialDetails = {
	fullName: "",
	aadhaarNumber: "",
	username: "",
	email: "",
	shopName: "",
	shopAddress: "",
	shopCity: "",
	shopState: "",
	city: "",
	state: "",
	pincode: ""
};
function RegisterPage() {
	const [step, setStep] = (0, import_react.useState)(1);
	const [draftId, setDraftId] = (0, import_react.useState)("");
	const [role, setRole] = (0, import_react.useState)("RETAILER");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [otp, setOtp] = (0, import_react.useState)("");
	const [shownOtp, setShownOtp] = (0, import_react.useState)("");
	const [pan, setPan] = (0, import_react.useState)("");
	const [details, setDetails] = (0, import_react.useState)(initialDetails);
	const [result, setResult] = (0, import_react.useState)();
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const run = async (action) => {
		setError("");
		setLoading(true);
		try {
			await action();
		} catch (e) {
			setError(e instanceof Error ? e.message : "Request failed.");
		} finally {
			setLoading(false);
		}
	};
	const submit = async (e) => {
		e.preventDefault();
		await run(async () => {
			if (step === 1) {
				const r = await authApi.registerRole(role);
				setDraftId(r.draftId);
				setStep(2);
				return;
			}
			if (step === 2) {
				const normalized = phone.replace(/\s/g, "");
				if (!/^(\+91)?[6-9]\d{9}$/.test(normalized)) throw new Error("Enter a valid Indian mobile number.");
				const r = await authApi.registerPhone(draftId, normalized);
				setPhone(normalized);
				setShownOtp(r.otp || "");
				setStep(3);
				return;
			}
			if (step === 3) {
				if (!/^\d{4,6}$/.test(otp)) throw new Error("Enter a valid OTP.");
				await authApi.verifyRegistrationOtp(draftId, phone, otp);
				setStep(4);
				return;
			}
			if (step === 4) {
				const value = pan.trim().toUpperCase();
				if (!/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(value)) throw new Error("Enter a valid PAN, for example ABCDE1234F.");
				await authApi.registerPan(draftId, value);
				setPan(value);
				setStep(5);
				return;
			}
			if (!Object.values(details).every((v) => v.trim())) throw new Error("Please complete all required fields.");
			if (!/^\d{12}$/.test(details.aadhaarNumber)) throw new Error("The Aadhaar number must contain exactly 12 digits.");
			if (!/^\d{6}$/.test(details.pincode)) throw new Error("The PIN code must contain exactly 6 digits.");
			const r = await authApi.registerDetails({
				...details,
				draftId
			});
			setResult(r);
		});
	};
	if (result) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg rounded-[2rem] border border-border bg-card p-8 text-center shadow-elegant sm:p-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
				className: "mx-auto text-accent",
				size: 56
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-4 text-3xl font-extrabold text-secondary",
				children: "Registration complete!"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Store these credentials securely now. They will not be displayed again."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 space-y-3 text-left",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Credential, {
						label: "Login ID",
						value: result.loginId
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Credential, {
						label: "Temporary password",
						value: result.temporaryPassword
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Credential, {
						label: "Temporary MPIN",
						value: result.temporaryMpin
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/login",
				className: "mt-7 flex w-full items-center justify-center gap-2 rounded-xl bg-secondary py-3.5 text-sm font-semibold text-secondary-foreground",
				children: ["Continue to Login ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 16 })]
			})
		]
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid w-full max-w-6xl gap-10 lg:grid-cols-[.75fr_1.25fr] lg:items-start",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "hidden lg:block",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-2 rounded-full border border-primary/20 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-primary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rocket, { size: 13 }), " Backend-connected onboarding"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mt-6 text-5xl font-extrabold leading-tight text-secondary",
					children: [
						"Start with",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-gradient-brand",
							children: "UMOBIPAY"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-foreground/70",
					children: "Each step is securely verified and saved. Please keep this page open until your registration is complete."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "gradient-border rounded-[2rem] bg-card p-7 shadow-elegant sm:p-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: logo_default,
						alt: "UMOBIPAY",
						className: "mb-6 h-10 w-auto"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-7 flex gap-1.5",
					children: labels.map((label, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-1.5 rounded-full ${i + 1 <= step ? "bg-primary" : "bg-muted"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `mt-1 hidden text-[10px] sm:block ${i + 1 === step ? "font-bold text-primary" : "text-muted-foreground"}`,
							children: label
						})]
					}, label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "text-2xl font-extrabold text-secondary",
					children: [labels[step - 1], " verification"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: [
						"Step ",
						step,
						" of 5"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					className: "mt-6 space-y-4",
					children: [
						step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleStep, {
							role,
							setRole
						}),
						" ",
						step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Indian mobile number",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								autoFocus: true,
								value: phone,
								onChange: (e) => setPhone(e.target.value),
								placeholder: "+91 9876543210",
								className: inputClass
							})
						}),
						" ",
						step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "OTP",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								autoFocus: true,
								inputMode: "numeric",
								maxLength: 6,
								value: otp,
								onChange: (e) => setOtp(e.target.value.replace(/\D/g, "")),
								placeholder: "Enter OTP",
								className: `${inputClass} text-center text-xl tracking-[.4em]`
							})
						}), shownOtp && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "rounded-xl bg-amber-50 px-4 py-3 text-sm text-amber-800",
							children: ["Development OTP: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: shownOtp })]
						})] }),
						" ",
						step === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "PAN number",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								autoFocus: true,
								maxLength: 10,
								value: pan,
								onChange: (e) => setPan(e.target.value.toUpperCase()),
								placeholder: "ABCDE1234F",
								className: `${inputClass} uppercase`
							})
						}),
						" ",
						step === 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailsStep, {
							values: details,
							setValues: setDetails
						}),
						" ",
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							role: "alert",
							className: "rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700",
							children: error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3",
							children: [step > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setStep(step - 1),
								className: "rounded-xl border border-border px-4 text-secondary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { size: 17 })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: loading,
								className: "flex flex-1 items-center justify-center gap-2 rounded-xl bg-primary py-3.5 text-sm font-semibold text-white disabled:opacity-60",
								children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
									className: "animate-spin",
									size: 17
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [step === 5 ? "Complete Registration" : "Continue", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 16 })] })
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-5 text-center text-sm text-muted-foreground",
					children: [
						"Already registered?",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							className: "font-semibold text-primary",
							children: "Sign in"
						})
					]
				})
			]
		})]
	}) });
}
function Shell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto flex min-h-[calc(100vh-5rem)] max-w-7xl items-center justify-center px-6 py-16",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-xs font-semibold uppercase tracking-widest text-muted-foreground",
			children: label
		}), children]
	});
}
function RoleStep({ role, setRole }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-3 sm:grid-cols-2",
		children: ["RETAILER", "DISTRIBUTOR"].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => setRole(v),
			className: `rounded-2xl border p-5 text-left ${role === v ? "border-primary bg-primary/5 ring-2 ring-primary/10" : "border-border"}`,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: role === v ? "text-primary" : "text-muted-foreground" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
					className: "mt-3 block text-secondary",
					children: v === "RETAILER" ? "Retailer" : "Distributor"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: v === "RETAILER" ? "Customer services and daily transactions" : "Manage your retailer network"
				})
			]
		}, v))
	});
}
function DetailsStep({ values, setValues }) {
	const update = (key, value) => setValues({
		...values,
		[key]: value
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-4 sm:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Full name",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: values.fullName,
					onChange: (e) => update("fullName", e.target.value),
					className: inputClass
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Username",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: values.username,
					onChange: (e) => update("username", e.target.value),
					className: inputClass
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Email",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "email",
					value: values.email,
					onChange: (e) => update("email", e.target.value),
					className: inputClass
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Aadhaar number",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					inputMode: "numeric",
					maxLength: 12,
					value: values.aadhaarNumber,
					onChange: (e) => update("aadhaarNumber", e.target.value.replace(/\D/g, "")),
					className: inputClass
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Shop name",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: values.shopName,
					onChange: (e) => update("shopName", e.target.value),
					className: inputClass
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Shop address",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: values.shopAddress,
					onChange: (e) => update("shopAddress", e.target.value),
					className: inputClass
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Shop city",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: values.shopCity,
					onChange: (e) => update("shopCity", e.target.value),
					className: inputClass
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Shop state",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: values.shopState,
					onChange: (e) => update("shopState", e.target.value),
					className: inputClass,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Select state"
					}), states.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Residential city",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					value: values.city,
					onChange: (e) => update("city", e.target.value),
					className: inputClass
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Residential state",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: values.state,
					onChange: (e) => update("state", e.target.value),
					className: inputClass,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Select state"
					}), states.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s }, s))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Pincode",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					inputMode: "numeric",
					maxLength: 6,
					value: values.pincode,
					onChange: (e) => update("pincode", e.target.value.replace(/\D/g, "")),
					className: inputClass
				})
			})
		]
	});
}
function Credential({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between rounded-xl border border-border bg-muted p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-xs uppercase text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
			className: "text-secondary",
			children: value
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => navigator.clipboard.writeText(value),
			"aria-label": `Copy ${label}`,
			className: "text-primary",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { size: 17 })
		})]
	});
}
//#endregion
export { RegisterPage as component };
