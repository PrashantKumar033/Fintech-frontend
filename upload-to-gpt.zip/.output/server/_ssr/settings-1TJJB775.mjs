import { i as AdminSettings } from "./router-BahmeVh9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-1TJJB775.js
var SplitComponent = AdminSettings;
//#endregion
export { SplitComponent as component };
