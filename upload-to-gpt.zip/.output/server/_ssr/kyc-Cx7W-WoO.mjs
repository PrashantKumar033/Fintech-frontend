import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { T as ShieldCheck } from "../_libs/lucide-react.mjs";
import { t as MasterDistributorModulePlaceholder } from "./module-placeholder-CYYFwolg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kyc-Cx7W-WoO.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MasterDistributorModulePlaceholder, {
		active: "kyc",
		icon: ShieldCheck,
		title: "Network KYC monitoring",
		description: "Monitor Distributor and downstream Retailer verification status.",
		pending: "A hierarchy-scoped KYC queue is not exposed by the current backend. Approval controls will only be enabled when role authorization is enforced server-side."
	});
}
//#endregion
export { Page as component };
