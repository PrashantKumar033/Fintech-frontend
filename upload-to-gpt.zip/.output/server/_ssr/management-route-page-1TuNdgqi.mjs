import { r as __toESM } from "../_runtime.mjs";
import { s as getSession } from "./auth-api-CJcoiRrI.mjs";
import { a as normalizeRole, s as signedInHome } from "./role-hierarchy-DL9K6lWq.mjs";
import { i as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { d as useLocation } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as Route$52, b as Route$56, d as Profile, f as Route$43, g as Route$51, h as Route$5, i as AdminSettings, m as Route$46, n as AdminDashboard, o as CreateMemberPage, p as Route$44, r as AdminIdentitySetup, t as Access, u as MemberManagementOverview, v as Route$54, x as Transactions, y as Route$55 } from "./router-BahmeVh9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/management-route-page-1TuNdgqi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var fromRoute = (route) => route.options.component;
var pages = {
	"": AdminDashboard,
	profile: Profile,
	merchants: MemberManagementOverview,
	"merchants/add": CreateMemberPage,
	"merchants/list": fromRoute(Route$5),
	transactions: Transactions,
	banking: fromRoute(Route$55),
	kyc: fromRoute(Route$52),
	commissions: fromRoute(Route$54),
	settlements: fromRoute(Route$44),
	access: Access,
	reports: fromRoute(Route$46),
	"api-settings": fromRoute(Route$56),
	settings: AdminSettings,
	legal: fromRoute(Route$51),
	sms: fromRoute(Route$43),
	"account-setup": AdminIdentitySetup
};
function ManagementRoutePage({ role, base }) {
	const pathname = useLocation({ select: (location) => location.pathname });
	const session = getSession();
	const Page = pages[pathname.slice(base.length).replace(/^\/+|\/+$/g, "")] || AdminDashboard;
	(0, import_react.useEffect)(() => {
		if (!session) return window.location.replace("/login");
		if (normalizeRole(session.identity.role) !== role) window.location.replace(signedInHome(session));
	}, [role, session]);
	if (!session || normalizeRole(session.identity.role) !== role) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {});
}
//#endregion
export { ManagementRoutePage as t };
