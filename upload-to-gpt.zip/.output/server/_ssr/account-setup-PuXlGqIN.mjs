import { r as AdminIdentitySetup } from "./router-BahmeVh9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-setup-PuXlGqIN.js
var SplitComponent = AdminIdentitySetup;
//#endregion
export { SplitComponent as component };
