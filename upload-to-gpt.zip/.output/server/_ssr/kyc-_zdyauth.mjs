import { c as KycPage } from "./router-BahmeVh9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kyc-_zdyauth.js
var SplitComponent = KycPage;
//#endregion
export { SplitComponent as component };
