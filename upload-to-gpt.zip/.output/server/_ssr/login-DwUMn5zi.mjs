import { r as __toESM } from "../_runtime.mjs";
import { i as clearSession, l as logo_default } from "./auth-api-CJcoiRrI.mjs";
import { c as getAdminSession, i as adminRequiresDeviceVerification, r as adminAuthApi } from "./admin-api-DhyC5xn6.mjs";
import { i as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { Ft as EyeOff, Pt as Eye, T as ShieldCheck, ln as ArrowRight, ot as LockKeyhole } from "../_libs/lucide-react.mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-DwUMn5zi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminLogin() {
	const navigate = useNavigate();
	const [identifier, setIdentifier] = (0, import_react.useState)("");
	const [loginWith, setLoginWith] = (0, import_react.useState)("PASSWORD");
	const [credential, setCredential] = (0, import_react.useState)("");
	const [show, setShow] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const [challenge, setChallenge] = (0, import_react.useState)(null);
	const [otp, setOtp] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (getAdminSession()) navigate({ to: "/admin" });
	}, [navigate]);
	async function submit(event) {
		event.preventDefault();
		setError("");
		setSubmitting(true);
		try {
			if (loginWith === "MPIN" && !/^\d{4}$/.test(credential)) {
				setError("Enter a valid 4 digit MPIN.");
				return;
			}
			const session = await adminAuthApi.login(identifier.trim(), loginWith, credential);
			if (adminRequiresDeviceVerification(session)) {
				setChallenge(session);
				setOtp("");
				return;
			}
			finishLogin(session);
		} catch (reason) {
			setError(reason instanceof Error ? reason.message : "Sign in failed.");
		} finally {
			setSubmitting(false);
		}
	}
	async function verifyDevice(event) {
		event.preventDefault();
		setError("");
		if (!challenge || !/^\d{6}$/.test(otp)) return setError("Enter the 6-digit verification code.");
		setSubmitting(true);
		try {
			finishLogin(await adminAuthApi.verifyDeviceLogin(challenge.challengeId, otp));
		} catch (reason) {
			setError(reason instanceof Error ? reason.message : "Device verification failed.");
		} finally {
			setSubmitting(false);
		}
	}
	function finishLogin(session) {
		clearSession();
		if (session.onboardingRequired) {
			navigate({ to: "/admin/onboarding" });
			return;
		}
		navigate({ to: "/admin" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "grid min-h-screen bg-[#f1f7f5] lg:grid-cols-[1.05fr_.95fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative hidden overflow-hidden bg-secondary p-14 text-white lg:flex lg:flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-24 -top-20 h-96 w-96 rounded-full bg-primary/25 blur-3xl" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: logo_default,
					alt: "UMOBIPAY",
					className: "relative h-11 w-fit brightness-0 invert"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative my-auto max-w-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-xs font-bold uppercase tracking-[.16em]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 16 }), " Secure operations workspace"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-7 text-5xl font-black leading-tight",
							children: "Control every financial operation from one place."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-lg text-base leading-7 text-white/65",
							children: "Review compliance, monitor bank verification and manage platform operations through a focused command center."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "relative text-xs text-white/40",
					children: "Protected by the dedicated Super Admin authentication service"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "flex items-center justify-center p-6 sm:p-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "lg:hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: logo_default,
							alt: "UMOBIPAY",
							className: "mb-10 h-10"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-14 w-14 place-items-center rounded-2xl bg-secondary text-white shadow-lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockKeyhole, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-7 text-xs font-extrabold uppercase tracking-[.2em] text-primary",
						children: "Administrator access"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 text-3xl font-black text-secondary",
						children: challenge ? "Verify this device" : "Welcome back"
					}),
					challenge ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: challenge.message
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm font-bold text-secondary",
							children: ["Code sent to ", challenge.maskedEmail]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
							onSubmit: verifyDevice,
							className: "mt-8 space-y-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "block text-xs font-extrabold uppercase tracking-wide text-secondary",
									children: ["6-digit verification code", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										autoFocus: true,
										autoComplete: "one-time-code",
										inputMode: "numeric",
										pattern: "[0-9]{6}",
										maxLength: 6,
										value: otp,
										onChange: (e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6)),
										className: "mt-2 w-full rounded-xl border border-border bg-white px-4 py-3.5 text-center text-xl tracking-[.5em] outline-none focus:border-primary"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground",
									children: ["Expires ", new Date(challenge.expiresAt).toLocaleString("en-IN")]
								}),
								error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									role: "alert",
									className: "rounded-xl border border-red-200 bg-red-50 p-3 text-sm font-semibold text-red-700",
									children: error
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									disabled: submitting || otp.length !== 6,
									className: "flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-4 text-sm font-extrabold text-white disabled:opacity-60",
									children: [submitting ? "Verifying..." : "Verify & Sign In", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 17 })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									disabled: submitting,
									onClick: () => {
										setChallenge(null);
										setOtp("");
										setError("");
									},
									className: "w-full rounded-xl border border-border py-3 text-sm font-bold",
									children: "Back to login"
								})
							]
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "Sign in with your Super Admin login ID, username, email or phone number."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: submit,
						className: "mt-8 space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex rounded-xl bg-secondary/5 p-1",
								"aria-label": "Sign-in method",
								children: ["PASSWORD", "MPIN"].map((method) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setLoginWith(method);
										setCredential("");
										setError("");
										setShow(false);
									},
									className: `flex-1 rounded-lg py-2.5 text-sm font-bold transition ${loginWith === method ? "bg-white text-secondary shadow-sm" : "text-muted-foreground hover:text-secondary"}`,
									children: method === "PASSWORD" ? "Password" : "MPIN"
								}, method))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs font-extrabold uppercase tracking-wide text-secondary",
								children: ["Login identifier", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									autoComplete: "username",
									required: true,
									value: identifier,
									onChange: (e) => setIdentifier(e.target.value),
									placeholder: "Login ID, username, email or phone",
									className: "mt-2 w-full rounded-xl border border-border bg-white px-4 py-3.5 text-sm outline-none focus:border-primary"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "block text-xs font-extrabold uppercase tracking-wide text-secondary",
								children: [loginWith === "PASSWORD" ? "Password" : "MPIN", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "relative mt-2 block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: show ? "text" : "password",
										autoComplete: loginWith === "PASSWORD" ? "current-password" : "one-time-code",
										inputMode: loginWith === "MPIN" ? "numeric" : void 0,
										maxLength: loginWith === "MPIN" ? 4 : void 0,
										required: true,
										value: credential,
										onChange: (e) => setCredential(loginWith === "MPIN" ? e.target.value.replace(/\D/g, "") : e.target.value),
										placeholder: loginWith === "PASSWORD" ? "Enter your password" : "Enter 4 digit MPIN",
										className: "w-full rounded-xl border border-border bg-white px-4 py-3.5 pr-12 text-sm outline-none focus:border-primary"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setShow(!show),
										"aria-label": show ? `Hide ${loginWith.toLowerCase()}` : `Show ${loginWith.toLowerCase()}`,
										className: "absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground",
										children: show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 18 })
									})]
								})]
							}),
							error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								role: "alert",
								className: "rounded-xl border border-red-200 bg-red-50 p-3 text-sm font-semibold text-red-700",
								children: error
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								disabled: submitting,
								className: "flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-4 text-sm font-extrabold text-white shadow-lg shadow-primary/20 disabled:opacity-60",
								children: [
									submitting ? "Signing in..." : `Continue with ${loginWith === "PASSWORD" ? "password" : "MPIN"}`,
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 17 })
								]
							})
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-6 text-center text-xs leading-5 text-muted-foreground",
						children: [
							"This portal uses the dedicated ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", { children: "/super-admin/auth" }),
							" backend flow. Retailer credentials will not work here."
						]
					})
				]
			})
		})]
	});
}
//#endregion
export { AdminLogin as component };
