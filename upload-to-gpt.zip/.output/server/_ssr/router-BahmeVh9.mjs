import { n as __exportAll$1, r as __toESM } from "../_runtime.mjs";
import { c as hasPermission, d as refreshSession, h as updateIdentityOnboarding, i as clearSession, l as logo_default, n as authApi, o as getEffectiveAccess, s as getSession, t as ApiError } from "./auth-api-CJcoiRrI.mjs";
import { a as normalizeRole, i as managementBasePath, o as registrationTargets, r as isManagementRole, s as signedInHome, t as credentialsPending } from "./role-hierarchy-DL9K6lWq.mjs";
import { a as asArray, c as getAdminSession, n as adminApi, s as getAdminActor, t as AdminApiError } from "./admin-api-DhyC5xn6.mjs";
import { i as require_jsx_runtime, n as QueryClientProvider, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { $t as Building2, Dt as FingerprintPattern, E as ShieldAlert, F as RefreshCw, Ft as EyeOff, Gt as CircleCheck, Ht as CircleX, J as Network, K as PenLine, M as Save, N as RotateCcw, Ot as FileUp, Pt as Eye, T as ShieldCheck, Ut as CircleUser, V as Plus, Vt as Clock3, W as Phone, Xt as Camera, _t as IndianRupee, a as Wallet, an as BadgeCheck, c as UsersRound, cn as ArrowUpRight, en as Box, fn as Activity, h as Trash2, ht as KeyRound, jt as FileCheckCorner, k as Search, ln as ArrowRight, mt as Landmark, o as WalletCards, ot as LockKeyhole, q as PackageCheck, r as X, rn as Banknote, rt as Mail, s as Users, st as LoaderCircle, u as UserPlus, y as Store } from "../_libs/lucide-react.mjs";
import { n as AdminPanel, r as ServiceState, t as AdminLayout } from "./admin-layout-CMM4oD2x.mjs";
import { t as distributorApi } from "./distributor-api-G-WPYZyn.mjs";
import { t as masterDistributorApi } from "./master-distributor-api-HgOsfLe7.mjs";
import { t as IdentitySecurityCenter } from "./account-security-center-BQH9c_yQ.mjs";
import { _ as createRootRouteWithContext, b as useRouter, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { i as complianceMessage, n as ServiceNotice, r as complianceApi, t as BusinessPage } from "./business-page-CLA-Unc5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/role-aware-account-page-C9buGDRw.js
var import_jsx_runtime = require_jsx_runtime();
function RoleAwareAccountPage({ identity, section, eyebrow, title, description, children }) {
	if (isManagementRole(identity.role)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "profile",
		eyebrow,
		title,
		description,
		children
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BusinessPage, {
		identity,
		active: section,
		eyebrow,
		title,
		description,
		children
	});
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-BahmeVh9.js
var router_BahmeVh9_exports = /* @__PURE__ */ __exportAll$1({
	S: () => AdminDashboard,
	_: () => Route$56,
	a: () => Transactions,
	b: () => DistributorDashboard,
	c: () => AdminSettings,
	d: () => CreateMemberPage,
	f: () => MemberManagementOverview,
	g: () => Route$55,
	getRouter: () => getRouter,
	h: () => Route$54,
	i: () => BankAccountsPage,
	l: () => Route$46,
	m: () => Route$52,
	n: () => Route$5,
	o: () => Route$43,
	p: () => Route$51,
	r: () => KycPage,
	s: () => Route$44,
	t: () => router_exports,
	u: () => Profile,
	v: () => Access,
	x: () => AdminIdentitySetup,
	y: () => MasterDashboard
});
var import_react = /* @__PURE__ */ __toESM(require_react());
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var styles_default = "/assets/styles-B_K-jtUf.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	window.__lovableReportRuntimeError?.({
		message,
		stack: error instanceof Error ? error.stack : void 0,
		filename: window.location.pathname
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$84 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "UMOBIPAY — Simple. Seamless. Secure. Payments." },
			{
				name: "description",
				content: "Fast, secure BBPS payments — mobile recharge, DTH, DMT and utility bills, all in one place."
			},
			{
				name: "author",
				content: "UMOBIPAY"
			},
			{
				property: "og:title",
				content: "UMOBIPAY — Simple. Seamless. Secure."
			},
			{
				property: "og:description",
				content: "Fast, secure BBPS payments — mobile recharge, DTH, DMT and utility bills."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "icon",
				href: "/favicon.ico",
				type: "image/x-icon"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Onest:wght@400;500;600;700;800;900&family=Inter:wght@400;500;600&display=swap"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$84.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
var $$splitComponentImporter$72 = () => import("./routes-DyHVgcOQ.mjs");
var Route$83 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "UMOBIPAY — Pay Smart. Pay Fast. India's fintech for everyday payments" },
		{
			name: "description",
			content: "Recharge, pay bills, and send money instantly with UMOBIPAY — the fintech built for every Indian retailer and consumer."
		},
		{
			property: "og:title",
			content: "UMOBIPAY — Pay Smart. Pay Fast."
		},
		{
			property: "og:description",
			content: "Recharge, bills and money transfer — simple, seamless, secure."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$72, "component")
});
var $$splitComponentImporter$71 = () => import("./about-7t8GdjiU.mjs");
var Route$82 = createFileRoute("/about")({
	head: () => ({ meta: [
		{ title: "About UMOBIPAY — Building India's payment backbone" },
		{
			name: "description",
			content: "UMOBIPAY is on a mission to make digital payments simple and reliable for every Indian retailer and consumer."
		},
		{
			property: "og:title",
			content: "About UMOBIPAY"
		},
		{
			property: "og:description",
			content: "Building India's payment backbone — simple, seamless, secure."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$71, "component")
});
var $$splitComponentImporter$70 = () => import("./activity-C_N0LK_i.mjs");
var Route$81 = createFileRoute("/activity")({
	head: () => ({ meta: [{ title: "Account Activity — UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$70, "component")
});
var $$splitComponentImporter$69 = () => import("./contact-NAh5kzKp.mjs");
var Route$80 = createFileRoute("/contact")({
	head: () => ({ meta: [{ title: "Contact UMOBIPAY — We're here to help" }, {
		name: "description",
		content: "Contact UMOBIPAY for service support, partnerships and retailer onboarding in Cheeka, Haryana."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$69, "component")
});
var $$splitComponentImporter$68 = () => import("./forgot-password-BMqGTqci.mjs");
var Route$79 = createFileRoute("/forgot-password")({
	head: () => ({ meta: [{ title: "Forgot Password — UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$68, "component")
});
var $$splitComponentImporter$67 = () => import("./login-CNE9lqwb.mjs");
var Route$78 = createFileRoute("/login")({
	head: () => ({ meta: [{ title: "Login — UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$67, "component")
});
var $$splitComponentImporter$66 = () => import("./privacy-Dc3lvaej.mjs");
var Route$77 = createFileRoute("/privacy")({
	head: () => ({ meta: [{ title: "Privacy Policy | UMOBIPAY" }, {
		name: "description",
		content: "Learn how UMOBIPAY protects your information and handles personal data with transparency and care."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$66, "component")
});
var $$splitComponentImporter$65 = () => import("./refund-policy-Dry63P5u.mjs");
var Route$76 = createFileRoute("/refund-policy")({
	head: () => ({ meta: [{ title: "Refund Policy | UMOBIPAY" }, {
		name: "description",
		content: "Understand UMOBIPAY's refund and dispute handling process for payments and service issues."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$65, "component")
});
var $$splitComponentImporter$64 = () => import("./register-Cb5gU3OL.mjs");
var Route$75 = createFileRoute("/register")({
	head: () => ({ meta: [{ title: "Register — UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$64, "component")
});
var $$splitComponentImporter$63 = () => import("./services-C2ksQCeV.mjs");
var Route$74 = createFileRoute("/services")({
	head: () => ({ meta: [
		{ title: "Our Services — UMOBIPAY | Recharge, DMT, BBPS & Bills" },
		{
			name: "description",
			content: "Mobile & DTH recharge, domestic money transfer, utility bill collection, BBPS, insurance payments and merchant services under one UMOBIPAY dashboard."
		},
		{
			property: "og:title",
			content: "UMOBIPAY Services"
		},
		{
			property: "og:description",
			content: "Recharge, money transfer, bills, insurance and merchant payments — one platform, every service."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$63, "component")
});
var $$splitComponentImporter$62 = () => import("./terms-BnAI8VML.mjs");
var Route$73 = createFileRoute("/terms")({
	head: () => ({ meta: [{ title: "Terms of Use | UMOBIPAY" }, {
		name: "description",
		content: "Review UMOBIPAY's terms of use for using our platform, services, and customer support."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$62, "component")
});
var Route$72 = createFileRoute("/admin/")({
	head: () => ({ meta: [{ title: "Admin Dashboard — UMOBIPAY" }] }),
	component: AdminDashboard
});
var metrics = [
	{
		label: "Total merchants",
		value: "—",
		detail: "Network-wide accounts",
		icon: Users,
		tone: "bg-blue-50 text-blue-700"
	},
	{
		label: "Today's transactions",
		value: "—",
		detail: "Across all services",
		icon: Activity,
		tone: "bg-emerald-50 text-emerald-700"
	},
	{
		label: "Today's volume",
		value: "₹—",
		detail: "Processed amount",
		icon: IndianRupee,
		tone: "bg-orange-50 text-orange-700"
	},
	{
		label: "Pending reviews",
		value: "—",
		detail: "KYC and bank queues",
		icon: Clock3,
		tone: "bg-amber-50 text-amber-700"
	}
];
var modules = [
	{
		to: "/admin/merchants",
		title: "Merchant network",
		text: "Retailers, distributors and account lifecycle.",
		icon: Building2,
		status: "Manage"
	},
	{
		to: "/admin/transactions",
		title: "Transactions",
		text: "Reconciliation, transaction health and reversals.",
		icon: Banknote,
		status: "Live API"
	},
	{
		to: "/admin/banking",
		title: "Bank operations",
		text: "Bank accounts and verification operations.",
		icon: Landmark,
		status: "Review"
	},
	{
		to: "/admin/kyc",
		title: "KYC approvals",
		text: "Compliance applications and verification status.",
		icon: ShieldCheck,
		status: "Review"
	},
	{
		to: "/admin/settlements",
		title: "Settlements",
		text: "Settlement batches and wallet movement.",
		icon: Wallet,
		status: "Monitor"
	}
];
var bars = [
	38,
	54,
	46,
	68,
	59,
	77,
	65,
	88,
	73,
	92,
	81,
	96
];
function AdminDashboard() {
	const base = managementBasePath(getAdminActor()?.role);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "dashboard",
		eyebrow: "Operations overview",
		title: "Admin dashboard",
		description: "Monitor the platform, review operational queues and open every administration service from one command center.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative overflow-hidden rounded-[28px] bg-[#00645c] p-7 text-white shadow-xl shadow-secondary/10 sm:p-9",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-20 -top-24 h-72 w-72 rounded-full bg-primary/25 blur-3xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex flex-col justify-between gap-7 xl:flex-row xl:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-2xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-xs font-bold text-emerald-200",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { size: 15 }), " Secure admin session active"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-5 text-2xl font-black sm:text-3xl",
								children: "UMOBIPAY operations at a glance"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-6 text-white/65",
								children: "Live totals will populate from summary APIs as they become available. Operational modules and authenticated workflows remain available below."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3 sm:flex",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
								label: "Main wallet",
								value: "₹—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
								label: "AEPS wallet",
								value: "₹—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroStat, {
								label: "Platform status",
								value: "Online"
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
				children: metrics.map(({ label, value, detail, icon: Icon, tone }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
					className: "min-h-44",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `grid h-11 w-11 place-items-center rounded-xl ${tone}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 21 })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-emerald-50 px-2 py-1 text-[10px] font-extrabold text-emerald-700",
								children: "LIVE READY"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-xs font-extrabold uppercase tracking-wide text-muted-foreground",
							children: label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-2xl font-black",
							children: value
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: detail
						})
					]
				}, label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-6 xl:grid-cols-[1.45fr_.75fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-extrabold uppercase tracking-wider text-primary",
							children: "Transaction monitoring"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-xl font-black",
							children: "Processing activity"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: `${base}/transactions`,
							className: "flex items-center gap-1 text-xs font-extrabold text-primary",
							children: ["View transactions ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { size: 15 })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 flex h-52 items-end gap-2 sm:gap-3",
						"aria-label": "Transaction activity chart",
						children: bars.map((height, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "group flex h-full flex-1 items-end",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-full rounded-t-md bg-secondary/15 transition group-hover:bg-primary",
								style: { height: `${height}%` }
							})
						}, index))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex justify-between text-[10px] font-bold uppercase text-muted-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "12 AM" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "6 AM" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "12 PM" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Now" })
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-extrabold uppercase tracking-wider text-primary",
						children: "Action center"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-xl font-black",
						children: "Review queues"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
						size: 18,
						className: "text-muted-foreground"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueueRow, {
							to: `${base}/kyc`,
							icon: ShieldCheck,
							label: "KYC applications",
							value: "Open queue"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueueRow, {
							to: `${base}/banking`,
							icon: Landmark,
							label: "Bank verification",
							value: "Open queue"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueueRow, {
							to: `${base}/transactions`,
							icon: Banknote,
							label: "Reconciliation",
							value: "Live API"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueueRow, {
							to: `${base}/access`,
							icon: Users,
							label: "Roles & permissions",
							value: "Live API"
						})
					]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-4 flex items-end justify-between",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-extrabold uppercase tracking-wider text-primary",
						children: "Administration modules"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-2xl font-black",
						children: "Manage platform services"
					})] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-5",
					children: modules.map(({ to, title, text, icon: Icon, status }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: `${base}${to.slice(6)}`,
						className: "group rounded-2xl border border-border bg-white p-5 shadow-sm transition hover:-translate-y-1 hover:border-primary/50 hover:shadow-lg",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 21 })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
									size: 17,
									className: "text-muted-foreground transition group-hover:text-primary"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-5 font-black group-hover:text-primary",
								children: title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 min-h-10 text-xs leading-5 text-muted-foreground",
								children: text
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-[10px] font-extrabold uppercase tracking-wider text-primary",
								children: status
							})
						]
					}, to))
				})]
			})
		]
	});
}
function HeroStat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-32 rounded-2xl border border-white/10 bg-white/10 px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] font-bold uppercase tracking-wide text-white/55",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-lg font-black",
			children: value
		})]
	});
}
function QueueRow({ to, icon: Icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: "flex items-center gap-3 rounded-xl border border-border p-3 transition hover:border-primary/40 hover:bg-primary/[.03]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-9 w-9 place-items-center rounded-lg bg-secondary/5 text-secondary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 17 })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "min-w-0 flex-1 text-sm font-bold",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-[10px] font-extrabold uppercase text-primary",
				children: value
			})
		]
	});
}
var Route$71 = createFileRoute("/admin/account-setup")({
	head: () => ({ meta: [{ title: "Verify admin identity — UMOBIPAY" }] }),
	component: AdminIdentitySetup
});
var inputClass$5 = "w-full rounded-xl border border-border bg-white px-4 py-3.5 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/15";
function AdminIdentitySetup() {
	const session = getSession();
	const role = normalizeRole(session?.identity.role);
	const isRetailer = role === "RETAILER";
	const managementBase = managementBasePath(role);
	const settingsPath = isRetailer ? "/retailer/settings" : `${managementBase}/settings`;
	const homePath = isRetailer ? "/retailer/dashboard" : managementBase;
	const [otpRequested, setOtpRequested] = (0, import_react.useState)(session?.nextStep === "VERIFY_PHONE_OTP");
	const [panOnly, setPanOnly] = (0, import_react.useState)(session?.nextStep === "ADD_PAN");
	const [phoneNumber, setPhoneNumber] = (0, import_react.useState)(session?.identity.phoneNumber || "");
	const [panNumber, setPanNumber] = (0, import_react.useState)(() => typeof window === "undefined" ? "" : sessionStorage.getItem("admin_setup_pan") || "");
	const [otp, setOtp] = (0, import_react.useState)("");
	const [developmentOtp, setDevelopmentOtp] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const current = getSession();
		const currentRole = normalizeRole(current?.identity.role);
		if (!current || !isManagementRole(currentRole) && currentRole !== "RETAILER") return window.location.replace("/login");
		if (current.identity.passwordChangedAt && current.identity.mpinChangedAt) return window.location.replace(homePath);
		if (["CHANGE_PASSWORD", "CHANGE_MPIN"].includes(current.nextStep || "")) window.location.replace(settingsPath);
	}, []);
	async function submit(event) {
		event.preventDefault();
		setError("");
		setMessage("");
		const phone = phoneNumber.replace(/\s/g, "");
		if (!otpRequested) {
			if (panOnly) {
				if (!/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(panNumber)) return setError("Enter a valid PAN in the format ABCDE1234F.");
			} else {
				if (!/^(?:\+91)?[6-9]\d{9}$/.test(phone)) return setError("Enter a valid Indian mobile number, for example +919876543210.");
				if (!/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(panNumber)) return setError("Enter a valid PAN in the format ABCDE1234F.");
			}
		} else if (!/^\d{6}$/.test(otp)) return setError("Enter the 6-digit OTP sent to your mobile number.");
		setLoading(true);
		try {
			if (panOnly) {
				const pan = await authApi.addIdentityOnboardingPan(panNumber);
				updateIdentityOnboarding("CHANGE_PASSWORD", pan.onboardingStatus);
				sessionStorage.removeItem("admin_setup_pan");
				window.location.replace(settingsPath);
			} else if (!otpRequested) {
				const result = await authApi.sendIdentityOnboardingPhoneOtp(phone);
				sessionStorage.setItem("admin_setup_pan", panNumber);
				setDevelopmentOtp(result.otp || "");
				setMessage(result.message);
				setOtpRequested(true);
				updateIdentityOnboarding("VERIFY_PHONE_OTP", result.onboardingStatus);
			} else {
				const verified = await authApi.verifyIdentityOnboardingPhoneOtp(otp);
				updateIdentityOnboarding("ADD_PAN", verified.onboardingStatus);
				setPanOnly(true);
				setOtpRequested(false);
				const pan = await authApi.addIdentityOnboardingPan(panNumber);
				updateIdentityOnboarding("CHANGE_PASSWORD", pan.onboardingStatus);
				sessionStorage.removeItem("admin_setup_pan");
				window.location.replace(settingsPath);
			}
		} catch (caught) {
			const text = caught instanceof Error ? caught.message : "Identity verification could not be completed.";
			if (!otpRequested && !panOnly && /phone number has already been verified/i.test(text)) {
				setPanOnly(true);
				updateIdentityOnboarding("ADD_PAN", "PAN_PENDING");
				try {
					const pan = await authApi.addIdentityOnboardingPan(panNumber);
					updateIdentityOnboarding("CHANGE_PASSWORD", pan.onboardingStatus);
					sessionStorage.removeItem("admin_setup_pan");
					window.location.replace(settingsPath);
				} catch (panError) {
					const panText = panError instanceof Error ? panError.message : "PAN could not be added.";
					if (/PAN onboarding is not currently available/i.test(panText)) {
						updateIdentityOnboarding("CHANGE_PASSWORD", "CREDENTIAL_CHANGE_REQUIRED");
						window.location.replace(settingsPath);
					} else {
						setError(panText);
						setMessage("Your phone number is already verified. Correct or confirm PAN to continue.");
					}
				}
			} else setError(text);
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-screen bg-[#f3f8f6] px-4 py-6 text-secondary sm:px-6 sm:py-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: logo_default,
					alt: "UMOBIPAY",
					className: "h-10 w-auto"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						clearSession();
						window.location.assign("/login");
					},
					className: "text-xs font-bold text-muted-foreground",
					children: "Sign out"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 grid overflow-hidden rounded-[30px] border border-border bg-white shadow-xl shadow-secondary/5 lg:grid-cols-[.8fr_1.2fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "bg-[#00645c] p-8 text-white sm:p-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "inline-flex rounded-full bg-white/10 px-3 py-1 text-[10px] font-extrabold uppercase tracking-[.18em] text-emerald-200",
							children: "First login verification"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-5 text-3xl font-black leading-tight",
							children: "Verify your admin identity"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-6 text-white/65",
							children: "Phone number, PAN and OTP are handled together on this single verification page. After completion, security setup continues in Admin Settings."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex items-center gap-3 rounded-2xl bg-white/10 p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-10 w-10 place-items-center rounded-xl bg-emerald-300 text-secondary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { size: 20 })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-extrabold",
								children: "Identity verification"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-0.5 text-xs text-white/55",
								children: "One required setup stage"
							})] })]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "p-8 sm:p-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary",
							children: otpRequested ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 21 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { size: 21 })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-extrabold uppercase tracking-wider text-primary",
							children: "Identity verification"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl font-black",
							children: otpRequested ? "Enter mobile OTP" : "Phone number and PAN"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: submit,
						className: "mt-7 space-y-4",
						children: [
							panOnly ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rounded-xl bg-amber-50 p-3 text-xs text-amber-800",
								children: "Phone OTP is verified. Correct or confirm PAN to continue."
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field$2, {
								label: "PAN number",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									autoFocus: true,
									value: panNumber,
									onChange: (e) => setPanNumber(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 10)),
									placeholder: "ABCDE1234F",
									className: `${inputClass$5} uppercase`
								})
							})] }) : !otpRequested ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field$2, {
								label: "Mobile number",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									autoFocus: true,
									value: phoneNumber,
									onChange: (e) => setPhoneNumber(e.target.value),
									placeholder: "+919876543210",
									inputMode: "tel",
									autoComplete: "tel",
									className: inputClass$5
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field$2, {
								label: "PAN number",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: panNumber,
									onChange: (e) => setPanNumber(e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 10)),
									placeholder: "ABCDE1234F",
									className: `${inputClass$5} uppercase`
								})
							})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								developmentOtp && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-amber-200 bg-amber-50 px-4 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] font-extrabold uppercase tracking-wider text-amber-700",
										children: "Development OTP"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-2xl font-black tracking-[.3em] text-amber-900",
										children: developmentOtp
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field$2, {
									label: "6-digit OTP",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										autoFocus: true,
										value: otp,
										onChange: (e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6)),
										placeholder: "000000",
										inputMode: "numeric",
										autoComplete: "one-time-code",
										className: `${inputClass$5} text-center text-xl tracking-[.35em]`
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl bg-muted px-4 py-3 text-xs text-muted-foreground",
									children: [
										"Phone: ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: phoneNumber }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
										"PAN: ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: panNumber || "Entered PAN" })
									]
								})
							] }),
							message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								role: "status",
								className: "rounded-xl bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-700",
								children: message
							}),
							error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								role: "alert",
								className: "rounded-xl bg-red-50 px-4 py-3 text-sm font-medium text-red-700",
								children: error
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: loading,
								className: "flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3.5 text-sm font-extrabold text-white disabled:opacity-60",
								children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
									className: "animate-spin",
									size: 17
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [panOnly ? "Save PAN & open Settings" : otpRequested ? "Verify & open Settings" : "Send OTP", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 17 })] })
							})
						]
					})]
				})]
			})]
		})
	});
}
function Field$2({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-xs font-extrabold uppercase tracking-wider text-muted-foreground",
			children: label
		}), children]
	});
}
var $$splitComponentImporter$61 = () => import("./login-DwUMn5zi.mjs");
var Route$70 = createFileRoute("/admin/login")({
	head: () => ({ meta: [{ title: "Admin sign in — UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$61, "component")
});
var $$splitComponentImporter$60 = () => import("./onboarding-DD69twMN.mjs");
var Route$69 = createFileRoute("/admin/onboarding")({ component: lazyRouteComponent($$splitComponentImporter$60, "component") });
var $$splitComponentImporter$59 = () => import("./distributor-CNpxf6Xl.mjs");
var Route$68 = createFileRoute("/distributor/")({
	head: () => ({ meta: [{ title: "Distributor Dashboard — UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$59, "component")
});
var $$splitComponentImporter$58 = () => import("../_-CW9St9SX.mjs");
var Route$67 = createFileRoute("/distributor/$")({ component: lazyRouteComponent($$splitComponentImporter$58, "component") });
var $$splitComponentImporter$57 = () => import("./account-setup-PuXlGqIN.mjs");
var Route$66 = createFileRoute("/distributor/account-setup")({ component: lazyRouteComponent($$splitComponentImporter$57, "component") });
var Route$65 = createFileRoute("/distributor/dashboard")({ component: DistributorDashboard });
function DistributorDashboard() {
	const session = getSession();
	const [balances, setBalances] = (0, import_react.useState)(null);
	const [transactions, setTransactions] = (0, import_react.useState)(null);
	const [retailers, setRetailers] = (0, import_react.useState)([]);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!session) return;
		Promise.allSettled([
			distributorApi.balances(session.identity.id),
			distributorApi.transactions("page=1&limit=50"),
			distributorApi.retailers(session.identity.id)
		]).then(([walletResult, transactionResult, retailerResult]) => {
			if (walletResult.status === "fulfilled") setBalances(walletResult.value);
			if (transactionResult.status === "fulfilled") setTransactions(transactionResult.value);
			if (retailerResult.status === "fulfilled") setRetailers(Array.isArray(retailerResult.value) ? retailerResult.value : []);
			if ([
				walletResult,
				transactionResult,
				retailerResult
			].every((result) => result.status === "rejected")) setError("Live distributor summaries are temporarily unavailable.");
		});
	}, [session?.identity.id]);
	const rows = transactions?.data || [];
	const successful = rows.filter((row) => row.status === "SUCCESS");
	const volume = successful.reduce((sum, row) => sum + Number(row.amount || 0), 0);
	const cards = [
		[
			"Total retailers",
			String(retailers.length),
			"Hierarchy API",
			Store
		],
		[
			"Transactions",
			String(transactions?.total ?? rows.length),
			`${successful.length} successful`,
			Activity
		],
		[
			"Business volume",
			`₹${volume.toLocaleString("en-IN")}`,
			"Successful transactions",
			IndianRupee
		],
		[
			"Wallet balance",
			`₹${Number(balances?.wallets.main || 0).toLocaleString("en-IN")}`,
			`Profit ₹${Number(balances?.wallets.profit || 0).toLocaleString("en-IN")}`,
			Wallet
		]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "dashboard",
		eyebrow: "Distributor network",
		title: "Distributor dashboard",
		description: "Retailer network, transaction and wallet summaries from available backend services.",
		children: [
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-5 rounded-xl bg-amber-50 p-4 text-sm text-amber-800",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
				children: cards.map(([label, value, detail, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "text-primary" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-xs font-bold uppercase text-muted-foreground",
						children: label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-2xl font-black",
						children: value
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: detail
					})
				] }, label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
				className: "mt-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-black",
					children: "Recent AEPS activity"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 overflow-x-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[650px] text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Reference"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Service"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Amount"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Date"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.slice(0, 8).map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border/60",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3 font-bold",
									children: row.referenceId
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3",
									children: row.operation
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "p-3",
									children: ["₹", Number(row.amount).toLocaleString("en-IN")]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3 font-bold",
									children: row.status
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3",
									children: new Date(row.createdAt).toLocaleDateString("en-IN")
								})
							]
						}, row.id)) })]
					}), !rows.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-10 text-center text-sm text-muted-foreground",
						children: "No transaction records returned yet."
					})]
				})]
			})
		]
	});
}
var $$splitComponentImporter$56 = () => import("./master-distributor-Cx7GIc7Q.mjs");
var Route$64 = createFileRoute("/master-distributor/")({
	head: () => ({ meta: [{ title: "Master Distributor Dashboard — UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$56, "component")
});
var $$splitComponentImporter$55 = () => import("../_-DkqG3g_Y.mjs");
var Route$63 = createFileRoute("/master-distributor/$")({ component: lazyRouteComponent($$splitComponentImporter$55, "component") });
var $$splitComponentImporter$54 = () => import("./account-setup-D0Ycony6.mjs");
var Route$62 = createFileRoute("/master-distributor/account-setup")({ component: lazyRouteComponent($$splitComponentImporter$54, "component") });
var Route$61 = createFileRoute("/master-distributor/dashboard")({ component: MasterDashboard });
function MasterDashboard() {
	const s = getSession(), [wallet, setWallet] = (0, import_react.useState)(null), [children, setChildren] = (0, import_react.useState)([]), [tx, setTx] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!s) return;
		Promise.allSettled([
			masterDistributorApi.balances(s.identity.id),
			masterDistributorApi.distributors(s.identity.id),
			masterDistributorApi.transactions()
		]).then(([a, b, c]) => {
			if (a.status === "fulfilled") setWallet(a.value);
			if (b.status === "fulfilled") setChildren(Array.isArray(b.value) ? b.value : []);
			if (c.status === "fulfilled") setTx(c.value);
		});
	}, [s?.identity.id]);
	const success = (tx?.data || []).filter((x) => x.status === "SUCCESS"), volume = success.reduce((n, x) => n + Number(x.amount || 0), 0);
	const cards = [
		[
			"Total distributors",
			children.length,
			"Direct hierarchy",
			Network
		],
		[
			"Transactions",
			tx?.total || 0,
			`${success.length} successful`,
			Activity
		],
		[
			"Business volume",
			`₹${volume.toLocaleString("en-IN")}`,
			"Available transaction scope",
			IndianRupee
		],
		[
			"Wallet balance",
			`₹${Number(wallet?.wallets.main || 0).toLocaleString("en-IN")}`,
			`Profit ₹${Number(wallet?.wallets.profit || 0).toLocaleString("en-IN")}`,
			Wallet
		]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "dashboard",
		eyebrow: "Network command center",
		title: "Master Distributor dashboard",
		description: "Manage Distributor hierarchy and monitor available wallet and transaction services.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
			children: cards.map(([l, v, d, I]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(I, { className: "text-primary" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-xs font-bold uppercase text-muted-foreground",
					children: l
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-2xl font-black",
					children: v
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: d
				})
			] }, l))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-black",
				children: "Network visibility"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: "Direct Distributor hierarchy is live. Recursive Retailer totals and downstream business summaries will populate after scoped backend aggregation endpoints are available."
			})]
		})]
	});
}
var $$splitComponentImporter$53 = () => import("./account-setup-D2ixwIM7.mjs");
var Route$60 = createFileRoute("/retailer/account-setup")({
	head: () => ({ meta: [{ title: "Verify identity — UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$53, "component")
});
var $$splitComponentImporter$52 = () => import("./dashboard-CcPCAwCX.mjs");
var Route$59 = createFileRoute("/retailer/dashboard")({
	head: () => ({ meta: [{ title: "Business Dashboard — UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$52, "component")
});
var $$splitComponentImporter$51 = () => import("./settings-BoQTNlsh.mjs");
var Route$58 = createFileRoute("/retailer/settings")({
	head: () => ({ meta: [{ title: "Settings & preferences — UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$51, "component")
});
var Route$57 = createFileRoute("/admin/access/")({ component: Access });
var inputClass$4 = "w-full rounded-xl border border-border bg-white px-3.5 py-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/15";
var errText = (error) => error instanceof Error ? error.message : "The request could not be completed.";
function Access() {
	const canManageAccess = getAdminActor()?.kind === "SUPER_ADMIN";
	const [view, setView] = (0, import_react.useState)("roles"), [roles, setRoles] = (0, import_react.useState)([]), [permissions, setPermissions] = (0, import_react.useState)([]), [packages, setPackages] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true), [busy, setBusy] = (0, import_react.useState)(false), [error, setError] = (0, import_react.useState)(""), [notice, setNotice] = (0, import_react.useState)("");
	async function load(showLoader = true) {
		if (!canManageAccess) {
			setLoading(false);
			return;
		}
		if (showLoader) setLoading(true);
		setError("");
		try {
			const [r, p, k] = await Promise.all([
				adminApi.roles.list(),
				adminApi.permissions.list(),
				adminApi.packages.list()
			]);
			setRoles(asArray(r));
			setPermissions(asArray(p));
			setPackages(asArray(k));
		} catch (e) {
			setError(errText(e));
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		load();
	}, [canManageAccess]);
	async function mutate(work, message, options = {}) {
		setBusy(true);
		setError("");
		setNotice("");
		try {
			await work();
			options.onSuccess?.();
			setNotice(message);
			if (options.refresh !== false) await load(false);
		} catch (e) {
			setError(errText(e));
		} finally {
			setBusy(false);
		}
	}
	const tabs = [
		[
			"roles",
			"Roles",
			UsersRound
		],
		[
			"permissions",
			"Permissions",
			KeyRound
		],
		[
			"packages",
			"Packages",
			Box
		],
		[
			"role-packages",
			"Assignments",
			PackageCheck
		],
		[
			"registration",
			"Registration matrix",
			ShieldCheck
		]
	];
	if (!canManageAccess) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "access",
		eyebrow: "Authorization control",
		title: "Roles, packages & permissions",
		description: "Authorization policy is managed centrally by the Super Admin.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-xl py-14 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-amber-50 text-amber-700",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-5 text-xl font-black",
					children: "Super Admin approval required"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-6 text-muted-foreground",
					children: "The current backend protects role and role-assignment endpoints with the Super Admin guard. This screen is therefore read-protected for Admin identities instead of making requests that would return 401 Unauthorized."
				})
			]
		}) })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "access",
		eyebrow: "Authorization control",
		title: "Roles, packages & permissions",
		description: "Manage the complete authorization graph from separate, auditable backend contracts.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex gap-2 overflow-x-auto rounded-2xl border border-border bg-white p-2",
				children: [tabs.map(([id, label, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setView(id),
					className: `inline-flex shrink-0 items-center gap-2 rounded-xl px-4 py-3 text-xs font-extrabold ${view === id ? "bg-secondary text-white" : "text-muted-foreground hover:bg-muted"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 15 }), label]
				}, id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => void load(),
					disabled: loading,
					className: "ml-auto inline-flex shrink-0 items-center gap-2 rounded-xl border border-border px-4 py-3 text-xs font-extrabold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
						size: 14,
						className: loading ? "animate-spin" : ""
					}), "Refresh"]
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mb-5 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700",
				children: error
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-5 rounded-xl bg-emerald-50 p-3 text-sm font-semibold text-emerald-700",
				children: notice
			}),
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-center gap-2 py-16 text-sm text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
					className: "animate-spin",
					size: 17
				}), "Loading authorization graph…"]
			}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				view === "roles" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityManager, {
					kind: "role",
					items: roles,
					busy,
					mutate,
					onStatusChange: (id, isActive) => setRoles((current) => current.map((item) => item.id === id ? {
						...item,
						isActive
					} : item))
				}),
				view === "permissions" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EntityManager, {
					kind: "permission",
					items: permissions,
					busy,
					mutate,
					onStatusChange: (id, isActive) => setPermissions((current) => current.map((item) => item.id === id ? {
						...item,
						isActive
					} : item))
				}),
				view === "packages" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PackageManager, {
					packages,
					permissions,
					busy,
					mutate,
					onStatusChange: (id, isActive) => setPackages((current) => current.map((item) => item.id === id ? {
						...item,
						isActive
					} : item))
				}),
				view === "role-packages" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RolePackageManager, {
					roles,
					packages,
					busy,
					mutate
				}),
				view === "registration" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RegistrationMatrix, {
					roles,
					busy,
					mutate
				})
			] })
		]
	});
}
function EntityManager({ kind, items, busy, mutate, onStatusChange }) {
	const [editing, setEditing] = (0, import_react.useState)(null), [name, setName] = (0, import_react.useState)(""), [code, setCode] = (0, import_react.useState)(""), [prefix, setPrefix] = (0, import_react.useState)(""), [description, setDescription] = (0, import_react.useState)("");
	function reset(item) {
		setEditing(item || null);
		setName(item?.name || "");
		setCode(item?.code || "");
		setPrefix(item?.prefix || "");
		setDescription(item?.description || "");
	}
	async function submit(e) {
		e.preventDefault();
		const api = kind === "role" ? adminApi.roles : adminApi.permissions;
		if (kind === "role") {
			const body = {
				name: name.trim().toUpperCase().replace(/\s+/g, "_"),
				prefix: prefix.trim().toUpperCase(),
				description: description.trim() || void 0,
				...!editing ? {
					startingLoginIdNumber: 1001,
					isActive: true
				} : {}
			};
			await mutate(() => editing ? api.update(editing.id, body) : api.create(body), `Role ${editing ? "updated" : "created"}.`);
		} else {
			const body = {
				code: code.trim().toUpperCase(),
				name: name.trim(),
				description: description.trim() || void 0,
				...!editing ? { isActive: true } : {}
			};
			await mutate(() => editing ? api.update(editing.id, body) : api.create(body), `Permission ${editing ? "updated" : "created"}.`);
		}
		reset();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 xl:grid-cols-[380px_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "text-lg font-black",
			children: [
				editing ? "Edit" : "Create",
				" ",
				kind
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "mt-5 space-y-4",
			children: [
				kind === "permission" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field$1, {
					label: "Permission code",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						pattern: "[A-Z][A-Z0-9_]*(\\.[A-Z][A-Z0-9_]*)+",
						value: code,
						onChange: (e) => setCode(e.target.value.toUpperCase()),
						placeholder: "WALLET.VIEW",
						className: inputClass$4
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field$1, {
					label: kind === "role" ? "Role name" : "Display name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: name,
						onChange: (e) => setName(e.target.value),
						placeholder: kind === "role" ? "DISTRIBUTOR" : "View wallet",
						className: inputClass$4
					})
				}),
				kind === "role" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field$1, {
					label: "Login ID prefix",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						maxLength: 10,
						pattern: "[A-Z0-9]+",
						value: prefix,
						onChange: (e) => setPrefix(e.target.value.toUpperCase()),
						placeholder: "DS",
						className: inputClass$4
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field$1, {
					label: "Description",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: description,
						onChange: (e) => setDescription(e.target.value),
						rows: 3,
						className: `${inputClass$4} resize-none`
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						disabled: busy,
						className: "inline-flex flex-1 items-center justify-center gap-2 rounded-xl bg-primary py-3 text-xs font-extrabold text-white",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { size: 14 }), editing ? "Save changes" : "Create"]
					}), editing && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => reset(),
						className: "rounded-xl border border-border px-4 text-xs font-extrabold",
						children: "Cancel"
					})]
				})
			]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
			className: "text-lg font-black",
			children: [
				"Configured ",
				kind,
				"s"
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-5 space-y-3",
			children: [items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 rounded-xl border border-border p-4 sm:flex-row sm:items-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-black",
								children: item.code || item.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status$2, { active: item.isActive })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: [item.name, item.prefix ? ` · Prefix ${item.prefix}` : ""]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => reset(item),
						className: "rounded-lg border border-border px-3 py-2 text-xs font-bold",
						children: "Edit"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: busy,
						onClick: () => void mutate(() => kind === "role" ? adminApi.roles.status(item.id, !item.isActive) : adminApi.permissions.status(item.id, !item.isActive), `${item.name} ${item.isActive ? "deactivated" : "activated"}.`, {
							refresh: false,
							onSuccess: () => onStatusChange(item.id, !item.isActive)
						}),
						className: `rounded-lg border px-3 py-2 text-xs font-bold ${item.isActive ? "border-amber-200 text-amber-800" : "border-emerald-200 text-emerald-700"}`,
						children: item.isActive ? "Deactivate" : "Activate"
					})
				]
			}, item.id)), !items.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: `No ${kind}s returned.` })]
		})] })]
	});
}
function PackageManager({ packages, permissions, busy, mutate, onStatusChange }) {
	const [selected, setSelected] = (0, import_react.useState)(""), [assigned, setAssigned] = (0, import_react.useState)([]), [name, setName] = (0, import_react.useState)(""), [code, setCode] = (0, import_react.useState)(""), [description, setDescription] = (0, import_react.useState)(""), [price, setPrice] = (0, import_react.useState)("0"), [loading, setLoading] = (0, import_react.useState)(false);
	async function select(id) {
		setSelected(id);
		setLoading(true);
		try {
			setAssigned(await adminApi.packages.permissions(id));
		} finally {
			setLoading(false);
		}
	}
	async function create(e) {
		e.preventDefault();
		await mutate(() => adminApi.packages.create({
			code: code.trim().toUpperCase(),
			name: name.trim(),
			description: description.trim() || void 0,
			price,
			isActive: true
		}), "Package created.");
		setName("");
		setCode("");
		setDescription("");
		setPrice("0");
	}
	const assignedIds = new Set(assigned.map((v) => v.permissionId));
	const selectedPackage = packages.find((v) => v.id === selected);
	async function editSelected() {
		if (!selectedPackage) return;
		const nextName = window.prompt("Package name", selectedPackage.name || "");
		if (nextName === null || !nextName.trim()) return;
		const nextDescription = window.prompt("Package description", selectedPackage.description || "");
		if (nextDescription === null) return;
		await mutate(() => adminApi.packages.update(selectedPackage.id, {
			name: nextName.trim(),
			description: nextDescription.trim() || void 0
		}), "Package updated.");
	}
	async function toggleStatus() {
		if (!selectedPackage) return;
		await mutate(() => adminApi.packages.status(selectedPackage.id, !selectedPackage.isActive), `Package ${selectedPackage.isActive ? "deactivated" : "activated"}.`, {
			refresh: false,
			onSuccess: () => onStatusChange(selectedPackage.id, !selectedPackage.isActive)
		});
	}
	async function toggle(permission) {
		if (!selected) return;
		const isAssigned = assignedIds.has(permission.id);
		await mutate(() => isAssigned ? adminApi.packages.removePermission(selected, permission.id) : adminApi.packages.assignPermission(selected, permission.id), "Package permissions updated.", {
			refresh: false,
			onSuccess: () => setAssigned((current) => isAssigned ? current.filter((entry) => entry.permissionId !== permission.id) : [...current, {
				packageId: selected,
				permissionId: permission.id,
				permission
			}])
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 xl:grid-cols-[380px_1fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-lg font-black",
			children: "Create package"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: create,
			className: "mt-5 space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field$1, {
					label: "Code",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: code,
						onChange: (e) => setCode(e.target.value.toUpperCase()),
						pattern: "[A-Z][A-Z0-9_]*",
						placeholder: "RETAILER_CORE",
						className: inputClass$4
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field$1, {
					label: "Name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: name,
						onChange: (e) => setName(e.target.value),
						className: inputClass$4
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field$1, {
					label: "Price",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						min: "0",
						step: "0.01",
						type: "number",
						value: price,
						onChange: (e) => setPrice(e.target.value),
						className: inputClass$4
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field$1, {
					label: "Description",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
						value: description,
						onChange: (e) => setDescription(e.target.value),
						rows: 3,
						className: `${inputClass$4} resize-none`
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					disabled: busy,
					className: "inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-xs font-extrabold text-white",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), "Create package"]
				})
			]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-black",
				children: "Package → permission assignment"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Select a package, then enable only the permissions it should grant."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
				value: selected,
				onChange: (e) => void select(e.target.value),
				className: `${inputClass$4} mt-5`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: "",
					children: "Select package"
				}), packages.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
					value: v.id,
					children: [v.code || v.name, v.isActive ? "" : " (inactive)"]
				}, v.id))]
			}),
			selectedPackage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy,
					onClick: () => void editSelected(),
					className: "rounded-lg border border-border px-3 py-2 text-xs font-bold",
					children: "Edit package"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy,
					onClick: () => void toggleStatus(),
					className: "rounded-lg border border-border px-3 py-2 text-xs font-bold",
					children: selectedPackage.isActive ? "Deactivate" : "Activate"
				})]
			}),
			selected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 max-h-[520px] space-y-2 overflow-y-auto pr-1",
				children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "Loading assignments…" }) : permissions.map((permission) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex cursor-pointer items-center gap-3 rounded-xl border border-border p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: assignedIds.has(permission.id),
							disabled: busy,
							onChange: () => void toggle(permission),
							className: "h-4 w-4 accent-primary"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "break-all text-xs font-black",
								children: permission.code
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: permission.name
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status$2, { active: permission.isActive })
					]
				}, permission.id))
			}),
			" ",
			!selected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "Select a package to manage its permissions." })
		] })]
	});
}
function RolePackageManager({ roles, packages, busy, mutate }) {
	const [roleId, setRoleId] = (0, import_react.useState)(""), [assigned, setAssigned] = (0, import_react.useState)([]), [effective, setEffective] = (0, import_react.useState)(null), [loading, setLoading] = (0, import_react.useState)(false);
	async function select(id) {
		setRoleId(id);
		setEffective(null);
		setLoading(true);
		try {
			setAssigned(await adminApi.roles.packages(id));
			setEffective(await adminApi.roles.effectivePermissions(id));
		} finally {
			setLoading(false);
		}
	}
	const assignedIds = new Set(assigned.map((v) => v.packageId));
	async function toggle(item) {
		const isAssigned = assignedIds.has(item.id);
		await mutate(() => isAssigned ? adminApi.roles.removePackage(roleId, item.id) : adminApi.roles.assignPackage(roleId, item.id), "Role packages updated.", {
			refresh: false,
			onSuccess: () => setAssigned((current) => isAssigned ? current.filter((entry) => entry.packageId !== item.id) : [...current, {
				roleId,
				packageId: item.id,
				package: item
			}])
		});
		try {
			setEffective(await adminApi.roles.effectivePermissions(roleId));
		} catch {}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-lg font-black",
			children: "Role → package assignment"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-muted-foreground",
			children: "Package changes immediately affect the role’s effective permission graph."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
			value: roleId,
			onChange: (e) => void select(e.target.value),
			className: `${inputClass$4} mt-5 max-w-lg`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: "",
				children: "Select role"
			}), roles.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: v.id,
				children: v.name
			}, v.id))]
		}),
		roleId && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-6 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-xs font-extrabold uppercase text-muted-foreground",
				children: "Available packages"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 space-y-2",
				children: packages.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex cursor-pointer items-center gap-3 rounded-xl border border-border p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: assignedIds.has(item.id),
							disabled: busy || loading,
							onChange: () => void toggle(item),
							className: "h-4 w-4 accent-primary"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1 text-xs font-black",
							children: item.code || item.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status$2, { active: item.isActive })
					]
				}, item.id))
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-xs font-extrabold uppercase text-muted-foreground",
					children: "Effective access preview"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 rounded-xl bg-secondary p-5 text-white",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-3xl font-black",
							children: effective?.permissionCodes.length || 0
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-white/60",
							children: "active effective permissions"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex flex-wrap gap-2",
							children: effective?.packages.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full bg-white/10 px-2 py-1 text-[10px] font-bold",
								children: v.code
							}, v.id))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 max-h-72 space-y-2 overflow-y-auto",
					children: effective?.permissions.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg border border-border p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "break-all text-xs font-black",
							children: v.code
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-[11px] text-muted-foreground",
							children: v.name
						})]
					}, v.id))
				})
			] })]
		}),
		!roleId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "Select a role to configure package access." })
	] });
}
function RegistrationMatrix({ roles, busy, mutate }) {
	const [registrar, setRegistrar] = (0, import_react.useState)(""), [rows, setRows] = (0, import_react.useState)([]), [loading, setLoading] = (0, import_react.useState)(false);
	async function select(id) {
		setRegistrar(id);
		setLoading(true);
		try {
			setRows(await adminApi.roles.registrationPermissions(id));
		} finally {
			setLoading(false);
		}
	}
	const rowByTarget = (0, import_react.useMemo)(() => new Map(rows.map((v) => [v.targetRoleId, v])), [rows]);
	async function toggle(target) {
		const row = rowByTarget.get(target.id);
		const nextActive = row ? !row.isActive : true;
		await mutate(() => row ? adminApi.roles.registrationStatus(registrar, target.id, !row.isActive) : adminApi.roles.allowRegistration(registrar, target.id), "Registration permission updated.", {
			refresh: false,
			onSuccess: () => setRows((current) => row ? current.map((entry) => entry.targetRoleId === target.id ? {
				...entry,
				isActive: nextActive
			} : entry) : [...current, {
				registrarRoleId: registrar,
				targetRoleId: target.id,
				isActive: true,
				targetRole: target
			}])
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-lg font-black",
				children: "Who can create which role"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "This matrix controls hierarchical managed-account registration at the backend."
			})] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
			value: registrar,
			onChange: (e) => void select(e.target.value),
			className: `${inputClass$4} mt-5 max-w-lg`,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: "",
				children: "Select registrar role"
			}), roles.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: v.id,
				children: v.name
			}, v.id))]
		}),
		registrar && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 grid gap-3 sm:grid-cols-2 xl:grid-cols-3",
			children: roles.filter((v) => v.id !== registrar).map((target) => {
				const row = rowByTarget.get(target.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					disabled: busy || loading,
					onClick: () => void toggle(target),
					className: `flex items-center gap-3 rounded-xl border p-4 text-left ${row?.isActive ? "border-emerald-200 bg-emerald-50" : "border-border bg-white"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `grid h-9 w-9 place-items-center rounded-lg ${row?.isActive ? "bg-emerald-100 text-emerald-700" : "bg-muted text-muted-foreground"}`,
						children: row?.isActive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { size: 17 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsersRound, { size: 17 })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-sm font-black",
							children: target.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] text-muted-foreground",
							children: row?.isActive ? "CREATION ALLOWED" : "NOT ALLOWED"
						})]
					})]
				}, target.id);
			})
		}),
		!registrar && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { text: "Choose a registrar role to edit its creation permissions." })
	] });
}
function Field$1({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-xs font-extrabold uppercase text-muted-foreground",
			children: label
		}), children]
	});
}
function Status$2({ active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-full px-2 py-1 text-[9px] font-extrabold ${active ? "bg-emerald-50 text-emerald-700" : "bg-muted text-muted-foreground"}`,
		children: active ? "ACTIVE" : "INACTIVE"
	});
}
function Empty({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-5 rounded-xl border border-dashed border-border py-10 text-center text-sm text-muted-foreground",
		children: text
	});
}
var $$splitComponentImporter$50 = () => import("./api-settings-ClhCbkQ0.mjs");
var Route$56 = createFileRoute("/admin/api-settings/")({ component: lazyRouteComponent($$splitComponentImporter$50, "component") });
var $$splitComponentImporter$49 = () => import("./banking-CqvrVS9v.mjs");
var Route$55 = createFileRoute("/admin/banking/")({ component: lazyRouteComponent($$splitComponentImporter$49, "component") });
var $$splitComponentImporter$48 = () => import("./commissions-DKfuK9pn.mjs");
var Route$54 = createFileRoute("/admin/commissions/")({ component: lazyRouteComponent($$splitComponentImporter$48, "component") });
var $$splitComponentImporter$47 = () => import("./hierarchy-DCWqmVKM.mjs");
var Route$53 = createFileRoute("/admin/commissions/hierarchy")({ component: lazyRouteComponent($$splitComponentImporter$47, "component") });
var $$splitComponentImporter$46 = () => import("./kyc-BEPd6Wv1.mjs");
var Route$52 = createFileRoute("/admin/kyc/")({ component: lazyRouteComponent($$splitComponentImporter$46, "component") });
var $$splitComponentImporter$45 = () => import("./legal-BAS_pCS4.mjs");
var Route$51 = createFileRoute("/admin/legal/")({ component: lazyRouteComponent($$splitComponentImporter$45, "component") });
var Route$50 = createFileRoute("/admin/merchants/")({ component: MemberManagementOverview });
var emptyForm = {
	role: "RETAILER",
	fullName: "",
	username: "",
	email: "",
	city: "",
	state: "",
	pincode: "",
	shopName: "",
	shopAddress: "",
	shopCity: "",
	shopState: ""
};
var inputClass$3 = "w-full rounded-xl border border-border bg-white px-4 py-3 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/15";
function MemberManagementOverview() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "merchants",
		eyebrow: "Network",
		title: "Member management",
		description: "Separate production workflows for creating, finding and managing platform members.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-5 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/admin/merchants/add",
				className: "rounded-2xl border border-border bg-white p-7 shadow-sm transition hover:border-primary/50 hover:shadow-lg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-12 w-12 place-items-center rounded-xl bg-primary/10 text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 text-xl font-black",
						children: "Add member"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-6 text-muted-foreground",
						children: "Create a managed identity using the verified Super Admin account API."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-xs font-extrabold uppercase text-primary",
						children: "Open form →"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/admin/merchants/list",
				className: "rounded-2xl border border-border bg-white p-7 shadow-sm transition hover:border-primary/50 hover:shadow-lg",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-12 w-12 place-items-center rounded-xl bg-secondary/10 text-secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 text-xl font-black",
						children: "Member list"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-6 text-muted-foreground",
						children: "Search and review managed accounts when the listing contract is available."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 text-xs font-extrabold uppercase text-primary",
						children: "Open list →"
					})
				]
			})]
		})
	});
}
function CreateMemberPage() {
	const actor = getAdminActor();
	const allowedRoles = registrationTargets(actor?.role);
	const canCreate = allowedRoles.length > 0;
	const [form, setForm] = (0, import_react.useState)(emptyForm);
	const [roles, setRoles] = (0, import_react.useState)([]);
	const [result, setResult] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setForm((current) => ({
			...current,
			role: allowedRoles[0] || "RETAILER"
		}));
		adminApi.roles.list().then((value) => setRoles(asArray(value).filter((role) => role.isActive && allowedRoles.includes(role.name.toUpperCase().replace(/[ -]+/g, "_"))))).catch(() => void 0);
	}, [actor?.role]);
	function update(field, value) {
		setForm((current) => ({
			...current,
			[field]: value
		}));
	}
	async function submit(event) {
		event.preventDefault();
		setError("");
		setResult(null);
		if (!canCreate) return setError("Your role cannot create another managed account.");
		if (!allowedRoles.includes(form.role)) return setError("You cannot create the selected role.");
		if (!/^[a-z0-9._-]{4,50}$/.test(form.username)) return setError("Username must be 4–50 lowercase characters and may include dots, underscores or hyphens.");
		if (!/^[1-9][0-9]{5}$/.test(form.pincode)) return setError("Enter a valid 6-digit Indian pincode.");
		setLoading(true);
		try {
			const created = await adminApi.createAccount(clean(form));
			setResult(created);
			setForm(emptyForm);
		} catch (reason) {
			setError(reason instanceof Error ? reason.message : "Account creation failed.");
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "merchants",
		eyebrow: "Network",
		title: "Member management",
		description: "Create role-based managed accounts through the verified Super Admin backend workflow.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 xl:grid-cols-[1.4fr_.6fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { size: 20 })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-black",
					children: "Create managed account"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Temporary credentials are generated by the backend and delivered by email."
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "mt-7 space-y-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
						title: "Account details",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Role",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									className: inputClass$3,
									value: form.role,
									onChange: (e) => update("role", e.target.value),
									children: roles.length ? roles.map((role) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: role.name,
										children: role.name.replaceAll("_", " ")
									}, role.id)) : allowedRoles.map((role) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: role,
										children: role.replaceAll("_", " ")
									}, role))
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Full name",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									maxLength: 150,
									className: inputClass$3,
									value: form.fullName,
									onChange: (e) => update("fullName", e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Username",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									minLength: 4,
									maxLength: 50,
									className: inputClass$3,
									placeholder: "lowercase.username",
									value: form.username,
									onChange: (e) => update("username", e.target.value.toLowerCase())
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Email",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									type: "email",
									maxLength: 150,
									className: inputClass$3,
									value: form.email,
									onChange: (e) => update("email", e.target.value.toLowerCase())
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
						title: "Location",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "City",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									maxLength: 100,
									className: inputClass$3,
									value: form.city,
									onChange: (e) => update("city", e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "State",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									maxLength: 100,
									className: inputClass$3,
									value: form.state,
									onChange: (e) => update("state", e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Pincode",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									inputMode: "numeric",
									maxLength: 6,
									className: inputClass$3,
									value: form.pincode,
									onChange: (e) => update("pincode", e.target.value.replace(/\D/g, ""))
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FormSection, {
						title: "Business details (optional)",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Shop name",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									maxLength: 150,
									className: inputClass$3,
									value: form.shopName,
									onChange: (e) => update("shopName", e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Shop city",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									maxLength: 100,
									className: inputClass$3,
									value: form.shopCity,
									onChange: (e) => update("shopCity", e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Shop state",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									maxLength: 100,
									className: inputClass$3,
									value: form.shopState,
									onChange: (e) => update("shopState", e.target.value)
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Shop address",
								wide: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									maxLength: 250,
									rows: 3,
									className: inputClass$3,
									value: form.shopAddress,
									onChange: (e) => update("shopAddress", e.target.value)
								})
							})
						]
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						disabled: !canCreate || loading,
						className: "flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3.5 text-sm font-extrabold text-white disabled:cursor-not-allowed disabled:opacity-45",
						children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
							size: 18,
							className: "animate-spin"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 18 }), " Create account"]
					})
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-black",
					children: "Backend workflow"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-5 space-y-4",
					children: [
						"Validate selected active role",
						"Generate password and 4-digit MPIN",
						"Create managed identity",
						"Queue credentials email",
						"Require first-login onboarding"
					].map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid h-7 w-7 shrink-0 place-items-center rounded-full bg-secondary text-xs font-black text-white",
							children: index + 1
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "pt-1 text-sm font-semibold",
							children: step
						})]
					}, step))
				})] }), result && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
					className: "border-emerald-200 bg-emerald-50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "text-emerald-700" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 text-lg font-black text-emerald-900",
							children: "Account created"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-emerald-800",
							children: result.message
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 rounded-xl bg-white p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[10px] font-bold uppercase text-muted-foreground",
									children: "Login ID"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-lg font-black",
									children: result.account.loginId
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 flex items-center gap-2 text-xs text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { size: 14 }), result.account.email]
								})
							]
						})
					]
				})]
			})]
		})
	});
}
function clean(form) {
	return Object.fromEntries(Object.entries(form).filter(([, value]) => value !== ""));
}
function FormSection({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
		className: "mb-4 text-sm font-black uppercase tracking-wide text-secondary",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-4 md:grid-cols-2",
		children
	})] });
}
function Field({ label, children, wide = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: wide ? "md:col-span-2" : "",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-xs font-extrabold uppercase tracking-wide text-muted-foreground",
			children: label
		}), children]
	});
}
var Route$49 = createFileRoute("/admin/profile/")({ component: Profile });
function Profile() {
	const actor = getAdminActor();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "profile",
		eyebrow: "Account",
		title: "My profile",
		description: "Administrator identity, security and access information in one dedicated workspace.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 xl:grid-cols-[340px_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
				className: "h-fit text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mx-auto grid h-24 w-24 place-items-center rounded-3xl bg-secondary text-3xl font-black text-white",
						children: actor?.name?.charAt(0).toUpperCase() || "A"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 text-2xl font-black",
						children: actor?.name || "Administrator"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs font-extrabold uppercase tracking-wider text-primary",
						children: actor?.role || "ADMIN"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileStat, {
							label: "Session",
							value: "Active"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileStat, {
							label: "Account",
							value: "Verified"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-black",
					children: "Account overview"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
							icon: CircleUser,
							label: "Display name",
							value: actor?.name || "Administrator"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
							icon: ShieldCheck,
							label: "Access level",
							value: actor?.role || "ADMIN"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
							icon: Mail,
							label: "Account type",
							value: actor?.kind === "SUPER_ADMIN" ? "Dedicated Super Admin" : "Identity Administrator"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
							icon: KeyRound,
							label: "Authentication",
							value: "Password or MPIN"
						})
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-emerald-50 text-emerald-700",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockKeyhole, { size: 20 })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-black",
						children: "Security controls"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-6 text-muted-foreground",
						children: "Password, MPIN, device verification and session-management actions will appear here when their role-specific backend contracts are exposed."
					})] })]
				}) })]
			})]
		})
	});
}
function ProfileStat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-muted p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] font-bold uppercase text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm font-black",
			children: value
		})]
	});
}
function Detail({ icon: Icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 rounded-xl border border-border p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid h-9 w-9 place-items-center rounded-lg bg-primary/10 text-primary",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 17 })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] font-bold uppercase text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-0.5 text-sm font-extrabold",
			children: value
		})] })]
	});
}
var $$splitComponentImporter$44 = () => import("./bank-zSiaJjVc.mjs");
var Route$48 = createFileRoute("/admin/profile/bank")({ component: lazyRouteComponent($$splitComponentImporter$44, "component") });
var $$splitComponentImporter$43 = () => import("./kyc-_zdyauth.mjs");
var Route$47 = createFileRoute("/admin/profile/kyc")({ component: lazyRouteComponent($$splitComponentImporter$43, "component") });
var $$splitComponentImporter$42 = () => import("./reports-CHze7p5_.mjs");
var Route$46 = createFileRoute("/admin/reports/")({ component: lazyRouteComponent($$splitComponentImporter$42, "component") });
var Route$45 = createFileRoute("/admin/settings/")({ component: AdminSettings });
var inputClass$2 = "w-full rounded-xl border border-border bg-white px-4 py-3 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/15";
function AdminSettings() {
	const [identity, setIdentity] = (0, import_react.useState)(() => getSession()?.identity || null);
	const isIdentityAdmin = isManagementRole(identity?.role);
	(0, import_react.useEffect)(() => {
		if (isIdentityAdmin && getSession()?.nextStep === "ADD_PAN") window.location.replace(`${managementBasePath(identity?.role)}/account-setup`);
	}, [isIdentityAdmin]);
	const securityComplete = Boolean(identity?.passwordChangedAt && identity?.mpinChangedAt);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "settings",
		eyebrow: "Account security",
		title: "Settings",
		description: isIdentityAdmin ? securityComplete ? "Manage your password, MPIN and account security at any time." : "Complete first-login security here. Other administration sections stay locked until both credentials are changed." : "Manage secure platform configuration.",
		children: isIdentityAdmin && identity ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CredentialSecurity, {
			identity,
			onIdentityChange: setIdentity
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentitySecurityCenter, {})] }) : getAdminSession() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceState, {
			title: "System configuration",
			description: "The current /auth/sessions and /auth/me/permissions endpoints belong to identity accounts. Dedicated Super Admin device-management endpoints are not present in the backend yet.",
			status: "Super Admin contract pending"
		}) : null
	});
}
function CredentialSecurity({ identity, onIdentityChange }) {
	const [mode, setMode] = (0, import_react.useState)(identity.passwordChangedAt ? "mpin" : "password");
	const [current, setCurrent] = (0, import_react.useState)("");
	const [next, setNext] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const [visible, setVisible] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [message, setMessage] = (0, import_react.useState)(null);
	const complete = Boolean(identity.passwordChangedAt && identity.mpinChangedAt);
	async function submit(event) {
		event.preventDefault();
		setMessage(null);
		if (!current) return setMessage({
			ok: false,
			text: `Enter your temporary ${mode}.`
		});
		if (next !== confirm) return setMessage({
			ok: false,
			text: `New ${mode} and confirmation do not match.`
		});
		if (mode === "mpin" && !/^\d{4}$/.test(next)) return setMessage({
			ok: false,
			text: "New MPIN must contain exactly 4 digits."
		});
		if (mode === "password" && !/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W_]).{8,}$/.test(next)) return setMessage({
			ok: false,
			text: "Password needs 8+ characters with uppercase, lowercase, number and special character."
		});
		const session = getSession();
		if (!session) return window.location.replace("/login");
		const wasSetupComplete = complete;
		setBusy(true);
		try {
			if (mode === "password") {
				await authApi.changePassword(session.accessToken, {
					currentPassword: current,
					newPassword: next
				});
				const synchronized = await refreshSession();
				onIdentityChange(synchronized.identity);
				if (!synchronized.identity.mpinChangedAt) {
					updateIdentityOnboarding("CHANGE_MPIN", "CREDENTIAL_CHANGE_REQUIRED");
					setMode("mpin");
					setMessage({
						ok: true,
						text: "Password changed. Now change your temporary MPIN to unlock the Admin Console."
					});
				} else if (wasSetupComplete) setMessage({
					ok: true,
					text: "Password updated successfully. Your MPIN remains active."
				});
				else window.location.replace(managementBasePath(synchronized.identity.role));
			} else {
				await authApi.changeMpin(session.accessToken, {
					currentMpin: current,
					newMpin: next
				});
				const synchronized = await refreshSession();
				onIdentityChange(synchronized.identity);
				if (synchronized.identity.passwordChangedAt && synchronized.identity.mpinChangedAt) {
					updateIdentityOnboarding(null);
					if (wasSetupComplete) setMessage({
						ok: true,
						text: "MPIN updated successfully. Your password remains active."
					});
					else {
						setMessage({
							ok: true,
							text: "Security setup complete. Management workspace unlocked."
						});
						window.location.replace(managementBasePath(synchronized.identity.role));
					}
				} else setMessage({
					ok: false,
					text: "The refreshed account still shows a pending credential. Please try again."
				});
			}
			setCurrent("");
			setNext("");
			setConfirm("");
		} catch (error) {
			setMessage({
				ok: false,
				text: error instanceof ApiError ? error.message : "Unable to update security credentials."
			});
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 xl:grid-cols-[.7fr_1.3fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-extrabold uppercase tracking-wider text-primary",
				children: complete ? "Account protection" : "First-login status"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 text-xl font-black",
				children: complete ? "Security overview" : "Security checklist"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status$1, {
						label: "Phone & PAN verification",
						done: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status$1, {
						label: complete ? "Password protection active" : "Temporary password changed",
						done: !!identity.passwordChangedAt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status$1, {
						label: complete ? "MPIN protection active" : "Temporary MPIN changed",
						done: !!identity.mpinChangedAt
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `mt-6 rounded-xl p-4 text-xs leading-5 ${complete ? "bg-emerald-50 text-emerald-800" : "bg-amber-50 text-amber-800"}`,
				children: complete ? "Your account verification and first-login setup are complete. You can update either credential anytime from this page; all permitted sections remain available." : "Dashboard and other management sections remain locked. Only Settings and Sign out are available during setup."
			}),
			complete && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-xl border border-border p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-black",
					children: "Security recommendation"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs leading-5 text-muted-foreground",
					children: "Use a unique password and private 4-digit MPIN. Never share OTP, password or MPIN with support staff."
				})]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary",
					children: mode === "password" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockKeyhole, { size: 21 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { size: 21 })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-extrabold uppercase tracking-wider text-primary",
						children: "Login & security"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-black",
						children: complete ? "Update security credentials" : "Change temporary credentials"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: complete ? "Choose password or MPIN below. Updating one does not reset the other." : "Replace both credentials once to unlock your workspace."
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusCard, {
					label: "Password",
					done: !!identity.passwordChangedAt
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusCard, {
					label: "MPIN",
					done: !!identity.mpinChangedAt
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex rounded-xl bg-muted p-1",
				children: ["password", "mpin"].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: !complete && !identity.passwordChangedAt && item === "mpin",
					onClick: () => {
						setMode(item);
						setMessage(null);
						setCurrent("");
						setNext("");
						setConfirm("");
					},
					className: `flex-1 rounded-lg py-2 text-sm font-bold capitalize disabled:cursor-not-allowed disabled:opacity-40 ${mode === item ? "bg-white text-secondary shadow-sm" : "text-muted-foreground"}`,
					children: item
				}, item))
			}),
			complete && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex items-center gap-3 rounded-xl bg-emerald-50 p-4 text-sm font-bold text-emerald-700",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { size: 20 }), "Security setup complete. Credential updates remain available below."]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "mt-5 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecureField, {
						label: `${complete ? "Current" : "Temporary"} ${mode}`,
						value: current,
						setValue: setCurrent,
						visible,
						mpin: mode === "mpin"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecureField, {
						label: `New ${mode}`,
						value: next,
						setValue: setNext,
						visible,
						mpin: mode === "mpin"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecureField, {
						label: `Confirm new ${mode}`,
						value: confirm,
						setValue: setConfirm,
						visible,
						mpin: mode === "mpin"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setVisible(!visible),
						className: "flex items-center gap-2 text-xs font-bold text-primary",
						children: [visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { size: 15 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 15 }), visible ? "Hide values" : "Show values"]
					}),
					message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: `rounded-xl p-4 text-sm font-semibold ${message.ok ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`,
						children: message.text
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: busy,
						className: "w-full rounded-xl bg-primary py-3.5 text-sm font-extrabold text-white disabled:opacity-60",
						children: busy ? "Updating..." : `${complete ? "Update" : "Change"} ${mode}`
					})
				]
			})
		] })]
	});
}
function Status$1({ label, done }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex items-center gap-3 rounded-xl border p-3 text-sm font-bold ${done ? "border-emerald-200 bg-emerald-50 text-emerald-700" : "border-amber-200 bg-amber-50 text-amber-800"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 17 }),
			label,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ml-auto text-[10px] uppercase",
				children: done ? "Complete" : "Required"
			})
		]
	});
}
function StatusCard({ label, done }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-xl border p-3 text-sm font-bold ${done ? "border-emerald-200 bg-emerald-50 text-emerald-700" : "border-amber-200 bg-amber-50 text-amber-800"}`,
		children: [
			label,
			": ",
			done ? "Changed" : "Temporary"
		]
	});
}
function SecureField({ label, value, setValue, visible, mpin }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-xs font-extrabold uppercase tracking-wider text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value,
			onChange: (event) => setValue(mpin ? event.target.value.replace(/\D/g, "").slice(0, 4) : event.target.value),
			type: visible ? "text" : "password",
			inputMode: mpin ? "numeric" : void 0,
			autoComplete: "new-password",
			className: inputClass$2
		})]
	});
}
var $$splitComponentImporter$41 = () => import("./settlements-BagrUXJq.mjs");
var Route$44 = createFileRoute("/admin/settlements/")({ component: lazyRouteComponent($$splitComponentImporter$41, "component") });
var $$splitComponentImporter$40 = () => import("./sms-B2B3KhWS.mjs");
var Route$43 = createFileRoute("/admin/sms/")({ component: lazyRouteComponent($$splitComponentImporter$40, "component") });
var messageOf$1 = (value) => value instanceof Error ? value.message : "The operation could not be completed.";
var money = (value) => new Intl.NumberFormat("en-IN", {
	style: "currency",
	currency: "INR"
}).format(Number(value) || 0);
var time = (value) => value ? new Date(value).toLocaleString("en-IN") : "—";
var inputClass$1 = "rounded-xl border border-border bg-white px-3 py-2.5 text-xs outline-none focus:border-primary";
function AdminTransactionOperations() {
	const actor = getAdminActor();
	const permissionLoaded = Boolean(getEffectiveAccess());
	const allowed = (code) => actor?.kind === "SUPER_ADMIN" || permissionLoaded && hasPermission(code);
	const canView = allowed("transaction.view"), canViewIncome = allowed("transaction.provider-income.view"), canReconcileIncome = allowed("transaction.provider-income.reconcile"), canRequestReversal = allowed("transaction.reversal.request"), canProcessReversal = allowed("transaction.reversal.process"), canRecover = allowed("transaction.financial-recovery");
	const [view, setView] = (0, import_react.useState)("transactions");
	const [transactions, setTransactions] = (0, import_react.useState)([]);
	const [reversals, setReversals] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(false), [busy, setBusy] = (0, import_react.useState)(false), [error, setError] = (0, import_react.useState)(""), [notice, setNotice] = (0, import_react.useState)(""), [status, setStatus] = (0, import_react.useState)("");
	const [detail, setDetail] = (0, import_react.useState)(null), [reverseTarget, setReverseTarget] = (0, import_react.useState)(null), [reason, setReason] = (0, import_react.useState)("");
	const [incomeTarget, setIncomeTarget] = (0, import_react.useState)(null), [income, setIncome] = (0, import_react.useState)({ incomeSource: "VIMOPAY_WALLET" });
	async function load() {
		if (view === "transactions" && !canView || view === "income" && !canViewIncome || view === "reversals" && !canProcessReversal && !canRequestReversal) return;
		setLoading(true);
		setError("");
		try {
			const query = new URLSearchParams({
				page: "1",
				limit: "50"
			});
			if (status) query.set("status", status);
			if (view === "transactions") setTransactions((await adminApi.providerTransactions(query.toString())).data || []);
			else if (view === "income") setTransactions((await adminApi.pendingProviderIncome(query.toString())).data || []);
			else setReversals((await adminApi.reversals(query.toString())).data || []);
		} catch (value) {
			setError(messageOf$1(value));
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		load();
	}, [view, status]);
	async function inspect(id) {
		setBusy(true);
		try {
			setDetail(await adminApi.transaction(id));
		} catch (value) {
			setError(messageOf$1(value));
		} finally {
			setBusy(false);
		}
	}
	async function requestReversal() {
		if (!reverseTarget || !reason.trim()) return setError("A reversal reason is required.");
		setBusy(true);
		try {
			await adminApi.requestReversal(reverseTarget.referenceId, reason.trim(), crypto.randomUUID());
			setNotice(`Reversal requested for ${reverseTarget.referenceId}.`);
			setReverseTarget(null);
			setReason("");
			await load();
		} catch (value) {
			setError(messageOf$1(value));
		} finally {
			setBusy(false);
		}
	}
	async function reconcileIncome() {
		if (!incomeTarget) return;
		setBusy(true);
		try {
			await adminApi.reconcileProviderIncome(incomeTarget.referenceId, income);
			setNotice(`Provider income reconciled for ${incomeTarget.referenceId}.`);
			setIncomeTarget(null);
			await load();
		} catch (value) {
			setError(messageOf$1(value));
		} finally {
			setBusy(false);
		}
	}
	async function processReversal(item) {
		if (!window.confirm(`${item.status === "FAILED" ? "Retry" : "Process"} reversal ${item.referenceId}?`)) return;
		setBusy(true);
		try {
			await adminApi.processReversal(item.referenceId);
			setNotice(`Reversal ${item.referenceId} processed.`);
			await load();
		} catch (value) {
			setError(messageOf$1(value));
		} finally {
			setBusy(false);
		}
	}
	async function recover(item) {
		if (!window.confirm(`Retry financial effects for ${item.referenceId}?`)) return;
		setBusy(true);
		try {
			await adminApi.recoverFinancialEffects(item.referenceId);
			setNotice(`Financial recovery requested for ${item.referenceId}.`);
			await load();
		} catch (value) {
			setError(messageOf$1(value));
		} finally {
			setBusy(false);
		}
	}
	if (!canView && !canViewIncome && !canProcessReversal && !canRequestReversal) return null;
	const tabs = [];
	if (canView) tabs.push(["transactions", "All transactions"]);
	if (canViewIncome) tabs.push(["income", "Pending provider income"]);
	if (canProcessReversal || canRequestReversal) tabs.push(["reversals", "Reversals"]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
		className: "mb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-black",
					children: "Transaction operations"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Provider transactions, income settlement and reversal lifecycle."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void load(),
					disabled: loading,
					className: "rounded-xl border border-border p-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
						size: 16,
						className: loading ? "animate-spin" : ""
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: tabs.map(([key, text]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setView(key);
						setStatus("");
					},
					className: `rounded-xl px-4 py-2.5 text-xs font-extrabold ${view === key ? "bg-secondary text-white" : "border border-border"}`,
					children: text
				}, key))
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-4 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700",
				children: error
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 rounded-xl bg-emerald-50 p-3 text-sm font-semibold text-emerald-700",
				children: notice
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: status,
					onChange: (event) => setStatus(event.target.value),
					className: inputClass$1,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "All statuses"
					}), (view === "reversals" ? [
						"REQUESTED",
						"PROCESSING",
						"COMPLETED",
						"FAILED"
					] : [
						"INITIATED",
						"PROCESSING",
						"SUCCESS",
						"FAILED",
						"PENDING",
						"UNKNOWN",
						"REVERSED"
					]).map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: value }, value))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 overflow-x-auto rounded-xl border border-border",
				children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid h-40 place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin text-primary" })
				}) : view === "reversals" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReversalTable, {
					items: reversals,
					busy,
					process: processReversal,
					canProcess: canProcessReversal
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransactionTable, {
					items: transactions,
					view,
					inspect,
					reverse: setReverseTarget,
					income: setIncomeTarget,
					recover,
					canReconcileIncome,
					canRequestReversal,
					canRecover
				})
			}),
			detail && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-xl border border-primary/30 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-black",
						children: "Transaction detail"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setDetail(null),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid gap-2 sm:grid-cols-3",
					children: Object.entries(detail).filter(([, value]) => value !== null && typeof value !== "object").map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg bg-muted p-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[9px] uppercase text-muted-foreground",
							children: key.replace(/([A-Z])/g, " $1")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "break-all text-xs font-bold",
							children: String(value)
						})]
					}, key))
				})]
			}),
			reverseTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
				title: "Request reversal",
				busy,
				close: () => setReverseTarget(null),
				confirm: () => void requestReversal(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "break-all text-xs",
					children: reverseTarget.referenceId
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: reason,
					onChange: (event) => setReason(event.target.value),
					rows: 3,
					placeholder: "Required reversal reason",
					className: `${inputClass$1} mt-4 w-full`
				})]
			}),
			incomeTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
				title: "Reconcile provider income",
				busy,
				close: () => setIncomeTarget(null),
				confirm: () => void reconcileIncome(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "break-all text-xs",
					children: incomeTarget.referenceId
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							min: "0.01",
							step: "0.01",
							value: income.providerIncomeAmount ?? "",
							onChange: (event) => setIncome({
								...income,
								providerIncomeAmount: event.target.value ? Number(event.target.value) : void 0
							}),
							placeholder: "Income amount (optional)",
							className: inputClass$1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: income.incomeSource,
							onChange: (event) => setIncome({
								...income,
								incomeSource: event.target.value
							}),
							className: inputClass$1,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "VIMOPAY_WALLET",
								children: "VIMOPAY WALLET"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "VIMOPAY_MS",
								children: "VIMOPAY MS"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: income.externalReference ?? "",
							onChange: (event) => setIncome({
								...income,
								externalReference: event.target.value || void 0
							}),
							placeholder: "External reference (optional)",
							className: inputClass$1
						})
					]
				})]
			})
		]
	});
}
function TransactionTable({ items, view, inspect, reverse, income, recover, canReconcileIncome, canRequestReversal, canRecover }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
		className: "w-full min-w-[1000px] text-left text-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
			className: "bg-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
				"Reference",
				"User",
				"Provider",
				"Amount",
				"Status",
				"Settlement",
				"Commission",
				"Created",
				"Actions"
			].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "p-3",
				children: value
			}, value)) })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
			className: "border-t",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3 font-bold",
					children: item.referenceId
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: item.userId
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
					className: "p-3",
					children: [
						item.provider,
						" / ",
						item.operation
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3 font-bold",
					children: money(item.amount)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3 font-bold",
					children: item.status
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: item.settlementStatus || "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: item.commissionStatus || "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: time(item.createdAt)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								title: "View",
								onClick: () => inspect(item.referenceId),
								className: "rounded-lg border p-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 14 })
							}),
							view === "income" && canReconcileIncome && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								title: "Reconcile income",
								onClick: () => income(item),
								className: "rounded-lg border border-emerald-200 p-2 text-emerald-700",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletCards, { size: 14 })
							}),
							view === "transactions" && canRequestReversal && item.status === "SUCCESS" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								title: "Request reversal",
								onClick: () => reverse(item),
								className: "rounded-lg border border-amber-200 p-2 text-amber-700",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { size: 14 })
							}),
							view === "transactions" && canRecover && !item.needsReconciliation && (item.settlementStatus === "FAILED" || item.commissionStatus === "FAILED") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => recover(item),
								className: "rounded-lg border px-2 py-1 font-bold text-red-700",
								children: "Recover"
							})
						]
					})
				})
			]
		}, item.referenceId)) })]
	});
}
function ReversalTable({ items, busy, process, canProcess }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
		className: "w-full min-w-[850px] text-left text-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
			className: "bg-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
				"Reversal",
				"Transaction",
				"Provider",
				"Amount",
				"Status",
				"Reason",
				"Action"
			].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "p-3",
				children: value
			}, value)) })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
			className: "border-t",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3 font-bold",
					children: item.referenceId
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: item.providerTransactionReference
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: item.provider
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: money(item.amount)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3 font-bold",
					children: item.status
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: item.failedReason || item.reason || "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: canProcess && ["REQUESTED", "FAILED"].includes(item.status) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: busy,
						onClick: () => void process(item),
						className: "rounded-lg bg-primary px-3 py-2 font-bold text-white",
						children: item.status === "FAILED" ? "Retry" : "Process"
					})
				})
			]
		}, item.referenceId)) })]
	});
}
function Dialog({ title, busy, close, confirm, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[100] grid place-items-center bg-secondary/60 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			className: "w-full max-w-lg rounded-2xl bg-white p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-black",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2",
					children
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: busy,
						onClick: close,
						className: "rounded-xl border px-4 py-3 text-xs font-bold",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: busy,
						onClick: confirm,
						className: "rounded-xl bg-primary px-4 py-3 text-xs font-bold text-white",
						children: busy ? "Working..." : "Confirm"
					})]
				})
			]
		})
	});
}
var Route$42 = createFileRoute("/admin/transactions/")({ component: Transactions });
var inputClass = "w-full rounded-xl border border-border bg-white px-3.5 py-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/15";
var messageOf = (error) => error instanceof AdminApiError || error instanceof Error ? error.message : "The request could not be completed.";
function dateTime(value) {
	if (!value) return "—";
	const date = new Date(value);
	return Number.isNaN(date.getTime()) ? "—" : new Intl.DateTimeFormat("en-IN", {
		dateStyle: "medium",
		timeStyle: "short"
	}).format(date);
}
function amount(value) {
	const number = Number(value);
	return Number.isFinite(number) ? new Intl.NumberFormat("en-IN", {
		style: "currency",
		currency: "INR"
	}).format(number) : "—";
}
function Transactions() {
	const actor = getAdminActor();
	const permissionLoaded = Boolean(getEffectiveAccess());
	const canResolve = actor?.kind === "SUPER_ADMIN" || permissionLoaded && hasPermission("transaction.reconciliation.resolve");
	actor?.kind === "SUPER_ADMIN" || !permissionLoaded || hasPermission("transaction.reversal.request");
	const [items, setItems] = (0, import_react.useState)([]), [loading, setLoading] = (0, import_react.useState)(true), [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(""), [notice, setNotice] = (0, import_react.useState)(""), [query, setQuery] = (0, import_react.useState)(""), [status, setStatus] = (0, import_react.useState)(""), [operation, setOperation] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(1), [totalPages, setTotalPages] = (0, import_react.useState)(1), [total, setTotal] = (0, import_react.useState)(0);
	const [detail, setDetail] = (0, import_react.useState)(null), [detailBusy, setDetailBusy] = (0, import_react.useState)(false), [action, setAction] = (0, import_react.useState)(null);
	const [resolution, setResolution] = (0, import_react.useState)("SUCCESS"), [note, setNote] = (0, import_react.useState)(""), [providerTxnRefId, setProviderTxnRefId] = (0, import_react.useState)(""), [rrn, setRrn] = (0, import_react.useState)("");
	async function load(targetPage = page) {
		setLoading(true);
		setError("");
		try {
			const params = new URLSearchParams({
				page: String(targetPage),
				limit: "25"
			});
			if (status) params.set("status", status);
			if (operation) params.set("operation", operation);
			const result = await adminApi.reconciliation(params.toString());
			setItems(result.data || []);
			setPage(result.page || targetPage);
			setTotalPages(Math.max(result.totalPages || 1, 1));
			setTotal(result.total || 0);
		} catch (caught) {
			setError(messageOf(caught));
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		load(1);
	}, [status, operation]);
	const visible = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		return needle ? items.filter((item) => `${item.referenceId} ${item.provider || ""} ${item.serviceType || ""} ${item.userId || ""} ${item.rrn || ""}`.toLowerCase().includes(needle)) : items;
	}, [items, query]);
	async function inspect(referenceId) {
		setDetailBusy(true);
		setError("");
		try {
			setDetail(await adminApi.transaction(referenceId));
		} catch (caught) {
			setError(messageOf(caught));
		} finally {
			setDetailBusy(false);
		}
	}
	function openAction(kind, item) {
		setAction({
			kind,
			item
		});
		setResolution("SUCCESS");
		setNote("");
		setProviderTxnRefId(item.providerTxnRefId || "");
		setRrn(item.rrn || "");
		setError("");
		setNotice("");
	}
	async function submitAction(event) {
		event.preventDefault();
		if (!action) return;
		if (!note.trim()) return setError(action.kind === "reverse" ? "Enter a reversal reason." : "Enter an operator note for the audit trail.");
		setBusy(true);
		setError("");
		setNotice("");
		try {
			if (action.kind === "resolve") {
				await adminApi.resolveTransaction(action.item.referenceId, {
					resolution,
					note: note.trim(),
					providerTxnRefId: providerTxnRefId.trim() || void 0,
					rrn: rrn.trim() || void 0
				});
				setNotice(`Transaction ${action.item.referenceId} resolved as ${resolution}.`);
			} else {
				await adminApi.requestReversal(action.item.referenceId, note.trim(), crypto.randomUUID());
				setNotice(`Reversal request submitted for ${action.item.referenceId}.`);
			}
			setAction(null);
			await load();
		} catch (caught) {
			setError(messageOf(caught));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "transactions",
		eyebrow: "Payments operations",
		title: "Transactions & reconciliation",
		description: "Search uncertain provider transactions, inspect the full record, resolve reconciliation and request controlled reversals.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminTransactionOperations, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
						label: "Queue total",
						value: String(total)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
						label: "Pending on page",
						value: String(items.filter((item) => item.status === "PENDING").length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
						label: "Unknown on page",
						value: String(items.filter((item) => item.status === "UNKNOWN").length)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
				className: "mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-black",
							children: "Reconciliation queue"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Every action is sent to the live admin transaction API and must be confirmed."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 sm:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 rounded-xl border border-border bg-white px-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { size: 15 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: query,
										onChange: (e) => setQuery(e.target.value),
										placeholder: "Reference, RRN…",
										className: "min-w-0 bg-transparent py-3 text-xs outline-none"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: status,
									onChange: (e) => setStatus(e.target.value),
									className: inputClass,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "All statuses"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "PENDING" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "UNKNOWN" })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: operation,
									onChange: (e) => setOperation(e.target.value),
									className: inputClass,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "All operations"
									}), [
										"BE",
										"MS",
										"CW",
										"AP",
										"CD"
									].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: v }, v))]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => void load(),
									disabled: loading,
									className: "inline-flex items-center justify-center gap-2 rounded-xl bg-secondary px-4 py-3 text-xs font-extrabold text-white disabled:opacity-50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
										size: 15,
										className: loading ? "animate-spin" : ""
									}), "Refresh"]
								})
							]
						})]
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "mt-5 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700",
						children: error
					}),
					notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 rounded-xl bg-emerald-50 p-3 text-sm font-semibold text-emerald-700",
						children: notice
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 overflow-x-auto rounded-xl border border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full min-w-[1050px] text-left text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "bg-muted/60",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "text-[10px] uppercase tracking-wider text-muted-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3",
												children: "Reference"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3",
												children: "Provider / service"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3",
												children: "Operation"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3",
												children: "Amount"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3",
												children: "Status"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3",
												children: "Reason"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3",
												children: "Created"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3 text-right",
												children: "Actions"
											})
										]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: visible.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t border-border/70 align-top",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "p-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "max-w-[190px] break-all font-black",
												children: item.referenceId
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-[10px] text-muted-foreground",
												children: item.userId || "User unavailable"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "p-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-bold",
												children: item.provider || "—"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												children: item.serviceType || "—"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3 font-bold",
											children: item.operation || "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3 font-black",
											children: amount(item.amount)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: item.status || "UNKNOWN" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "max-w-[220px] p-3 text-xs leading-5 text-muted-foreground",
											children: item.reconciliationReason || item.providerStatusMessage || "Awaiting operator review"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3 text-xs",
											children: dateTime(item.createdAt)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-end gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionButton, {
													title: "View transaction",
													onClick: () => void inspect(item.referenceId),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 15 })
												}), canResolve && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionButton, {
													title: "Resolve",
													tone: "good",
													onClick: () => openAction("resolve", item),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { size: 15 })
												})]
											})
										})
									]
								}, item.referenceId)) })]
							}),
							loading && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-center gap-2 py-12 text-sm text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
									className: "animate-spin",
									size: 17
								}), "Loading live queue…"]
							}),
							!loading && !visible.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "py-12 text-center text-sm text-muted-foreground",
								children: "No transactions match the current filters."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center justify-between text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: [
								"Page ",
								page,
								" of ",
								totalPages
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: loading || page <= 1,
								onClick: () => void load(page - 1),
								className: "rounded-lg border border-border px-3 py-2 font-bold disabled:opacity-40",
								children: "Previous"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: loading || page >= totalPages,
								onClick: () => void load(page + 1),
								className: "rounded-lg border border-border px-3 py-2 font-bold disabled:opacity-40",
								children: "Next"
							})]
						})]
					})
				]
			}),
			(detail || detailBusy) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
				className: "mt-6 border-primary/25",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-extrabold uppercase tracking-wider text-primary",
						children: "Transaction details"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-xl font-black",
						children: detail?.referenceId || "Loading record…"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setDetail(null),
						"aria-label": "Close details",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { size: 21 })
					})]
				}), detailBusy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "py-10 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mx-auto animate-spin text-primary" })
				}) : detail && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4",
					children: Object.entries(detail).filter(([, v]) => v !== null && typeof v !== "object").map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-muted/50 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-extrabold uppercase text-muted-foreground",
							children: key.replace(/([A-Z])/g, " $1")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 break-all text-xs font-bold",
							children: String(value)
						})]
					}, key))
				})]
			}),
			action && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-[80] grid place-items-center bg-secondary/55 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submitAction,
					className: "w-full max-w-xl rounded-2xl bg-white p-6 shadow-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `grid h-11 w-11 place-items-center rounded-xl ${action.kind === "resolve" ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}`,
								children: action.kind === "resolve" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-extrabold uppercase text-primary",
									children: "Controlled admin action"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-xl font-black",
									children: action.kind === "resolve" ? "Resolve reconciliation" : "Request reversal"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 break-all text-xs text-muted-foreground",
									children: action.item.referenceId
								})
							] })]
						}),
						action.kind === "resolve" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-5 block text-xs font-extrabold",
							children: ["FINAL RESOLUTION", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: resolution,
								onChange: (e) => setResolution(e.target.value),
								className: `${inputClass} mt-2`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "SUCCESS",
									children: "SUCCESS — provider confirmed"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "FAILED",
									children: "FAILED — release/rollback safely"
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs font-extrabold",
								children: ["PROVIDER TXN REF", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: providerTxnRefId,
									onChange: (e) => setProviderTxnRefId(e.target.value),
									className: `${inputClass} mt-2`
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs font-extrabold",
								children: ["RRN", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: rrn,
									onChange: (e) => setRrn(e.target.value),
									className: `${inputClass} mt-2`
								})]
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-4 block text-xs font-extrabold",
							children: [action.kind === "resolve" ? "OPERATOR NOTE" : "REVERSAL REASON", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: note,
								onChange: (e) => setNote(e.target.value),
								rows: 3,
								className: `${inputClass} mt-2 resize-none`,
								placeholder: "Required for the audit trail"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex gap-3 rounded-xl bg-amber-50 p-4 text-xs leading-5 text-amber-900",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {
								size: 18,
								className: "shrink-0"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Confirm provider evidence before continuing. Financial actions are idempotent and audited by the backend." })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy,
								onClick: () => setAction(null),
								className: "rounded-xl border border-border px-4 py-3 text-xs font-extrabold",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								disabled: busy,
								className: `inline-flex items-center gap-2 rounded-xl px-5 py-3 text-xs font-extrabold text-white ${action.kind === "resolve" ? "bg-emerald-600" : "bg-amber-600"}`,
								children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
									size: 14,
									className: "animate-spin"
								}), "Confirm action"]
							})]
						})
					]
				})
			})
		]
	});
}
function Summary({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs font-extrabold uppercase tracking-wider text-muted-foreground",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-2xl font-black text-secondary",
		children: value
	})] });
}
function Status({ value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-full px-2 py-1 text-[10px] font-extrabold ${value === "UNKNOWN" ? "bg-red-50 text-red-700" : "bg-amber-50 text-amber-800"}`,
		children: value
	});
}
function ActionButton({ title, onClick, tone, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		title,
		"aria-label": title,
		onClick,
		className: `rounded-lg border p-2 ${tone === "good" ? "border-emerald-200 text-emerald-700" : tone === "warn" ? "border-amber-200 text-amber-700" : "border-border text-secondary"}`,
		children
	});
}
var $$splitComponentImporter$39 = () => import("./aeps-CCIwkacb.mjs");
var Route$41 = createFileRoute("/distributor/aeps/")({ component: lazyRouteComponent($$splitComponentImporter$39, "component") });
var $$splitComponentImporter$38 = () => import("./balance-enquiry-Bxj0gVck.mjs");
var Route$40 = createFileRoute("/distributor/aeps/balance-enquiry")({ component: lazyRouteComponent($$splitComponentImporter$38, "component") });
var $$splitComponentImporter$37 = () => import("./cash-withdrawal-C-NaXCNh.mjs");
var Route$39 = createFileRoute("/distributor/aeps/cash-withdrawal")({ component: lazyRouteComponent($$splitComponentImporter$37, "component") });
var $$splitComponentImporter$36 = () => import("./mini-statement-DqnNuBxX.mjs");
var Route$38 = createFileRoute("/distributor/aeps/mini-statement")({ component: lazyRouteComponent($$splitComponentImporter$36, "component") });
var $$splitComponentImporter$35 = () => import("./transactions-wAa9ihHB.mjs");
var Route$37 = createFileRoute("/distributor/aeps/transactions")({ component: lazyRouteComponent($$splitComponentImporter$35, "component") });
var $$splitComponentImporter$34 = () => import("./commission-BgbeME8Y.mjs");
var Route$36 = createFileRoute("/distributor/commission/")({ component: lazyRouteComponent($$splitComponentImporter$34, "component") });
var $$splitComponentImporter$33 = () => import("./profile-dzYqfrpr.mjs");
var Route$35 = createFileRoute("/distributor/profile/")({ component: lazyRouteComponent($$splitComponentImporter$33, "component") });
var $$splitComponentImporter$32 = () => import("./bank-B8GwtJz_.mjs");
var Route$34 = createFileRoute("/distributor/profile/bank")({ component: lazyRouteComponent($$splitComponentImporter$32, "component") });
var $$splitComponentImporter$31 = () => import("./kyc-DMFhUCzh2.mjs");
var Route$33 = createFileRoute("/distributor/profile/kyc")({ component: lazyRouteComponent($$splitComponentImporter$31, "component") });
var $$splitComponentImporter$30 = () => import("./reports-B6j23oND.mjs");
var Route$32 = createFileRoute("/distributor/reports/")({ component: lazyRouteComponent($$splitComponentImporter$30, "component") });
var $$splitComponentImporter$29 = () => import("./retailers-BBDaK8iC.mjs");
var Route$31 = createFileRoute("/distributor/retailers/")({ component: lazyRouteComponent($$splitComponentImporter$29, "component") });
var $$splitComponentImporter$28 = () => import("./settings-zIVaMc9M.mjs");
var Route$30 = createFileRoute("/distributor/settings/")({ component: lazyRouteComponent($$splitComponentImporter$28, "component") });
var $$splitComponentImporter$27 = () => import("./support-Dbgrj1sU.mjs");
var Route$29 = createFileRoute("/distributor/support/")({ component: lazyRouteComponent($$splitComponentImporter$27, "component") });
var $$splitComponentImporter$26 = () => import("./wallet-CPRmcJI3.mjs");
var Route$28 = createFileRoute("/distributor/wallet/")({
	head: () => ({ meta: [{ title: "Wallet — Distributor | UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$26, "component")
});
var $$splitComponentImporter$25 = () => import("./transfer-p0Kq6mJh.mjs");
var Route$27 = createFileRoute("/distributor/wallet/transfer")({
	head: () => ({ meta: [{ title: "Transfer Fund — Distributor | UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$25, "component")
});
var $$splitComponentImporter$24 = () => import("./commission-nmdzNI0v.mjs");
var Route$26 = createFileRoute("/master-distributor/commission/")({ component: lazyRouteComponent($$splitComponentImporter$24, "component") });
var $$splitComponentImporter$23 = () => import("./kyc-Cx7W-WoO.mjs");
var Route$25 = createFileRoute("/master-distributor/kyc/")({ component: lazyRouteComponent($$splitComponentImporter$23, "component") });
var $$splitComponentImporter$22 = () => import("./notifications-CGBJau-u.mjs");
var Route$24 = createFileRoute("/master-distributor/notifications/")({ component: lazyRouteComponent($$splitComponentImporter$22, "component") });
var $$splitComponentImporter$21 = () => import("./profile-B1sscRRe.mjs");
var Route$23 = createFileRoute("/master-distributor/profile/")({ component: lazyRouteComponent($$splitComponentImporter$21, "component") });
var $$splitComponentImporter$20 = () => import("./bank-DnYGggVq.mjs");
var Route$22 = createFileRoute("/master-distributor/profile/bank")({ component: lazyRouteComponent($$splitComponentImporter$20, "component") });
var $$splitComponentImporter$19 = () => import("./kyc-DCOZ0GHT.mjs");
var Route$21 = createFileRoute("/master-distributor/profile/kyc")({ component: lazyRouteComponent($$splitComponentImporter$19, "component") });
var $$splitComponentImporter$18 = () => import("./reports-DnFEhugW.mjs");
var Route$20 = createFileRoute("/master-distributor/reports/")({ component: lazyRouteComponent($$splitComponentImporter$18, "component") });
var $$splitComponentImporter$17 = () => import("./settings-1TJJB775.mjs");
var Route$19 = createFileRoute("/master-distributor/settings/")({ component: lazyRouteComponent($$splitComponentImporter$17, "component") });
var $$splitComponentImporter$16 = () => import("./support-B6zfRT0D.mjs");
var Route$18 = createFileRoute("/master-distributor/support/")({ component: lazyRouteComponent($$splitComponentImporter$16, "component") });
var $$splitComponentImporter$15 = () => import("./transactions-CqF2Fs0m.mjs");
var Route$17 = createFileRoute("/master-distributor/transactions/")({ component: lazyRouteComponent($$splitComponentImporter$15, "component") });
var $$splitComponentImporter$14 = () => import("./wallet-CPLVkkns.mjs");
var Route$16 = createFileRoute("/master-distributor/wallet/")({
	head: () => ({ meta: [{ title: "Wallet — Master Distributor | UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$14, "component")
});
var $$splitComponentImporter$13 = () => import("./history-YIB8yXc-.mjs");
var Route$15 = createFileRoute("/master-distributor/wallet/history")({ component: lazyRouteComponent($$splitComponentImporter$13, "component") });
var $$splitComponentImporter$12 = () => import("./requests-DKQtJtRx.mjs");
var Route$14 = createFileRoute("/master-distributor/wallet/requests")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("./transfer-HPS7wErB.mjs");
var Route$13 = createFileRoute("/master-distributor/wallet/transfer")({
	head: () => ({ meta: [{ title: "Transfer Fund — Master Distributor | UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("./aeps-DthBxf-V.mjs");
var Route$12 = createFileRoute("/retailer/aeps/")({
	head: () => ({ meta: [{ title: "VimoPay AEPS — UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var Route$11 = createFileRoute("/retailer/bank/")({
	head: () => ({ meta: [{ title: "Bank Accounts — UMOBIPAY" }] }),
	component: BankAccountsPage
});
var initial = {
	bankName: "",
	ifsc: "",
	branchName: "",
	accountHolderName: "",
	accountNumber: "",
	confirm: "",
	accountType: "SAVINGS",
	purposes: ["PAYOUT"]
};
function BankAccountsPage() {
	const navigate = useNavigate(), [session, setSession] = (0, import_react.useState)(null), [accounts, setAccounts] = (0, import_react.useState)([]), [bankDirectory, setBankDirectory] = (0, import_react.useState)([]), [form, setForm] = (0, import_react.useState)(initial), [adding, setAdding] = (0, import_react.useState)(false), [editingId, setEditingId] = (0, import_react.useState)(null), [busy, setBusy] = (0, import_react.useState)(false), [loading, setLoading] = (0, import_react.useState)(true), [message, setMessage] = (0, import_react.useState)(null);
	async function load(token) {
		setLoading(true);
		try {
			setAccounts(await complianceApi.banks(token));
		} catch (e) {
			setMessage({
				ok: false,
				text: complianceMessage(e)
			});
		} finally {
			setLoading(false);
		}
	}
	async function loadBankDirectory(token) {
		try {
			const response = await complianceApi.bankDirectory(token);
			const root = response && typeof response === "object" ? response : {};
			const candidates = Array.isArray(response) ? response : Array.isArray(root.data) ? root.data : Array.isArray(root.banks) ? root.banks : [];
			setBankDirectory(candidates.map((item) => typeof item === "string" ? item : item && typeof item === "object" ? String(item.bankName || item.name || "") : "").filter(Boolean));
		} catch {
			setBankDirectory([]);
		}
	}
	(0, import_react.useEffect)(() => {
		const value = getSession();
		if (!value) {
			navigate({ to: "/login" });
			return;
		}
		if (credentialsPending(value.identity)) {
			window.location.replace(signedInHome(value));
			return;
		}
		setSession(value);
		setForm((f) => ({
			...f,
			accountHolderName: value.identity.fullName
		}));
		load(value.accessToken);
		loadBankDirectory(value.accessToken);
	}, [navigate]);
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "animate-spin text-primary" })
	});
	const activeSession = session;
	async function submit(e) {
		e.preventDefault();
		setMessage(null);
		if (form.accountNumber && form.accountNumber !== form.confirm) return setMessage({
			ok: false,
			text: "Account numbers do not match."
		});
		if (!form.purposes.length) return setMessage({
			ok: false,
			text: "Select at least one account purpose."
		});
		setBusy(true);
		try {
			const payload = {
				bankName: form.bankName.trim(),
				ifsc: form.ifsc.toUpperCase(),
				branchName: form.branchName || void 0,
				accountHolderName: form.accountHolderName.trim(),
				accountType: form.accountType,
				purposes: form.purposes,
				...form.accountNumber ? { accountNumber: form.accountNumber } : {}
			};
			if (editingId) await complianceApi.updateBank(activeSession.accessToken, editingId, payload);
			else await complianceApi.addBank(activeSession.accessToken, {
				...payload,
				accountNumber: form.accountNumber
			});
			setForm({
				...initial,
				accountHolderName: activeSession.identity.fullName
			});
			setAdding(false);
			setEditingId(null);
			setMessage({
				ok: true,
				text: editingId ? "Bank account updated and sent for verification." : "Bank account verified and added successfully."
			});
			await load(activeSession.accessToken);
		} catch (err) {
			setMessage({
				ok: false,
				text: complianceMessage(err)
			});
		} finally {
			setBusy(false);
		}
	}
	const verified = accounts.some((a) => a.status === "ACTIVE" && a.verificationStatus === "VERIFIED" && a.ownershipStatus === "VERIFIED");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RoleAwareAccountPage, {
		identity: session.identity,
		active: "bank",
		eyebrow: "Settlement & payouts",
		title: "Bank accounts",
		description: "Manage verified settlement accounts independently from KYC and AEPS services.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-[1fr_340px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-border bg-card p-5 shadow-soft sm:p-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-extrabold text-secondary",
							children: "Your bank accounts"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Account details are encrypted; only the last four digits are displayed."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => {
								setEditingId(null);
								setForm({
									...initial,
									accountHolderName: activeSession.identity.fullName
								});
								setAdding(!adding);
							},
							className: "flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 16 }), " Add account"]
						})]
					}),
					message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceNotice, {
							ok: message.ok,
							children: message.text
						})
					}),
					loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-40 place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "animate-spin text-primary" })
					}) : accounts.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 space-y-3",
						children: accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
							className: "rounded-2xl border border-border bg-background p-5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-4 sm:flex-row sm:items-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-12 w-12 place-items-center rounded-xl bg-mint text-secondary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
													className: "font-extrabold text-secondary",
													children: a.bankName
												}), a.isDefault && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "rounded-full bg-primary/10 px-2 py-1 text-[10px] font-bold text-primary",
													children: "PRIMARY"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-1 text-sm text-muted-foreground",
												children: [
													"•••• ",
													a.accountNumberLast4,
													" · ",
													a.accountType,
													" · ",
													a.ifsc
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-xs text-muted-foreground",
												children: a.accountHolderName
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-right",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: `text-xs font-extrabold ${a.verificationStatus === "VERIFIED" ? "text-emerald-600" : "text-amber-600"}`,
												children: a.verificationStatus
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px] text-muted-foreground",
												children: ["Ownership ", a.ownershipStatus]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => {
													setEditingId(a.id);
													setAdding(true);
													setForm({
														bankName: a.bankName,
														ifsc: a.ifsc,
														branchName: a.branchName || "",
														accountHolderName: a.accountHolderName,
														accountNumber: "",
														confirm: "",
														accountType: a.accountType,
														purposes: a.purposes
													});
													setMessage(null);
												},
												className: "mt-2 inline-flex items-center gap-1 text-xs font-bold text-primary",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { size: 12 }), " Edit"]
											}),
											!a.isDefault && a.status === "ACTIVE" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												onClick: async () => {
													try {
														await complianceApi.setPrimary(session.accessToken, a.id);
														await load(session.accessToken);
														setMessage({
															ok: true,
															text: "Primary bank account updated."
														});
													} catch (error) {
														setMessage({
															ok: false,
															text: complianceMessage(error)
														});
													}
												},
												className: "ml-3 mt-2 text-xs font-bold text-primary",
												children: "Set as primary"
											}),
											!a.isDefault && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												onClick: async () => {
													if (!window.confirm(`Remove ${a.bankName} account ending ${a.accountNumberLast4}?`)) return;
													try {
														await complianceApi.deleteBank(session.accessToken, a.id);
														await load(session.accessToken);
														setMessage({
															ok: true,
															text: "Bank account removed."
														});
													} catch (error) {
														setMessage({
															ok: false,
															text: complianceMessage(error)
														});
													}
												},
												className: "ml-3 mt-2 inline-flex items-center gap-1 text-xs font-bold text-red-600",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 12 }), " Remove"]
											})
										]
									})
								]
							})
						}, a.id))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 rounded-2xl border border-dashed border-border p-12 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "mx-auto text-muted-foreground" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 font-bold text-secondary",
								children: "No bank account connected"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: "Add an account to enable settlement and AEPS onboarding."
							})
						]
					}),
					adding && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: submit,
						className: "mt-6 grid gap-4 rounded-2xl border border-border bg-mint/40 p-5 sm:grid-cols-2",
						children: [
							[
								["Bank name", "bankName"],
								["IFSC code", "ifsc"],
								["Branch (optional)", "branchName"],
								["Account holder name", "accountHolderName"],
								["Account number", "accountNumber"],
								["Confirm account number", "confirm"]
							].map(([label, key]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs font-bold uppercase text-muted-foreground",
								children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									list: key === "bankName" ? "supported-bank-directory" : void 0,
									required: key !== "branchName" && (!editingId || !["accountNumber", "confirm"].includes(key)),
									value: form[key],
									onChange: (e) => setForm({
										...form,
										[key]: key === "ifsc" ? e.target.value.toUpperCase().slice(0, 11) : key.includes("accountNumber") || key === "confirm" ? e.target.value.replace(/\D/g, "").slice(0, 18) : e.target.value
									}),
									className: "mt-1.5 w-full rounded-xl border border-border bg-card px-4 py-3 text-sm font-normal normal-case outline-none focus:border-primary"
								})]
							}, key)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
								id: "supported-bank-directory",
								children: bankDirectory.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: name }, name))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs font-bold uppercase text-muted-foreground",
								children: ["Account type", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: form.accountType,
									onChange: (e) => setForm({
										...form,
										accountType: e.target.value
									}),
									className: "mt-1.5 w-full rounded-xl border border-border bg-card px-4 py-3 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "SAVINGS",
											children: "Savings"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "CURRENT",
											children: "Current"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "SALARY",
											children: "Salary"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
								className: "text-xs font-bold uppercase text-muted-foreground",
								children: ["Use account for", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 flex gap-4 rounded-xl border border-border bg-card px-4 py-3 normal-case",
									children: ["PAYOUT", "DMT"].map((purpose) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "checkbox",
												checked: form.purposes.includes(purpose),
												onChange: (event) => setForm({
													...form,
													purposes: event.target.checked ? [...form.purposes, purpose] : form.purposes.filter((item) => item !== purpose)
												})
											}),
											" ",
											purpose
										]
									}, purpose))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: busy,
								className: "self-end rounded-xl bg-secondary py-3 text-sm font-bold text-white disabled:opacity-50",
								children: busy ? "Saving account…" : editingId ? "Save and re-verify" : "Verify and save"
							}),
							editingId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setEditingId(null);
									setAdding(false);
									setForm({
										...initial,
										accountHolderName: activeSession.identity.fullName
									});
								},
								className: "rounded-xl border border-border bg-white py-3 text-sm font-bold text-secondary",
								children: "Cancel edit"
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl bg-secondary p-6 text-white",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 text-lg font-extrabold",
							children: "Bank verification"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-white/65",
							children: "The Bank service validates account status, IFSC and ownership before saving."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-extrabold uppercase text-muted-foreground",
							children: "Next step"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 font-extrabold text-secondary",
							children: "Complete business KYC"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: "KYC is a separate compliance service and can be started after bank verification."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: isManagementRole(session.identity.role) ? `${managementBasePath(session.identity.role)}/profile/kyc` : "/retailer/kyc",
							className: `mt-4 flex items-center justify-center gap-2 rounded-xl py-3 text-sm font-bold ${verified ? "bg-primary text-white" : "pointer-events-none bg-muted text-muted-foreground"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { size: 16 }), " Continue to KYC"]
						})
					]
				})]
			})]
		})
	});
}
var Route$10 = createFileRoute("/retailer/kyc/")({
	head: () => ({ meta: [{ title: "KYC Verification — UMOBIPAY" }] }),
	component: KycPage
});
var docs = [
	{
		type: "PAN_CARD",
		label: "PAN card",
		number: true
	},
	{
		type: "SIGNATURE",
		label: "Signature",
		number: false
	},
	{
		type: "SHOP_FRONT",
		label: "Shop front",
		number: false
	},
	{
		type: "BUSINESS_PROOF",
		label: "Business proof",
		number: true
	}
];
function KycPage() {
	const navigate = useNavigate(), [session, setSession] = (0, import_react.useState)(null), [kyc, setKyc] = (0, import_react.useState)(null), [bundle, setBundle] = (0, import_react.useState)(null), [loading, setLoading] = (0, import_react.useState)(true), [busy, setBusy] = (0, import_react.useState)(""), [message, setMessage] = (0, import_react.useState)(null);
	async function load(token) {
		setLoading(true);
		try {
			const profile = await complianceApi.getKyc(token);
			setKyc(profile);
			setBundle(await complianceApi.bundle(token));
		} catch (error) {
			if (error instanceof ApiError && error.status === 404) {
				setKyc(null);
				setBundle(null);
			} else setMessage({
				ok: false,
				text: `KYC service: ${complianceMessage(error)}`
			});
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		const value = getSession();
		if (!value) {
			navigate({ to: "/login" });
			return;
		}
		if (credentialsPending(value.identity)) {
			window.location.replace(signedInHome(value));
			return;
		}
		setSession(value);
		load(value.accessToken);
	}, [navigate]);
	const uploaded = (0, import_react.useMemo)(() => new Set(bundle?.documents.map((d) => d.documentType) || []), [bundle]);
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "animate-spin text-primary" })
	});
	const activeSession = session;
	async function run(name, task, text) {
		setBusy(name);
		setMessage(null);
		try {
			await task();
			await load(activeSession.accessToken);
			setMessage({
				ok: true,
				text
			});
		} catch (e) {
			setMessage({
				ok: false,
				text: complianceMessage(e)
			});
		} finally {
			setBusy("");
		}
	}
	const editable = !!kyc && (kyc.status === "PENDING" || kyc.status === "REJECTED"), complete = docs.every((d) => uploaded.has(d.type)) && uploaded.has("AADHAAR_FRONT") && uploaded.has("AADHAAR_BACK") && !!bundle?.video;
	const missingItems = [
		...docs.filter((document) => !uploaded.has(document.type)).map((document) => document.label),
		...!uploaded.has("AADHAAR_FRONT") || !uploaded.has("AADHAAR_BACK") ? ["Aadhaar front & back"] : [],
		...!bundle?.video ? ["Verification video"] : []
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RoleAwareAccountPage, {
		identity: session.identity,
		active: "kyc",
		eyebrow: "Identity & compliance",
		title: "KYC verification",
		description: "Submit business documents and track approval status. KYC is the first prerequisite for AEPS.",
		children: [message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceNotice, {
				ok: message.ok,
				children: message.text
			})
		}), loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid h-72 place-items-center rounded-2xl bg-card",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "animate-spin text-primary" })
		}) : !kyc ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "rounded-2xl border border-border bg-card p-8 shadow-soft",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-xl text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-mint text-secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { size: 30 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 text-2xl font-extrabold text-secondary",
						children: "Start business verification"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "Create your KYC application, then upload the required documents securely."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: !!busy,
						onClick: () => run("create", () => complianceApi.createKyc(session.accessToken), "KYC application created."),
						className: "mt-6 rounded-xl bg-secondary px-6 py-3 text-sm font-bold text-white",
						children: "Create KYC application"
					})
				]
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-[1fr_320px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-extrabold uppercase tracking-wider text-primary",
								children: "Application status"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 text-xl font-extrabold text-secondary",
								children: kyc.status.replaceAll("_", " ")
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `rounded-full px-3 py-1.5 text-xs font-extrabold ${kyc.status === "APPROVED" ? "bg-emerald-50 text-emerald-700" : kyc.status === "REJECTED" ? "bg-red-50 text-red-700" : "bg-amber-50 text-amber-700"}`,
								children: kyc.status
							})]
						}), kyc.remarks && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 rounded-xl bg-red-50 p-4 text-sm text-red-700",
							children: ["Reviewer remarks: ", kyc.remarks]
						})]
					}),
					editable && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-extrabold text-secondary",
									children: "1. Business documents"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted-foreground",
									children: "JPEG, PNG or PDF as supported by the KYC service."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-5 grid gap-4 sm:grid-cols-2",
									children: docs.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentCard, {
										label: d.label,
										needNumber: d.number,
										done: uploaded.has(d.type),
										existingNumber: bundle?.documents.find((item) => item.documentType === d.type)?.documentNumber || "",
										disabled: !!busy,
										upload: (file, number) => run(d.type, () => complianceApi.uploadDocument(session.accessToken, d.type, number, file), `${d.label} uploaded.`),
										replace: (file, number) => run(`replace-${d.type}`, () => complianceApi.updateDocument(session.accessToken, d.type, number, file), `${d.label} replaced and queued for verification.`)
									}, d.type))
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AadhaarCard, {
							done: uploaded.has("AADHAAR_FRONT") && uploaded.has("AADHAAR_BACK"),
							disabled: !!busy,
							upload: (number, front, back) => run("aadhaar", () => uploaded.has("AADHAAR_FRONT") || uploaded.has("AADHAAR_BACK") ? complianceApi.updateAadhaar(session.accessToken, number, front, back) : complianceApi.uploadAadhaar(session.accessToken, number, front, back), uploaded.has("AADHAAR_FRONT") || uploaded.has("AADHAAR_BACK") ? "Aadhaar images replaced and queued for verification." : "Aadhaar uploaded.")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, {
							done: !!bundle?.video,
							disabled: !!busy,
							upload: (file) => run("video", () => complianceApi.uploadVideo(session.accessToken, file), "Verification video uploaded.")
						}),
						!complete && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							role: "alert",
							className: "rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-bold",
								children: "Complete these items before final submission:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1",
								children: missingItems.join(", ")
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: !complete || !!busy,
							onClick: () => run("submit", () => complianceApi.submitKyc(session.accessToken), "KYC submitted for review."),
							className: "w-full rounded-xl bg-primary py-4 text-sm font-extrabold text-white disabled:cursor-not-allowed disabled:opacity-40",
							children: "Submit application for review"
						})
					] }),
					kyc.status === "UNDER_REVIEW" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceNotice, {
						ok: true,
						children: "Application submitted. The compliance team is reviewing your documents."
					}),
					kyc.status === "APPROVED" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-2xl bg-secondary p-7 text-white",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FingerprintPattern, { size: 28 }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-4 text-xl font-extrabold",
								children: "KYC approved"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-white/65",
								children: "Your identity prerequisite is ready. Continue to the independent AEPS onboarding service."
							}),
							isManagementRole(session.identity.role) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: managementBasePath(session.identity.role),
								className: "mt-5 inline-flex rounded-xl bg-primary px-5 py-3 text-sm font-bold",
								children: "Return to dashboard"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/retailer/aeps",
								className: "mt-5 inline-flex rounded-xl bg-primary px-5 py-3 text-sm font-bold",
								children: "Continue to AEPS"
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "sticky top-6 space-y-4",
				children: [editable && (bundle?.documents.length || bundle?.video) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-extrabold text-secondary",
						children: "Uploaded files"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 space-y-2",
						children: [bundle.documents.map((document) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 rounded-xl bg-muted p-3 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheckCorner, {
									size: 15,
									className: "text-emerald-600"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "min-w-0 flex-1 truncate font-semibold",
									children: document.documentType.replaceAll("_", " ")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									disabled: !!busy,
									"aria-label": `Delete ${document.documentType}`,
									onClick: () => run(`delete-${document.id}`, () => complianceApi.deleteDocument(session.accessToken, document.id), "Document removed. You can upload a replacement."),
									className: "text-red-600 disabled:opacity-40",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 15 })
								})
							]
						}, document.id)), bundle.video && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2 rounded-xl bg-muted p-3 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {
									size: 15,
									className: "text-emerald-600"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "flex-1 font-semibold",
									children: "Verification video"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									disabled: !!busy,
									"aria-label": "Delete verification video",
									onClick: () => run("delete-video", () => complianceApi.deleteVideo(session.accessToken, bundle.video.id), "Verification video removed."),
									className: "text-red-600 disabled:opacity-40",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 15 })
								})
							]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-extrabold text-secondary",
						children: "Application checklist"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 space-y-3",
						children: [
							...docs.map((d) => [d.label, uploaded.has(d.type)]),
							["Aadhaar front & back", uploaded.has("AADHAAR_FRONT") && uploaded.has("AADHAAR_BACK")],
							["Verification video", !!bundle?.video]
						].map(([label, done]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `grid h-7 w-7 place-items-center rounded-full ${done ? "bg-emerald-50 text-emerald-600" : "bg-muted text-muted-foreground"}`,
								children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheckCorner, { size: 14 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileUp, { size: 14 })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: done ? "font-semibold text-secondary" : "text-muted-foreground",
								children: label
							})]
						}, label))
					})]
				})]
			}) })]
		})]
	});
}
function DocumentCard({ label, needNumber, done, existingNumber, disabled, upload, replace }) {
	const [number, setNumber] = (0, import_react.useState)(existingNumber);
	const [file, setFile] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const submit = () => {
		setError("");
		const value = number.trim().toUpperCase();
		if (needNumber && !value) return setError(`${label} number is required.`);
		if (label === "PAN card" && !/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(value)) return setError("Enter a valid PAN, for example ABCDE1234F.");
		if (!file) return setError(`Select the ${label} file.`);
		if (![
			"application/pdf",
			"image/jpeg",
			"image/png"
		].includes(file.type)) return setError("Only PDF, JPG, JPEG and PNG files are allowed.");
		if (file.size > 10485760) return setError("Document must not exceed 10 MB.");
		if (done) replace(file, value);
		else upload(file, value);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-background p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-bold text-secondary",
					children: label
				}), done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, {
					size: 17,
					className: "text-emerald-600"
				})]
			}),
			needNumber && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: number,
				onChange: (e) => {
					setNumber(e.target.value.toUpperCase());
					setError("");
				},
				placeholder: "Document number",
				className: "mt-3 w-full rounded-lg border border-border bg-card px-3 py-2 text-xs"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				disabled,
				type: "file",
				accept: "image/jpeg,image/png,application/pdf",
				onChange: (e) => {
					setFile(e.target.files?.[0] || null);
					setError("");
				},
				className: "mt-3 block w-full text-xs"
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-2 text-xs font-semibold text-red-600",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled,
				onClick: submit,
				className: "mt-3 w-full rounded-lg bg-secondary px-3 py-2 text-xs font-bold text-white disabled:opacity-50",
				children: disabled ? "Uploading…" : done ? `Replace ${label}` : `Upload ${label}`
			})
		]
	});
}
function VideoCard({ done, disabled, upload }) {
	const [file, setFile] = (0, import_react.useState)(null), [error, setError] = (0, import_react.useState)("");
	const submit = () => {
		setError("");
		if (!file) return setError("Select or record a verification video.");
		if (![
			"video/mp4",
			"video/webm",
			"video/quicktime"
		].includes(file.type)) return setError("Only MP4, WebM and MOV videos are allowed.");
		if (file.size > 104857600) return setError("Video must not exceed 100 MB.");
		upload(file);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-10 w-10 place-items-center rounded-xl bg-mint",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { size: 18 })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-extrabold text-secondary",
					children: ["3. Live verification video ", done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-emerald-600",
						children: "✓"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Record or select an MP4, WebM or MOV video up to 100 MB."
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				disabled: disabled || done,
				type: "file",
				accept: "video/mp4,video/webm,video/quicktime,.mov",
				capture: "user",
				onChange: (e) => {
					setFile(e.target.files?.[0] || null);
					setError("");
				},
				className: "mt-5 block w-full text-sm"
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-2 text-xs font-semibold text-red-600",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled,
				onClick: submit,
				className: "mt-4 rounded-xl bg-secondary px-5 py-2.5 text-sm font-bold text-white disabled:opacity-50",
				children: done ? "Video uploaded" : disabled ? "Uploading…" : "Upload verification video"
			})
		]
	});
}
function AadhaarCard({ done, disabled, upload }) {
	const [number, setNumber] = (0, import_react.useState)(""), [front, setFront] = (0, import_react.useState)(null), [back, setBack] = (0, import_react.useState)(null), [error, setError] = (0, import_react.useState)("");
	const submit = () => {
		setError("");
		if (number.length !== 12) return setError("Enter a valid 12-digit Aadhaar number.");
		if (!front || !back) return setError("Select both Aadhaar front and back images.");
		if (![front, back].every((file) => ["image/jpeg", "image/png"].includes(file.type))) return setError("Aadhaar files must be JPG, JPEG or PNG images.");
		if ([front, back].some((file) => file.size > 5242880)) return setError("Each Aadhaar image must not exceed 5 MB.");
		upload(number, front, back);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "font-extrabold text-secondary",
				children: ["2. Aadhaar verification ", done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-emerald-600",
					children: "✓"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Upload clear front and back images together."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: number,
						onChange: (e) => {
							setNumber(e.target.value.replace(/\D/g, "").slice(0, 12));
							setError("");
						},
						placeholder: "12-digit Aadhaar",
						className: "rounded-xl border border-border px-3 py-2 text-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs font-bold text-muted-foreground",
						children: ["FRONT IMAGE", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/jpeg,image/png",
							onChange: (e) => {
								setFront(e.target.files?.[0] || null);
								setError("");
							},
							className: "mt-2 block w-full font-normal"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs font-bold text-muted-foreground",
						children: ["BACK IMAGE", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/jpeg,image/png",
							onChange: (e) => {
								setBack(e.target.files?.[0] || null);
								setError("");
							},
							className: "mt-2 block w-full font-normal"
						})]
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-3 text-xs font-semibold text-red-600",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				disabled,
				onClick: submit,
				className: "mt-5 rounded-xl bg-secondary px-5 py-2.5 text-sm font-bold text-white disabled:opacity-40",
				children: disabled ? "Uploading…" : done ? "Replace Aadhaar images" : "Upload Aadhaar"
			})
		]
	});
}
var $$splitComponentImporter$9 = () => import("./transactions-C4uEWZ0L.mjs");
var Route$9 = createFileRoute("/retailer/transactions/")({
	head: () => ({ meta: [{ title: "Transaction History — UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("./wallet-CqNSgtyB.mjs");
var Route$8 = createFileRoute("/retailer/wallet/")({
	head: () => ({ meta: [{ title: "Wallet — Retailer | UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./transfer-CA0B8QiC.mjs");
var Route$7 = createFileRoute("/retailer/wallet/transfer")({
	head: () => ({ meta: [{ title: "Transfer Fund — Retailer | UMOBIPAY" }] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./add-tM4L44O0.mjs");
var Route$6 = createFileRoute("/admin/merchants/add/")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./list-DgIsCt2E.mjs");
var Route$5 = createFileRoute("/admin/merchants/list/")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./add-DeGd-DCf.mjs");
var Route$4 = createFileRoute("/distributor/retailers/add/")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./distributors-Sb3Iq6Yz.mjs");
var Route$3 = createFileRoute("/master-distributor/network/distributors/")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./retailers-Ig4zfK2X.mjs");
var Route$2 = createFileRoute("/master-distributor/network/retailers/")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./tree-CkQbM2qa.mjs");
var Route$1 = createFileRoute("/master-distributor/network/tree/")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./add-vzsZUtkB.mjs");
var Route = createFileRoute("/master-distributor/network/distributors/add/")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var IndexRoute = Route$83.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$84
});
var AboutRoute = Route$82.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$84
});
var ActivityRoute = Route$81.update({
	id: "/activity",
	path: "/activity",
	getParentRoute: () => Route$84
});
var ContactRoute = Route$80.update({
	id: "/contact",
	path: "/contact",
	getParentRoute: () => Route$84
});
var ForgotPasswordRoute = Route$79.update({
	id: "/forgot-password",
	path: "/forgot-password",
	getParentRoute: () => Route$84
});
var LoginRoute = Route$78.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$84
});
var PrivacyRoute = Route$77.update({
	id: "/privacy",
	path: "/privacy",
	getParentRoute: () => Route$84
});
var RefundPolicyRoute = Route$76.update({
	id: "/refund-policy",
	path: "/refund-policy",
	getParentRoute: () => Route$84
});
var RegisterRoute = Route$75.update({
	id: "/register",
	path: "/register",
	getParentRoute: () => Route$84
});
var ServicesRoute = Route$74.update({
	id: "/services",
	path: "/services",
	getParentRoute: () => Route$84
});
var TermsRoute = Route$73.update({
	id: "/terms",
	path: "/terms",
	getParentRoute: () => Route$84
});
var AdminIndexRoute = Route$72.update({
	id: "/admin/",
	path: "/admin/",
	getParentRoute: () => Route$84
});
var AdminAccountSetupRoute = Route$71.update({
	id: "/admin/account-setup",
	path: "/admin/account-setup",
	getParentRoute: () => Route$84
});
var AdminLoginRoute = Route$70.update({
	id: "/admin/login",
	path: "/admin/login",
	getParentRoute: () => Route$84
});
var AdminOnboardingRoute = Route$69.update({
	id: "/admin/onboarding",
	path: "/admin/onboarding",
	getParentRoute: () => Route$84
});
var DistributorIndexRoute = Route$68.update({
	id: "/distributor/",
	path: "/distributor/",
	getParentRoute: () => Route$84
});
var DistributorSplatRoute = Route$67.update({
	id: "/distributor/$",
	path: "/distributor/$",
	getParentRoute: () => Route$84
});
var DistributorAccountSetupRoute = Route$66.update({
	id: "/distributor/account-setup",
	path: "/distributor/account-setup",
	getParentRoute: () => Route$84
});
var DistributorDashboardRoute = Route$65.update({
	id: "/distributor/dashboard",
	path: "/distributor/dashboard",
	getParentRoute: () => Route$84
});
var MasterDistributorIndexRoute = Route$64.update({
	id: "/master-distributor/",
	path: "/master-distributor/",
	getParentRoute: () => Route$84
});
var MasterDistributorSplatRoute = Route$63.update({
	id: "/master-distributor/$",
	path: "/master-distributor/$",
	getParentRoute: () => Route$84
});
var MasterDistributorAccountSetupRoute = Route$62.update({
	id: "/master-distributor/account-setup",
	path: "/master-distributor/account-setup",
	getParentRoute: () => Route$84
});
var MasterDistributorDashboardRoute = Route$61.update({
	id: "/master-distributor/dashboard",
	path: "/master-distributor/dashboard",
	getParentRoute: () => Route$84
});
var RetailerAccountSetupRoute = Route$60.update({
	id: "/retailer/account-setup",
	path: "/retailer/account-setup",
	getParentRoute: () => Route$84
});
var RetailerDashboardRoute = Route$59.update({
	id: "/retailer/dashboard",
	path: "/retailer/dashboard",
	getParentRoute: () => Route$84
});
var RetailerSettingsRoute = Route$58.update({
	id: "/retailer/settings",
	path: "/retailer/settings",
	getParentRoute: () => Route$84
});
var AdminAccessIndexRoute = Route$57.update({
	id: "/admin/access/",
	path: "/admin/access/",
	getParentRoute: () => Route$84
});
var AdminApiSettingsIndexRoute = Route$56.update({
	id: "/admin/api-settings/",
	path: "/admin/api-settings/",
	getParentRoute: () => Route$84
});
var AdminBankingIndexRoute = Route$55.update({
	id: "/admin/banking/",
	path: "/admin/banking/",
	getParentRoute: () => Route$84
});
var AdminCommissionsIndexRoute = Route$54.update({
	id: "/admin/commissions/",
	path: "/admin/commissions/",
	getParentRoute: () => Route$84
});
var AdminCommissionsHierarchyRoute = Route$53.update({
	id: "/admin/commissions/hierarchy",
	path: "/admin/commissions/hierarchy",
	getParentRoute: () => Route$84
});
var AdminKycIndexRoute = Route$52.update({
	id: "/admin/kyc/",
	path: "/admin/kyc/",
	getParentRoute: () => Route$84
});
var AdminLegalIndexRoute = Route$51.update({
	id: "/admin/legal/",
	path: "/admin/legal/",
	getParentRoute: () => Route$84
});
var AdminMerchantsIndexRoute = Route$50.update({
	id: "/admin/merchants/",
	path: "/admin/merchants/",
	getParentRoute: () => Route$84
});
var AdminProfileIndexRoute = Route$49.update({
	id: "/admin/profile/",
	path: "/admin/profile/",
	getParentRoute: () => Route$84
});
var AdminProfileBankRoute = Route$48.update({
	id: "/admin/profile/bank",
	path: "/admin/profile/bank",
	getParentRoute: () => Route$84
});
var AdminProfileKycRoute = Route$47.update({
	id: "/admin/profile/kyc",
	path: "/admin/profile/kyc",
	getParentRoute: () => Route$84
});
var AdminReportsIndexRoute = Route$46.update({
	id: "/admin/reports/",
	path: "/admin/reports/",
	getParentRoute: () => Route$84
});
var AdminSettingsIndexRoute = Route$45.update({
	id: "/admin/settings/",
	path: "/admin/settings/",
	getParentRoute: () => Route$84
});
var AdminSettlementsIndexRoute = Route$44.update({
	id: "/admin/settlements/",
	path: "/admin/settlements/",
	getParentRoute: () => Route$84
});
var AdminSmsIndexRoute = Route$43.update({
	id: "/admin/sms/",
	path: "/admin/sms/",
	getParentRoute: () => Route$84
});
var AdminTransactionsIndexRoute = Route$42.update({
	id: "/admin/transactions/",
	path: "/admin/transactions/",
	getParentRoute: () => Route$84
});
var DistributorAepsIndexRoute = Route$41.update({
	id: "/distributor/aeps/",
	path: "/distributor/aeps/",
	getParentRoute: () => Route$84
});
var DistributorAepsBalanceEnquiryRoute = Route$40.update({
	id: "/distributor/aeps/balance-enquiry",
	path: "/distributor/aeps/balance-enquiry",
	getParentRoute: () => Route$84
});
var DistributorAepsCashWithdrawalRoute = Route$39.update({
	id: "/distributor/aeps/cash-withdrawal",
	path: "/distributor/aeps/cash-withdrawal",
	getParentRoute: () => Route$84
});
var DistributorAepsMiniStatementRoute = Route$38.update({
	id: "/distributor/aeps/mini-statement",
	path: "/distributor/aeps/mini-statement",
	getParentRoute: () => Route$84
});
var DistributorAepsTransactionsRoute = Route$37.update({
	id: "/distributor/aeps/transactions",
	path: "/distributor/aeps/transactions",
	getParentRoute: () => Route$84
});
var DistributorCommissionIndexRoute = Route$36.update({
	id: "/distributor/commission/",
	path: "/distributor/commission/",
	getParentRoute: () => Route$84
});
var DistributorProfileIndexRoute = Route$35.update({
	id: "/distributor/profile/",
	path: "/distributor/profile/",
	getParentRoute: () => Route$84
});
var DistributorProfileBankRoute = Route$34.update({
	id: "/distributor/profile/bank",
	path: "/distributor/profile/bank",
	getParentRoute: () => Route$84
});
var DistributorProfileKycRoute = Route$33.update({
	id: "/distributor/profile/kyc",
	path: "/distributor/profile/kyc",
	getParentRoute: () => Route$84
});
var DistributorReportsIndexRoute = Route$32.update({
	id: "/distributor/reports/",
	path: "/distributor/reports/",
	getParentRoute: () => Route$84
});
var DistributorRetailersIndexRoute = Route$31.update({
	id: "/distributor/retailers/",
	path: "/distributor/retailers/",
	getParentRoute: () => Route$84
});
var DistributorSettingsIndexRoute = Route$30.update({
	id: "/distributor/settings/",
	path: "/distributor/settings/",
	getParentRoute: () => Route$84
});
var DistributorSupportIndexRoute = Route$29.update({
	id: "/distributor/support/",
	path: "/distributor/support/",
	getParentRoute: () => Route$84
});
var DistributorWalletIndexRoute = Route$28.update({
	id: "/distributor/wallet/",
	path: "/distributor/wallet/",
	getParentRoute: () => Route$84
});
var DistributorWalletTransferRoute = Route$27.update({
	id: "/distributor/wallet/transfer",
	path: "/distributor/wallet/transfer",
	getParentRoute: () => Route$84
});
var MasterDistributorCommissionIndexRoute = Route$26.update({
	id: "/master-distributor/commission/",
	path: "/master-distributor/commission/",
	getParentRoute: () => Route$84
});
var MasterDistributorKycIndexRoute = Route$25.update({
	id: "/master-distributor/kyc/",
	path: "/master-distributor/kyc/",
	getParentRoute: () => Route$84
});
var MasterDistributorNotificationsIndexRoute = Route$24.update({
	id: "/master-distributor/notifications/",
	path: "/master-distributor/notifications/",
	getParentRoute: () => Route$84
});
var MasterDistributorProfileIndexRoute = Route$23.update({
	id: "/master-distributor/profile/",
	path: "/master-distributor/profile/",
	getParentRoute: () => Route$84
});
var MasterDistributorProfileBankRoute = Route$22.update({
	id: "/master-distributor/profile/bank",
	path: "/master-distributor/profile/bank",
	getParentRoute: () => Route$84
});
var MasterDistributorProfileKycRoute = Route$21.update({
	id: "/master-distributor/profile/kyc",
	path: "/master-distributor/profile/kyc",
	getParentRoute: () => Route$84
});
var MasterDistributorReportsIndexRoute = Route$20.update({
	id: "/master-distributor/reports/",
	path: "/master-distributor/reports/",
	getParentRoute: () => Route$84
});
var MasterDistributorSettingsIndexRoute = Route$19.update({
	id: "/master-distributor/settings/",
	path: "/master-distributor/settings/",
	getParentRoute: () => Route$84
});
var MasterDistributorSupportIndexRoute = Route$18.update({
	id: "/master-distributor/support/",
	path: "/master-distributor/support/",
	getParentRoute: () => Route$84
});
var MasterDistributorTransactionsIndexRoute = Route$17.update({
	id: "/master-distributor/transactions/",
	path: "/master-distributor/transactions/",
	getParentRoute: () => Route$84
});
var MasterDistributorWalletIndexRoute = Route$16.update({
	id: "/master-distributor/wallet/",
	path: "/master-distributor/wallet/",
	getParentRoute: () => Route$84
});
var MasterDistributorWalletHistoryRoute = Route$15.update({
	id: "/master-distributor/wallet/history",
	path: "/master-distributor/wallet/history",
	getParentRoute: () => Route$84
});
var MasterDistributorWalletRequestsRoute = Route$14.update({
	id: "/master-distributor/wallet/requests",
	path: "/master-distributor/wallet/requests",
	getParentRoute: () => Route$84
});
var MasterDistributorWalletTransferRoute = Route$13.update({
	id: "/master-distributor/wallet/transfer",
	path: "/master-distributor/wallet/transfer",
	getParentRoute: () => Route$84
});
var RetailerAepsIndexRoute = Route$12.update({
	id: "/retailer/aeps/",
	path: "/retailer/aeps/",
	getParentRoute: () => Route$84
});
var RetailerBankIndexRoute = Route$11.update({
	id: "/retailer/bank/",
	path: "/retailer/bank/",
	getParentRoute: () => Route$84
});
var RetailerKycIndexRoute = Route$10.update({
	id: "/retailer/kyc/",
	path: "/retailer/kyc/",
	getParentRoute: () => Route$84
});
var RetailerTransactionsIndexRoute = Route$9.update({
	id: "/retailer/transactions/",
	path: "/retailer/transactions/",
	getParentRoute: () => Route$84
});
var RetailerWalletIndexRoute = Route$8.update({
	id: "/retailer/wallet/",
	path: "/retailer/wallet/",
	getParentRoute: () => Route$84
});
var rootRouteChildren = {
	IndexRoute,
	AboutRoute,
	ActivityRoute,
	ContactRoute,
	ForgotPasswordRoute,
	LoginRoute,
	PrivacyRoute,
	RefundPolicyRoute,
	RegisterRoute,
	ServicesRoute,
	TermsRoute,
	AdminAccountSetupRoute,
	AdminLoginRoute,
	AdminOnboardingRoute,
	DistributorSplatRoute,
	DistributorAccountSetupRoute,
	DistributorDashboardRoute,
	MasterDistributorSplatRoute,
	MasterDistributorAccountSetupRoute,
	MasterDistributorDashboardRoute,
	RetailerAccountSetupRoute,
	RetailerDashboardRoute,
	RetailerSettingsRoute,
	AdminIndexRoute,
	DistributorIndexRoute,
	MasterDistributorIndexRoute,
	AdminCommissionsHierarchyRoute,
	AdminProfileBankRoute,
	AdminProfileKycRoute,
	DistributorAepsBalanceEnquiryRoute,
	DistributorAepsCashWithdrawalRoute,
	DistributorAepsMiniStatementRoute,
	DistributorAepsTransactionsRoute,
	DistributorProfileBankRoute,
	DistributorProfileKycRoute,
	DistributorWalletTransferRoute,
	MasterDistributorProfileBankRoute,
	MasterDistributorProfileKycRoute,
	MasterDistributorWalletHistoryRoute,
	MasterDistributorWalletRequestsRoute,
	MasterDistributorWalletTransferRoute,
	RetailerWalletTransferRoute: Route$7.update({
		id: "/retailer/wallet/transfer",
		path: "/retailer/wallet/transfer",
		getParentRoute: () => Route$84
	}),
	AdminAccessIndexRoute,
	AdminApiSettingsIndexRoute,
	AdminBankingIndexRoute,
	AdminCommissionsIndexRoute,
	AdminKycIndexRoute,
	AdminLegalIndexRoute,
	AdminMerchantsIndexRoute,
	AdminProfileIndexRoute,
	AdminReportsIndexRoute,
	AdminSettingsIndexRoute,
	AdminSettlementsIndexRoute,
	AdminSmsIndexRoute,
	AdminTransactionsIndexRoute,
	DistributorAepsIndexRoute,
	DistributorCommissionIndexRoute,
	DistributorProfileIndexRoute,
	DistributorReportsIndexRoute,
	DistributorRetailersIndexRoute,
	DistributorSettingsIndexRoute,
	DistributorSupportIndexRoute,
	DistributorWalletIndexRoute,
	MasterDistributorCommissionIndexRoute,
	MasterDistributorKycIndexRoute,
	MasterDistributorNotificationsIndexRoute,
	MasterDistributorProfileIndexRoute,
	MasterDistributorReportsIndexRoute,
	MasterDistributorSettingsIndexRoute,
	MasterDistributorSupportIndexRoute,
	MasterDistributorTransactionsIndexRoute,
	MasterDistributorWalletIndexRoute,
	RetailerAepsIndexRoute,
	RetailerBankIndexRoute,
	RetailerKycIndexRoute,
	RetailerTransactionsIndexRoute,
	RetailerWalletIndexRoute,
	AdminMerchantsAddIndexRoute: Route$6.update({
		id: "/admin/merchants/add/",
		path: "/admin/merchants/add/",
		getParentRoute: () => Route$84
	}),
	AdminMerchantsListIndexRoute: Route$5.update({
		id: "/admin/merchants/list/",
		path: "/admin/merchants/list/",
		getParentRoute: () => Route$84
	}),
	DistributorRetailersAddIndexRoute: Route$4.update({
		id: "/distributor/retailers/add/",
		path: "/distributor/retailers/add/",
		getParentRoute: () => Route$84
	}),
	MasterDistributorNetworkDistributorsIndexRoute: Route$3.update({
		id: "/master-distributor/network/distributors/",
		path: "/master-distributor/network/distributors/",
		getParentRoute: () => Route$84
	}),
	MasterDistributorNetworkRetailersIndexRoute: Route$2.update({
		id: "/master-distributor/network/retailers/",
		path: "/master-distributor/network/retailers/",
		getParentRoute: () => Route$84
	}),
	MasterDistributorNetworkTreeIndexRoute: Route$1.update({
		id: "/master-distributor/network/tree/",
		path: "/master-distributor/network/tree/",
		getParentRoute: () => Route$84
	}),
	MasterDistributorNetworkDistributorsAddIndexRoute: Route.update({
		id: "/master-distributor/network/distributors/add/",
		path: "/master-distributor/network/distributors/add/",
		getParentRoute: () => Route$84
	})
};
var routeTree = Route$84._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { router_BahmeVh9_exports as S, Route$52 as _, BankAccountsPage as a, Route$56 as b, KycPage as c, Profile as d, Route$43 as f, Route$51 as g, Route$5 as h, AdminSettings as i, MasterDashboard as l, Route$46 as m, AdminDashboard as n, CreateMemberPage as o, Route$44 as p, AdminIdentitySetup as r, DistributorDashboard as s, Access as t, MemberManagementOverview as u, Route$54 as v, Transactions as x, Route$55 as y };
