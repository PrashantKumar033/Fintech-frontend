import { o as MasterDashboard } from "./router-B644QERq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/master-distributor-B86bkdxq.js
var SplitComponent = MasterDashboard;
//#endregion
export { SplitComponent as component };
