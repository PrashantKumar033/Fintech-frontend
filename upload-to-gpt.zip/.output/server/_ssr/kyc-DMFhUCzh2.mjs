import { c as KycPage } from "./router-BahmeVh9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kyc-DMFhUCzh2.js
var SplitComponent = KycPage;
//#endregion
export { SplitComponent as component };
