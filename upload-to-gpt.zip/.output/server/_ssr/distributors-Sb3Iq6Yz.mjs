import { r as __toESM } from "../_runtime.mjs";
import { s as getSession } from "./auth-api-CJcoiRrI.mjs";
import { i as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { J as Network, u as UserPlus } from "../_libs/lucide-react.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-CMM4oD2x.mjs";
import { t as masterDistributorApi } from "./master-distributor-api-HgOsfLe7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/distributors-Sb3Iq6Yz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Distributors() {
	const s = getSession(), [rows, setRows] = (0, import_react.useState)([]), [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (s) masterDistributorApi.distributors(s.identity.id).then((v) => setRows(Array.isArray(v) ? v : [])).catch((e) => setError(e instanceof Error ? e.message : "Network unavailable."));
	}, [s?.identity.id]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "merchants",
		eyebrow: "Network",
		title: "Distributor management",
		description: "View and create direct Distributors under this Master Distributor.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-5 flex justify-end",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				href: "/master-distributor/network/distributors/add",
				className: "flex items-center gap-2 rounded-xl bg-primary px-4 py-3 text-sm font-bold text-white",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { size: 17 }), "Add Distributor"]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 rounded-xl bg-red-50 p-3 text-sm text-red-700",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3 rounded-xl border border-border p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Network, { className: "text-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-black",
							children: r.childUserId || r.id
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: r.serviceType || "All services"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-auto text-xs font-bold",
							children: r.isActive === false ? "INACTIVE" : "ACTIVE"
						})
					]
				}, r.id || i)), !rows.length && !error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-10 text-center text-sm text-muted-foreground",
					children: "No direct Distributor hierarchy records found."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 rounded-xl bg-muted p-3 text-xs text-muted-foreground",
				children: "Full profile, KYC, wallet and Retailer count require protected child-detail aggregation APIs."
			})
		] })]
	});
}
//#endregion
export { Distributors as component };
