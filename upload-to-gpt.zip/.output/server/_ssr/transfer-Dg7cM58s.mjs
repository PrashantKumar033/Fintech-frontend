import { r as __toESM } from "../_runtime.mjs";
import { a as credentialsPending, c as getSession, m as normalizeRole, t as ApiError, y as signedInHome } from "./role-hierarchy-B8AZOwBW.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as ShieldCheck, L as RefreshCw, Xt as CircleAlert, Yt as CircleCheck, bt as IndianRupee, dt as LoaderCircle, f as UserRoundCheck, hn as ArrowRightLeft, mn as ArrowRight, o as WalletCards } from "../_libs/lucide-react.mjs";
import { a as useEffectiveAccess, r as UI_PERMISSION } from "./section-tabs-DXmZfcpC.mjs";
import { t as ActionPermissionNotice } from "./action-permission-notice-CGOJQx-x.mjs";
import { t as BusinessPage } from "./business-page-BafQTwce.mjs";
import { n as operationsApi, r as operationsMessage, t as newTransferIdempotencyKey } from "./operations-api-DCS6pUHX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/transfer-Dg7cM58s.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var inr = new Intl.NumberFormat("en-IN", {
	style: "currency",
	currency: "INR",
	minimumFractionDigits: 2
});
function normaliseAmountInput(value) {
	const cleaned = value.replace(/[^0-9.]/g, "");
	const firstDot = cleaned.indexOf(".");
	if (firstDot === -1) return cleaned.replace(/^0+(?=\d)/, "");
	return `${cleaned.slice(0, firstDot).replace(/^0+(?=\d)/, "") || "0"}.${cleaned.slice(firstDot + 1).replace(/\./g, "").slice(0, 2)}`;
}
function RetailerWalletTransferPage() {
	const navigate = useNavigate();
	const session = getSession();
	const { can } = useEffectiveAccess();
	const canTransfer = can(UI_PERMISSION.WALLET_TRANSFER, ["RETAILER"]);
	const [balances, setBalances] = (0, import_react.useState)(null);
	const [receiverLoginId, setReceiverLoginId] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [loadingBalance, setLoadingBalance] = (0, import_react.useState)(true);
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const [review, setReview] = (0, import_react.useState)(null);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [result, setResult] = (0, import_react.useState)(null);
	const idempotencyKeyRef = (0, import_react.useRef)(null);
	const mainBalance = Number(balances?.wallets.main ?? 0);
	const numericAmount = Number(amount);
	const receiver = receiverLoginId.trim().toUpperCase();
	const selfLoginId = session?.identity.loginId?.trim().toUpperCase() ?? "";
	const amountAfterTransfer = (0, import_react.useMemo)(() => {
		if (!Number.isFinite(numericAmount) || numericAmount <= 0) return mainBalance;
		return Math.max(0, mainBalance - numericAmount);
	}, [mainBalance, numericAmount]);
	async function loadBalance() {
		if (!session) return;
		setLoadingBalance(true);
		try {
			setBalances(await operationsApi.balances(session.accessToken, session.identity.id));
		} catch (error) {
			setNotice({
				ok: false,
				text: operationsMessage(error)
			});
		} finally {
			setLoadingBalance(false);
		}
	}
	(0, import_react.useEffect)(() => {
		if (!session) {
			navigate({ to: "/login" });
			return;
		}
		if (normalizeRole(session.identity.role) !== "RETAILER") {
			window.location.replace(signedInHome(session));
			return;
		}
		if (credentialsPending(session.identity)) {
			window.location.replace(signedInHome(session));
			return;
		}
		loadBalance();
	}, [navigate, session?.identity.id]);
	function resetTransfer() {
		setReceiverLoginId("");
		setAmount("");
		setReview(null);
		setResult(null);
		setNotice(null);
		idempotencyKeyRef.current = null;
	}
	function validateDraft() {
		if (!receiver) {
			setNotice({
				ok: false,
				text: "Enter the receiver Retailer login ID."
			});
			return null;
		}
		if (receiver.length < 3 || receiver.length > 50) {
			setNotice({
				ok: false,
				text: "Receiver login ID must be between 3 and 50 characters."
			});
			return null;
		}
		if (receiver === selfLoginId) {
			setNotice({
				ok: false,
				text: "You cannot transfer money to your own wallet."
			});
			return null;
		}
		if (!amount.trim() || !Number.isFinite(numericAmount) || numericAmount < .01) {
			setNotice({
				ok: false,
				text: "Enter a valid amount of at least ₹0.01."
			});
			return null;
		}
		if (!/^\d+(?:\.\d{1,2})?$/.test(amount)) {
			setNotice({
				ok: false,
				text: "Amount can have a maximum of 2 decimal places."
			});
			return null;
		}
		if (numericAmount > mainBalance) {
			setNotice({
				ok: false,
				text: `Insufficient MAIN wallet balance. Available balance is ${inr.format(mainBalance)}.`
			});
			return null;
		}
		return {
			receiverLoginId: receiver,
			amount: numericAmount
		};
	}
	function reviewTransfer(event) {
		event.preventDefault();
		setNotice(null);
		setResult(null);
		const draft = validateDraft();
		if (!draft) return;
		idempotencyKeyRef.current = null;
		setReview(draft);
	}
	async function confirmTransfer() {
		if (!session || !review || submitting) return;
		if (!canTransfer) {
			setNotice({
				ok: false,
				text: `Permission ${UI_PERMISSION.WALLET_TRANSFER} is required.`
			});
			return;
		}
		setSubmitting(true);
		setNotice(null);
		if (!idempotencyKeyRef.current) idempotencyKeyRef.current = newTransferIdempotencyKey();
		try {
			const response = await operationsApi.transfer(session.accessToken, {
				receiverLoginId: review.receiverLoginId,
				amount: review.amount
			}, idempotencyKeyRef.current);
			setResult(response);
			setReview(null);
			setReceiverLoginId("");
			setAmount("");
			idempotencyKeyRef.current = null;
			setNotice({
				ok: true,
				text: response.duplicate ? "This transfer was already completed earlier. No second debit was made." : "Transfer completed successfully."
			});
			await loadBalance();
		} catch (error) {
			setNotice({
				ok: false,
				text: operationsMessage(error)
			});
			if (!(error instanceof ApiError && (error.status === 0 || error.status >= 500))) idempotencyKeyRef.current = null;
		} finally {
			setSubmitting(false);
		}
	}
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center bg-[#f5f8f8]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin text-primary" })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BusinessPage, {
		identity: session.identity,
		active: "wallet",
		eyebrow: "Wallet service",
		title: "Transfer fund",
		description: "Send money securely from your MAIN wallet to another active Retailer account.",
		children: [
			!canTransfer && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionPermissionNotice, {
					permission: UI_PERMISSION.WALLET_TRANSFER,
					title: "Wallet transfer is not enabled"
				})
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "status",
				className: `mb-5 flex items-start gap-3 rounded-2xl border p-4 text-sm ${notice.ok ? "border-emerald-200 bg-emerald-50 text-emerald-800" : "border-red-200 bg-red-50 text-red-800"}`,
				children: [notice.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
					className: "mt-0.5 shrink-0",
					size: 19
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, {
					className: "mt-0.5 shrink-0",
					size: 19
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-semibold leading-6",
					children: notice.text
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 xl:grid-cols-[minmax(0,1fr)_360px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-12 w-12 place-items-center rounded-2xl bg-primary/10 text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletCards, { size: 22 })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-extrabold uppercase tracking-[.12em] text-muted-foreground",
									children: "Available MAIN wallet"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-3xl font-black text-secondary",
									children: loadingBalance ? "—" : inr.format(mainBalance)
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => void loadBalance(),
								disabled: !canTransfer || loadingBalance || submitting,
								className: "inline-flex items-center justify-center gap-2 rounded-xl border border-border bg-white px-4 py-2.5 text-sm font-extrabold text-secondary transition hover:bg-muted disabled:cursor-not-allowed disabled:opacity-50",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
									className: loadingBalance ? "animate-spin" : "",
									size: 16
								}), "Refresh balance"]
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRightLeft, { size: 20 })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-xl font-black text-secondary",
									children: "Retailer to Retailer"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm leading-6 text-muted-foreground",
									children: "Enter the receiver's Retailer login ID. Your backend validates the receiver role and account status before any debit happens."
								})] })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: reviewTransfer,
								className: "mt-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-5 md:grid-cols-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-extrabold uppercase tracking-[.08em] text-muted-foreground",
													children: "Receiver login ID"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "text",
													value: receiverLoginId,
													onChange: (event) => {
														setReceiverLoginId(event.target.value.toUpperCase().slice(0, 50));
														setReview(null);
														setResult(null);
													},
													autoComplete: "off",
													autoCapitalize: "characters",
													spellCheck: false,
													minLength: 3,
													maxLength: 50,
													placeholder: "Enter Retailer login ID",
													disabled: !canTransfer || submitting,
													className: "mt-2 w-full rounded-xl border border-border bg-background px-4 py-3.5 text-sm font-semibold uppercase outline-none transition placeholder:normal-case placeholder:font-normal focus:border-primary focus:ring-4 focus:ring-primary/10 disabled:cursor-not-allowed disabled:opacity-60"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mt-2 block text-xs text-muted-foreground",
													children: "Only an active Retailer account can receive this transfer."
												})
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "block",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs font-extrabold uppercase tracking-[.08em] text-muted-foreground",
													children: "Amount"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "relative mt-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndianRupee, {
														size: 17,
														className: "pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														type: "text",
														inputMode: "decimal",
														value: amount,
														onChange: (event) => {
															setAmount(normaliseAmountInput(event.target.value));
															setReview(null);
															setResult(null);
														},
														placeholder: "0.00",
														disabled: !canTransfer || submitting,
														className: "w-full rounded-xl border border-border bg-background py-3.5 pl-10 pr-4 text-sm font-semibold outline-none transition focus:border-primary focus:ring-4 focus:ring-primary/10 disabled:cursor-not-allowed disabled:opacity-60"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "mt-2 block text-xs text-muted-foreground",
													children: "Transfer uses the MAIN wallet only. Minimum amount is ₹0.01."
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-5 rounded-2xl bg-muted/70 p-4",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center justify-between gap-3 text-sm",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-semibold text-muted-foreground",
												children: "Balance after transfer"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "font-black text-secondary",
												children: loadingBalance ? "—" : inr.format(amountAfterTransfer)
											})]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "submit",
										disabled: !canTransfer || loadingBalance || submitting,
										className: "mt-5 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3.5 text-sm font-extrabold text-white shadow-md shadow-primary/20 transition hover:brightness-95 disabled:cursor-not-allowed disabled:opacity-50",
										children: ["Review transfer", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 17 })]
									})
								]
							}),
							review && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 rounded-2xl border-2 border-primary/20 bg-primary/[0.035] p-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
											className: "mt-0.5 shrink-0 text-primary",
											size: 22
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-lg font-black text-secondary",
											children: "Confirm transfer"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-sm leading-6 text-muted-foreground",
											children: "Check the details carefully. A successful wallet transfer is posted immediately."
										})] })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
										className: "mt-5 divide-y divide-border rounded-xl border border-border bg-white px-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between gap-4 py-3.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
													className: "text-sm text-muted-foreground",
													children: "From"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
													className: "text-right text-sm font-extrabold text-secondary",
													children: selfLoginId
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between gap-4 py-3.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
													className: "text-sm text-muted-foreground",
													children: "To Retailer"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
													className: "text-right text-sm font-extrabold text-secondary",
													children: review.receiverLoginId
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between gap-4 py-3.5",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
													className: "text-sm text-muted-foreground",
													children: "Amount"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
													className: "text-right text-base font-black text-secondary",
													children: inr.format(review.amount)
												})]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-5 grid gap-3 sm:grid-cols-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => {
												setReview(null);
												idempotencyKeyRef.current = null;
											},
											disabled: !canTransfer || submitting,
											className: "rounded-xl border border-border bg-white px-5 py-3.5 text-sm font-extrabold text-secondary transition hover:bg-muted disabled:cursor-not-allowed disabled:opacity-50",
											children: "Edit details"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => void confirmTransfer(),
											disabled: !canTransfer || submitting,
											className: "inline-flex items-center justify-center gap-2 rounded-xl bg-secondary px-5 py-3.5 text-sm font-extrabold text-white transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50",
											children: submitting ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
												className: "animate-spin",
												size: 17
											}), "Processing..."] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 17 }), "Confirm & transfer"] })
										})]
									})
								]
							}),
							result && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-6 rounded-2xl border border-emerald-200 bg-emerald-50 p-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-start gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
											className: "mt-0.5 shrink-0 text-emerald-700",
											size: 22
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "min-w-0",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
												className: "text-lg font-black text-emerald-900",
												children: "Transfer successful"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-1 text-sm text-emerald-800",
												children: [
													"Reference:",
													" ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "break-all font-extrabold",
														children: result.transferReference
													})
												]
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-4 grid gap-3 sm:grid-cols-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-xl bg-white/75 p-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-bold uppercase text-emerald-800/70",
												children: "Debited"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-xl font-black text-emerald-950",
												children: inr.format(Number(result.senderTransaction.amount))
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-xl bg-white/75 p-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs font-bold uppercase text-emerald-800/70",
												children: "New MAIN balance"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-xl font-black text-emerald-950",
												children: inr.format(Number(result.senderTransaction.closingBalance))
											})]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: resetTransfer,
										className: "mt-4 rounded-xl border border-emerald-300 bg-white px-4 py-2.5 text-sm font-extrabold text-emerald-900 transition hover:bg-emerald-100",
										children: "Make another transfer"
									})
								]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRoundCheck, {
								className: "text-primary",
								size: 21
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg font-black text-secondary",
								children: "Transfer rules"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-4 space-y-4 text-sm leading-6 text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
										className: "mt-1 shrink-0 text-emerald-600",
										size: 16
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
										"Receiver must have the same ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
											className: "text-secondary",
											children: "RETAILER"
										}),
										" ",
										"role."
									] })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
										className: "mt-1 shrink-0 text-emerald-600",
										size: 16
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Both sender and receiver accounts and roles must be active." })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
										className: "mt-1 shrink-0 text-emerald-600",
										size: 16
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "The debit always comes from the MAIN wallet." })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
										className: "mt-1 shrink-0 text-emerald-600",
										size: 16
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "The backend checks the current balance again before posting the debit." })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
										className: "mt-1 shrink-0 text-emerald-600",
										size: 16
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Confirmed requests use an idempotency key to reduce duplicate-transfer risk." })]
								})
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-secondary p-6 text-white shadow-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 24 }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-4 text-lg font-black",
								children: "Backend protected"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm leading-6 text-white/65",
								children: "Your backend resolves both accounts, blocks self-transfer, checks the same-role rule and active status, locks the wallet transaction, checks balance, and posts both debit and credit together."
							})
						]
					})]
				})]
			})
		]
	});
}
//#endregion
export { RetailerWalletTransferPage as component };
