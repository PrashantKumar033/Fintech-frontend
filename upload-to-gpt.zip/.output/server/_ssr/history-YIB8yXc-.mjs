import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { vt as History } from "../_libs/lucide-react.mjs";
import { t as MasterDistributorModulePlaceholder } from "./module-placeholder-CYYFwolg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/history-YIB8yXc-.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MasterDistributorModulePlaceholder, {
		active: "settlements",
		icon: History,
		title: "Wallet history",
		description: "Review credits, debits and closing balances.",
		pending: "The backend currently returns wallet balances but does not expose a dedicated Master Distributor ledger endpoint."
	});
}
//#endregion
export { Page as component };
