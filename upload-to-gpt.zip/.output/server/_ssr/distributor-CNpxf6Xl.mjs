import { s as DistributorDashboard } from "./router-BahmeVh9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/distributor-CNpxf6Xl.js
var SplitComponent = DistributorDashboard;
//#endregion
export { SplitComponent as component };
