import { i as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { r as ServiceState, t as AdminLayout } from "./admin-layout-CMM4oD2x.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settlements-BagrUXJq.js
var import_jsx_runtime = require_jsx_runtime();
function Settlements() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "settlements",
		eyebrow: "Wallet operations",
		title: "Settlements",
		description: "Settlement operations have their own scalable module boundary.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceState, {
			title: "Settlement workspace",
			description: "Settlement batches and controls will be connected to the transaction and wallet admin contracts when those endpoints are exposed.",
			status: "Backend contract pending"
		})
	});
}
//#endregion
export { Settlements as component };
