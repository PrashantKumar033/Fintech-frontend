import { a as BankAccountsPage } from "./router-BahmeVh9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bank-DnYGggVq.js
var SplitComponent = BankAccountsPage;
//#endregion
export { SplitComponent as component };
