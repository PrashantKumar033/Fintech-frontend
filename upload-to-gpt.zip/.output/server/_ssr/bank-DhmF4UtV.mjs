import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { l as Route$11 } from "./router-B644QERq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bank-DhmF4UtV.js
var import_jsx_runtime = require_jsx_runtime();
function BankPage() {
	const Component = Route$11.options.component;
	return Component ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Component, {}) : null;
}
//#endregion
export { BankPage as component };
