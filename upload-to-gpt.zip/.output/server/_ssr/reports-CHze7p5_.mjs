import { r as __toESM } from "../_runtime.mjs";
import { n as adminApi } from "./admin-api-DhyC5xn6.mjs";
import { i as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { F as RefreshCw, Pt as Eye, k as Search, r as X, st as LoaderCircle } from "../_libs/lucide-react.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-CMM4oD2x.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports-CHze7p5_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var inputClass = "rounded-xl border border-border bg-white px-3.5 py-3 text-xs outline-none focus:border-primary";
function when(value) {
	if (!value) return "—";
	const date = new Date(value);
	return Number.isNaN(date.getTime()) ? "—" : new Intl.DateTimeFormat("en-IN", {
		dateStyle: "medium",
		timeStyle: "short"
	}).format(date);
}
function Reports() {
	const [items, setItems] = (0, import_react.useState)([]), [loading, setLoading] = (0, import_react.useState)(true), [error, setError] = (0, import_react.useState)(""), [page, setPage] = (0, import_react.useState)(1), [totalPages, setTotalPages] = (0, import_react.useState)(1), [total, setTotal] = (0, import_react.useState)(0), [selected, setSelected] = (0, import_react.useState)(null);
	const [service, setService] = (0, import_react.useState)(""), [action, setAction] = (0, import_react.useState)(""), [status, setStatus] = (0, import_react.useState)(""), [loginId, setLoginId] = (0, import_react.useState)("");
	async function load(target = page) {
		setLoading(true);
		setError("");
		try {
			const query = new URLSearchParams({
				page: String(target),
				limit: "25"
			});
			if (service.trim()) query.set("service", service.trim().toUpperCase());
			if (action.trim()) query.set("action", action.trim().toUpperCase());
			if (status) query.set("status", status);
			if (loginId.trim()) query.set("loginId", loginId.trim());
			const result = await adminApi.auditLogs(query.toString());
			setItems(result.data || []);
			setPage(result.pagination?.page || target);
			setTotalPages(Math.max(result.pagination?.totalPages || 1, 1));
			setTotal(result.pagination?.total || 0);
		} catch (e) {
			setError(e instanceof Error ? e.message : "Unable to load audit logs.");
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		load(1);
	}, []);
	function filter(e) {
		e.preventDefault();
		load(1);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "reports",
		eyebrow: "Security observability",
		title: "Audit logs",
		description: "Review successful and failed operations with identity, service, action and resource context.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: filter,
				className: "grid gap-3 lg:grid-cols-[1fr_1fr_1fr_160px_auto]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 rounded-xl border border-border bg-white px-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { size: 14 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: loginId,
							onChange: (e) => setLoginId(e.target.value),
							placeholder: "Login ID",
							className: "min-w-0 flex-1 py-3 text-xs outline-none"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: service,
						onChange: (e) => setService(e.target.value),
						placeholder: "Service",
						className: inputClass
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: action,
						onChange: (e) => setAction(e.target.value),
						placeholder: "Action",
						className: inputClass
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: status,
						onChange: (e) => setStatus(e.target.value),
						className: inputClass,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "All statuses"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "SUCCESS" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "FAILED" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						disabled: loading,
						className: "inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-xs font-extrabold text-white",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
							size: 14,
							className: loading ? "animate-spin" : ""
						}), "Apply"]
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-5 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 overflow-x-auto rounded-xl border border-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[900px] text-left text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-muted/60 text-[10px] uppercase text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Time"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Identity"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Service"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Action"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Resource"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "p-3" })
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: items.map((log) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border/70",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3 whitespace-nowrap",
									children: when(log.createdAt)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-black",
										children: log.loginId || "System"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] text-muted-foreground",
										children: log.role || log.identityId || "—"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3 font-bold",
									children: log.service || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3 font-bold",
									children: log.action || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "p-3",
									children: [log.resourceType || "—", log.resourceId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "max-w-[150px] truncate text-[10px] text-muted-foreground",
										children: log.resourceId
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `rounded-full px-2 py-1 text-[9px] font-extrabold ${log.status === "FAILED" ? "bg-red-50 text-red-700" : "bg-emerald-50 text-emerald-700"}`,
										children: log.status || "UNKNOWN"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3 text-right",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setSelected(log),
										title: "View audit detail",
										className: "rounded-lg border border-border p-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 14 })
									})
								})
							]
						}, log.id)) })]
					}),
					loading && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-center gap-2 py-12 text-sm text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
							size: 17,
							className: "animate-spin"
						}), "Loading audit trail…"]
					}),
					!loading && !items.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-12 text-center text-sm text-muted-foreground",
						children: "No audit events match these filters."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-center justify-between text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted-foreground",
					children: [
						total,
						" events · Page ",
						page,
						" of ",
						totalPages
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: page <= 1 || loading,
						onClick: () => void load(page - 1),
						className: "rounded-lg border border-border px-3 py-2 font-bold disabled:opacity-40",
						children: "Previous"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: page >= totalPages || loading,
						onClick: () => void load(page + 1),
						className: "rounded-lg border border-border px-3 py-2 font-bold disabled:opacity-40",
						children: "Next"
					})]
				})]
			})
		] }), selected && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "fixed inset-0 z-[80] grid place-items-center bg-secondary/55 p-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-h-[85vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-extrabold uppercase text-primary",
							children: "Audit event"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-xl font-black",
							children: selected.action || "Event details"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setSelected(null),
							"aria-label": "Close",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-5 grid gap-3 sm:grid-cols-2",
						children: Object.entries(selected).filter(([, v]) => v !== null && v !== void 0 && typeof v !== "object").map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl bg-muted/50 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[10px] font-extrabold uppercase text-muted-foreground",
								children: key.replace(/([A-Z])/g, " $1")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 break-all text-xs font-bold",
								children: String(value)
							})]
						}, key))
					}),
					selected.metadata && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-4 overflow-x-auto rounded-xl bg-secondary p-4 text-[11px] text-white",
						children: JSON.stringify(selected.metadata, null, 2)
					}),
					selected.errorMessage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 rounded-xl bg-red-50 p-4 text-sm text-red-700",
						children: selected.errorMessage
					})
				]
			})
		})]
	});
}
//#endregion
export { Reports as component };
