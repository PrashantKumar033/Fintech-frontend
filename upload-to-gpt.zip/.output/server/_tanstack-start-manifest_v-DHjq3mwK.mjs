//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DHjq3mwK.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/activity",
			"/contact",
			"/forgot-password",
			"/login",
			"/privacy",
			"/refund-policy",
			"/register",
			"/services",
			"/terms",
			"/admin/account-setup",
			"/admin/login",
			"/admin/onboarding",
			"/distributor/$",
			"/distributor/account-setup",
			"/distributor/dashboard",
			"/master-distributor/$",
			"/master-distributor/account-setup",
			"/master-distributor/dashboard",
			"/retailer/account-setup",
			"/retailer/dashboard",
			"/retailer/settings",
			"/admin/",
			"/distributor/",
			"/master-distributor/",
			"/admin/commissions/hierarchy",
			"/admin/profile/bank",
			"/admin/profile/kyc",
			"/distributor/aeps/balance-enquiry",
			"/distributor/aeps/cash-withdrawal",
			"/distributor/aeps/mini-statement",
			"/distributor/aeps/transactions",
			"/distributor/profile/bank",
			"/distributor/profile/kyc",
			"/distributor/wallet/transfer",
			"/master-distributor/profile/bank",
			"/master-distributor/profile/kyc",
			"/master-distributor/wallet/history",
			"/master-distributor/wallet/requests",
			"/master-distributor/wallet/transfer",
			"/retailer/wallet/transfer",
			"/admin/access/",
			"/admin/api-settings/",
			"/admin/banking/",
			"/admin/commissions/",
			"/admin/kyc/",
			"/admin/legal/",
			"/admin/merchants/",
			"/admin/profile/",
			"/admin/reports/",
			"/admin/settings/",
			"/admin/settlements/",
			"/admin/sms/",
			"/admin/transactions/",
			"/distributor/aeps/",
			"/distributor/commission/",
			"/distributor/profile/",
			"/distributor/reports/",
			"/distributor/retailers/",
			"/distributor/settings/",
			"/distributor/support/",
			"/distributor/wallet/",
			"/master-distributor/commission/",
			"/master-distributor/kyc/",
			"/master-distributor/notifications/",
			"/master-distributor/profile/",
			"/master-distributor/reports/",
			"/master-distributor/settings/",
			"/master-distributor/support/",
			"/master-distributor/transactions/",
			"/master-distributor/wallet/",
			"/retailer/aeps/",
			"/retailer/bank/",
			"/retailer/kyc/",
			"/retailer/transactions/",
			"/retailer/wallet/",
			"/admin/merchants/add/",
			"/admin/merchants/list/",
			"/distributor/retailers/add/",
			"/master-distributor/network/distributors/",
			"/master-distributor/network/retailers/",
			"/master-distributor/network/tree/",
			"/master-distributor/network/distributors/add/"
		],
		preloads: [
			"/assets/index-0VCXPUit.js",
			"/assets/auth-api-B9x8s0k0.js",
			"/assets/link-C6cjydXt.js",
			"/assets/fileRoute-DeX4phA8.js",
			"/assets/useRouter-foS_hwN_.js",
			"/assets/list-Dx6TrdWg.js",
			"/assets/business-page-AcXT1fJV.js",
			"/assets/kyc-B3gwIpSd.js",
			"/assets/account-setup-8n_zkohb.js",
			"/assets/dashboard-BI1bj7R9.js",
			"/assets/dashboard-BraOHckP.js",
			"/assets/merchants-CRpVVhA1.js",
			"/assets/profile-laDccleW.js",
			"/assets/settings-BV5OQfoM.js",
			"/assets/bank-CahRFhjz.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-0VCXPUit.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CxoXZtY6.js",
			"/assets/arrow-right-D31X6d3x.js",
			"/assets/arrow-up-right-Bx-FYnBN.js",
			"/assets/banknote-DtKL-Mdi.js",
			"/assets/chevron-right-CVmD0fTb.js",
			"/assets/circle-check-DQnatJGq.js",
			"/assets/credit-card-Bfi9HqfL.js",
			"/assets/eye-BqZLvFFK.js",
			"/assets/site-footer-CS10Fh84.js",
			"/assets/fingerprint-pattern-BPKB22uF.js",
			"/assets/layers-CK6ONJj6.js",
			"/assets/lock-BpW6kl2b.js",
			"/assets/plus-Bl6dYczp.js",
			"/assets/receipt-DIDmceR5.js",
			"/assets/rocket-D_Ysizv0.js",
			"/assets/send-dPcSEspl.js",
			"/assets/shield-CrIEUBWK.js",
			"/assets/smartphone-DEfeZTOb.js",
			"/assets/phone-mock-Bl1d91Sy.js",
			"/assets/tv-Ezs_DIT3.js",
			"/assets/wallet-_dy2A2no.js",
			"/assets/zap-Bap0mHou.js"
		]
	},
	"/about": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-BA8AJxNz.js",
			"/assets/arrow-right-D31X6d3x.js",
			"/assets/site-footer-CS10Fh84.js",
			"/assets/headphones-DCYog-ek.js",
			"/assets/rocket-D_Ysizv0.js",
			"/assets/shield-check-D02Im-d-.js",
			"/assets/phone-mock-Bl1d91Sy.js",
			"/assets/zap-Bap0mHou.js",
			"/assets/about-team-DwbCHxeD.js"
		]
	},
	"/activity": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/activity.tsx",
		children: void 0,
		preloads: [
			"/assets/activity-CcIdoBIy.js",
			"/assets/useNavigate-Cq7scpv_.js",
			"/assets/refresh-cw-4EV9_Zyk.js",
			"/assets/operations-api-C34N4yrZ.js"
		]
	},
	"/contact": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-BWXJzbIw.js",
			"/assets/clock-3-D20xpJkY.js",
			"/assets/site-footer-CS10Fh84.js",
			"/assets/mail-BtSgOMYN.js",
			"/assets/map-pin-CteHijQS.js",
			"/assets/phone-Cca1rtAj.js",
			"/assets/send-dPcSEspl.js"
		]
	},
	"/forgot-password": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/forgot-password.tsx",
		children: void 0,
		preloads: [
			"/assets/forgot-password-CugNMd1T.js",
			"/assets/useNavigate-Cq7scpv_.js",
			"/assets/arrow-left-DzDW4iU5.js",
			"/assets/arrow-right-D31X6d3x.js",
			"/assets/eye-off-CUblN92o.js",
			"/assets/eye-BqZLvFFK.js",
			"/assets/site-footer-CS10Fh84.js",
			"/assets/key-round-DcR4RG9w.js",
			"/assets/loader-circle-DnU6Axip.js",
			"/assets/shield-check-D02Im-d-.js",
			"/assets/user-BRTYHsF0.js"
		]
	},
	"/login": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-2KQIad4r.js",
			"/assets/arrow-right-D31X6d3x.js",
			"/assets/eye-off-CUblN92o.js",
			"/assets/eye-BqZLvFFK.js",
			"/assets/site-footer-CS10Fh84.js",
			"/assets/loader-circle-DnU6Axip.js",
			"/assets/lock-BpW6kl2b.js",
			"/assets/shield-CrIEUBWK.js",
			"/assets/smartphone-DEfeZTOb.js",
			"/assets/role-hierarchy-DU3OEIqB.js",
			"/assets/admin-api-8skld9FG.js"
		]
	},
	"/privacy": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/privacy.tsx",
		children: void 0,
		preloads: [
			"/assets/privacy-DwM5K6OT.js",
			"/assets/policy-page-BbMRKoHa.js",
			"/assets/shield-check-D02Im-d-.js"
		]
	},
	"/refund-policy": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/refund-policy.tsx",
		children: void 0,
		preloads: [
			"/assets/refund-policy-CnYaK1to.js",
			"/assets/policy-page-BbMRKoHa.js",
			"/assets/rotate-ccw-yqYFuWJl.js"
		]
	},
	"/register": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-C4fLz21d.js",
			"/assets/arrow-left-DzDW4iU5.js",
			"/assets/arrow-right-D31X6d3x.js",
			"/assets/circle-check-DQnatJGq.js",
			"/assets/site-footer-CS10Fh84.js",
			"/assets/loader-circle-DnU6Axip.js",
			"/assets/rocket-D_Ysizv0.js",
			"/assets/shield-check-D02Im-d-.js"
		]
	},
	"/services": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/services.tsx",
		children: void 0,
		preloads: [
			"/assets/services-BQ8Pb3GA.js",
			"/assets/arrow-right-D31X6d3x.js",
			"/assets/badge-check-C_BffVz5.js",
			"/assets/banknote-DtKL-Mdi.js",
			"/assets/circle-check-DQnatJGq.js",
			"/assets/credit-card-Bfi9HqfL.js",
			"/assets/site-footer-CS10Fh84.js",
			"/assets/flame-D_vIB7H7.js",
			"/assets/landmark-aWshVbus.js",
			"/assets/receipt-text-DzX5dX3J.js",
			"/assets/send-dPcSEspl.js",
			"/assets/shield-check-D02Im-d-.js",
			"/assets/smartphone-DEfeZTOb.js",
			"/assets/store-BQabIQkl.js",
			"/assets/wifi-BmlRo2FR.js",
			"/assets/zap-Bap0mHou.js",
			"/assets/about-team-DwbCHxeD.js"
		]
	},
	"/terms": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/terms.tsx",
		children: void 0,
		preloads: [
			"/assets/terms-CXpzMeTX.js",
			"/assets/file-text-CClDXWfn.js",
			"/assets/policy-page-BbMRKoHa.js"
		]
	},
	"/admin/login": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-UBTEv2HE.js",
			"/assets/useNavigate-Cq7scpv_.js",
			"/assets/arrow-right-D31X6d3x.js",
			"/assets/eye-off-CUblN92o.js",
			"/assets/eye-BqZLvFFK.js",
			"/assets/lock-keyhole-dw5mvxv_.js",
			"/assets/shield-check-D02Im-d-.js",
			"/assets/admin-api-8skld9FG.js"
		]
	},
	"/admin/onboarding": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/onboarding.tsx",
		children: void 0,
		preloads: [
			"/assets/onboarding-D11YsDDb.js",
			"/assets/useNavigate-Cq7scpv_.js",
			"/assets/arrow-right-D31X6d3x.js",
			"/assets/circle-check-DQnatJGq.js",
			"/assets/loader-circle-DnU6Axip.js",
			"/assets/lock-keyhole-dw5mvxv_.js",
			"/assets/shield-check-D02Im-d-.js",
			"/assets/admin-api-8skld9FG.js"
		]
	},
	"/distributor/$": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/$.tsx",
		children: void 0,
		preloads: ["/assets/_-C6hLzYjS.js", "/assets/management-route-page-5Tiw6_AN.js"]
	},
	"/distributor/account-setup": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/account-setup.tsx",
		children: void 0,
		preloads: ["/assets/account-setup-C9ZFhlg9.js"]
	},
	"/master-distributor/$": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/$.tsx",
		children: void 0,
		preloads: ["/assets/_-CLdBnVoR.js", "/assets/management-route-page-5Tiw6_AN.js"]
	},
	"/master-distributor/account-setup": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/account-setup.tsx",
		children: void 0,
		preloads: ["/assets/account-setup-fBUmVVWl.js"]
	},
	"/retailer/account-setup": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/account-setup.tsx",
		children: void 0,
		preloads: ["/assets/account-setup-DPQgdED3.js"]
	},
	"/retailer/dashboard": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-C3CJrtuv.js",
			"/assets/useNavigate-Cq7scpv_.js",
			"/assets/activity-CbvoD3lA.js",
			"/assets/badge-check-C_BffVz5.js",
			"/assets/banknote-DtKL-Mdi.js",
			"/assets/building-2-BOVuat08.js",
			"/assets/chevron-right-CVmD0fTb.js",
			"/assets/credit-card-Bfi9HqfL.js",
			"/assets/fingerprint-pattern-BPKB22uF.js",
			"/assets/flame-D_vIB7H7.js",
			"/assets/gift-CGQKCSpc.js",
			"/assets/headphones-DCYog-ek.js",
			"/assets/indian-rupee-Bxj0z0M4.js",
			"/assets/landmark-aWshVbus.js",
			"/assets/refresh-cw-4EV9_Zyk.js",
			"/assets/shield-CrIEUBWK.js",
			"/assets/smartphone-DEfeZTOb.js",
			"/assets/tv-Ezs_DIT3.js",
			"/assets/wallet-_dy2A2no.js",
			"/assets/wifi-BmlRo2FR.js",
			"/assets/role-hierarchy-DU3OEIqB.js",
			"/assets/operations-api-C34N4yrZ.js"
		]
	},
	"/retailer/settings": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CDdmQ6r5.js",
			"/assets/useNavigate-Cq7scpv_.js",
			"/assets/badge-check-C_BffVz5.js",
			"/assets/section-tabs-B_6Tt9Ie.js",
			"/assets/chevron-right-CVmD0fTb.js",
			"/assets/eye-off-CUblN92o.js",
			"/assets/eye-BqZLvFFK.js",
			"/assets/key-round-DcR4RG9w.js",
			"/assets/account-security-center-CmCmBevI.js",
			"/assets/mail-BtSgOMYN.js",
			"/assets/network-CsjjsKzP.js",
			"/assets/phone-Cca1rtAj.js",
			"/assets/refresh-cw-4EV9_Zyk.js",
			"/assets/shield-check-D02Im-d-.js",
			"/assets/shield-CrIEUBWK.js",
			"/assets/user-BRTYHsF0.js",
			"/assets/role-hierarchy-DU3OEIqB.js"
		]
	},
	"/distributor/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/index.tsx",
		children: void 0,
		preloads: ["/assets/distributor-DEuI2Y8f.js"]
	},
	"/master-distributor/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/index.tsx",
		children: void 0,
		preloads: ["/assets/master-distributor-CfJ6oZHV.js"]
	},
	"/admin/commissions/hierarchy": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/commissions/hierarchy.tsx",
		children: void 0,
		preloads: [
			"/assets/hierarchy-CR08Cmt9.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/loader-circle-DnU6Axip.js",
			"/assets/plus-Bl6dYczp.js",
			"/assets/refresh-cw-4EV9_Zyk.js",
			"/assets/search-C8FjkgWK.js",
			"/assets/trash-2-Dv5KtKI9.js",
			"/assets/admin-api-8skld9FG.js"
		]
	},
	"/admin/profile/bank": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/profile/bank.tsx",
		children: void 0,
		preloads: ["/assets/bank-Dpdx-6Qu.js"]
	},
	"/admin/profile/kyc": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/profile/kyc.tsx",
		children: void 0,
		preloads: ["/assets/kyc-BxiBAd_v.js"]
	},
	"/distributor/aeps/balance-enquiry": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/balance-enquiry.tsx",
		children: void 0,
		preloads: [
			"/assets/balance-enquiry-DQKyoO_o.js",
			"/assets/landmark-aWshVbus.js",
			"/assets/module-placeholder-C94h07Ln.js"
		]
	},
	"/distributor/aeps/cash-withdrawal": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/cash-withdrawal.tsx",
		children: void 0,
		preloads: [
			"/assets/cash-withdrawal-D_Fi31Mh.js",
			"/assets/banknote-DtKL-Mdi.js",
			"/assets/module-placeholder-C94h07Ln.js"
		]
	},
	"/distributor/aeps/mini-statement": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/mini-statement.tsx",
		children: void 0,
		preloads: [
			"/assets/mini-statement-nFdwQnyc.js",
			"/assets/file-text-CClDXWfn.js",
			"/assets/module-placeholder-C94h07Ln.js"
		]
	},
	"/distributor/aeps/transactions": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/transactions.tsx",
		children: void 0,
		preloads: [
			"/assets/transactions-xzcsh2kb.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/transaction-detail-dialog-DqLu6nbL.js",
			"/assets/distributor-api-2ydipgR0.js"
		]
	},
	"/distributor/profile/bank": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/profile/bank.tsx",
		children: void 0,
		preloads: ["/assets/bank-Des1JLm_.js"]
	},
	"/distributor/profile/kyc": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/profile/kyc.tsx",
		children: void 0,
		preloads: ["/assets/kyc-HgZjW846.js"]
	},
	"/distributor/wallet/transfer": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/wallet/transfer.tsx",
		children: void 0,
		preloads: [
			"/assets/transfer-9WlrepOj.js",
			"/assets/useNavigate-Cq7scpv_.js",
			"/assets/arrow-right-left-CnZtrXxO.js",
			"/assets/arrow-right-D31X6d3x.js",
			"/assets/user-round-check-BZuOKJ9N.js",
			"/assets/circle-check-DQnatJGq.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/indian-rupee-Bxj0z0M4.js",
			"/assets/loader-circle-DnU6Axip.js",
			"/assets/refresh-cw-4EV9_Zyk.js",
			"/assets/shield-check-D02Im-d-.js",
			"/assets/wallet-cards-BAYd4v2E.js",
			"/assets/role-hierarchy-DU3OEIqB.js",
			"/assets/distributor-api-2ydipgR0.js",
			"/assets/operations-api-C34N4yrZ.js"
		]
	},
	"/master-distributor/profile/bank": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/profile/bank.tsx",
		children: void 0,
		preloads: ["/assets/bank-DtxW1SUv.js"]
	},
	"/master-distributor/profile/kyc": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/profile/kyc.tsx",
		children: void 0,
		preloads: ["/assets/kyc-bH4aMpfS.js"]
	},
	"/master-distributor/wallet/history": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/wallet/history.tsx",
		children: void 0,
		preloads: ["/assets/history-CdVNWnVA.js", "/assets/module-placeholder-4QqX7Fkr.js"]
	},
	"/master-distributor/wallet/requests": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/wallet/requests.tsx",
		children: void 0,
		preloads: ["/assets/requests-D0bvNPyi.js", "/assets/module-placeholder-4QqX7Fkr.js"]
	},
	"/master-distributor/wallet/transfer": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/wallet/transfer.tsx",
		children: void 0,
		preloads: [
			"/assets/transfer-DdUPKVM1.js",
			"/assets/useNavigate-Cq7scpv_.js",
			"/assets/arrow-right-left-CnZtrXxO.js",
			"/assets/arrow-right-D31X6d3x.js",
			"/assets/user-round-check-BZuOKJ9N.js",
			"/assets/circle-check-DQnatJGq.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/indian-rupee-Bxj0z0M4.js",
			"/assets/loader-circle-DnU6Axip.js",
			"/assets/refresh-cw-4EV9_Zyk.js",
			"/assets/shield-check-D02Im-d-.js",
			"/assets/wallet-cards-BAYd4v2E.js",
			"/assets/role-hierarchy-DU3OEIqB.js",
			"/assets/master-distributor-api-Cp5eVs4_.js",
			"/assets/operations-api-C34N4yrZ.js"
		]
	},
	"/retailer/wallet/transfer": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/wallet/transfer.tsx",
		children: void 0,
		preloads: [
			"/assets/transfer-BtmBrvcJ.js",
			"/assets/useNavigate-Cq7scpv_.js",
			"/assets/arrow-right-left-CnZtrXxO.js",
			"/assets/arrow-right-D31X6d3x.js",
			"/assets/user-round-check-BZuOKJ9N.js",
			"/assets/circle-check-DQnatJGq.js",
			"/assets/indian-rupee-Bxj0z0M4.js",
			"/assets/loader-circle-DnU6Axip.js",
			"/assets/refresh-cw-4EV9_Zyk.js",
			"/assets/shield-check-D02Im-d-.js",
			"/assets/wallet-cards-BAYd4v2E.js",
			"/assets/role-hierarchy-DU3OEIqB.js",
			"/assets/operations-api-C34N4yrZ.js"
		]
	},
	"/admin/api-settings/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/api-settings/index.tsx",
		children: void 0,
		preloads: [
			"/assets/api-settings-DSupnLkk.js",
			"/assets/activity-CbvoD3lA.js",
			"/assets/cable-Dw7Q5vks.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/refresh-cw-4EV9_Zyk.js",
			"/assets/admin-feature-grid-Uo1Jrnv3.js"
		]
	},
	"/admin/banking/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/banking/index.tsx",
		children: void 0,
		preloads: ["/assets/banking-_9CPZHEQ.js", "/assets/admin-layout-BG4t9-Gc.js"]
	},
	"/admin/commissions/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/commissions/index.tsx",
		children: void 0,
		preloads: [
			"/assets/commissions-C6z7Ql-l.js",
			"/assets/circle-check-DQnatJGq.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/indian-rupee-Bxj0z0M4.js",
			"/assets/layers-CK6ONJj6.js",
			"/assets/loader-circle-DnU6Axip.js",
			"/assets/x-SCASd-Br.js",
			"/assets/pen-line-MWpa1JVD.js",
			"/assets/plus-Bl6dYczp.js",
			"/assets/refresh-cw-4EV9_Zyk.js",
			"/assets/search-C8FjkgWK.js",
			"/assets/shield-alert-BdrSzvhG.js",
			"/assets/users-round-Bu9qZLP0.js",
			"/assets/admin-api-8skld9FG.js"
		]
	},
	"/admin/kyc/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/kyc/index.tsx",
		children: void 0,
		preloads: ["/assets/kyc-BVwLqfpL.js", "/assets/admin-layout-BG4t9-Gc.js"]
	},
	"/admin/legal/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/legal/index.tsx",
		children: void 0,
		preloads: [
			"/assets/legal-DKRPW_uy.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/file-check-corner-CcWv3TEW.js",
			"/assets/lock-keyhole-dw5mvxv_.js",
			"/assets/shield-alert-BdrSzvhG.js",
			"/assets/admin-feature-grid-Uo1Jrnv3.js"
		]
	},
	"/admin/reports/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/reports/index.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-DLqHQw8r.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/eye-BqZLvFFK.js",
			"/assets/loader-circle-DnU6Axip.js",
			"/assets/x-SCASd-Br.js",
			"/assets/refresh-cw-4EV9_Zyk.js",
			"/assets/search-C8FjkgWK.js",
			"/assets/admin-api-8skld9FG.js"
		]
	},
	"/admin/settlements/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/settlements/index.tsx",
		children: void 0,
		preloads: ["/assets/settlements-CIbuKELN.js", "/assets/admin-layout-BG4t9-Gc.js"]
	},
	"/admin/sms/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/sms/index.tsx",
		children: void 0,
		preloads: [
			"/assets/sms-wkE14YL6.js",
			"/assets/cable-Dw7Q5vks.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/admin-feature-grid-Uo1Jrnv3.js"
		]
	},
	"/distributor/aeps/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/index.tsx",
		children: void 0,
		preloads: [
			"/assets/aeps-C9H9idKA.js",
			"/assets/banknote-DtKL-Mdi.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/file-text-CClDXWfn.js",
			"/assets/landmark-aWshVbus.js"
		]
	},
	"/distributor/commission/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/commission/index.tsx",
		children: void 0,
		preloads: [
			"/assets/commission-DBRJyMH_.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/indian-rupee-Bxj0z0M4.js",
			"/assets/admin-api-8skld9FG.js",
			"/assets/distributor-api-2ydipgR0.js"
		]
	},
	"/distributor/profile/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/profile/index.tsx",
		children: void 0,
		preloads: ["/assets/profile-RX21d7Ap.js"]
	},
	"/distributor/reports/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/reports/index.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-CTStPNwW.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/distributor-api-2ydipgR0.js"
		]
	},
	"/distributor/retailers/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/retailers/index.tsx",
		children: void 0,
		preloads: [
			"/assets/retailers-BSCOJ8lZ.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/store-BQabIQkl.js",
			"/assets/user-plus-BRdgWT7m.js",
			"/assets/distributor-api-2ydipgR0.js"
		]
	},
	"/distributor/settings/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/settings/index.tsx",
		children: void 0,
		preloads: ["/assets/settings-BMzqxMkv.js"]
	},
	"/distributor/support/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/support/index.tsx",
		children: void 0,
		preloads: [
			"/assets/support-B77xL-af.js",
			"/assets/headphones-DCYog-ek.js",
			"/assets/module-placeholder-C94h07Ln.js"
		]
	},
	"/distributor/wallet/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/wallet/index.tsx",
		children: void 0,
		preloads: [
			"/assets/wallet-DHk8-7g0.js",
			"/assets/useNavigate-Cq7scpv_.js",
			"/assets/arrow-right-left-CnZtrXxO.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/fingerprint-pattern-BPKB22uF.js",
			"/assets/gift-CGQKCSpc.js",
			"/assets/loader-circle-DnU6Axip.js",
			"/assets/refresh-cw-4EV9_Zyk.js",
			"/assets/shield-check-D02Im-d-.js",
			"/assets/wallet-cards-BAYd4v2E.js",
			"/assets/role-hierarchy-DU3OEIqB.js",
			"/assets/distributor-api-2ydipgR0.js",
			"/assets/operations-api-C34N4yrZ.js"
		]
	},
	"/master-distributor/commission/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/commission/index.tsx",
		children: void 0,
		preloads: [
			"/assets/commission-BsYi0ChU.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/indian-rupee-Bxj0z0M4.js",
			"/assets/admin-api-8skld9FG.js",
			"/assets/master-distributor-api-Cp5eVs4_.js"
		]
	},
	"/master-distributor/kyc/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/kyc/index.tsx",
		children: void 0,
		preloads: [
			"/assets/kyc-GHsyE1dS.js",
			"/assets/shield-check-D02Im-d-.js",
			"/assets/module-placeholder-4QqX7Fkr.js"
		]
	},
	"/master-distributor/notifications/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/notifications/index.tsx",
		children: void 0,
		preloads: [
			"/assets/notifications-x25ptDCi.js",
			"/assets/section-tabs-B_6Tt9Ie.js",
			"/assets/module-placeholder-4QqX7Fkr.js"
		]
	},
	"/master-distributor/profile/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/profile/index.tsx",
		children: void 0,
		preloads: ["/assets/profile-CQapldUS.js"]
	},
	"/master-distributor/reports/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/reports/index.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-CI8VYdnf.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/master-distributor-api-Cp5eVs4_.js"
		]
	},
	"/master-distributor/settings/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/settings/index.tsx",
		children: void 0,
		preloads: ["/assets/settings-D5yCqN5N.js"]
	},
	"/master-distributor/support/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/support/index.tsx",
		children: void 0,
		preloads: [
			"/assets/support-DuaDFcXR.js",
			"/assets/headphones-DCYog-ek.js",
			"/assets/module-placeholder-4QqX7Fkr.js"
		]
	},
	"/master-distributor/transactions/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/transactions/index.tsx",
		children: void 0,
		preloads: [
			"/assets/transactions-BTU_IHb3.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/transaction-detail-dialog-DqLu6nbL.js",
			"/assets/master-distributor-api-Cp5eVs4_.js"
		]
	},
	"/master-distributor/wallet/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/wallet/index.tsx",
		children: void 0,
		preloads: [
			"/assets/wallet-ClX6SK2T.js",
			"/assets/useNavigate-Cq7scpv_.js",
			"/assets/arrow-right-left-CnZtrXxO.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/fingerprint-pattern-BPKB22uF.js",
			"/assets/gift-CGQKCSpc.js",
			"/assets/loader-circle-DnU6Axip.js",
			"/assets/refresh-cw-4EV9_Zyk.js",
			"/assets/shield-check-D02Im-d-.js",
			"/assets/wallet-cards-BAYd4v2E.js",
			"/assets/role-hierarchy-DU3OEIqB.js",
			"/assets/master-distributor-api-Cp5eVs4_.js",
			"/assets/operations-api-C34N4yrZ.js"
		]
	},
	"/retailer/aeps/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/aeps/index.tsx",
		children: void 0,
		preloads: [
			"/assets/aeps-BDJgHY7W.js",
			"/assets/useNavigate-Cq7scpv_.js",
			"/assets/banknote-DtKL-Mdi.js",
			"/assets/circle-check-DQnatJGq.js",
			"/assets/fingerprint-pattern-BPKB22uF.js",
			"/assets/landmark-aWshVbus.js",
			"/assets/loader-circle-DnU6Axip.js",
			"/assets/map-pin-CteHijQS.js",
			"/assets/receipt-text-DzX5dX3J.js",
			"/assets/refresh-cw-4EV9_Zyk.js",
			"/assets/shield-alert-BdrSzvhG.js",
			"/assets/wallet-cards-BAYd4v2E.js",
			"/assets/role-hierarchy-DU3OEIqB.js"
		]
	},
	"/retailer/transactions/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/transactions/index.tsx",
		children: void 0,
		preloads: [
			"/assets/transactions-xDlJc6e9.js",
			"/assets/useNavigate-Cq7scpv_.js",
			"/assets/transaction-detail-dialog-DqLu6nbL.js",
			"/assets/receipt-DIDmceR5.js",
			"/assets/refresh-cw-4EV9_Zyk.js",
			"/assets/search-C8FjkgWK.js",
			"/assets/role-hierarchy-DU3OEIqB.js",
			"/assets/operations-api-C34N4yrZ.js"
		]
	},
	"/retailer/wallet/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/wallet/index.tsx",
		children: void 0,
		preloads: [
			"/assets/wallet-DqULBmz7.js",
			"/assets/useNavigate-Cq7scpv_.js",
			"/assets/arrow-right-left-CnZtrXxO.js",
			"/assets/fingerprint-pattern-BPKB22uF.js",
			"/assets/loader-circle-DnU6Axip.js",
			"/assets/refresh-cw-4EV9_Zyk.js",
			"/assets/shield-check-D02Im-d-.js",
			"/assets/wallet-cards-BAYd4v2E.js",
			"/assets/role-hierarchy-DU3OEIqB.js",
			"/assets/operations-api-C34N4yrZ.js"
		]
	},
	"/admin/merchants/add/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/merchants/add/index.tsx",
		children: void 0,
		preloads: ["/assets/add-B9XGT4pL.js"]
	},
	"/admin/merchants/list/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/merchants/list/index.tsx",
		children: void 0,
		preloads: [
			"/assets/list-kk9cRB2Y.js",
			"/assets/section-tabs-B_6Tt9Ie.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/search-C8FjkgWK.js",
			"/assets/user-plus-BRdgWT7m.js"
		]
	},
	"/distributor/retailers/add/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/retailers/add/index.tsx",
		children: void 0,
		preloads: ["/assets/add-CR5qS4DA.js"]
	},
	"/master-distributor/network/distributors/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/network/distributors/index.tsx",
		children: void 0,
		preloads: [
			"/assets/distributors-Cgf1rnzs.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/network-CsjjsKzP.js",
			"/assets/user-plus-BRdgWT7m.js",
			"/assets/master-distributor-api-Cp5eVs4_.js"
		]
	},
	"/master-distributor/network/retailers/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/network/retailers/index.tsx",
		children: void 0,
		preloads: [
			"/assets/retailers-CqoKgOy2.js",
			"/assets/store-BQabIQkl.js",
			"/assets/module-placeholder-4QqX7Fkr.js"
		]
	},
	"/master-distributor/network/tree/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/network/tree/index.tsx",
		children: void 0,
		preloads: [
			"/assets/tree-BC3Tx1TM.js",
			"/assets/section-tabs-B_6Tt9Ie.js",
			"/assets/admin-layout-BG4t9-Gc.js",
			"/assets/network-CsjjsKzP.js",
			"/assets/master-distributor-api-Cp5eVs4_.js"
		]
	},
	"/master-distributor/network/distributors/add/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/network/distributors/add/index.tsx",
		children: void 0,
		preloads: ["/assets/add-Cnl65ScI.js"]
	}
} });
//#endregion
export { tsrStartManifest };
