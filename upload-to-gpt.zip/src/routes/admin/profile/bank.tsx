import { createFileRoute } from "@tanstack/react-router";import{BankAccountsPage}from"@/routes/retailer/bank";export const Route=createFileRoute("/admin/profile/bank")({component:BankAccountsPage});
