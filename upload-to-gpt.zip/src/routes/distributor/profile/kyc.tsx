import { createFileRoute } from "@tanstack/react-router";import{KycPage}from"@/routes/retailer/kyc";export const Route=createFileRoute("/distributor/profile/kyc")({component:KycPage});
