import { useEffect, useState } from "react";
import { Eye, Loader2, RefreshCw, RotateCcw, WalletCards, X } from "lucide-react";
import { AdminPanel } from "@/components/admin/admin-layout";
import {
  adminApi,
  type ProviderIncomeInput,
  type ProviderReversal,
  type TransactionDetail,
} from "@/lib/admin-api";
import { getAdminActor } from "@/lib/admin-api";
import { getEffectiveAccess, hasPermission } from "@/lib/auth-api";
import type { ProviderTransaction } from "@/lib/operations-api";

type View = "transactions" | "income" | "reversals";
const messageOf = (value: unknown) =>
  value instanceof Error ? value.message : "The operation could not be completed.";
const money = (value: string | number) =>
  new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR" }).format(Number(value) || 0);
const time = (value?: string | null) => (value ? new Date(value).toLocaleString("en-IN") : "—");
const inputClass =
  "rounded-xl border border-border bg-white px-3 py-2.5 text-xs outline-none focus:border-primary";

export function AdminTransactionOperations() {
  const actor = getAdminActor();
  const permissionLoaded = Boolean(getEffectiveAccess());
  const allowed = (code: string) =>
    actor?.kind === "SUPER_ADMIN" || (permissionLoaded && hasPermission(code));
  const canView = allowed("transaction.view"),
    canViewIncome = allowed("transaction.provider-income.view"),
    canReconcileIncome = allowed("transaction.provider-income.reconcile"),
    canRequestReversal = allowed("transaction.reversal.request"),
    canProcessReversal = allowed("transaction.reversal.process"),
    canRecover = allowed("transaction.financial-recovery");
  const [view, setView] = useState<View>("transactions");
  const [transactions, setTransactions] = useState<ProviderTransaction[]>([]);
  const [reversals, setReversals] = useState<ProviderReversal[]>([]);
  const [loading, setLoading] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    [status, setStatus] = useState("");
  const [detail, setDetail] = useState<TransactionDetail | null>(null),
    [reverseTarget, setReverseTarget] = useState<ProviderTransaction | null>(null),
    [reason, setReason] = useState("");
  const [incomeTarget, setIncomeTarget] = useState<ProviderTransaction | null>(null),
    [income, setIncome] = useState<ProviderIncomeInput>({ incomeSource: "VIMOPAY_WALLET" });
  async function load() {
    if (
      (view === "transactions" && !canView) ||
      (view === "income" && !canViewIncome) ||
      (view === "reversals" && !canProcessReversal && !canRequestReversal)
    )
      return;
    setLoading(true);
    setError("");
    try {
      const query = new URLSearchParams({ page: "1", limit: "50" });
      if (status) query.set("status", status);
      if (view === "transactions")
        setTransactions((await adminApi.providerTransactions(query.toString())).data || []);
      else if (view === "income")
        setTransactions((await adminApi.pendingProviderIncome(query.toString())).data || []);
      else setReversals((await adminApi.reversals(query.toString())).data || []);
    } catch (value) {
      setError(messageOf(value));
    } finally {
      setLoading(false);
    }
  }
  useEffect(() => {
    void load();
  }, [view, status]);
  async function inspect(id: string) {
    setBusy(true);
    try {
      setDetail(await adminApi.transaction(id));
    } catch (value) {
      setError(messageOf(value));
    } finally {
      setBusy(false);
    }
  }
  async function requestReversal() {
    if (!reverseTarget || !reason.trim()) return setError("A reversal reason is required.");
    setBusy(true);
    try {
      await adminApi.requestReversal(reverseTarget.referenceId, reason.trim(), crypto.randomUUID());
      setNotice(`Reversal requested for ${reverseTarget.referenceId}.`);
      setReverseTarget(null);
      setReason("");
      await load();
    } catch (value) {
      setError(messageOf(value));
    } finally {
      setBusy(false);
    }
  }
  async function reconcileIncome() {
    if (!incomeTarget) return;
    setBusy(true);
    try {
      await adminApi.reconcileProviderIncome(incomeTarget.referenceId, income);
      setNotice(`Provider income reconciled for ${incomeTarget.referenceId}.`);
      setIncomeTarget(null);
      await load();
    } catch (value) {
      setError(messageOf(value));
    } finally {
      setBusy(false);
    }
  }
  async function processReversal(item: ProviderReversal) {
    if (
      !window.confirm(
        `${item.status === "FAILED" ? "Retry" : "Process"} reversal ${item.referenceId}?`,
      )
    )
      return;
    setBusy(true);
    try {
      await adminApi.processReversal(item.referenceId);
      setNotice(`Reversal ${item.referenceId} processed.`);
      await load();
    } catch (value) {
      setError(messageOf(value));
    } finally {
      setBusy(false);
    }
  }
  async function recover(item: ProviderTransaction) {
    if (!window.confirm(`Retry financial effects for ${item.referenceId}?`)) return;
    setBusy(true);
    try {
      await adminApi.recoverFinancialEffects(item.referenceId);
      setNotice(`Financial recovery requested for ${item.referenceId}.`);
      await load();
    } catch (value) {
      setError(messageOf(value));
    } finally {
      setBusy(false);
    }
  }
  if (!canView && !canViewIncome && !canProcessReversal && !canRequestReversal) return null;
  const tabs: Array<[View, string]> = [];
  if (canView) tabs.push(["transactions", "All transactions"]);
  if (canViewIncome) tabs.push(["income", "Pending provider income"]);
  if (canProcessReversal || canRequestReversal) tabs.push(["reversals", "Reversals"]);
  return (
    <AdminPanel className="mb-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-black">Transaction operations</h2>
          <p className="text-xs text-muted-foreground">
            Provider transactions, income settlement and reversal lifecycle.
          </p>
        </div>
        <button
          type="button"
          onClick={() => void load()}
          disabled={loading}
          className="rounded-xl border border-border p-3"
        >
          <RefreshCw size={16} className={loading ? "animate-spin" : ""} />
        </button>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {tabs.map(([key, text]) => (
          <button
            type="button"
            key={key}
            onClick={() => {
              setView(key);
              setStatus("");
            }}
            className={`rounded-xl px-4 py-2.5 text-xs font-extrabold ${view === key ? "bg-secondary text-white" : "border border-border"}`}
          >
            {text}
          </button>
        ))}
      </div>
      {error && (
        <p
          role="alert"
          className="mt-4 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700"
        >
          {error}
        </p>
      )}
      {notice && (
        <p className="mt-4 rounded-xl bg-emerald-50 p-3 text-sm font-semibold text-emerald-700">
          {notice}
        </p>
      )}
      <div className="mt-4 flex justify-end">
        <select
          value={status}
          onChange={(event) => setStatus(event.target.value)}
          className={inputClass}
        >
          <option value="">All statuses</option>
          {(view === "reversals"
            ? ["REQUESTED", "PROCESSING", "COMPLETED", "FAILED"]
            : ["INITIATED", "PROCESSING", "SUCCESS", "FAILED", "PENDING", "UNKNOWN", "REVERSED"]
          ).map((value) => (
            <option key={value}>{value}</option>
          ))}
        </select>
      </div>
      <div className="mt-4 overflow-x-auto rounded-xl border border-border">
        {loading ? (
          <div className="grid h-40 place-items-center">
            <Loader2 className="animate-spin text-primary" />
          </div>
        ) : view === "reversals" ? (
          <ReversalTable
            items={reversals}
            busy={busy}
            process={processReversal}
            canProcess={canProcessReversal}
          />
        ) : (
          <TransactionTable
            items={transactions}
            view={view}
            inspect={inspect}
            reverse={setReverseTarget}
            income={setIncomeTarget}
            recover={recover}
            canReconcileIncome={canReconcileIncome}
            canRequestReversal={canRequestReversal}
            canRecover={canRecover}
          />
        )}
      </div>
      {detail && (
        <div className="mt-4 rounded-xl border border-primary/30 p-4">
          <div className="flex justify-between">
            <h3 className="font-black">Transaction detail</h3>
            <button onClick={() => setDetail(null)}>
              <X size={18} />
            </button>
          </div>
          <div className="mt-3 grid gap-2 sm:grid-cols-3">
            {Object.entries(detail)
              .filter(([, value]) => value !== null && typeof value !== "object")
              .map(([key, value]) => (
                <div key={key} className="rounded-lg bg-muted p-2">
                  <p className="text-[9px] uppercase text-muted-foreground">
                    {key.replace(/([A-Z])/g, " $1")}
                  </p>
                  <p className="break-all text-xs font-bold">{String(value)}</p>
                </div>
              ))}
          </div>
        </div>
      )}
      {reverseTarget && (
        <Dialog
          title="Request reversal"
          busy={busy}
          close={() => setReverseTarget(null)}
          confirm={() => void requestReversal()}
        >
          <p className="break-all text-xs">{reverseTarget.referenceId}</p>
          <textarea
            value={reason}
            onChange={(event) => setReason(event.target.value)}
            rows={3}
            placeholder="Required reversal reason"
            className={`${inputClass} mt-4 w-full`}
          />
        </Dialog>
      )}
      {incomeTarget && (
        <Dialog
          title="Reconcile provider income"
          busy={busy}
          close={() => setIncomeTarget(null)}
          confirm={() => void reconcileIncome()}
        >
          <p className="break-all text-xs">{incomeTarget.referenceId}</p>
          <div className="mt-4 grid gap-3">
            <input
              type="number"
              min="0.01"
              step="0.01"
              value={income.providerIncomeAmount ?? ""}
              onChange={(event) =>
                setIncome({
                  ...income,
                  providerIncomeAmount: event.target.value ? Number(event.target.value) : undefined,
                })
              }
              placeholder="Income amount (optional)"
              className={inputClass}
            />
            <select
              value={income.incomeSource}
              onChange={(event) =>
                setIncome({
                  ...income,
                  incomeSource: event.target.value as ProviderIncomeInput["incomeSource"],
                })
              }
              className={inputClass}
            >
              <option value="VIMOPAY_WALLET">VIMOPAY WALLET</option>
              <option value="VIMOPAY_MS">VIMOPAY MS</option>
            </select>
            <input
              value={income.externalReference ?? ""}
              onChange={(event) =>
                setIncome({ ...income, externalReference: event.target.value || undefined })
              }
              placeholder="External reference (optional)"
              className={inputClass}
            />
          </div>
        </Dialog>
      )}
    </AdminPanel>
  );
}
function TransactionTable({
  items,
  view,
  inspect,
  reverse,
  income,
  recover,
  canReconcileIncome,
  canRequestReversal,
  canRecover,
}: {
  items: ProviderTransaction[];
  view: View;
  inspect: (id: string) => void;
  reverse: (item: ProviderTransaction) => void;
  income: (item: ProviderTransaction) => void;
  recover: (item: ProviderTransaction) => void;
  canReconcileIncome: boolean;
  canRequestReversal: boolean;
  canRecover: boolean;
}) {
  return (
    <table className="w-full min-w-[1000px] text-left text-xs">
      <thead className="bg-muted">
        <tr>
          {[
            "Reference",
            "User",
            "Provider",
            "Amount",
            "Status",
            "Settlement",
            "Commission",
            "Created",
            "Actions",
          ].map((value) => (
            <th key={value} className="p-3">
              {value}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {items.map((item) => (
          <tr key={item.referenceId} className="border-t">
            <td className="p-3 font-bold">{item.referenceId}</td>
            <td className="p-3">{item.userId}</td>
            <td className="p-3">
              {item.provider} / {item.operation}
            </td>
            <td className="p-3 font-bold">{money(item.amount)}</td>
            <td className="p-3 font-bold">{item.status}</td>
            <td className="p-3">{item.settlementStatus || "—"}</td>
            <td className="p-3">{item.commissionStatus || "—"}</td>
            <td className="p-3">{time(item.createdAt)}</td>
            <td className="p-3">
              <div className="flex gap-2">
                <button
                  title="View"
                  onClick={() => inspect(item.referenceId)}
                  className="rounded-lg border p-2"
                >
                  <Eye size={14} />
                </button>
                {view === "income" && canReconcileIncome && (
                  <button
                    title="Reconcile income"
                    onClick={() => income(item)}
                    className="rounded-lg border border-emerald-200 p-2 text-emerald-700"
                  >
                    <WalletCards size={14} />
                  </button>
                )}
                {view === "transactions" && canRequestReversal && item.status === "SUCCESS" && (
                  <button
                    title="Request reversal"
                    onClick={() => reverse(item)}
                    className="rounded-lg border border-amber-200 p-2 text-amber-700"
                  >
                    <RotateCcw size={14} />
                  </button>
                )}
                {view === "transactions" &&
                  canRecover &&
                  !item.needsReconciliation &&
                  (item.settlementStatus === "FAILED" || item.commissionStatus === "FAILED") && (
                    <button
                      onClick={() => recover(item)}
                      className="rounded-lg border px-2 py-1 font-bold text-red-700"
                    >
                      Recover
                    </button>
                  )}
              </div>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
function ReversalTable({
  items,
  busy,
  process,
  canProcess,
}: {
  items: ProviderReversal[];
  busy: boolean;
  process: (item: ProviderReversal) => void;
  canProcess: boolean;
}) {
  return (
    <table className="w-full min-w-[850px] text-left text-xs">
      <thead className="bg-muted">
        <tr>
          {["Reversal", "Transaction", "Provider", "Amount", "Status", "Reason", "Action"].map(
            (value) => (
              <th key={value} className="p-3">
                {value}
              </th>
            ),
          )}
        </tr>
      </thead>
      <tbody>
        {items.map((item) => (
          <tr key={item.referenceId} className="border-t">
            <td className="p-3 font-bold">{item.referenceId}</td>
            <td className="p-3">{item.providerTransactionReference}</td>
            <td className="p-3">{item.provider}</td>
            <td className="p-3">{money(item.amount)}</td>
            <td className="p-3 font-bold">{item.status}</td>
            <td className="p-3">{item.failedReason || item.reason || "—"}</td>
            <td className="p-3">
              {canProcess && ["REQUESTED", "FAILED"].includes(item.status) && (
                <button
                  disabled={busy}
                  onClick={() => void process(item)}
                  className="rounded-lg bg-primary px-3 py-2 font-bold text-white"
                >
                  {item.status === "FAILED" ? "Retry" : "Process"}
                </button>
              )}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
function Dialog({
  title,
  busy,
  close,
  confirm,
  children,
}: {
  title: string;
  busy: boolean;
  close: () => void;
  confirm: () => void;
  children: React.ReactNode;
}) {
  return (
    <div className="fixed inset-0 z-[100] grid place-items-center bg-secondary/60 p-4">
      <div role="dialog" aria-modal="true" className="w-full max-w-lg rounded-2xl bg-white p-6">
        <h2 className="text-xl font-black">{title}</h2>
        <div className="mt-2">{children}</div>
        <div className="mt-5 flex justify-end gap-2">
          <button
            type="button"
            disabled={busy}
            onClick={close}
            className="rounded-xl border px-4 py-3 text-xs font-bold"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={busy}
            onClick={confirm}
            className="rounded-xl bg-primary px-4 py-3 text-xs font-bold text-white"
          >
            {busy ? "Working..." : "Confirm"}
          </button>
        </div>
      </div>
    </div>
  );
}
