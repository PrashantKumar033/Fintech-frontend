import { r as require_jsx_runtime } from "./_libs/react+tanstack__react-query.mjs";
import { t as ManagementRoutePage } from "./_ssr/management-route-page-BPKcnOXT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_-COsxa983.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ManagementRoutePage, {
	role: "DISTRIBUTOR",
	base: "/distributor"
});
//#endregion
export { SplitComponent as component };
