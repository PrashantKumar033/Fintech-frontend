//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DKwI6siv.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/activity",
			"/contact",
			"/forgot-password",
			"/login",
			"/privacy",
			"/refund-policy",
			"/register",
			"/services",
			"/terms",
			"/admin/account-setup",
			"/admin/login",
			"/admin/onboarding",
			"/distributor/$",
			"/distributor/account-setup",
			"/distributor/dashboard",
			"/master-distributor/$",
			"/master-distributor/account-setup",
			"/master-distributor/dashboard",
			"/retailer/account-setup",
			"/retailer/dashboard",
			"/retailer/settings",
			"/admin/",
			"/distributor/",
			"/master-distributor/",
			"/admin/commissions/hierarchy",
			"/admin/profile/bank",
			"/admin/profile/kyc",
			"/distributor/aeps/balance-enquiry",
			"/distributor/aeps/cash-withdrawal",
			"/distributor/aeps/mini-statement",
			"/distributor/aeps/transactions",
			"/distributor/profile/bank",
			"/distributor/profile/kyc",
			"/distributor/wallet/transfer",
			"/master-distributor/profile/bank",
			"/master-distributor/profile/kyc",
			"/master-distributor/wallet/history",
			"/master-distributor/wallet/requests",
			"/master-distributor/wallet/transfer",
			"/retailer/wallet/transfer",
			"/admin/access/",
			"/admin/api-settings/",
			"/admin/banking/",
			"/admin/commissions/",
			"/admin/kyc/",
			"/admin/legal/",
			"/admin/merchants/",
			"/admin/profile/",
			"/admin/reports/",
			"/admin/settings/",
			"/admin/settlements/",
			"/admin/sms/",
			"/admin/transactions/",
			"/distributor/aeps/",
			"/distributor/commission/",
			"/distributor/profile/",
			"/distributor/reports/",
			"/distributor/retailers/",
			"/distributor/settings/",
			"/distributor/support/",
			"/distributor/wallet/",
			"/master-distributor/commission/",
			"/master-distributor/kyc/",
			"/master-distributor/notifications/",
			"/master-distributor/profile/",
			"/master-distributor/reports/",
			"/master-distributor/settings/",
			"/master-distributor/support/",
			"/master-distributor/transactions/",
			"/master-distributor/wallet/",
			"/retailer/aeps/",
			"/retailer/bank/",
			"/retailer/kyc/",
			"/retailer/transactions/",
			"/retailer/wallet/",
			"/admin/merchants/add/",
			"/admin/merchants/list/",
			"/distributor/retailers/add/",
			"/master-distributor/network/distributors/",
			"/master-distributor/network/retailers/",
			"/master-distributor/network/tree/",
			"/master-distributor/network/distributors/add/"
		],
		preloads: [
			"/assets/index-CVLtlQ65.js",
			"/assets/useRouter-Dpb7RwMI.js",
			"/assets/link-CUOYqXrb.js",
			"/assets/fileRoute-CW4_dn4B.js",
			"/assets/preload-helper-CNW_eQwo.js",
			"/assets/QueryClientProvider-D2ORKNlU.js",
			"/assets/list-CAoURA0o.js",
			"/assets/commissions-mAHBTUnH.js",
			"/assets/account-setup-BLOG6YbP.js",
			"/assets/dashboard-ZU8OuJP8.js",
			"/assets/dashboard-Dfujpk0t.js",
			"/assets/merchants-CFsLsaqy.js",
			"/assets/bank-C6M0-WGb.js",
			"/assets/kyc-qdR18wyp.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CVLtlQ65.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CKpZ3itH.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/arrow-up-right-BvVdVLFn.js",
			"/assets/banknote-C6usj-O4.js",
			"/assets/chevron-right-CVOu2CR6.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/credit-card-maer9814.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/site-footer-BuZRVEOg.js",
			"/assets/fingerprint-pattern-DusAVo6P.js",
			"/assets/layers-CcIsRSix.js",
			"/assets/lock-B_gNe_BY.js",
			"/assets/plus-Bdnb2ZNb.js",
			"/assets/receipt-DFDQG__6.js",
			"/assets/rocket-DQwWGqf5.js",
			"/assets/send-CbjhJMmq.js",
			"/assets/shield-BW8Z1vjs.js",
			"/assets/smartphone-BtuZSEaD.js",
			"/assets/phone-mock-Dwfrz5MA.js",
			"/assets/tv-DknOYPfw.js",
			"/assets/wallet-C_FdkSA2.js",
			"/assets/zap-BAHwXssL.js"
		]
	},
	"/about": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-CSMJ4_F7.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/site-footer-BuZRVEOg.js",
			"/assets/headphones-CSMfsWDB.js",
			"/assets/rocket-DQwWGqf5.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/phone-mock-Dwfrz5MA.js",
			"/assets/zap-BAHwXssL.js",
			"/assets/about-team-DwbCHxeD.js"
		]
	},
	"/activity": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/activity.tsx",
		children: void 0,
		preloads: [
			"/assets/activity-DsvKPI9S.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-BID2KZD9.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/audit-detail-dialog-D4ZgQXQb.js",
			"/assets/operations-api-C_845XxJ.js"
		]
	},
	"/contact": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-Bd3XyJUc.js",
			"/assets/clock-3-CGRh6MXR.js",
			"/assets/site-footer-BuZRVEOg.js",
			"/assets/mail-COJLXX0Q.js",
			"/assets/map-pin-DQIlFshA.js",
			"/assets/phone-DvXayWc-.js",
			"/assets/send-CbjhJMmq.js"
		]
	},
	"/forgot-password": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/forgot-password.tsx",
		children: void 0,
		preloads: [
			"/assets/forgot-password-DjwsK0Tc.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-left-BjAwhohy.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/eye-off-McVPoG-a.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/site-footer-BuZRVEOg.js",
			"/assets/key-round-CZp0iHdH.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/user-D00v0c_Y.js"
		]
	},
	"/login": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DdvR2O_L.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/eye-off-McVPoG-a.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/site-footer-BuZRVEOg.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/lock-B_gNe_BY.js",
			"/assets/shield-BW8Z1vjs.js",
			"/assets/smartphone-BtuZSEaD.js",
			"/assets/admin-api-B3Yh5hKN.js"
		]
	},
	"/privacy": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/privacy.tsx",
		children: void 0,
		preloads: [
			"/assets/privacy-DOYNGp3Y.js",
			"/assets/policy-page-DqR167Ck.js",
			"/assets/shield-check-ChgPxF7N.js"
		]
	},
	"/refund-policy": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/refund-policy.tsx",
		children: void 0,
		preloads: [
			"/assets/refund-policy-DE9CI_yu.js",
			"/assets/policy-page-DqR167Ck.js",
			"/assets/rotate-ccw-CBht_CfB.js"
		]
	},
	"/register": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-BZxdMP3H.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-left-BjAwhohy.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/site-footer-BuZRVEOg.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/rocket-DQwWGqf5.js",
			"/assets/shield-check-ChgPxF7N.js"
		]
	},
	"/services": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/services.tsx",
		children: void 0,
		preloads: [
			"/assets/services-BbgYhedz.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/badge-check-BwLOlpyy.js",
			"/assets/banknote-C6usj-O4.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/credit-card-maer9814.js",
			"/assets/site-footer-BuZRVEOg.js",
			"/assets/flame-vsWJXxaR.js",
			"/assets/landmark-dUYLgG_6.js",
			"/assets/receipt-text-Dgko8puo.js",
			"/assets/send-CbjhJMmq.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/smartphone-BtuZSEaD.js",
			"/assets/store-D_GWgnJN.js",
			"/assets/wifi-BXtKiUfv.js",
			"/assets/zap-BAHwXssL.js",
			"/assets/about-team-DwbCHxeD.js"
		]
	},
	"/terms": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/terms.tsx",
		children: void 0,
		preloads: [
			"/assets/terms-BhwK4O51.js",
			"/assets/file-text-Dp5fkK0S.js",
			"/assets/policy-page-DqR167Ck.js"
		]
	},
	"/admin/login": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DmrCV5eh.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/eye-off-McVPoG-a.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/lock-keyhole-DX4BFJYB.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/admin-api-B3Yh5hKN.js"
		]
	},
	"/admin/onboarding": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/onboarding.tsx",
		children: void 0,
		preloads: [
			"/assets/onboarding-BkXhmzM8.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/lock-keyhole-DX4BFJYB.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/admin-api-B3Yh5hKN.js"
		]
	},
	"/distributor/$": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/$.tsx",
		children: void 0,
		preloads: ["/assets/_-UU__bXiS.js", "/assets/management-route-page-DCVXDQbJ.js"]
	},
	"/distributor/account-setup": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/account-setup.tsx",
		children: void 0,
		preloads: ["/assets/account-setup-DynGcbPC.js"]
	},
	"/master-distributor/$": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/$.tsx",
		children: void 0,
		preloads: ["/assets/_-69vfdg3X.js", "/assets/management-route-page-DCVXDQbJ.js"]
	},
	"/master-distributor/account-setup": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/account-setup.tsx",
		children: void 0,
		preloads: ["/assets/account-setup-CE3l6-3X.js"]
	},
	"/retailer/account-setup": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/account-setup.tsx",
		children: void 0,
		preloads: ["/assets/account-setup-CNi-y7T3.js"]
	},
	"/retailer/dashboard": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-HIQ-S_o2.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-BID2KZD9.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/activity-F3hX8pd-.js",
			"/assets/badge-check-BwLOlpyy.js",
			"/assets/banknote-C6usj-O4.js",
			"/assets/building-2-CatBgH1_.js",
			"/assets/chevron-right-CVOu2CR6.js",
			"/assets/credit-card-maer9814.js",
			"/assets/fingerprint-pattern-DusAVo6P.js",
			"/assets/flame-vsWJXxaR.js",
			"/assets/gift-ngJNahPQ.js",
			"/assets/headphones-CSMfsWDB.js",
			"/assets/indian-rupee-C3OWDxyx.js",
			"/assets/landmark-dUYLgG_6.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-BW8Z1vjs.js",
			"/assets/smartphone-BtuZSEaD.js",
			"/assets/tv-DknOYPfw.js",
			"/assets/wallet-C_FdkSA2.js",
			"/assets/wifi-BXtKiUfv.js",
			"/assets/operations-api-C_845XxJ.js"
		]
	},
	"/retailer/settings": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-BkypciCK.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-BID2KZD9.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/badge-check-BwLOlpyy.js",
			"/assets/section-tabs-BQRa3xAK.js",
			"/assets/chevron-right-CVOu2CR6.js",
			"/assets/eye-off-McVPoG-a.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/key-round-CZp0iHdH.js",
			"/assets/contact-verification-center-dQSC7zx9.js",
			"/assets/mail-COJLXX0Q.js",
			"/assets/network-tYjdoXH5.js",
			"/assets/phone-DvXayWc-.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/shield-BW8Z1vjs.js",
			"/assets/user-D00v0c_Y.js"
		]
	},
	"/distributor/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/index.tsx",
		children: void 0,
		preloads: ["/assets/distributor-Dk5Lj7Zl.js"]
	},
	"/master-distributor/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/index.tsx",
		children: void 0,
		preloads: ["/assets/master-distributor-Di0yjKyq.js"]
	},
	"/admin/commissions/hierarchy": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/commissions/hierarchy.tsx",
		children: void 0,
		preloads: [
			"/assets/hierarchy-DIHFvbQ6.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/section-tabs-BQRa3xAK.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/plus-Bdnb2ZNb.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/search-De6vCcHc.js",
			"/assets/trash-2-FVXA8-WK.js",
			"/assets/admin-api-B3Yh5hKN.js",
			"/assets/action-permission-notice-CynqGYpG.js"
		]
	},
	"/admin/profile/bank": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/profile/bank.tsx",
		children: void 0,
		preloads: ["/assets/bank-DXKEd80Y.js"]
	},
	"/admin/profile/kyc": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/profile/kyc.tsx",
		children: void 0,
		preloads: ["/assets/kyc-C8JKnFQl.js"]
	},
	"/distributor/aeps/balance-enquiry": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/balance-enquiry.tsx",
		children: void 0,
		preloads: [
			"/assets/balance-enquiry-D0SIw3Dc.js",
			"/assets/landmark-dUYLgG_6.js",
			"/assets/module-placeholder-B0Vv-3Dp.js"
		]
	},
	"/distributor/aeps/cash-withdrawal": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/cash-withdrawal.tsx",
		children: void 0,
		preloads: [
			"/assets/cash-withdrawal-D3zPlvFh.js",
			"/assets/banknote-C6usj-O4.js",
			"/assets/module-placeholder-B0Vv-3Dp.js"
		]
	},
	"/distributor/aeps/mini-statement": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/mini-statement.tsx",
		children: void 0,
		preloads: [
			"/assets/mini-statement-CCPRsXLW.js",
			"/assets/file-text-Dp5fkK0S.js",
			"/assets/module-placeholder-B0Vv-3Dp.js"
		]
	},
	"/distributor/aeps/transactions": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/transactions.tsx",
		children: void 0,
		preloads: [
			"/assets/transactions-DSN4ULbD.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/transaction-detail-dialog-B-P-RYIl.js",
			"/assets/distributor-api-BYUUpFTH.js"
		]
	},
	"/distributor/profile/bank": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/profile/bank.tsx",
		children: void 0,
		preloads: ["/assets/bank-Ca4D2Nml.js"]
	},
	"/distributor/profile/kyc": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/profile/kyc.tsx",
		children: void 0,
		preloads: ["/assets/kyc-C5B7-y5h.js"]
	},
	"/distributor/wallet/transfer": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/wallet/transfer.tsx",
		children: void 0,
		preloads: [
			"/assets/transfer-MfAQ6Bn0.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-left-CADTCfEr.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/section-tabs-BQRa3xAK.js",
			"/assets/user-round-check-Dt5Lwnve.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/indian-rupee-C3OWDxyx.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/wallet-cards-Dqz3d6ph.js",
			"/assets/distributor-api-BYUUpFTH.js",
			"/assets/action-permission-notice-CynqGYpG.js",
			"/assets/operations-api-C_845XxJ.js"
		]
	},
	"/master-distributor/profile/bank": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/profile/bank.tsx",
		children: void 0,
		preloads: ["/assets/bank-D7RnVsVT.js"]
	},
	"/master-distributor/profile/kyc": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/profile/kyc.tsx",
		children: void 0,
		preloads: ["/assets/kyc-Co_jrsnj.js"]
	},
	"/master-distributor/wallet/history": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/wallet/history.tsx",
		children: void 0,
		preloads: [
			"/assets/history-BBSxdz78.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/module-placeholder-BilWAK1-.js"
		]
	},
	"/master-distributor/wallet/requests": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/wallet/requests.tsx",
		children: void 0,
		preloads: [
			"/assets/requests-BNK_fYEI.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/module-placeholder-BilWAK1-.js"
		]
	},
	"/master-distributor/wallet/transfer": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/wallet/transfer.tsx",
		children: void 0,
		preloads: [
			"/assets/transfer-C4BptUVD.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-left-CADTCfEr.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/section-tabs-BQRa3xAK.js",
			"/assets/user-round-check-Dt5Lwnve.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/indian-rupee-C3OWDxyx.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/wallet-cards-Dqz3d6ph.js",
			"/assets/master-distributor-api-BisgGCVZ.js",
			"/assets/action-permission-notice-CynqGYpG.js",
			"/assets/operations-api-C_845XxJ.js"
		]
	},
	"/retailer/wallet/transfer": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/wallet/transfer.tsx",
		children: void 0,
		preloads: [
			"/assets/transfer-C6NL2TSr.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-BID2KZD9.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-left-CADTCfEr.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/section-tabs-BQRa3xAK.js",
			"/assets/user-round-check-Dt5Lwnve.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/indian-rupee-C3OWDxyx.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/wallet-cards-Dqz3d6ph.js",
			"/assets/action-permission-notice-CynqGYpG.js",
			"/assets/operations-api-C_845XxJ.js"
		]
	},
	"/admin/api-settings/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/api-settings/index.tsx",
		children: void 0,
		preloads: [
			"/assets/api-settings-Bhz_P2qF.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/activity-F3hX8pd-.js",
			"/assets/cable-DIxbaW5r.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/admin-feature-grid-DTX1YCtF.js"
		]
	},
	"/admin/banking/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/banking/index.tsx",
		children: void 0,
		preloads: ["/assets/banking-DclEsITX.js", "/assets/admin-layout-CtDMk_P8.js"]
	},
	"/admin/commissions/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/commissions/index.tsx",
		children: void 0,
		preloads: [
			"/assets/commissions-BlH4vu0f.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/section-tabs-BQRa3xAK.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/indian-rupee-C3OWDxyx.js",
			"/assets/layers-CcIsRSix.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/x-BZsgst37.js",
			"/assets/pen-line-DREmztiJ.js",
			"/assets/plus-Bdnb2ZNb.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/search-De6vCcHc.js",
			"/assets/admin-api-B3Yh5hKN.js",
			"/assets/operations-api-C_845XxJ.js"
		]
	},
	"/admin/kyc/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/kyc/index.tsx",
		children: void 0,
		preloads: [
			"/assets/kyc-CWz32xle.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/section-tabs-BQRa3xAK.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/x-BZsgst37.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/admin-api-B3Yh5hKN.js",
			"/assets/action-permission-notice-CynqGYpG.js"
		]
	},
	"/admin/legal/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/legal/index.tsx",
		children: void 0,
		preloads: [
			"/assets/legal-UmOLSGjW.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/section-tabs-BQRa3xAK.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/file-check-corner-Dvje3IS9.js",
			"/assets/lock-keyhole-DX4BFJYB.js",
			"/assets/admin-feature-grid-DTX1YCtF.js"
		]
	},
	"/admin/profile/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/profile/index.tsx",
		children: void 0,
		preloads: ["/assets/profile-QBuPupzt.js", "/assets/admin-profile-page-_YS_iDnE.js"]
	},
	"/admin/reports/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/reports/index.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-D7PLMk5e.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/search-De6vCcHc.js",
			"/assets/admin-api-B3Yh5hKN.js",
			"/assets/audit-detail-dialog-D4ZgQXQb.js"
		]
	},
	"/admin/settings/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/settings/index.tsx",
		children: void 0,
		preloads: ["/assets/settings-C_zU9YTN.js", "/assets/admin-settings-page-DzzNVc3Q.js"]
	},
	"/admin/settlements/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/settlements/index.tsx",
		children: void 0,
		preloads: ["/assets/settlements-G_-e1jAr.js", "/assets/admin-layout-CtDMk_P8.js"]
	},
	"/admin/sms/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/sms/index.tsx",
		children: void 0,
		preloads: [
			"/assets/sms-c5IJmWAO.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/cable-DIxbaW5r.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/admin-feature-grid-DTX1YCtF.js"
		]
	},
	"/admin/transactions/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/transactions/index.tsx",
		children: void 0,
		preloads: [
			"/assets/transactions-DpXeEJHc.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/section-tabs-BQRa3xAK.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/x-BZsgst37.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/rotate-ccw-CBht_CfB.js",
			"/assets/search-De6vCcHc.js",
			"/assets/wallet-cards-Dqz3d6ph.js",
			"/assets/admin-api-B3Yh5hKN.js",
			"/assets/action-permission-notice-CynqGYpG.js"
		]
	},
	"/distributor/aeps/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/index.tsx",
		children: void 0,
		preloads: [
			"/assets/aeps-CARpk5Uv.js",
			"/assets/banknote-C6usj-O4.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/file-text-Dp5fkK0S.js",
			"/assets/landmark-dUYLgG_6.js"
		]
	},
	"/distributor/commission/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/commission/index.tsx",
		children: void 0,
		preloads: [
			"/assets/commission-movgq2Ro.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/indian-rupee-C3OWDxyx.js",
			"/assets/admin-api-B3Yh5hKN.js",
			"/assets/distributor-api-BYUUpFTH.js"
		]
	},
	"/distributor/profile/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/profile/index.tsx",
		children: void 0,
		preloads: ["/assets/profile-CRSyRwXp.js", "/assets/admin-profile-page-_YS_iDnE.js"]
	},
	"/distributor/reports/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/reports/index.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-DUSRV7wv.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/distributor-api-BYUUpFTH.js"
		]
	},
	"/distributor/retailers/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/retailers/index.tsx",
		children: void 0,
		preloads: [
			"/assets/retailers-BDaDZFcP.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/store-D_GWgnJN.js",
			"/assets/user-plus-BkWABhos.js",
			"/assets/distributor-api-BYUUpFTH.js"
		]
	},
	"/distributor/settings/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/settings/index.tsx",
		children: void 0,
		preloads: ["/assets/settings-KNI-OJgA.js", "/assets/admin-settings-page-DzzNVc3Q.js"]
	},
	"/distributor/support/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/support/index.tsx",
		children: void 0,
		preloads: [
			"/assets/support-DKVAYcj_.js",
			"/assets/headphones-CSMfsWDB.js",
			"/assets/module-placeholder-B0Vv-3Dp.js"
		]
	},
	"/distributor/wallet/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/wallet/index.tsx",
		children: void 0,
		preloads: [
			"/assets/wallet-BzLYWgk2.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-left-CADTCfEr.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/fingerprint-pattern-DusAVo6P.js",
			"/assets/gift-ngJNahPQ.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/wallet-cards-Dqz3d6ph.js",
			"/assets/distributor-api-BYUUpFTH.js",
			"/assets/operations-api-C_845XxJ.js"
		]
	},
	"/master-distributor/commission/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/commission/index.tsx",
		children: void 0,
		preloads: [
			"/assets/commission-CRGVtgZc.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/indian-rupee-C3OWDxyx.js",
			"/assets/admin-api-B3Yh5hKN.js",
			"/assets/master-distributor-api-BisgGCVZ.js"
		]
	},
	"/master-distributor/kyc/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/kyc/index.tsx",
		children: void 0,
		preloads: [
			"/assets/kyc-XwtmTSDw.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/module-placeholder-BilWAK1-.js"
		]
	},
	"/master-distributor/notifications/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/notifications/index.tsx",
		children: void 0,
		preloads: [
			"/assets/notifications-CkB3_sYE.js",
			"/assets/section-tabs-BQRa3xAK.js",
			"/assets/module-placeholder-BilWAK1-.js"
		]
	},
	"/master-distributor/profile/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/profile/index.tsx",
		children: void 0,
		preloads: ["/assets/profile-D8g2CoPu.js", "/assets/admin-profile-page-_YS_iDnE.js"]
	},
	"/master-distributor/reports/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/reports/index.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-DuOm6W7b.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/master-distributor-api-BisgGCVZ.js"
		]
	},
	"/master-distributor/settings/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/settings/index.tsx",
		children: void 0,
		preloads: ["/assets/settings-BynDp6o7.js", "/assets/admin-settings-page-DzzNVc3Q.js"]
	},
	"/master-distributor/support/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/support/index.tsx",
		children: void 0,
		preloads: [
			"/assets/support-O0GBQQIx.js",
			"/assets/headphones-CSMfsWDB.js",
			"/assets/module-placeholder-BilWAK1-.js"
		]
	},
	"/master-distributor/transactions/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/transactions/index.tsx",
		children: void 0,
		preloads: [
			"/assets/transactions-CpTsJDkT.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/transaction-detail-dialog-B-P-RYIl.js",
			"/assets/master-distributor-api-BisgGCVZ.js"
		]
	},
	"/master-distributor/wallet/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/wallet/index.tsx",
		children: void 0,
		preloads: [
			"/assets/wallet-Db01-IiJ.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-left-CADTCfEr.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/fingerprint-pattern-DusAVo6P.js",
			"/assets/gift-ngJNahPQ.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/wallet-cards-Dqz3d6ph.js",
			"/assets/master-distributor-api-BisgGCVZ.js",
			"/assets/operations-api-C_845XxJ.js"
		]
	},
	"/retailer/aeps/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/aeps/index.tsx",
		children: void 0,
		preloads: [
			"/assets/aeps-CvMkpX2-.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-BID2KZD9.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/banknote-C6usj-O4.js",
			"/assets/section-tabs-BQRa3xAK.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/clock-3-CGRh6MXR.js",
			"/assets/fingerprint-pattern-DusAVo6P.js",
			"/assets/landmark-dUYLgG_6.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/map-pin-DQIlFshA.js",
			"/assets/receipt-text-Dgko8puo.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/wallet-cards-Dqz3d6ph.js",
			"/assets/action-permission-notice-CynqGYpG.js"
		]
	},
	"/retailer/bank/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/bank/index.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-D62pb7vg.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-BID2KZD9.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/badge-check-BwLOlpyy.js",
			"/assets/section-tabs-BQRa3xAK.js",
			"/assets/building-2-CatBgH1_.js",
			"/assets/landmark-dUYLgG_6.js",
			"/assets/pen-line-DREmztiJ.js",
			"/assets/plus-Bdnb2ZNb.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/trash-2-FVXA8-WK.js",
			"/assets/action-permission-notice-CynqGYpG.js",
			"/assets/role-aware-account-page-DVtBq6un.js"
		]
	},
	"/retailer/kyc/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/kyc/index.tsx",
		children: void 0,
		preloads: [
			"/assets/kyc-BJyPTYyn.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-BID2KZD9.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/badge-check-BwLOlpyy.js",
			"/assets/section-tabs-BQRa3xAK.js",
			"/assets/file-check-corner-Dvje3IS9.js",
			"/assets/fingerprint-pattern-DusAVo6P.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/trash-2-FVXA8-WK.js",
			"/assets/action-permission-notice-CynqGYpG.js",
			"/assets/role-aware-account-page-DVtBq6un.js"
		]
	},
	"/retailer/transactions/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/transactions/index.tsx",
		children: void 0,
		preloads: [
			"/assets/transactions-DJK5E4iY.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-BID2KZD9.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/transaction-detail-dialog-B-P-RYIl.js",
			"/assets/receipt-DFDQG__6.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/search-De6vCcHc.js",
			"/assets/operations-api-C_845XxJ.js"
		]
	},
	"/retailer/wallet/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/wallet/index.tsx",
		children: void 0,
		preloads: [
			"/assets/wallet-BV6cbnhb.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-BID2KZD9.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-left-CADTCfEr.js",
			"/assets/fingerprint-pattern-DusAVo6P.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/wallet-cards-Dqz3d6ph.js",
			"/assets/operations-api-C_845XxJ.js"
		]
	},
	"/admin/merchants/add/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/merchants/add/index.tsx",
		children: void 0,
		preloads: ["/assets/add-CN9WNJTA.js"]
	},
	"/admin/merchants/list/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/merchants/list/index.tsx",
		children: void 0,
		preloads: [
			"/assets/list-DbRDGhJe.js",
			"/assets/section-tabs-BQRa3xAK.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/search-De6vCcHc.js",
			"/assets/user-plus-BkWABhos.js"
		]
	},
	"/distributor/retailers/add/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/retailers/add/index.tsx",
		children: void 0,
		preloads: ["/assets/add-BqsLtD_4.js"]
	},
	"/master-distributor/network/distributors/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/network/distributors/index.tsx",
		children: void 0,
		preloads: [
			"/assets/distributors-BXR_F6ES.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/network-tYjdoXH5.js",
			"/assets/user-plus-BkWABhos.js",
			"/assets/master-distributor-api-BisgGCVZ.js"
		]
	},
	"/master-distributor/network/retailers/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/network/retailers/index.tsx",
		children: void 0,
		preloads: [
			"/assets/retailers-Dh4Gj36h.js",
			"/assets/store-D_GWgnJN.js",
			"/assets/module-placeholder-BilWAK1-.js"
		]
	},
	"/master-distributor/network/tree/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/network/tree/index.tsx",
		children: void 0,
		preloads: [
			"/assets/tree-3i2udTcC.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/section-tabs-BQRa3xAK.js",
			"/assets/admin-layout-CtDMk_P8.js",
			"/assets/network-tYjdoXH5.js",
			"/assets/master-distributor-api-BisgGCVZ.js"
		]
	},
	"/master-distributor/network/distributors/add/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/network/distributors/add/index.tsx",
		children: void 0,
		preloads: ["/assets/add-Cu0NPjwQ.js"]
	}
} });
//#endregion
export { tsrStartManifest };
