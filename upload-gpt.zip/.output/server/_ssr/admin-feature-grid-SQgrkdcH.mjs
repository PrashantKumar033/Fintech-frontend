import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { Jt as CircleCheck, Ut as Clock3, pn as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { n as AdminPanel } from "./admin-layout-Cf_Fn8iZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-feature-grid-SQgrkdcH.js
var import_jsx_runtime = require_jsx_runtime();
function AdminFeatureGrid({ features }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-4 md:grid-cols-2 xl:grid-cols-3",
		children: features.map(({ title, description, icon: Icon, available }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
			className: "group",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 20 })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: `flex items-center gap-1 rounded-full px-2 py-1 text-[10px] font-extrabold ${available ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}`,
						children: [available ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { size: 12 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { size: 12 }), available ? "API READY" : "PLANNED"]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-5 text-lg font-black",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 min-h-12 text-sm leading-6 text-muted-foreground",
					children: description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center gap-1 text-xs font-extrabold text-primary",
					children: [available ? "Open workflow" : "Backend contract required", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { size: 14 })]
				})
			]
		}, title))
	});
}
//#endregion
export { AdminFeatureGrid as t };
