import { r as __toESM } from "../_runtime.mjs";
import { d as logo_default } from "./role-hierarchy-B8AZOwBW.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { Jt as CircleCheck, T as ShieldCheck, ct as LockKeyhole, lt as LoaderCircle, mn as ArrowRight } from "../_libs/lucide-react.mjs";
import { c as getAdminSession, l as updateAdminOnboarding, r as adminAuthApi } from "./admin-api-DUkIMU28.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/onboarding-BdOTFPtt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var steps = [
	"ADD_PHONE",
	"VERIFY_PHONE_OTP",
	"ADD_PAN",
	"CHANGE_PASSWORD",
	"CHANGE_MPIN"
];
function SuperAdminOnboarding() {
	const navigate = useNavigate();
	const initial = getAdminSession();
	const [step, setStep] = (0, import_react.useState)(initial?.nextStep || "ADD_PHONE");
	const [values, setValues] = (0, import_react.useState)({});
	const [error, setError] = (0, import_react.useState)("");
	const [message, setMessage] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!getAdminSession()) navigate({ to: "/admin/login" });
		else if (!getAdminSession()?.onboardingRequired) navigate({ to: "/admin" });
	}, [navigate]);
	const set = (key, value) => setValues((current) => ({
		...current,
		[key]: value
	}));
	async function submit(event) {
		event.preventDefault();
		setError("");
		setMessage("");
		setLoading(true);
		try {
			let result;
			if (step === "ADD_PHONE") result = await adminAuthApi.sendOnboardingPhoneOtp(values.phoneNumber);
			else if (step === "VERIFY_PHONE_OTP") result = await adminAuthApi.verifyOnboardingPhoneOtp(values.otp);
			else if (step === "ADD_PAN") result = await adminAuthApi.addOnboardingPan(values.panNumber);
			else if (step === "CHANGE_PASSWORD") {
				if (values.newPassword !== values.confirmPassword) throw new Error("New passwords do not match.");
				result = await adminAuthApi.changeOnboardingPassword(values.currentPassword, values.newPassword);
			} else {
				if (values.newMpin !== values.confirmMpin) throw new Error("New MPINs do not match.");
				result = await adminAuthApi.changeOnboardingMpin(values.currentMpin, values.newMpin);
			}
			updateAdminOnboarding(result.nextStep, result.onboardingStatus);
			setMessage(result.message);
			setValues({});
			if (!result.nextStep) setTimeout(() => void navigate({ to: "/admin" }), 700);
			else setStep(result.nextStep);
		} catch (reason) {
			setError(reason instanceof Error ? reason.message : "Onboarding step failed.");
		} finally {
			setLoading(false);
		}
	}
	const position = Math.max(0, steps.indexOf(step));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "min-h-screen bg-[#f3f8f6] p-5 sm:p-10",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-2xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: logo_default,
				alt: "UMOBIPAY",
				className: "h-10"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 rounded-[28px] border border-border bg-white p-6 shadow-xl sm:p-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-14 w-14 place-items-center rounded-2xl bg-secondary text-white",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockKeyhole, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-xs font-extrabold uppercase tracking-[.18em] text-primary",
						children: "Secure Super Admin setup"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 text-3xl font-black",
						children: "Complete account onboarding"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-6 text-muted-foreground",
						children: "Temporary credentials cannot access protected administration APIs until all security steps are completed."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-7 flex gap-2",
						children: steps.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-2 flex-1 rounded-full ${index <= position ? "bg-primary" : "bg-muted"}` }, item))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: submit,
						className: "mt-8 space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StepFields, {
								step,
								values,
								set
							}),
							error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700",
								children: error
							}),
							message && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "flex items-center gap-2 rounded-xl bg-emerald-50 p-3 text-sm font-semibold text-emerald-700",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { size: 17 }), message]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								disabled: loading,
								className: "flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3.5 text-sm font-extrabold text-white disabled:opacity-60",
								children: [
									loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
										className: "animate-spin",
										size: 18
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 18 }),
									" Continue securely ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 16 })
								]
							})
						]
					})
				]
			})]
		})
	});
}
var input = "mt-2 w-full rounded-xl border border-border px-4 py-3 text-sm outline-none focus:border-primary";
function Field({ label, type = "text", value, onChange, maxLength }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-xs font-extrabold uppercase tracking-wide",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			required: true,
			type,
			value: value || "",
			maxLength,
			onChange: (e) => onChange(e.target.value),
			className: input
		})]
	});
}
function StepFields({ step, values, set }) {
	if (step === "ADD_PHONE") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
		label: "Indian phone number",
		value: values.phoneNumber,
		onChange: (v) => set("phoneNumber", v)
	});
	if (step === "VERIFY_PHONE_OTP") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
		label: "6-digit phone OTP",
		value: values.otp,
		maxLength: 6,
		onChange: (v) => set("otp", v.replace(/\D/g, ""))
	});
	if (step === "ADD_PAN") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
		label: "PAN number",
		value: values.panNumber,
		maxLength: 10,
		onChange: (v) => set("panNumber", v.toUpperCase())
	});
	if (step === "CHANGE_PASSWORD") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Temporary password",
			type: "password",
			value: values.currentPassword,
			onChange: (v) => set("currentPassword", v)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "New password",
			type: "password",
			value: values.newPassword,
			onChange: (v) => set("newPassword", v)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Confirm new password",
			type: "password",
			value: values.confirmPassword,
			onChange: (v) => set("confirmPassword", v)
		})
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Temporary MPIN",
			type: "password",
			value: values.currentMpin,
			maxLength: 4,
			onChange: (v) => set("currentMpin", v.replace(/\D/g, ""))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "New 4-digit MPIN",
			type: "password",
			value: values.newMpin,
			maxLength: 4,
			onChange: (v) => set("newMpin", v.replace(/\D/g, ""))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Confirm new MPIN",
			type: "password",
			value: values.confirmMpin,
			maxLength: 4,
			onChange: (v) => set("confirmMpin", v.replace(/\D/g, ""))
		})
	] });
}
//#endregion
export { SuperAdminOnboarding as component };
