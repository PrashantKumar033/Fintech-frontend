import { i as CreateMemberPage } from "./router-CU2_-cwA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/add-CwfMIpQp.js
var SplitComponent = CreateMemberPage;
//#endregion
export { SplitComponent as component };
