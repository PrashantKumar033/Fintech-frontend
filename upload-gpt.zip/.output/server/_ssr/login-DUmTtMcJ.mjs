import { r as __toESM } from "../_runtime.mjs";
import { _ as requiresDeviceVerification, b as syncMyPermissions, d as logo_default, n as authApi, v as saveSession, y as signedInHome } from "./role-hierarchy-B8AZOwBW.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { It as Eye, Lt as EyeOff, S as Smartphone, lt as LoaderCircle, mn as ArrowRight, st as Lock, w as Shield } from "../_libs/lucide-react.mjs";
import { o as clearAdminSession } from "./admin-api-DUkIMU28.mjs";
import { n as SiteNav, t as SiteFooter } from "./site-footer-DjO9amhV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-DUmTtMcJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var inputClass = "w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-secondary outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20";
function LoginPage() {
	const [identifier, setIdentifier] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [loginWith, setLoginWith] = (0, import_react.useState)("PASSWORD");
	const [show, setShow] = (0, import_react.useState)(false);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [challenge, setChallenge] = (0, import_react.useState)(null);
	const [otp, setOtp] = (0, import_react.useState)("");
	async function submit(event) {
		event.preventDefault();
		setError("");
		if (!identifier.trim() || !password.trim()) return setError("Please complete all required fields.");
		setLoading(true);
		try {
			const result = await authApi.login({
				identifier: identifier.trim(),
				loginWith,
				password
			});
			if (requiresDeviceVerification(result)) {
				setChallenge(result);
				setOtp("");
				return;
			}
			await completeLogin(result);
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Login failed.");
		} finally {
			setLoading(false);
		}
	}
	async function verifyDevice(event) {
		event.preventDefault();
		setError("");
		if (!challenge || !/^\d{6}$/.test(otp)) return setError("Enter the 6-digit verification code.");
		setLoading(true);
		try {
			await completeLogin(await authApi.verifyDeviceLogin(challenge.challengeId, otp));
		} catch (caught) {
			setError(caught instanceof Error ? caught.message : "Device verification failed.");
		} finally {
			setLoading(false);
		}
	}
	async function completeLogin(result) {
		clearAdminSession();
		saveSession(result.accessToken, result.identity);
		try {
			await syncMyPermissions(result.accessToken);
		} catch (permissionError) {
			console.warn("Unable to pre-load effective permissions after login.", permissionError);
		}
		window.location.assign(signedInHome(result));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen overflow-x-clip bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "pointer-events-none fixed inset-0 -z-10 bg-grid opacity-30"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto flex min-h-[calc(100vh-5rem)] max-w-7xl items-center px-6 py-16",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid w-full gap-12 lg:grid-cols-[1.1fr_1fr] lg:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "hidden lg:block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-2 rounded-full border border-accent/30 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-accent",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { size: 13 }), " Secure login"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "mt-6 font-display text-5xl font-extrabold leading-tight text-secondary",
								children: [
									"Welcome back to",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gradient-warm",
										children: "UMOBIPAY"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 max-w-sm text-foreground/70",
								children: "Sign in securely using your login ID, username, email address, or phone number."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-8 space-y-3",
								children: [
									{
										icon: Smartphone,
										text: "Multiple login identifiers"
									},
									{
										icon: Lock,
										text: "Password and MPIN support"
									},
									{
										icon: ArrowRight,
										text: "Secure refresh-token session"
									}
								].map(({ icon: Icon, text }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3 rounded-2xl border border-border bg-card px-5 py-3.5 shadow-soft",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-9 w-9 place-items-center rounded-xl bg-mint",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 16 })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-medium text-secondary",
										children: text
									})]
								}, text))
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "gradient-border rounded-[2rem] bg-card p-8 shadow-elegant sm:p-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: logo_default,
									alt: "UMOBIPAY",
									className: "mb-6 h-10 w-auto"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl font-extrabold text-secondary",
								children: challenge ? "Verify this device" : "Sign in to your account"
							}),
							challenge ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-foreground/60",
									children: challenge.message
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-sm font-semibold text-secondary",
									children: ["Code sent to ", challenge.maskedEmail]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: verifyDevice,
									className: "mt-6 space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "6-digit verification code",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												autoFocus: true,
												autoComplete: "one-time-code",
												inputMode: "numeric",
												pattern: "[0-9]{6}",
												maxLength: 6,
												value: otp,
												onChange: (e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6)),
												placeholder: "000000",
												className: `${inputClass} text-center text-xl tracking-[.5em]`
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-xs text-muted-foreground",
											children: ["Expires ", new Date(challenge.expiresAt).toLocaleString("en-IN")]
										}),
										error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											role: "alert",
											className: "rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700",
											children: error
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											disabled: loading || otp.length !== 6,
											className: "flex w-full items-center justify-center gap-2 rounded-xl bg-secondary py-3.5 text-sm font-semibold text-secondary-foreground disabled:opacity-60",
											children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
												className: "animate-spin",
												size: 17
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Verify & Sign In ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 16 })] })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											disabled: loading,
											onClick: () => {
												setChallenge(null);
												setOtp("");
												setError("");
											},
											className: "w-full rounded-xl border border-border py-3 text-sm font-semibold",
											children: "Back to login"
										})
									]
								})
							] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm text-foreground/60",
									children: [
										"New user?",
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/register",
											className: "font-semibold text-primary hover:underline",
											children: "Register here"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-6 flex rounded-xl border border-border bg-muted p-1",
									children: ["PASSWORD", "MPIN"].map((method) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => {
											setLoginWith(method);
											setPassword("");
										},
										className: `flex-1 rounded-lg py-2 text-sm font-semibold ${loginWith === method ? "bg-card text-secondary shadow-sm" : "text-muted-foreground"}`,
										children: method === "PASSWORD" ? "Password" : "MPIN"
									}, method))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
									onSubmit: submit,
									className: "mt-6 space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Login ID / Username / Email / Phone",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												autoComplete: "username",
												value: identifier,
												onChange: (e) => setIdentifier(e.target.value),
												placeholder: "Enter your identifier",
												className: inputClass
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: loginWith === "PASSWORD" ? "Password" : "MPIN",
											action: loginWith === "PASSWORD" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/forgot-password",
												className: "text-xs font-semibold text-primary hover:underline",
												children: "Forgot Password?"
											}) : void 0,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "relative",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													autoComplete: "current-password",
													type: show ? "text" : "password",
													value: password,
													onChange: (e) => setPassword(e.target.value),
													maxLength: loginWith === "MPIN" ? 6 : void 0,
													inputMode: loginWith === "MPIN" ? "numeric" : void 0,
													placeholder: loginWith === "PASSWORD" ? "Enter password" : "Enter MPIN",
													className: `${inputClass} pr-11`
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => setShow(!show),
													"aria-label": "Toggle visibility",
													className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground",
													children: show ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { size: 17 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 17 })
												})]
											})
										}),
										error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											role: "alert",
											className: "rounded-xl bg-red-50 px-4 py-3 text-sm text-red-700",
											children: error
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											disabled: loading,
											className: "flex w-full items-center justify-center gap-2 rounded-xl bg-secondary py-3.5 text-sm font-semibold text-secondary-foreground disabled:opacity-60",
											children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
												className: "animate-spin",
												size: 17
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Sign In ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 16 })] })
										})
									]
								})
							] })
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
function Field({ label, action, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "mb-1.5 flex items-center justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-semibold uppercase tracking-widest text-muted-foreground",
				children: label
			}), action]
		}), children]
	});
}
//#endregion
export { LoginPage as component };
