import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { Kt as CircleUser, T as ShieldCheck, _t as KeyRound, ct as LockKeyhole, it as Mail } from "../_libs/lucide-react.mjs";
import { s as getAdminActor } from "./admin-api-DUkIMU28.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-Cf_Fn8iZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-profile-page-C29b7XLq.js
var import_jsx_runtime = require_jsx_runtime();
function AdminProfilePage() {
	const actor = getAdminActor();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "profile",
		eyebrow: "Account",
		title: "My profile",
		description: "Administrator identity, security and access information in one dedicated workspace.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 xl:grid-cols-[340px_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
				className: "h-fit text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mx-auto grid h-24 w-24 place-items-center rounded-3xl bg-secondary text-3xl font-black text-white",
						children: actor?.name?.charAt(0).toUpperCase() || "A"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-5 text-2xl font-black",
						children: actor?.name || "Administrator"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs font-extrabold uppercase tracking-wider text-primary",
						children: actor?.role || "ADMIN"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileStat, {
							label: "Session",
							value: "Active"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileStat, {
							label: "Account",
							value: "Verified"
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-black",
					children: "Account overview"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
							icon: CircleUser,
							label: "Display name",
							value: actor?.name || "Administrator"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
							icon: ShieldCheck,
							label: "Access level",
							value: actor?.role || "ADMIN"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
							icon: Mail,
							label: "Account type",
							value: actor?.kind === "SUPER_ADMIN" ? "Dedicated Super Admin" : "Identity Administrator"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
							icon: KeyRound,
							label: "Authentication",
							value: "Password or MPIN"
						})
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-emerald-50 text-emerald-700",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockKeyhole, { size: 20 })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-black",
						children: "Security controls"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-6 text-muted-foreground",
						children: "Password, MPIN, device verification and session-management actions will appear here when their role-specific backend contracts are exposed."
					})] })]
				}) })]
			})]
		})
	});
}
function ProfileStat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-muted p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] font-bold uppercase text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm font-black",
			children: value
		})]
	});
}
function Detail({ icon: Icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3 rounded-xl border border-border p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid h-9 w-9 place-items-center rounded-lg bg-primary/10 text-primary",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 17 })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] font-bold uppercase text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-0.5 text-sm font-extrabold",
			children: value
		})] })]
	});
}
//#endregion
export { AdminProfilePage as t };
