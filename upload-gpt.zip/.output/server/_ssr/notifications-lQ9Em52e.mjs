import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { sn as Bell } from "../_libs/lucide-react.mjs";
import { t as MasterDistributorModulePlaceholder } from "./module-placeholder-C_Fr-5KU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notifications-lQ9Em52e.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MasterDistributorModulePlaceholder, {
		active: "settings",
		icon: Bell,
		title: "Notifications",
		description: "Operational alerts and account messages.",
		pending: "A role-scoped notification inbox endpoint is not available yet."
	});
}
//#endregion
export { Page as component };
