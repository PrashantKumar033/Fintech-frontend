import { o as MasterDashboard } from "./router-CU2_-cwA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/master-distributor-DMIwyTcn.js
var SplitComponent = MasterDashboard;
//#endregion
export { SplitComponent as component };
