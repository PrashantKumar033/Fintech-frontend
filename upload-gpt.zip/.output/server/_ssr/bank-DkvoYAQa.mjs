import { r as __toESM } from "../_runtime.mjs";
import { a as credentialsPending, c as getSession, p as managementBasePath, u as isManagementRole, y as signedInHome } from "./role-hierarchy-B8AZOwBW.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { F as RefreshCw, T as ShieldCheck, V as Plus, gt as Landmark, h as Trash2, in as Building2, q as PenLine, un as BadgeCheck } from "../_libs/lucide-react.mjs";
import { a as useEffectiveAccess, r as UI_PERMISSION } from "./section-tabs-DrewjFLo.mjs";
import { t as ActionPermissionNotice } from "./action-permission-notice-CGOJQx-x.mjs";
import { i as complianceMessage, n as ServiceNotice, r as complianceApi } from "./business-page-8tLFPoxT.mjs";
import { t as RoleAwareAccountPage } from "./role-aware-account-page-BvvB6S-H.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/bank-DkvoYAQa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var initial = {
	bankName: "",
	ifsc: "",
	branchName: "",
	accountHolderName: "",
	accountNumber: "",
	confirm: "",
	accountType: "SAVINGS",
	purposes: ["PAYOUT"]
};
function BankAccountsPage() {
	const { can } = useEffectiveAccess();
	const canManageBank = can(UI_PERMISSION.BANK_MANAGE, [
		"ADMIN",
		"MASTER_DISTRIBUTOR",
		"DISTRIBUTOR",
		"RETAILER"
	]);
	const navigate = useNavigate(), [session, setSession] = (0, import_react.useState)(null), [accounts, setAccounts] = (0, import_react.useState)([]), [bankDirectory, setBankDirectory] = (0, import_react.useState)([]), [form, setForm] = (0, import_react.useState)(initial), [adding, setAdding] = (0, import_react.useState)(false), [editingId, setEditingId] = (0, import_react.useState)(null), [busy, setBusy] = (0, import_react.useState)(false), [loading, setLoading] = (0, import_react.useState)(true), [message, setMessage] = (0, import_react.useState)(null);
	async function load(token) {
		setLoading(true);
		try {
			const loaded = await complianceApi.banks(token);
			if (loaded.length) try {
				const primary = await complianceApi.primaryBank(token);
				setAccounts(loaded.map((account) => ({
					...account,
					isDefault: account.id === primary.id
				})));
			} catch {
				setAccounts(loaded);
			}
			else setAccounts([]);
		} catch (e) {
			setMessage({
				ok: false,
				text: complianceMessage(e)
			});
		} finally {
			setLoading(false);
		}
	}
	async function loadBankDirectory(token) {
		try {
			const response = await complianceApi.bankDirectory(token);
			const root = response && typeof response === "object" ? response : {};
			const candidates = Array.isArray(response) ? response : Array.isArray(root.data) ? root.data : Array.isArray(root.banks) ? root.banks : [];
			setBankDirectory(candidates.map((item) => typeof item === "string" ? item : item && typeof item === "object" ? String(item.bankName || item.name || "") : "").filter(Boolean));
		} catch {
			setBankDirectory([]);
		}
	}
	(0, import_react.useEffect)(() => {
		const value = getSession();
		if (!value) {
			navigate({ to: "/login" });
			return;
		}
		if (credentialsPending(value.identity)) {
			window.location.replace(signedInHome(value));
			return;
		}
		setSession(value);
		setForm((f) => ({
			...f,
			accountHolderName: value.identity.fullName
		}));
		load(value.accessToken);
		loadBankDirectory(value.accessToken);
	}, [navigate]);
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "animate-spin text-primary" })
	});
	const activeSession = session;
	async function submit(e) {
		e.preventDefault();
		setMessage(null);
		if (!canManageBank) return setMessage({
			ok: false,
			text: `Permission ${UI_PERMISSION.BANK_MANAGE} is required.`
		});
		if (form.accountNumber && form.accountNumber !== form.confirm) return setMessage({
			ok: false,
			text: "Account numbers do not match."
		});
		if (!form.purposes.length) return setMessage({
			ok: false,
			text: "Select at least one account purpose."
		});
		setBusy(true);
		try {
			const payload = {
				bankName: form.bankName.trim(),
				ifsc: form.ifsc.toUpperCase(),
				branchName: form.branchName || void 0,
				accountHolderName: form.accountHolderName.trim(),
				accountType: form.accountType,
				purposes: form.purposes,
				...form.accountNumber ? { accountNumber: form.accountNumber } : {}
			};
			if (editingId) await complianceApi.updateBank(activeSession.accessToken, editingId, payload);
			else await complianceApi.addBank(activeSession.accessToken, {
				...payload,
				accountNumber: form.accountNumber
			});
			setForm({
				...initial,
				accountHolderName: activeSession.identity.fullName
			});
			setAdding(false);
			setEditingId(null);
			setMessage({
				ok: true,
				text: editingId ? "Bank account updated and sent for verification." : "Bank account verified and added successfully."
			});
			await load(activeSession.accessToken);
		} catch (err) {
			setMessage({
				ok: false,
				text: complianceMessage(err)
			});
		} finally {
			setBusy(false);
		}
	}
	const verified = accounts.some((a) => a.status === "ACTIVE" && a.verificationStatus === "VERIFIED" && a.ownershipStatus === "VERIFIED");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RoleAwareAccountPage, {
		identity: session.identity,
		section: "bank",
		eyebrow: "Settlement & payouts",
		title: "Bank accounts",
		description: "Manage verified settlement accounts independently from KYC and AEPS services.",
		children: [!canManageBank && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionPermissionNotice, {
				permission: UI_PERMISSION.BANK_MANAGE,
				title: "Bank accounts are read-only",
				text: "Add, edit, primary-bank and remove actions are not enabled for your active package."
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-6 lg:grid-cols-[1fr_340px]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-border bg-card p-5 shadow-soft sm:p-7",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-extrabold text-secondary",
							children: "Your bank accounts"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Account details are encrypted; only the last four digits are displayed."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							disabled: !canManageBank,
							onClick: () => {
								setEditingId(null);
								setForm({
									...initial,
									accountHolderName: activeSession.identity.fullName
								});
								setAdding(!adding);
							},
							className: "flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-white disabled:cursor-not-allowed disabled:opacity-50",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 16 }), " Add account"]
						})]
					}),
					message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceNotice, {
							ok: message.ok,
							children: message.text
						})
					}),
					loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid h-40 place-items-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "animate-spin text-primary" })
					}) : accounts.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 space-y-3",
						children: accounts.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
							className: "rounded-2xl border border-border bg-background p-5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-4 sm:flex-row sm:items-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-12 w-12 place-items-center rounded-xl bg-mint text-secondary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
													className: "font-extrabold text-secondary",
													children: a.bankName
												}), a.isDefault && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "rounded-full bg-primary/10 px-2 py-1 text-[10px] font-bold text-primary",
													children: "PRIMARY"
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-1 text-sm text-muted-foreground",
												children: [
													"•••• ",
													a.accountNumberLast4,
													" · ",
													a.accountType,
													" · ",
													a.ifsc
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-xs text-muted-foreground",
												children: a.accountHolderName
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-right",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: `text-xs font-extrabold ${a.verificationStatus === "VERIFIED" ? "text-emerald-600" : "text-amber-600"}`,
												children: a.verificationStatus
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-[10px] text-muted-foreground",
												children: ["Ownership ", a.ownershipStatus]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: async () => {
													setBusy(true);
													setMessage(null);
													try {
														const latest = await complianceApi.bank(session.accessToken, a.id);
														setEditingId(latest.id);
														setAdding(true);
														setForm({
															bankName: latest.bankName,
															ifsc: latest.ifsc,
															branchName: latest.branchName || "",
															accountHolderName: latest.accountHolderName,
															accountNumber: "",
															confirm: "",
															accountType: latest.accountType,
															purposes: latest.purposes
														});
													} catch (error) {
														setMessage({
															ok: false,
															text: complianceMessage(error)
														});
													} finally {
														setBusy(false);
													}
												},
												disabled: !canManageBank || busy,
												className: "mt-2 inline-flex items-center gap-1 text-xs font-bold text-primary",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { size: 12 }), " Edit"]
											}),
											!a.isDefault && a.status === "ACTIVE" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												disabled: !canManageBank || busy,
												onClick: async () => {
													try {
														await complianceApi.setPrimary(session.accessToken, a.id);
														await load(session.accessToken);
														setMessage({
															ok: true,
															text: "Primary bank account updated."
														});
													} catch (error) {
														setMessage({
															ok: false,
															text: complianceMessage(error)
														});
													}
												},
												className: "ml-3 mt-2 text-xs font-bold text-primary disabled:cursor-not-allowed disabled:opacity-50",
												children: "Set as primary"
											}),
											!a.isDefault && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												disabled: !canManageBank || busy,
												onClick: async () => {
													if (!window.confirm(`Remove ${a.bankName} account ending ${a.accountNumberLast4}?`)) return;
													try {
														await complianceApi.deleteBank(session.accessToken, a.id);
														await load(session.accessToken);
														setMessage({
															ok: true,
															text: "Bank account removed."
														});
													} catch (error) {
														setMessage({
															ok: false,
															text: complianceMessage(error)
														});
													}
												},
												className: "ml-3 mt-2 inline-flex items-center gap-1 text-xs font-bold text-red-600",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 12 }), " Remove"]
											})
										]
									})
								]
							})
						}, a.id))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 rounded-2xl border border-dashed border-border p-12 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building2, { className: "mx-auto text-muted-foreground" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 font-bold text-secondary",
								children: "No bank account connected"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: "Add an account to enable settlement and AEPS onboarding."
							})
						]
					}),
					adding && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: submit,
						className: "mt-6 grid gap-4 rounded-2xl border border-border bg-mint/40 p-5 sm:grid-cols-2",
						children: [
							[
								["Bank name", "bankName"],
								["IFSC code", "ifsc"],
								["Branch (optional)", "branchName"],
								["Account holder name", "accountHolderName"],
								["Account number", "accountNumber"],
								["Confirm account number", "confirm"]
							].map(([label, key]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs font-bold uppercase text-muted-foreground",
								children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									list: key === "bankName" ? "supported-bank-directory" : void 0,
									required: key !== "branchName" && (!editingId || !["accountNumber", "confirm"].includes(key)),
									value: form[key],
									onChange: (e) => setForm({
										...form,
										[key]: key === "ifsc" ? e.target.value.toUpperCase().slice(0, 11) : key.includes("accountNumber") || key === "confirm" ? e.target.value.replace(/\D/g, "").slice(0, 18) : e.target.value
									}),
									className: "mt-1.5 w-full rounded-xl border border-border bg-card px-4 py-3 text-sm font-normal normal-case outline-none focus:border-primary"
								})]
							}, key)),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
								id: "supported-bank-directory",
								children: bankDirectory.map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: name }, name))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs font-bold uppercase text-muted-foreground",
								children: ["Account type", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: form.accountType,
									onChange: (e) => setForm({
										...form,
										accountType: e.target.value
									}),
									className: "mt-1.5 w-full rounded-xl border border-border bg-card px-4 py-3 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "SAVINGS",
											children: "Savings"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "CURRENT",
											children: "Current"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "SALARY",
											children: "Salary"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
								className: "text-xs font-bold uppercase text-muted-foreground",
								children: ["Use account for", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 flex gap-4 rounded-xl border border-border bg-card px-4 py-3 normal-case",
									children: ["PAYOUT", "DMT"].map((purpose) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "checkbox",
												checked: form.purposes.includes(purpose),
												onChange: (event) => setForm({
													...form,
													purposes: event.target.checked ? [...form.purposes, purpose] : form.purposes.filter((item) => item !== purpose)
												})
											}),
											" ",
											purpose
										]
									}, purpose))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: !canManageBank || busy,
								className: "self-end rounded-xl bg-secondary py-3 text-sm font-bold text-white disabled:opacity-50",
								children: busy ? "Saving account…" : editingId ? "Save and re-verify" : "Verify and save"
							}),
							editingId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setEditingId(null);
									setAdding(false);
									setForm({
										...initial,
										accountHolderName: activeSession.identity.fullName
									});
								},
								className: "rounded-xl border border-border bg-white py-3 text-sm font-bold text-secondary",
								children: "Cancel edit"
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl bg-secondary p-6 text-white",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 text-lg font-extrabold",
							children: "Bank verification"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-white/65",
							children: "The Bank service validates account status, IFSC and ownership before saving."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-extrabold uppercase text-muted-foreground",
							children: "Next step"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 font-extrabold text-secondary",
							children: "Complete business KYC"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: "KYC is a separate compliance service and can be started after bank verification."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: isManagementRole(session.identity.role) ? `${managementBasePath(session.identity.role)}/profile/kyc` : "/retailer/kyc",
							className: `mt-4 flex items-center justify-center gap-2 rounded-xl py-3 text-sm font-bold ${verified ? "bg-primary text-white" : "pointer-events-none bg-muted text-muted-foreground"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { size: 16 }), " Continue to KYC"]
						})
					]
				})]
			})]
		})]
	});
}
//#endregion
export { BankAccountsPage as component };
