import { u as isManagementRole } from "./role-hierarchy-B8AZOwBW.mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as AdminLayout } from "./admin-layout-Cf_Fn8iZ.mjs";
import { t as BusinessPage } from "./business-page-8tLFPoxT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/role-aware-account-page-BvvB6S-H.js
var import_jsx_runtime = require_jsx_runtime();
function RoleAwareAccountPage({ identity, section, eyebrow, title, description, children }) {
	if (isManagementRole(identity.role)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "profile",
		eyebrow,
		title,
		description,
		children
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BusinessPage, {
		identity,
		active: section,
		eyebrow,
		title,
		description,
		children
	});
}
//#endregion
export { RoleAwareAccountPage as t };
