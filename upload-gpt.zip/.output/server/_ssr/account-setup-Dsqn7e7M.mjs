import { r as AdminIdentitySetup } from "./router-CU2_-cwA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-setup-Dsqn7e7M.js
var SplitComponent = AdminIdentitySetup;
//#endregion
export { SplitComponent as component };
