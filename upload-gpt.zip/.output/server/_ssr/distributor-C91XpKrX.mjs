import { a as DistributorDashboard } from "./router-CU2_-cwA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/distributor-C91XpKrX.js
var SplitComponent = DistributorDashboard;
//#endregion
export { SplitComponent as component };
