import { createFileRoute } from "@tanstack/react-router";
import { AepsWorkspace } from "@/components/aeps-workspace";

export const Route = createFileRoute("/retailer/aeps/")({
  head: () => ({ meta: [{ title: "VimoPay AEPS — UMOBIPAY" }] }),
  component: AepsWorkspace,
});
