import { r as require_jsx_runtime } from "./_libs/react+tanstack__react-query.mjs";
import { t as ManagementRoutePage } from "./_ssr/management-route-page-jFL1wqm2.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_-D2vz8MOc.js
var import_jsx_runtime = require_jsx_runtime();
var SplitComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ManagementRoutePage, {
	role: "MASTER_DISTRIBUTOR",
	base: "/master-distributor"
});
//#endregion
export { SplitComponent as component };
