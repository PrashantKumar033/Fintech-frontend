import { t as AdminSettingsPage } from "./admin-settings-page-Bn1P6wwa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-vrOqMZHi.js
var SplitComponent = AdminSettingsPage;
//#endregion
export { SplitComponent as component };
