import { t as AdminProfilePage } from "./admin-profile-page-B20y24uW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-D0J5rmuI.js
var SplitComponent = AdminProfilePage;
//#endregion
export { SplitComponent as component };
