import { t as AdminSettingsPage } from "./admin-settings-page-Bn1P6wwa.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-xLnsloB9.js
var SplitComponent = AdminSettingsPage;
//#endregion
export { SplitComponent as component };
