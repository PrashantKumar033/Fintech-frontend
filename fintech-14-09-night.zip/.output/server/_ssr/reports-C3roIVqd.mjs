import { r as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-BjKbHz5M.mjs";
import { t as masterDistributorApi } from "./master-distributor-api-eH9rUdoO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports-C3roIVqd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const [data, setData] = (0, import_react.useState)(null), [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		masterDistributorApi.audits().then(setData).catch((e) => setError(e instanceof Error ? e.message : "Reports unavailable."));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "reports",
		eyebrow: "Reports",
		title: "Account activity",
		description: "Live audit activity for your authenticated account.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 rounded-xl bg-amber-50 p-3 text-xs text-amber-800",
				children: "Downstream business and transaction reports require a scoped network-report API."
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 rounded-xl bg-red-50 p-3 text-sm text-red-700",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "overflow-x-auto",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[650px] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3",
								children: "Date"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3",
								children: "Service"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3",
								children: "Action"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3",
								children: "Status"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: data?.data.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3",
								children: new Date(r.createdAt).toLocaleString("en-IN")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3",
								children: r.service
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3 font-bold",
								children: r.action
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3",
								children: r.status
							})
						]
					}, r.id)) })]
				}), !data?.data.length && !error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-10 text-center text-sm text-muted-foreground",
					children: "No activity records returned."
				})]
			})
		] })
	});
}
//#endregion
export { Page as component };
