import { r as __toESM } from "../_runtime.mjs";
import { a as performance_default } from "../_libs/h3+rou3+srvx+unenv.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { $t as ChevronLeft, E as Shield, Et as Globe, H as Quote, L as Rocket, Qt as ChevronRight, Rt as Eye, S as Star, Ut as CreditCard, V as Receipt, W as Plus, Xt as CircleCheck, a as Wallet, et as Minus, g as TrendingUp, gt as Layers, h as Tv, hn as ArrowRight, j as Send, jt as FingerprintPattern, ln as Banknote, mn as ArrowUpRight, pn as ArrowUp, t as Zap, ut as Lock, w as Smartphone, y as Target } from "../_libs/lucide-react.mjs";
import { n as SiteNav, t as SiteFooter } from "./site-footer-v-UByBCe.mjs";
import { t as phone_mock_default } from "./phone-mock-yJTrDaUx.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-YvAzWoBC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CustomCursor() {
	const dot = (0, import_react.useRef)(null);
	const ring = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!window.matchMedia("(hover: hover) and (pointer: fine)").matches) return;
		document.body.classList.add("cursor-host");
		let mx = window.innerWidth / 2;
		let my = window.innerHeight / 2;
		let rx = mx;
		let ry = my;
		let raf = 0;
		const move = (e) => {
			mx = e.clientX;
			my = e.clientY;
			if (dot.current) dot.current.style.transform = `translate3d(${mx - 3.5}px, ${my - 3.5}px, 0)`;
			const interactive = !!e.target?.closest("a, button, input, textarea, select, [data-cursor]");
			if (ring.current) {
				ring.current.style.width = interactive ? "68px" : "40px";
				ring.current.style.height = interactive ? "68px" : "40px";
				ring.current.style.backgroundColor = interactive ? "color-mix(in oklab, var(--primary) 18%, transparent)" : "color-mix(in oklab, var(--primary) 8%, transparent)";
			}
		};
		const loop = () => {
			rx += (mx - rx) * .16;
			ry += (my - ry) * .16;
			if (ring.current) {
				const size = ring.current.offsetWidth / 2;
				ring.current.style.transform = `translate3d(${rx - size}px, ${ry - size}px, 0)`;
			}
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		window.addEventListener("mousemove", move);
		return () => {
			cancelAnimationFrame(raf);
			window.removeEventListener("mousemove", move);
			document.body.classList.remove("cursor-host");
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: ring,
		"aria-hidden": true,
		className: "cursor-ring hidden md:block"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: dot,
		"aria-hidden": true,
		className: "cursor-dot hidden md:block"
	})] });
}
function Reveal({ children, delay = 0, className = "" }) {
	const ref = (0, import_react.useRef)(null);
	const [shown, setShown] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const node = ref.current;
		if (!node) return;
		const io = new IntersectionObserver(([entry]) => {
			if (entry.isIntersecting) {
				setShown(true);
				io.disconnect();
			}
		}, { threshold: .12 });
		io.observe(node);
		return () => io.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		style: { transitionDelay: `${delay}ms` },
		className: `${shown ? "reveal-shown" : "reveal-hidden"} ${className}`,
		children
	});
}
function Counter({ to, decimals = 0, duration = 1600 }) {
	const ref = (0, import_react.useRef)(null);
	const [value, setValue] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const node = ref.current;
		if (!node) return;
		let raf = 0;
		const io = new IntersectionObserver(([entry]) => {
			if (!entry.isIntersecting) return;
			io.disconnect();
			const start = performance_default.now();
			const tick = (now) => {
				const p = Math.min((now - start) / duration, 1);
				const eased = 1 - Math.pow(1 - p, 3);
				setValue(to * eased);
				if (p < 1) raf = requestAnimationFrame(tick);
			};
			raf = requestAnimationFrame(tick);
		}, { threshold: .4 });
		io.observe(node);
		return () => {
			io.disconnect();
			cancelAnimationFrame(raf);
		};
	}, [to, duration]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		ref,
		children: value.toLocaleString("en-IN", {
			minimumFractionDigits: decimals,
			maximumFractionDigits: decimals
		})
	});
}
function SpotlightCard({ children, className = "" }) {
	const ref = (0, import_react.useRef)(null);
	const onMove = (e) => {
		const node = ref.current;
		if (!node) return;
		const r = node.getBoundingClientRect();
		node.style.setProperty("--mx", `${e.clientX - r.left}px`);
		node.style.setProperty("--my", `${e.clientY - r.top}px`);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		onMouseMove: onMove,
		className: `spotlight ${className}`,
		children
	});
}
function Magnetic({ children, className = "" }) {
	const ref = (0, import_react.useRef)(null);
	const onMove = (e) => {
		const node = ref.current;
		if (!node) return;
		const r = node.getBoundingClientRect();
		const x = e.clientX - r.left - r.width / 2;
		const y = e.clientY - r.top - r.height / 2;
		node.style.transform = `translate3d(${x * .2}px, ${y * .3}px, 0)`;
	};
	const reset = () => {
		if (ref.current) ref.current.style.transform = "translate3d(0,0,0)";
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		onMouseMove: onMove,
		onMouseLeave: reset,
		className: `inline-block transition-transform duration-300 ease-out ${className}`,
		children
	});
}
var faqs = [
	{
		q: "What services can I access through this platform?",
		a: "Mobile & DTH recharges, utility bill payments (electricity, water, gas, broadband and more), and Aadhaar-based banking services like cash withdrawal and balance inquiry."
	},
	{
		q: "Are the transactions secure?",
		a: "Absolutely. Every transaction runs through encrypted channels and follows industry-standard safety protocols, including RBI and NPCI-compliant systems."
	},
	{
		q: "What happens if a transaction fails?",
		a: "If a transaction fails due to a technical or network issue, the deducted amount is automatically refunded to your wallet or source account within 24–48 hours."
	},
	{
		q: "Do I get proof or receipt after the transaction?",
		a: "Yes. Every successful recharge, bill payment or AEPS transaction sends a confirmation via SMS, email or printed receipt with a transaction reference ID."
	}
];
function FaqSection() {
	const [open, setOpen] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "faq",
		className: "relative mx-auto max-w-7xl px-6 py-28",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "pointer-events-none absolute inset-x-0 top-10 -z-10 mx-auto h-72 max-w-3xl rounded-full bg-primary/10 blur-3xl"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
				className: "mx-auto max-w-2xl text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-bold uppercase tracking-[0.3em] text-primary",
						children: "FAQ's"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "mt-3 font-display text-4xl font-extrabold tracking-tighter text-secondary sm:text-5xl",
						children: ["Frequently asked ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-primary",
							children: "questions"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-foreground/70",
						children: "Quick answers to common queries — from account management to transaction security."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto mt-12 max-w-3xl space-y-4",
				children: faqs.map((f, i) => {
					const active = open === i;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: i * 70,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SpotlightCard, {
							className: `overflow-hidden rounded-3xl border transition-colors ${active ? "border-primary/40 bg-card" : "border-border bg-card/70"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => setOpen(active ? null : i),
								"aria-expanded": active,
								className: "flex w-full items-center justify-between gap-6 px-7 py-6 text-left",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-lg font-bold text-secondary",
									children: f.q
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `grid h-9 w-9 shrink-0 place-items-center rounded-full transition-colors ${active ? "bg-primary text-primary-foreground" : "bg-mint text-secondary"}`,
									children: active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { size: 16 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 16 })
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid transition-all duration-500 ease-out",
								style: { gridTemplateRows: active ? "1fr" : "0fr" },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "overflow-hidden",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "px-7 pb-7 text-sm leading-relaxed text-foreground/70",
										children: f.a
									})
								})
							})]
						})
					}, f.q);
				})
			})
		]
	});
}
var testimonials = [
	{
		name: "Mohit Yadav",
		role: "Client · Delhi",
		quote: "This portal is very good and attractive. It is very beneficial for all online payments — my son liked it a lot."
	},
	{
		name: "Priya Sharma",
		role: "Retailer · Jaipur",
		quote: "Recharge and bill collection on one screen. My daily wait time dropped by half and my customers genuinely love it."
	},
	{
		name: "Ramesh Yadav",
		role: "Kirana owner · Lucknow",
		quote: "DMT settlement is instant and commissions credit daily. UMOBIPAY changed the way I run my shop."
	},
	{
		name: "Arjun Nair",
		role: "Mobile agent · Kochi",
		quote: "The dashboard is beautifully simple. Even my father, who never used a smartphone, does BBPS payments now."
	}
];
function TestimonialSlider({ avatars }) {
	const [i, setI] = (0, import_react.useState)(0);
	const go = (d) => setI((p) => (p + d + testimonials.length) % testimonials.length);
	(0, import_react.useEffect)(() => {
		const t = setInterval(() => setI((p) => (p + 1) % testimonials.length), 8e3);
		return () => clearInterval(t);
	}, []);
	const t = testimonials[i];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "relative overflow-hidden bg-secondary py-28 text-secondary-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto max-w-5xl px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-bold uppercase tracking-[0.3em] text-primary",
					children: "Testimonial"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-4xl font-extrabold tracking-tighter sm:text-5xl",
					children: "What our clients say"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						"aria-label": "Previous testimonial",
						onClick: () => go(-1),
						className: "grid h-12 w-12 place-items-center rounded-full border border-secondary-foreground/20 transition-colors hover:bg-primary hover:text-primary-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { size: 18 })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						"aria-label": "Next testimonial",
						onClick: () => go(1),
						className: "grid h-12 w-12 place-items-center rounded-full border border-secondary-foreground/20 transition-colors hover:bg-primary hover:text-primary-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { size: 18 })
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SpotlightCard, {
				className: "mt-10 rounded-[2.5rem] border border-secondary-foreground/10 bg-secondary-foreground/5 p-10 backdrop-blur sm:p-14",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quote, {
						size: 40,
						className: "text-primary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-6 font-display text-2xl leading-snug tracking-tight sm:text-3xl [animation:var(--animate-float)_0s_1]",
						children: [
							"“",
							t.quote,
							"”"
						]
					}, t.name),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-10 flex items-center gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: avatars[i % avatars.length],
								alt: t.name,
								width: 56,
								height: 56,
								loading: "lazy",
								className: "h-14 w-14 rounded-full object-cover ring-2 ring-primary/60"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-display text-lg font-bold",
									children: t.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-secondary-foreground/70",
									children: t.role
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden gap-1 text-primary sm:flex",
								children: [...Array(5)].map((_, k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
									size: 14,
									className: "fill-primary"
								}, k))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 flex gap-2",
						children: testimonials.map((x, k) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							"aria-label": `Show testimonial ${k + 1}`,
							onClick: () => setI(k),
							className: `h-1.5 rounded-full transition-all ${k === i ? "w-10 bg-primary" : "w-4 bg-secondary-foreground/25"}`
						}, x.name))
					})
				]
			})]
		})
	});
}
function ScrollToTop() {
	const [show, setShow] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onScroll = () => setShow(window.scrollY > 600);
		onScroll();
		window.addEventListener("scroll", onScroll, { passive: true });
		return () => window.removeEventListener("scroll", onScroll);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		"aria-label": "Scroll to top",
		onClick: () => window.scrollTo({
			top: 0,
			behavior: "smooth"
		}),
		className: `fixed bottom-8 right-8 z-40 grid h-12 w-12 place-items-center rounded-full bg-secondary text-secondary-foreground shadow-2xl transition-all duration-300 hover:bg-primary hover:text-primary-foreground ${show ? "translate-y-0 opacity-100" : "pointer-events-none translate-y-6 opacity-0"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { size: 18 })
	});
}
var testi_1_default = "/assets/testi-1-60byFK3Z.jpg";
var testi_2_default = "/assets/testi-2-CXzvTJjx.jpg";
var testi_3_default = "/assets/testi-3-D_aSGUBz.jpg";
var billers = [
	"Airtel",
	"Jio",
	"Vi",
	"BSNL",
	"BSES",
	"Tata Power",
	"Adani",
	"MSEB",
	"Tata Play",
	"Sun Direct",
	"Dish TV",
	"Airtel DTH",
	"Indraprastha Gas",
	"Mahanagar Gas",
	"JioFiber",
	"ACT Fibernet",
	"Hathway",
	"Vodafone Idea"
];
var services = [
	{
		icon: Smartphone,
		title: "Mobile & DTH",
		desc: "All operators. Instant recharge.",
		tone: "primary"
	},
	{
		icon: Send,
		title: "DMT Transfer",
		desc: "IMPS · NEFT · RTGS — 24×7.",
		tone: "secondary"
	},
	{
		icon: Zap,
		title: "Utility Bills",
		desc: "Electricity · Water · Gas · LPG.",
		tone: "primary"
	},
	{
		icon: Tv,
		title: "BBPS",
		desc: "500+ billers, one dashboard.",
		tone: "secondary"
	},
	{
		icon: Wallet,
		title: "AEPS",
		desc: "Aadhaar-enabled cash withdrawal.",
		tone: "primary"
	},
	{
		icon: Globe,
		title: "PAN / Insurance",
		desc: "PAN card, LIC and more.",
		tone: "secondary"
	}
];
var proServices = [
	{
		icon: Send,
		title: "DMT",
		desc: "Fast, secure domestic money transfer straight to any bank account — minimal documentation, 24×7 availability."
	},
	{
		icon: FingerprintPattern,
		title: "AEPS",
		desc: "Aadhaar Enabled Payment System — cash withdrawal, balance enquiry and mini statement using a fingerprint."
	},
	{
		icon: Receipt,
		title: "BBPS",
		desc: "Pay every kind of utility bill in a fast, secure manner — and earn a commission on each bill you settle."
	},
	{
		icon: CreditCard,
		title: "Credit Bill Payment",
		desc: "Instant credit-card bill payments with real-time updates so your customers never pay a late fee."
	},
	{
		icon: Layers,
		title: "Payment Gateway",
		desc: "Accept and process online payments through a single integration with banks and card networks."
	},
	{
		icon: Banknote,
		title: "Payment Collection",
		desc: "Collect via UPI, cards, net banking and wallets with automated reminders and real-time tracking."
	},
	{
		icon: Smartphone,
		title: "Recharge",
		desc: "Airtel, Jio, Vi, BSNL, Tata — recharge every operator from the web dashboard or the mobile app."
	},
	{
		icon: Wallet,
		title: "CMS",
		desc: "Manage business data, customer records and workflows from one clean, user-friendly console."
	}
];
var heroFeatures = [
	{
		icon: Smartphone,
		title: "Mobile & DTH Recharge"
	},
	{
		icon: Send,
		title: "DMT Services"
	},
	{
		icon: Zap,
		title: "Utility Bill Collection"
	},
	{
		icon: Receipt,
		title: "BBPS Services"
	}
];
var funFacts = [
	{
		to: 12,
		suffix: "",
		label: "Years of Service"
	},
	{
		to: 45,
		suffix: "M+",
		label: "Recharges Processed"
	},
	{
		to: 99.9,
		decimals: 1,
		suffix: "%",
		label: "Secure Recharges"
	},
	{
		to: 28,
		suffix: "",
		label: "Regions Covered"
	},
	{
		to: 9e4,
		suffix: "+",
		label: "Daily Recharges"
	}
];
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background overflow-x-clip",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CustomCursor, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollToTop, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative isolate bg-mint",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					"aria-hidden": true,
					className: "pointer-events-none absolute inset-x-0 bottom-0 h-[420px] w-full opacity-40",
					viewBox: "0 0 1440 420",
					fill: "none",
					preserveAspectRatio: "none",
					children: Array.from({ length: 14 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: `M0 ${180 + i * 8} C 360 ${120 + i * 10}, 1080 ${340 - i * 6}, 1440 ${200 + i * 8}`,
						stroke: "currentColor",
						strokeWidth: "1",
						className: "text-secondary/25"
					}, i))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto grid max-w-7xl gap-16 px-6 pb-20 pt-12 lg:grid-cols-[1.15fr_1fr] lg:items-center lg:pt-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-2 rounded-full bg-card px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-secondary",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-primary" }), "Simple · Seamless · Secure"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-6 font-display text-[clamp(2.75rem,6.8vw,5.75rem)] font-extrabold leading-[1.02] tracking-tighter text-primary",
							children: [
								"Welcome to",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"UMOBIPAY"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 flex flex-wrap items-center gap-x-5 gap-y-2 font-display text-xl font-bold text-primary sm:text-2xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "· Simple" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "· Seamless" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "· Secure" })
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-xl text-base leading-relaxed text-foreground/75",
							children: "Online payments made easy and fast — mobile & DTH recharge, DMT, utility bills and BBPS, all on one clean dashboard trusted by retailers across India."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 flex flex-wrap items-center gap-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex flex-wrap items-center gap-x-6 gap-y-2 text-sm font-semibold text-secondary",
								children: [
									"Online Payments",
									"Easy And Fast",
									"Safe And Secure"
								].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "inline-flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
										size: 16,
										className: "text-accent"
									}), t]
								}, t))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap items-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/services",
								className: "group inline-flex items-center gap-2 rounded-full bg-primary px-8 py-4 text-sm font-semibold text-primary-foreground shadow-elegant transition-transform hover:-translate-y-0.5",
								children: ["Get Started here", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
									size: 16,
									className: "transition-transform group-hover:translate-x-1"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/services",
								className: "inline-flex items-center gap-2 rounded-full border border-secondary/25 px-8 py-4 text-sm font-semibold text-secondary hover:bg-card",
								children: "Our Services"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-12 grid max-w-lg grid-cols-3 gap-6 border-t border-secondary/10 pt-8",
							children: [
								{
									v: "50L+",
									l: "Retailers"
								},
								{
									v: "₹1,200 Cr",
									l: "Processed"
								},
								{
									v: "99.99%",
									l: "Uptime"
								}
							].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-3xl font-extrabold text-secondary",
								children: s.v
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs uppercase tracking-widest text-muted-foreground",
								children: s.l
							})] }, s.l))
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative mx-auto w-full max-w-md",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: phone_mock_default,
									alt: "UMOBIPAY app on a phone",
									width: 900,
									height: 1600,
									className: "relative z-10 mx-auto w-full max-w-sm drop-shadow-2xl [animation:var(--animate-float)]"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute -left-4 top-16 z-20 hidden rounded-2xl border border-border bg-card p-4 shadow-soft sm:block",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid h-10 w-10 place-items-center rounded-xl bg-primary text-primary-foreground",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { size: 18 })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] uppercase tracking-widest text-muted-foreground",
											children: "Bill paid"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-bold text-secondary",
											children: "₹1,245 · BSES"
										})] })]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute -right-4 bottom-32 z-20 hidden rounded-2xl border border-border bg-card p-4 shadow-soft sm:block",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "grid h-10 w-10 place-items-center rounded-xl bg-secondary text-secondary-foreground",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { size: 18 })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-[10px] uppercase tracking-widest text-muted-foreground",
											children: "Secure"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-bold text-secondary",
											children: "256-bit encrypted"
										})] })]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute -bottom-2 left-1/2 z-20 -translate-x-1/2 rounded-full border border-border bg-card px-5 py-2 shadow-soft",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-xs font-semibold",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "flex text-primary",
											children: [...Array(5)].map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
												size: 12,
												className: "fill-primary"
											}, i))
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-secondary",
											children: "4.9 · 1.2L reviews"
										})]
									})
								})
							]
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative mx-auto max-w-7xl px-6 pb-4 pt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
					className: "mx-auto max-w-2xl text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-bold uppercase tracking-[0.3em] text-primary",
							children: "Features"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "mt-3 font-display text-4xl font-extrabold tracking-tighter text-secondary sm:text-5xl",
							children: ["Delivering ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary",
								children: "payment solutions"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-foreground/70",
							children: "At UMOBIPAY we simplify bill payments through BBPS. From utility bills to mobile recharges — fast, secure and hassle-free, all in one place."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-4",
					children: heroFeatures.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
						delay: i * 90,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SpotlightCard, {
							className: "group h-full rounded-[1.25rem] border border-border bg-card p-7 transition-transform duration-300 hover:-translate-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-14 w-14 place-items-center rounded-2xl bg-mint text-secondary transition-colors group-hover:bg-primary group-hover:text-primary-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(f.icon, { size: 24 })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-6 font-display text-lg font-bold text-secondary",
									children: f.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-foreground/65",
									children: "Instant processing, live receipts and transparent commissions on every transaction."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-5 inline-flex items-center gap-1 text-xs font-semibold text-primary opacity-0 transition-opacity group-hover:opacity-100",
									children: ["Learn more ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { size: 13 })]
								})
							]
						})
					}, f.title))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "border-y border-border bg-secondary/5 py-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-6 text-center text-xs font-bold uppercase tracking-[0.3em] text-muted-foreground",
					children: "Trusted by 500+ billers · powered by BBPS"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "group relative overflow-hidden",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute left-0 top-0 z-10 h-full w-24 bg-gradient-to-r from-background to-transparent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute right-0 top-0 z-10 h-full w-24 bg-gradient-to-l from-background to-transparent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex w-max gap-14 [animation:var(--animate-marquee)]",
							children: [...billers, ...billers].map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-2xl font-bold tracking-tight text-secondary/50 hover:text-secondary transition-colors",
								children: b
							}, i))
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative mx-auto max-w-7xl px-6 py-28",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-bold uppercase tracking-widest text-primary",
						children: "All-in-one"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "mt-3 max-w-2xl font-display text-4xl font-extrabold tracking-tighter text-secondary sm:text-6xl",
						children: ["Every payment. ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-primary",
							children: "One platform."
						})]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/services",
						className: "inline-flex items-center gap-1 text-sm font-semibold text-secondary hover:text-primary",
						children: ["See all services ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { size: 16 })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-14 grid gap-5 md:grid-cols-6 md:grid-rows-2 md:[grid-auto-rows:minmax(220px,auto)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative overflow-hidden rounded-[2rem] bg-secondary p-8 text-secondary-foreground md:col-span-3 md:row-span-2 md:p-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								"aria-hidden": true,
								className: "absolute -right-16 -top-16 h-72 w-72 rounded-full bg-primary/40 blur-3xl"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -bottom-10 -left-10 h-60 w-60 rounded-full bg-primary/20 blur-3xl" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative flex h-full flex-col justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-2 rounded-full bg-primary/20 px-3 py-1 text-[11px] font-bold uppercase tracking-widest text-primary",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-primary [animation:var(--animate-shine)]" }),
											" ",
											"Flagship"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "mt-6 font-display text-4xl font-extrabold tracking-tight sm:text-5xl",
										children: [
											"BBPS payments,",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											" made retail-simple."
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-4 max-w-md text-secondary-foreground/70",
										children: "A single API, one screen, every biller in India — from electricity to LPG to broadband. Instant settlement, transparent commissions."
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-10 flex flex-wrap gap-3",
									children: [
										"500+ billers",
										"Live receipts",
										"Auto refunds",
										"Daily settlement"
									].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full border border-secondary-foreground/15 bg-secondary-foreground/5 px-3 py-1.5 text-xs font-medium",
										children: t
									}, t))
								})]
							})
						]
					}), services.slice(0, 4).map((s, idx) => {
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `group relative overflow-hidden rounded-[2rem] p-7 transition-transform hover:-translate-y-1 ${[
								"md:col-span-2",
								"md:col-span-1",
								"md:col-span-1",
								"md:col-span-2"
							][idx]} ${s.tone === "primary" ? "bg-mint text-secondary" : "bg-card text-secondary border border-border"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `grid h-12 w-12 place-items-center rounded-2xl ${s.tone === "primary" ? "bg-primary text-primary-foreground" : "bg-secondary text-secondary-foreground"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.icon, { size: 22 })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-5 font-display text-xl font-bold",
									children: s.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-foreground/70",
									children: s.desc
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {
									size: 16,
									className: "absolute right-6 top-6 opacity-0 transition-opacity group-hover:opacity-100"
								})
							]
						}, s.title);
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "professional",
				className: "relative border-y border-border bg-mint/60 py-28",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto max-w-7xl px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
						className: "mx-auto max-w-2xl text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-bold uppercase tracking-[0.3em] text-primary",
								children: "Our Services"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "mt-3 font-display text-4xl font-extrabold tracking-tighter text-secondary sm:text-5xl",
								children: ["We provide you our ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-primary",
									children: "valuable services"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 text-foreground/70",
								children: "Eight production-grade rails powering retailers, agents and businesses across India."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4",
						children: proServices.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: i % 4 * 80,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SpotlightCard, {
								className: "group flex h-full flex-col rounded-[1.25rem] border border-border bg-card p-7 transition-all duration-300 hover:-translate-y-2 hover:border-primary/40",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-12 w-12 place-items-center rounded-2xl bg-secondary text-secondary-foreground transition-colors group-hover:bg-primary group-hover:text-primary-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(s.icon, { size: 20 })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-5 font-display text-xl font-bold text-secondary",
										children: s.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 flex-1 text-sm leading-relaxed text-foreground/65",
										children: s.desc
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/services",
										className: "mt-5 inline-flex items-center gap-1 text-xs font-bold uppercase tracking-widest text-primary",
										children: [
											"Learn more",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
												size: 13,
												className: "transition-transform group-hover:translate-x-1"
											})
										]
									})
								]
							})
						}, s.title))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto max-w-7xl px-6 py-28",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-14 lg:grid-cols-[1fr_1.1fr] lg:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-bold uppercase tracking-[0.3em] text-primary",
							children: "Why us"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "mt-3 font-display text-4xl font-extrabold tracking-tighter text-secondary sm:text-5xl",
							children: ["Why choose ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary",
								children: "UMOBIPAY?"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-md text-foreground/70",
							children: "Choose UMOBIPAY for an unparalleled Recharge and BBPS experience. Our technology keeps every transaction secure, efficient and completely transparent."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 grid max-w-md gap-3",
							children: [
								"Instant settlements, every single day",
								"Transparent, industry-best commissions",
								"24×7 human support in your language"
							].map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 rounded-2xl border border-border bg-card px-5 py-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
									size: 18,
									className: "shrink-0 text-primary"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium text-secondary",
									children: p
								})]
							}, p))
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-5 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 100,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SpotlightCard, {
								className: "h-full rounded-[2rem] bg-secondary p-8 text-secondary-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-12 w-12 place-items-center rounded-2xl bg-primary text-primary-foreground",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 20 })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-6 font-display text-2xl font-bold",
										children: "Our Vision"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm leading-relaxed text-secondary-foreground/75",
										children: "To ace the Indian e-commerce sector by redefining its concept and serving every Indian by driving a self-employment revolution through the power of mobile and Aadhaar."
									})
								]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: 200,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SpotlightCard, {
								className: "h-full rounded-[2rem] border border-border bg-card p-8",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-12 w-12 place-items-center rounded-2xl bg-mint text-secondary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { size: 20 })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-6 font-display text-2xl font-bold text-secondary",
										children: "Our Mission"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-3 text-sm leading-relaxed text-foreground/70",
										children: "To create numerous jobs through an ever-expanding network of individuals with entrepreneurial spirit, and give every Indian the best value for their money."
									})
								]
							})
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "relative overflow-hidden border-y border-border bg-card py-24",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto max-w-7xl px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-end justify-between gap-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Reveal, {
							className: "max-w-xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-bold uppercase tracking-[0.3em] text-primary",
									children: "Fun facts"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 font-display text-4xl font-extrabold tracking-tighter text-secondary sm:text-5xl",
									children: "Tap into Digital India payments"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-foreground/70",
									children: "Our Recharge, BBPS and AEPS rails are built on deep industry knowledge and years of collaboration with trusted telecom, utility and banking partners."
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Magnetic, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/contact",
							className: "inline-flex items-center gap-2 rounded-full bg-secondary px-8 py-4 text-sm font-semibold text-secondary-foreground transition-colors hover:bg-primary hover:text-primary-foreground",
							children: ["Reach out ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { size: 16 })]
						}) })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-5",
						children: funFacts.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reveal, {
							delay: i * 80,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SpotlightCard, {
								className: "h-full rounded-[1.25rem] border border-border bg-background p-7 text-center transition-transform duration-300 hover:-translate-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-display text-4xl font-black tracking-tighter text-secondary",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Counter, {
										to: f.to,
										decimals: f.decimals ?? 0
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-primary",
										children: f.suffix
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs font-semibold uppercase tracking-widest text-muted-foreground",
									children: f.label
								})]
							})
						}, f.label))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto max-w-7xl px-6 pb-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative overflow-hidden rounded-[2.5rem] bg-secondary p-10 text-secondary-foreground sm:p-16",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative grid gap-14 lg:grid-cols-2 lg:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-bold uppercase tracking-widest text-primary",
								children: "Built for scale"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-4xl font-extrabold tracking-tighter sm:text-5xl",
								children: "Enterprise-grade fintech, retail-simple UX."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 max-w-md text-secondary-foreground/70",
								children: "We handle the infra — RBI-aligned custody, PCI-DSS, real-time reconciliation — so you can focus on serving customers."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex flex-wrap gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground",
									children: "Start free trial"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/contact",
									className: "rounded-full border border-secondary-foreground/25 px-6 py-3 text-sm font-semibold",
									children: "Book a demo"
								})]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 gap-4 sm:grid-cols-3",
							children: [
								{
									icon: Shield,
									label: "PCI-DSS"
								},
								{
									icon: Lock,
									label: "256-bit SSL"
								},
								{
									icon: FingerprintPattern,
									label: "Biometric login"
								},
								{
									icon: TrendingUp,
									label: "Live analytics"
								},
								{
									icon: Rocket,
									label: "Instant onboarding"
								},
								{
									icon: Globe,
									label: "Pan-India"
								}
							].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-2xl border border-secondary-foreground/10 bg-secondary-foreground/5 p-5 backdrop-blur",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(f.icon, {
									size: 20,
									className: "text-primary"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-sm font-semibold",
									children: f.label
								})]
							}, f.label))
						})]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FaqSection, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TestimonialSlider, { avatars: [
				testi_1_default,
				testi_2_default,
				testi_3_default
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto max-w-7xl px-6 py-16",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-14 lg:grid-cols-[1fr_1.2fr] lg:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-bold uppercase tracking-widest text-primary",
							children: "How it works"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "mt-3 font-display text-4xl font-extrabold tracking-tighter text-secondary sm:text-5xl",
							children: [
								"Three steps. ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"Zero friction."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-md text-foreground/70",
							children: "Get onboarded in the time it takes to make chai. Real KYC in minutes, transacting on the same day."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-4",
						children: [
							{
								n: "01",
								t: "Sign up in 60 seconds",
								d: "Enter your mobile, verify OTP, done."
							},
							{
								n: "02",
								t: "Complete KYC",
								d: "PAN + Aadhaar. Auto-verified in minutes."
							},
							{
								n: "03",
								t: "Start transacting",
								d: "Recharge, pay bills, transfer money instantly."
							}
						].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "group flex items-center gap-6 rounded-2xl border border-border bg-card p-6 transition-colors hover:border-primary/50",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-display text-5xl font-black text-primary/30 transition-colors group-hover:text-primary",
									children: s.n
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-lg font-bold text-secondary",
										children: s.t
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-foreground/70",
										children: s.d
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {
									size: 18,
									className: "text-secondary/40 transition-transform group-hover:translate-x-1 group-hover:text-primary"
								})
							]
						}, s.n))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto max-w-7xl px-6 pb-24 pt-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative overflow-hidden rounded-[3rem] bg-primary p-12 text-primary-foreground sm:p-20",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative grid gap-10 lg:grid-cols-[1.4fr_1fr] lg:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "font-display text-5xl font-extrabold tracking-tighter sm:text-6xl",
								children: [
									"Ready to power",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									" your payments?"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 max-w-md text-lg text-primary-foreground/85",
								children: "Join 5 lakh+ agents and retailers who trust UMOBIPAY every single day."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-10 flex flex-wrap gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "rounded-full bg-background px-8 py-4 text-sm font-semibold text-secondary hover:bg-mint",
									children: "Become an Agent"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/contact",
									className: "rounded-full border border-primary-foreground/40 px-8 py-4 text-sm font-semibold hover:bg-primary-foreground/10",
									children: "Talk to sales"
								})]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-3",
							children: [
								"No setup fees",
								"Instant onboarding",
								"24/7 human support",
								"Daily settlements"
							].map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 rounded-2xl bg-primary-foreground/10 p-4 backdrop-blur",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
									size: 20,
									className: "text-primary-foreground"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: b
								})]
							}, b))
						})]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { Home as component };
