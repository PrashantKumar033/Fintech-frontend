import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { u as Route$17 } from "./router-CdmUoS7N.mjs";
import { t as NetworkAepsTransactions } from "./network-aeps-transactions-lm1oABTe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/transactions-C0JLN0zk.js
var import_jsx_runtime = require_jsx_runtime();
function MasterDistributorTransactions() {
	const { status } = Route$17.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NetworkAepsTransactions, {
		activeArea: "aeps",
		initialStatus: status ?? "",
		title: "Network AEPS transactions",
		description: "Monitor AEPS activity across your assigned Distributors and their Retailer network."
	});
}
//#endregion
export { MasterDistributorTransactions as component };
