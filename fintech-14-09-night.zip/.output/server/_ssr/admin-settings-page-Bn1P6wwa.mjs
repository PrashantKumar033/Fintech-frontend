import { r as __toESM } from "../_runtime.mjs";
import { c as getSession, h as refreshSession, n as authApi, p as managementBasePath, t as ApiError, u as isManagementRole, x as updateIdentityOnboarding } from "./role-hierarchy-3Eppvhsl.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { D as ShieldCheck, Rt as Eye, Xt as CircleCheck, dt as LockKeyhole, yt as KeyRound, zt as EyeOff } from "../_libs/lucide-react.mjs";
import { c as getAdminSession } from "./admin-api-BMvykyWe.mjs";
import { n as AdminPanel, r as ServiceState, t as AdminLayout } from "./admin-layout-BjKbHz5M.mjs";
import { n as IdentitySecurityCenter, t as ContactVerificationCenter } from "./contact-verification-center-08e6xS8_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-settings-page-Bn1P6wwa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var inputClass = "w-full rounded-xl border border-border bg-white px-4 py-3 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/15";
function AdminSettingsPage() {
	const [identity, setIdentity] = (0, import_react.useState)(() => getSession()?.identity || null);
	const isIdentityAdmin = isManagementRole(identity?.role);
	(0, import_react.useEffect)(() => {
		if (isIdentityAdmin && getSession()?.nextStep === "ADD_PAN") window.location.replace(`${managementBasePath(identity?.role)}/account-setup`);
	}, [identity?.role, isIdentityAdmin]);
	const securityComplete = Boolean(identity?.passwordChangedAt && identity?.mpinChangedAt);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "settings",
		eyebrow: "Account security",
		title: "Settings",
		description: isIdentityAdmin ? securityComplete ? "Manage your password, MPIN and account security at any time." : "Complete first-login security here. Other administration sections stay locked until both credentials are changed." : "Manage secure platform configuration.",
		children: isIdentityAdmin && identity ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CredentialSecurity, {
				identity,
				onIdentityChange: setIdentity
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactVerificationCenter, { identity }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentitySecurityCenter, {})
		] }) : getAdminSession() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceState, {
			title: "System configuration",
			description: "The current /auth/sessions and /auth/me/permissions endpoints belong to identity accounts. Dedicated Super Admin device-management endpoints are not present in the backend yet.",
			status: "Super Admin contract pending"
		}) : null
	});
}
function CredentialSecurity({ identity, onIdentityChange }) {
	const [mode, setMode] = (0, import_react.useState)(identity.passwordChangedAt ? "mpin" : "password");
	const [current, setCurrent] = (0, import_react.useState)("");
	const [next, setNext] = (0, import_react.useState)("");
	const [confirm, setConfirm] = (0, import_react.useState)("");
	const [visible, setVisible] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [message, setMessage] = (0, import_react.useState)(null);
	const complete = Boolean(identity.passwordChangedAt && identity.mpinChangedAt);
	async function submit(event) {
		event.preventDefault();
		setMessage(null);
		if (!current) return setMessage({
			ok: false,
			text: `Enter your temporary ${mode}.`
		});
		if (next !== confirm) return setMessage({
			ok: false,
			text: `New ${mode} and confirmation do not match.`
		});
		if (mode === "mpin" && !/^\d{4}$/.test(next)) return setMessage({
			ok: false,
			text: "New MPIN must contain exactly 4 digits."
		});
		if (mode === "password" && !/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W_]).{8,}$/.test(next)) return setMessage({
			ok: false,
			text: "Password needs 8+ characters with uppercase, lowercase, number and special character."
		});
		const session = getSession();
		if (!session) return window.location.replace("/login");
		const wasSetupComplete = complete;
		setBusy(true);
		try {
			if (mode === "password") {
				await authApi.changePassword(session.accessToken, {
					currentPassword: current,
					newPassword: next
				});
				const synchronized = await refreshSession();
				onIdentityChange(synchronized.identity);
				if (!synchronized.identity.mpinChangedAt) {
					updateIdentityOnboarding("CHANGE_MPIN", "CREDENTIAL_CHANGE_REQUIRED");
					setMode("mpin");
					setMessage({
						ok: true,
						text: "Password changed. Now change your temporary MPIN to unlock the Admin Console."
					});
				} else if (wasSetupComplete) setMessage({
					ok: true,
					text: "Password updated successfully. Your MPIN remains active."
				});
				else window.location.replace(managementBasePath(synchronized.identity.role));
			} else {
				await authApi.changeMpin(session.accessToken, {
					currentMpin: current,
					newMpin: next
				});
				const synchronized = await refreshSession();
				onIdentityChange(synchronized.identity);
				if (synchronized.identity.passwordChangedAt && synchronized.identity.mpinChangedAt) {
					updateIdentityOnboarding(null);
					if (wasSetupComplete) setMessage({
						ok: true,
						text: "MPIN updated successfully. Your password remains active."
					});
					else {
						setMessage({
							ok: true,
							text: "Security setup complete. Management workspace unlocked."
						});
						window.location.replace(managementBasePath(synchronized.identity.role));
					}
				} else setMessage({
					ok: false,
					text: "The refreshed account still shows a pending credential. Please try again."
				});
			}
			setCurrent("");
			setNext("");
			setConfirm("");
		} catch (error) {
			setMessage({
				ok: false,
				text: error instanceof ApiError ? error.message : "Unable to update security credentials."
			});
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 xl:grid-cols-[.7fr_1.3fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-extrabold uppercase tracking-wider text-primary",
				children: complete ? "Account protection" : "First-login status"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 text-xl font-black",
				children: complete ? "Security overview" : "Security checklist"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, {
						label: "Phone & PAN verification",
						done: true
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, {
						label: complete ? "Password protection active" : "Temporary password changed",
						done: !!identity.passwordChangedAt
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, {
						label: complete ? "MPIN protection active" : "Temporary MPIN changed",
						done: !!identity.mpinChangedAt
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: `mt-6 rounded-xl p-4 text-xs leading-5 ${complete ? "bg-emerald-50 text-emerald-800" : "bg-amber-50 text-amber-800"}`,
				children: complete ? "Your account verification and first-login setup are complete. You can update either credential anytime from this page; all permitted sections remain available." : "Dashboard and other management sections remain locked. Only Settings and Sign out are available during setup."
			}),
			complete && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-xl border border-border p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-black",
					children: "Security recommendation"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs leading-5 text-muted-foreground",
					children: "Use a unique password and private 4-digit MPIN. Never share OTP, password or MPIN with support staff."
				})]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary",
					children: mode === "password" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LockKeyhole, { size: 21 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { size: 21 })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-extrabold uppercase tracking-wider text-primary",
						children: "Login & security"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-black",
						children: complete ? "Update security credentials" : "Change temporary credentials"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: complete ? "Choose password or MPIN below. Updating one does not reset the other." : "Replace both credentials once to unlock your workspace."
					})
				] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusCard, {
					label: "Password",
					done: !!identity.passwordChangedAt
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusCard, {
					label: "MPIN",
					done: !!identity.mpinChangedAt
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex rounded-xl bg-muted p-1",
				children: ["password", "mpin"].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: !complete && !identity.passwordChangedAt && item === "mpin",
					onClick: () => {
						setMode(item);
						setMessage(null);
						setCurrent("");
						setNext("");
						setConfirm("");
					},
					className: `flex-1 rounded-lg py-2 text-sm font-bold capitalize disabled:cursor-not-allowed disabled:opacity-40 ${mode === item ? "bg-white text-secondary shadow-sm" : "text-muted-foreground"}`,
					children: item
				}, item))
			}),
			complete && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex items-center gap-3 rounded-xl bg-emerald-50 p-4 text-sm font-bold text-emerald-700",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { size: 20 }), "Security setup complete. Credential updates remain available below."]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "mt-5 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecureField, {
						label: `${complete ? "Current" : "Temporary"} ${mode}`,
						value: current,
						setValue: setCurrent,
						visible,
						mpin: mode === "mpin"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecureField, {
						label: `New ${mode}`,
						value: next,
						setValue: setNext,
						visible,
						mpin: mode === "mpin"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecureField, {
						label: `Confirm new ${mode}`,
						value: confirm,
						setValue: setConfirm,
						visible,
						mpin: mode === "mpin"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setVisible(!visible),
						className: "flex items-center gap-2 text-xs font-bold text-primary",
						children: [visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { size: 15 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 15 }), visible ? "Hide values" : "Show values"]
					}),
					message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: `rounded-xl p-4 text-sm font-semibold ${message.ok ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`,
						children: message.text
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: busy,
						className: "w-full rounded-xl bg-primary py-3.5 text-sm font-extrabold text-white disabled:opacity-60",
						children: busy ? "Updating..." : `${complete ? "Update" : "Change"} ${mode}`
					})
				]
			})
		] })]
	});
}
function Status({ label, done }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex items-center gap-3 rounded-xl border p-3 text-sm font-bold ${done ? "border-emerald-200 bg-emerald-50 text-emerald-700" : "border-amber-200 bg-amber-50 text-amber-800"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 17 }),
			label,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ml-auto text-[10px] uppercase",
				children: done ? "Complete" : "Required"
			})
		]
	});
}
function StatusCard({ label, done }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-xl border p-3 text-sm font-bold ${done ? "border-emerald-200 bg-emerald-50 text-emerald-700" : "border-amber-200 bg-amber-50 text-amber-800"}`,
		children: [
			label,
			": ",
			done ? "Changed" : "Temporary"
		]
	});
}
function SecureField({ label, value, setValue, visible, mpin }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-xs font-extrabold uppercase tracking-wider text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			value,
			onChange: (event) => setValue(mpin ? event.target.value.replace(/\D/g, "").slice(0, 4) : event.target.value),
			type: visible ? "text" : "password",
			inputMode: mpin ? "numeric" : void 0,
			autoComplete: "new-password",
			className: inputClass
		})]
	});
}
//#endregion
export { AdminSettingsPage as t };
