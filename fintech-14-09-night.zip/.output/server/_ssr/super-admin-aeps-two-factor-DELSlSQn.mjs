import { r as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { A as Settings2, R as RefreshCw, Xt as CircleCheck, ft as LoaderCircle, r as X } from "../_libs/lucide-react.mjs";
import { n as adminApi } from "./admin-api-BMvykyWe.mjs";
import { n as AdminPanel } from "./admin-layout-BjKbHz5M.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/super-admin-aeps-two-factor-DELSlSQn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var field = "w-full rounded-xl border border-border bg-white px-3 py-2.5 text-sm outline-none focus:border-primary";
var actions = [
	"RECONCILE_DEBIT",
	"CONFIRM_PROVIDER_SUCCESS",
	"CONFIRM_PROVIDER_FAILED",
	"RETRY_REVERSAL"
];
var messageOf = (error) => error instanceof Error ? error.message : "The AEPS 2FA request could not be completed.";
function SuperAdminAepsTwoFactor() {
	const [fee, setFee] = (0, import_react.useState)("");
	const [feeReason, setFeeReason] = (0, import_react.useState)("");
	const [items, setItems] = (0, import_react.useState)([]);
	const [page, setPage] = (0, import_react.useState)(1);
	const [pages, setPages] = (0, import_react.useState)(1);
	const [total, setTotal] = (0, import_react.useState)(0);
	const [identityId, setIdentityId] = (0, import_react.useState)("");
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [notice, setNotice] = (0, import_react.useState)("");
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [action, setAction] = (0, import_react.useState)("RECONCILE_DEBIT");
	const [reason, setReason] = (0, import_react.useState)("");
	const [providerTxnRefId, setProviderTxnRefId] = (0, import_react.useState)("");
	const [providerStatusCode, setProviderStatusCode] = (0, import_react.useState)("");
	const [providerStatusMessage, setProviderStatusMessage] = (0, import_react.useState)("");
	const load = (0, import_react.useCallback)(async (targetPage = 1) => {
		setLoading(true);
		setError("");
		try {
			const query = new URLSearchParams({
				provider: "VIMOPAY",
				page: String(targetPage),
				limit: "20"
			});
			if (identityId.trim()) query.set("identityId", identityId.trim());
			const [configuration, queue] = await Promise.all([adminApi.superAdminAeps.twoFactorFee("VIMOPAY"), adminApi.superAdminAeps.twoFactorReconciliation(query.toString())]);
			setFee(String(configuration.feeAmount ?? ""));
			setItems(queue.items || []);
			setPage(queue.page || targetPage);
			setPages(Math.max(queue.totalPages || 1, 1));
			setTotal(queue.total || 0);
		} catch (value) {
			setError(messageOf(value));
		} finally {
			setLoading(false);
		}
	}, [identityId]);
	(0, import_react.useEffect)(() => void load(1), [load]);
	async function saveFee(event) {
		event.preventDefault();
		const amount = Number(fee);
		if (!Number.isFinite(amount) || amount <= 0) return setError("Enter a valid fee greater than zero.");
		if (!feeReason.trim()) return setError("Enter the reason for changing the fee.");
		setBusy(true);
		setError("");
		try {
			await adminApi.superAdminAeps.updateTwoFactorFee("VIMOPAY", amount, feeReason.trim());
			setFeeReason("");
			setNotice("VimoPay 2FA fee configuration updated.");
			await load(page);
		} catch (value) {
			setError(messageOf(value));
		} finally {
			setBusy(false);
		}
	}
	async function resolve(event) {
		event.preventDefault();
		if (!selected) return;
		if (!reason.trim()) return setError("Enter a reconciliation reason.");
		if (action === "CONFIRM_PROVIDER_SUCCESS" && !providerTxnRefId.trim()) return setError("Provider transaction reference is required for a successful confirmation.");
		setBusy(true);
		setError("");
		try {
			await adminApi.superAdminAeps.resolveTwoFactor(selected.id, {
				action,
				reason: reason.trim(),
				providerTxnRefId: providerTxnRefId.trim() || void 0,
				providerStatusCode: providerStatusCode.trim() || void 0,
				providerStatusMessage: providerStatusMessage.trim() || void 0
			});
			setSelected(null);
			setNotice("2FA reconciliation action completed.");
			await load(page);
		} catch (value) {
			setError(messageOf(value));
		} finally {
			setBusy(false);
		}
	}
	function open(item) {
		setSelected(item);
		setAction("RECONCILE_DEBIT");
		setReason("");
		setProviderTxnRefId(item.providerTxnRefId || "");
		setProviderStatusCode(item.providerStatusCode || "");
		setProviderStatusMessage(item.providerStatusMessage || "");
		setError("");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banner, {
				tone: "error",
				children: error
			}) : null,
			notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banner, {
				tone: "success",
				children: notice
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings2, { size: 20 })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-black",
					children: "VimoPay daily 2FA fee"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Audited fee configuration used by the backend 2FA flow."
				})] })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: saveFee,
				className: "mt-5 grid gap-3 md:grid-cols-[180px_1fr_auto]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs font-black",
						children: ["FEE AMOUNT (INR)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							min: "0.01",
							step: "0.01",
							value: fee,
							onChange: (e) => setFee(e.target.value),
							className: `${field} mt-2`
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs font-black",
						children: ["CHANGE REASON", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: feeReason,
							onChange: (e) => setFeeReason(e.target.value),
							maxLength: 500,
							className: `${field} mt-2`,
							placeholder: "Required for audit"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: busy,
						className: "mt-auto cursor-pointer rounded-xl bg-primary px-5 py-3 text-sm font-bold text-white disabled:cursor-not-allowed disabled:opacity-50",
						children: "Save fee"
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-black",
						children: "2FA reconciliation"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [total, " attempts require operational review."]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: identityId,
							onChange: (e) => setIdentityId(e.target.value),
							className: field,
							placeholder: "Identity UUID (optional)"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => void load(1),
							className: `${field} cursor-pointer`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
								size: 17,
								className: loading ? "animate-spin" : ""
							})
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 overflow-x-auto rounded-xl border border-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[900px] text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-muted/60 text-xs uppercase text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
								"Identity",
								"Business date",
								"Status",
								"Fee",
								"Provider reference",
								"Failure",
								"Action"
							].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: v
							}, v)) })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-border",
							children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 7,
								className: "h-36 text-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mx-auto animate-spin text-primary" })
							}) }) : items.length ? items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-mono text-xs",
									children: item.day?.profile?.identityId || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: date(item.day?.businessDate)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { value: item.status })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-4 py-3",
									children: ["₹", item.feeAmount ?? "—"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-xs",
									children: item.providerTxnRefId || item.providerMerchantRefId || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "max-w-xs px-4 py-3 text-xs text-red-700",
									children: item.failureReason || item.providerStatusMessage || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => open(item),
										className: "cursor-pointer rounded-lg border border-border px-3 py-2 font-bold",
										children: "Resolve"
									})
								})
							] }, item.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 7,
								className: "h-36 text-center text-muted-foreground",
								children: "No 2FA reconciliation attempts found."
							}) })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pagination, {
					page,
					pages,
					loading,
					load
				})
			] }),
			selected ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResolutionDialog, {
				title: "Resolve AEPS 2FA attempt",
				busy,
				action,
				setAction,
				reason,
				setReason,
				providerRef: providerTxnRefId,
				setProviderRef: setProviderTxnRefId,
				providerCode: providerStatusCode,
				setProviderCode: setProviderStatusCode,
				providerMessage: providerStatusMessage,
				setProviderMessage: setProviderStatusMessage,
				close: () => setSelected(null),
				submit: resolve
			}) : null
		]
	});
}
function ResolutionDialog({ title, busy, action, setAction, reason, setReason, providerRef, setProviderRef, providerCode, setProviderCode, providerMessage, setProviderMessage, accountHolder, setAccountHolder, close, submit }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[120] grid place-items-center bg-secondary/60 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "max-h-[90vh] w-full max-w-xl overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-black uppercase text-primary",
						children: "Audited action"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-black",
						children: title
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: close,
						className: "cursor-pointer rounded-xl border border-border p-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid gap-3 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs font-black",
							children: ["ACTION", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: action,
								onChange: (e) => setAction(e.target.value),
								className: `${field} mt-2`,
								children: actions.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: v }, v))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs font-black",
							children: ["PROVIDER REFERENCE", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: providerRef,
								onChange: (e) => setProviderRef(e.target.value),
								className: `${field} mt-2`
							})]
						}),
						setAccountHolder ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs font-black",
							children: ["ACCOUNT HOLDER", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: accountHolder,
								onChange: (e) => setAccountHolder(e.target.value),
								className: `${field} mt-2`
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs font-black",
							children: ["PROVIDER CODE", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: providerCode,
								onChange: (e) => setProviderCode(e.target.value),
								className: `${field} mt-2`
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs font-black sm:col-span-2",
							children: ["PROVIDER MESSAGE", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: providerMessage,
								onChange: (e) => setProviderMessage(e.target.value),
								className: `${field} mt-2`
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-xs font-black sm:col-span-2",
							children: ["REASON", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								required: true,
								maxLength: 500,
								rows: 3,
								value: reason,
								onChange: (e) => setReason(e.target.value),
								className: `${field} mt-2 resize-none`
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					disabled: busy,
					className: "mt-5 flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl bg-primary py-3 font-bold text-white disabled:cursor-not-allowed disabled:opacity-50",
					children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
						className: "animate-spin",
						size: 17
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { size: 17 }), "Confirm resolution"]
				})
			]
		})
	});
}
function Pagination({ page, pages, loading, load }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 flex items-center justify-between text-xs font-bold",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
			"Page ",
			page,
			" of ",
			pages
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				disabled: loading || page <= 1,
				onClick: () => void load(page - 1),
				className: `${field} cursor-pointer disabled:cursor-not-allowed`,
				children: "Previous"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				disabled: loading || page >= pages,
				onClick: () => void load(page + 1),
				className: `${field} cursor-pointer disabled:cursor-not-allowed`,
				children: "Next"
			})]
		})]
	});
}
function Badge({ value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "rounded-full bg-amber-50 px-2 py-1 text-[10px] font-black text-amber-800",
		children: value.replaceAll("_", " ")
	});
}
function Banner({ tone, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		role: tone === "error" ? "alert" : void 0,
		className: `rounded-xl p-3 text-sm font-semibold ${tone === "error" ? "bg-red-50 text-red-700" : "bg-emerald-50 text-emerald-700"}`,
		children
	});
}
function date(value) {
	if (!value) return "—";
	const parsed = new Date(value);
	return Number.isNaN(parsed.getTime()) ? value : parsed.toLocaleDateString("en-IN");
}
//#endregion
export { ResolutionDialog as n, SuperAdminAepsTwoFactor as r, Pagination as t };
