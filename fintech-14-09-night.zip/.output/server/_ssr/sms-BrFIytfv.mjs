import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { b as Tags, in as Cable, mt as LayoutTemplate } from "../_libs/lucide-react.mjs";
import { t as AdminLayout } from "./admin-layout-BjKbHz5M.mjs";
import { t as AdminFeatureGrid } from "./admin-feature-grid-DkPW9VOm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sms-BrFIytfv.js
var import_jsx_runtime = require_jsx_runtime();
function Sms() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "sms",
		eyebrow: "Communication",
		title: "SMS settings",
		description: "Configure transactional message categories, templates and provider integrations.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminFeatureGrid, { features: [
			{
				title: "SMS categories",
				description: "Organize login, transaction and operational messages.",
				icon: Tags
			},
			{
				title: "SMS templates",
				description: "Manage approved message bodies and template identifiers.",
				icon: LayoutTemplate
			},
			{
				title: "SMS integrations",
				description: "Configure provider credentials, routing and delivery settings.",
				icon: Cable
			}
		] })
	});
}
//#endregion
export { Sms as component };
