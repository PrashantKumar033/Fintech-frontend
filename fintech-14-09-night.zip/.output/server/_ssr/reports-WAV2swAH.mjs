import { r as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { M as Search, R as RefreshCw, Rt as Eye, ft as LoaderCircle } from "../_libs/lucide-react.mjs";
import { n as adminApi } from "./admin-api-BMvykyWe.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-BjKbHz5M.mjs";
import { t as AuditDetailDialog } from "./audit-detail-dialog-DPdYiEwE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reports-WAV2swAH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var inputClass = "rounded-xl border border-border bg-white px-3.5 py-3 text-xs outline-none focus:border-primary";
function when(value) {
	if (!value) return "—";
	const date = new Date(value);
	return Number.isNaN(date.getTime()) ? "—" : new Intl.DateTimeFormat("en-IN", {
		dateStyle: "medium",
		timeStyle: "short"
	}).format(date);
}
function Reports() {
	const [items, setItems] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(1);
	const [totalPages, setTotalPages] = (0, import_react.useState)(1);
	const [total, setTotal] = (0, import_react.useState)(0);
	const [selectedAuditId, setSelectedAuditId] = (0, import_react.useState)(null);
	const [service, setService] = (0, import_react.useState)("");
	const [action, setAction] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("");
	const [loginId, setLoginId] = (0, import_react.useState)("");
	async function load(target = page) {
		setLoading(true);
		setError("");
		try {
			const query = new URLSearchParams({
				page: String(target),
				limit: "25"
			});
			if (service.trim()) query.set("service", service.trim().toUpperCase());
			if (action.trim()) query.set("action", action.trim().toUpperCase());
			if (status) query.set("status", status);
			if (loginId.trim()) query.set("loginId", loginId.trim());
			const result = await adminApi.auditLogs(query.toString());
			setItems(result.data || []);
			setPage(result.pagination?.page || target);
			setTotalPages(Math.max(result.pagination?.totalPages || 1, 1));
			setTotal(result.pagination?.total || 0);
		} catch (value) {
			setError(value instanceof Error ? value.message : "Unable to load audit logs.");
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		load(1);
	}, []);
	const loadAuditDetail = (0, import_react.useCallback)((auditId) => adminApi.auditLog(auditId), []);
	function filter(event) {
		event.preventDefault();
		load(1);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "reports",
		eyebrow: "Security observability",
		title: "Audit logs",
		description: "Review successful and failed operations with identity, service, action and resource context.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: filter,
				className: "grid gap-3 lg:grid-cols-[1fr_1fr_1fr_160px_auto]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 rounded-xl border border-border bg-white px-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { size: 14 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: loginId,
							onChange: (event) => setLoginId(event.target.value),
							placeholder: "Login ID",
							className: "min-w-0 flex-1 py-3 text-xs outline-none"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: service,
						onChange: (event) => setService(event.target.value),
						placeholder: "Service",
						className: inputClass
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: action,
						onChange: (event) => setAction(event.target.value),
						placeholder: "Action",
						className: inputClass
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: status,
						onChange: (event) => setStatus(event.target.value),
						className: inputClass,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "All statuses"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "SUCCESS" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "FAILED" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						disabled: loading,
						className: "inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-xs font-extrabold text-white",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
							size: 14,
							className: loading ? "animate-spin" : ""
						}), "Apply"]
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-5 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 overflow-x-auto rounded-xl border border-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[900px] text-left text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-muted/60 text-[10px] uppercase text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Time"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Identity"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Service"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Action"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Request"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "p-3" })
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: items.map((log) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border/70",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "whitespace-nowrap p-3",
									children: when(log.createdAt)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-black",
										children: log.loginId || "System"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-[10px] text-muted-foreground",
										children: log.role || log.identityId || "—"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3 font-bold",
									children: log.service || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3 font-bold",
									children: log.action || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-bold",
										children: log.httpMethod || "EVENT"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "max-w-[190px] truncate text-[10px] text-muted-foreground",
										children: log.endpoint || "—"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `rounded-full px-2 py-1 text-[9px] font-extrabold ${log.status === "FAILED" ? "bg-red-50 text-red-700" : "bg-emerald-50 text-emerald-700"}`,
										children: log.status || "UNKNOWN"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3 text-right",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setSelectedAuditId(log.id),
										title: "View audit detail",
										className: "rounded-lg border border-border p-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 14 })
									})
								})
							]
						}, log.id)) })]
					}),
					loading && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-center gap-2 py-12 text-sm text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
							size: 17,
							className: "animate-spin"
						}), "Loading audit trail…"]
					}),
					!loading && !items.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-12 text-center text-sm text-muted-foreground",
						children: "No audit events match these filters."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-center justify-between text-xs",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted-foreground",
					children: [
						total,
						" events · Page ",
						page,
						" of ",
						totalPages
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: page <= 1 || loading,
						onClick: () => void load(page - 1),
						className: "rounded-lg border border-border px-3 py-2 font-bold disabled:opacity-40",
						children: "Previous"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: page >= totalPages || loading,
						onClick: () => void load(page + 1),
						className: "rounded-lg border border-border px-3 py-2 font-bold disabled:opacity-40",
						children: "Next"
					})]
				})]
			})
		] }), selectedAuditId && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuditDetailDialog, {
			auditId: selectedAuditId,
			loadAudit: loadAuditDetail,
			onClose: () => setSelectedAuditId(null)
		})]
	});
}
//#endregion
export { Reports as component };
