import { c as getSession, f as logout, h as refreshSession, i as clearSession, o as getDeviceId, u as isManagementRole } from "./role-hierarchy-3Eppvhsl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-api-BMvykyWe.js
var API_URL = (typeof window !== "undefined" ? `${window.location.protocol}//${window.location.hostname}:8000` : "http://localhost:8000").replace(/\/$/, "");
var TOKEN_KEY = "nexus_super_admin_access_token";
var SESSION_KEY = "nexus_super_admin_session";
function adminRequiresDeviceVerification(result) {
	return "requiresDeviceVerification" in result && result.requiresDeviceVerification === true;
}
var AdminApiError = class extends Error {
	status;
	constructor(message, status) {
		super(message);
		this.status = status;
		this.name = "AdminApiError";
	}
};
function messageOf(value) {
	if (typeof value === "string" && value.trim()) return value;
	if (!value || typeof value !== "object") return null;
	const data = value;
	if (Array.isArray(data.message)) return data.message.join(", ");
	return messageOf(data.message) || messageOf(data.error) || messageOf(data.response);
}
function storeSession(session) {
	if (typeof window === "undefined") return;
	localStorage.setItem(TOKEN_KEY, session.accessToken);
	localStorage.setItem(SESSION_KEY, JSON.stringify(session));
}
function getAdminSession() {
	if (typeof window === "undefined") return null;
	const token = localStorage.getItem(TOKEN_KEY);
	if (!token) return null;
	try {
		return {
			...JSON.parse(localStorage.getItem(SESSION_KEY) || "{}"),
			accessToken: token
		};
	} catch {
		return null;
	}
}
function clearAdminSession() {
	if (typeof window === "undefined") return;
	localStorage.removeItem(TOKEN_KEY);
	localStorage.removeItem(SESSION_KEY);
}
var refreshInFlight = null;
async function parse(response) {
	const data = await response.json().catch(() => ({}));
	if (!response.ok) throw new AdminApiError(messageOf(data) || "The request could not be completed.", response.status);
	return data;
}
async function performAdminRefresh(rejectedAccessToken) {
	const latestSession = getAdminSession();
	if (rejectedAccessToken && latestSession?.accessToken && latestSession.accessToken !== rejectedAccessToken) return latestSession;
	if (refreshInFlight) return refreshInFlight;
	refreshInFlight = fetch(`${API_URL}/super-admin/auth/refresh`, {
		method: "POST",
		credentials: "include",
		headers: { Accept: "application/json" }
	}).then(parse).then((session) => {
		storeSession(session);
		return session;
	}).catch((error) => {
		if (error instanceof AdminApiError && (error.status === 401 || error.status === 403)) clearAdminSession();
		throw error;
	}).finally(() => {
		refreshInFlight = null;
	});
	return refreshInFlight;
}
async function refresh(rejectedAccessToken) {
	if (typeof navigator !== "undefined" && navigator.locks) return navigator.locks.request("nexus-super-admin-session-refresh", () => performAdminRefresh(rejectedAccessToken));
	return performAdminRefresh(rejectedAccessToken);
}
function getAdminActor() {
	const superSession = getAdminSession();
	if (superSession) return {
		kind: "SUPER_ADMIN",
		accessToken: superSession.accessToken,
		name: superSession.superAdmin?.fullName || "Super Admin",
		role: "SUPER_ADMIN"
	};
	const identitySession = getSession();
	const role = identitySession?.identity.role?.trim().toUpperCase();
	if (identitySession && (role === "SUPER_ADMIN" || isManagementRole(role))) return {
		kind: "IDENTITY_ADMIN",
		accessToken: identitySession.accessToken,
		name: identitySession.identity.fullName || "Administrator",
		role
	};
	return null;
}
async function call(path, init = {}, retry = true) {
	const actor = getAdminActor();
	const token = actor?.accessToken;
	if (!token) throw new AdminApiError("Super Admin session is missing.", 401);
	let response;
	try {
		response = await fetch(`${API_URL}${path}`, {
			...init,
			credentials: "include",
			headers: {
				Accept: "application/json",
				...init.body ? { "Content-Type": "application/json" } : {},
				...init.headers,
				Authorization: `Bearer ${token}`
			}
		});
	} catch {
		throw new AdminApiError("Cannot connect to the API Gateway on port 8000.", 0);
	}
	if (response.status === 401 && retry) {
		if (actor?.kind === "SUPER_ADMIN") await refresh(token);
		else await refreshSession(token);
		return call(path, init, false);
	}
	return parse(response);
}
var json = (method, body) => ({
	method,
	...body === void 0 ? {} : { body: JSON.stringify(body) }
});
var adminAuthApi = {
	async login(identifier, loginWith, credential) {
		const result = await parse(await fetch(`${API_URL}/super-admin/auth/login`, {
			method: "POST",
			credentials: "include",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				identifier,
				loginWith,
				password: credential,
				deviceId: getDeviceId()
			})
		}));
		if (!adminRequiresDeviceVerification(result)) storeSession(result);
		return result;
	},
	async verifyDeviceLogin(challengeId, otp) {
		const session = await parse(await fetch(`${API_URL}/super-admin/auth/login/verify-device`, {
			method: "POST",
			credentials: "include",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				challengeId,
				otp
			})
		}));
		storeSession(session);
		return session;
	},
	sendOnboardingPhoneOtp: (phoneNumber) => call("/super-admin/auth/onboarding/phone/send-otp", json("POST", { phoneNumber })),
	verifyOnboardingPhoneOtp: (otp) => call("/super-admin/auth/onboarding/phone/verify-otp", json("POST", { otp })),
	addOnboardingPan: (panNumber) => call("/super-admin/auth/onboarding/pan", json("POST", { panNumber })),
	changeOnboardingPassword: (currentPassword, newPassword) => call("/super-admin/auth/onboarding/change-password", json("POST", {
		currentPassword,
		newPassword
	})),
	changeOnboardingMpin: (currentMpin, newMpin) => call("/super-admin/auth/onboarding/change-mpin", json("POST", {
		currentMpin,
		newMpin
	})),
	async logout() {
		const actor = getAdminActor();
		try {
			if (actor?.kind === "SUPER_ADMIN") await call("/super-admin/auth/logout", { method: "POST" });
			else if (actor?.kind === "IDENTITY_ADMIN") await logout();
		} finally {
			clearAdminSession();
			clearSession();
		}
	}
};
function updateAdminOnboarding(nextStep, onboardingStatus) {
	const session = getAdminSession();
	if (!session) return;
	storeSession({
		...session,
		nextStep: nextStep || void 0,
		onboardingStatus: onboardingStatus || session.onboardingStatus,
		onboardingRequired: Boolean(nextStep)
	});
}
var adminApi = {
	superAdminAeps: {
		twoFactorFee: (provider) => call(`/super-admin/aeps/2fa/fees/${encodeURIComponent(provider)}`, { cache: "no-store" }),
		updateTwoFactorFee: (provider, feeAmount, reason) => call(`/super-admin/aeps/2fa/fees/${encodeURIComponent(provider)}`, json("PATCH", {
			feeAmount,
			reason
		})),
		twoFactorReconciliation: (query = "") => call(`/super-admin/aeps/2fa/reconciliation${query ? `?${query}` : ""}`, { cache: "no-store" }),
		resolveTwoFactor: (attemptId, body) => call(`/super-admin/aeps/2fa/reconciliation/${encodeURIComponent(attemptId)}/resolve`, json("POST", body))
	},
	bankVerificationReconciliation: {
		list: (query = "") => call(`/super-admin/bank-verifications/reconciliation${query ? `?${query}` : ""}`, { cache: "no-store" }),
		resolve: (attemptId, body) => call(`/super-admin/bank-verifications/reconciliation/${encodeURIComponent(attemptId)}/resolve`, json("POST", body))
	},
	operations: {
		dashboardSummary: () => call("/admin/dashboard/summary", { cache: "no-store" }),
		members: (query = "") => call(`/admin/members${query ? `?${query}` : ""}`, { cache: "no-store" }),
		member: (identityId) => call(`/admin/members/${encodeURIComponent(identityId)}`, { cache: "no-store" }),
		updateMemberStatus: (identityId, status, reason) => call(`/admin/members/${encodeURIComponent(identityId)}/status`, json("PATCH", {
			status,
			...reason?.trim() ? { reason: reason.trim() } : {}
		})),
		bankAccounts: (query = "") => call(`/admin/bank-accounts${query ? `?${query}` : ""}`, { cache: "no-store" }),
		bankAccount: (bankId) => call(`/admin/bank-accounts/${encodeURIComponent(bankId)}`, { cache: "no-store" }),
		updateAepsMerchantStatus: (identityId, status, reason) => call(`/admin/aeps/merchants/${encodeURIComponent(identityId)}/status`, json("PATCH", {
			status,
			...reason?.trim() ? { reason: reason.trim() } : {}
		})),
		walletLedger: (identityId, query = "") => call(`/admin/wallets/${encodeURIComponent(identityId)}/ledger${query ? `?${query}` : ""}`, { cache: "no-store" }),
		aepsProviderStatus: () => call("/admin/aeps/providers/status", { cache: "no-store" }),
		updateAepsProviderServiceStatus: (provider, operation, isEnabled, reason) => call(`/admin/aeps/providers/${encodeURIComponent(provider)}/services/${encodeURIComponent(operation)}/status`, json("PATCH", {
			isEnabled,
			...reason?.trim() ? { reason: reason.trim() } : {}
		}))
	},
	roles: {
		list: () => call("/roles"),
		get: (id) => call(`/roles/${encodeURIComponent(id)}`),
		create: (body) => call("/roles", json("POST", body)),
		update: (id, body) => call(`/roles/${id}`, json("PATCH", body)),
		status: (id, isActive) => call(`/roles/${id}/status`, json("PATCH", { isActive })),
		packages: (id) => call(`/roles/${id}/packages`),
		assignPackage: (id, packageId) => call(`/roles/${id}/packages`, json("POST", { packageId })),
		removePackage: (id, packageId) => call(`/roles/${id}/packages/${packageId}`, { method: "DELETE" }),
		registrationPermissions: (id) => call(`/roles/${id}/register-permissions`),
		allowRegistration: (id, targetRoleId) => call(`/roles/${id}/register-permissions`, json("POST", {
			targetRoleId,
			isActive: true
		})),
		registrationStatus: (id, targetRoleId, isActive) => call(`/roles/${id}/register-permissions/${targetRoleId}/status`, json("PATCH", { isActive })),
		removeRegistration: (id, targetRoleId) => call(`/roles/${id}/register-permissions/${targetRoleId}`, { method: "DELETE" }),
		effectivePermissions: (id) => call(`/roles/${id}/effective-permissions`)
	},
	permissions: {
		list: () => call("/permissions"),
		get: (id) => call(`/permissions/${encodeURIComponent(id)}`),
		create: (body) => call("/permissions", json("POST", body)),
		update: (id, body) => call(`/permissions/${id}`, json("PATCH", body)),
		status: (id, isActive) => call(`/permissions/${id}/status`, json("PATCH", { isActive }))
	},
	packages: {
		list: () => call("/packages"),
		get: (id) => call(`/packages/${encodeURIComponent(id)}`),
		create: (body) => call("/packages", json("POST", body)),
		update: (id, body) => call(`/packages/${id}`, json("PATCH", body)),
		status: (id, isActive) => call(`/packages/${id}/status`, json("PATCH", { isActive })),
		permissions: (id) => call(`/packages/${id}/permissions`),
		assignPermission: (id, permissionId) => call(`/packages/${id}/permissions`, json("POST", { permissionId })),
		removePermission: (id, permissionId) => call(`/packages/${id}/permissions/${permissionId}`, { method: "DELETE" })
	},
	async createAccount(body) {
		const path = getAdminActor()?.kind === "SUPER_ADMIN" ? "/super-admin/accounts" : "/accounts";
		try {
			return await call(path, json("POST", body));
		} catch (error) {
			if (error instanceof AdminApiError && error.status >= 500) throw new AdminApiError("The account service could not complete the request. Confirm admin-service and auth-service are connected to Kafka, then try again.", error.status);
			throw error;
		}
	},
	auditLogs: (query = "") => {
		return call(`${getAdminActor()?.kind === "SUPER_ADMIN" ? "/audit" : "/audit/me"}${query ? `?${query}` : ""}`);
	},
	auditLog: (auditId) => call(`/audit/me/${encodeURIComponent(auditId)}`),
	transaction: (referenceId) => call(`/admin/transactions/provider/${encodeURIComponent(referenceId)}`),
	providerTransactions: (query = "") => call(`/admin/transactions/provider${query ? `?${query}` : ""}`),
	pendingProviderIncome: (query = "") => call(`/admin/transactions/provider-income/pending${query ? `?${query}` : ""}`),
	reconcileProviderIncome: (referenceId, body) => call(`/admin/transactions/${encodeURIComponent(referenceId)}/provider-income/reconcile`, json("POST", body)),
	reconciliation: (query = "") => call(`/admin/transactions/reconciliation${query ? `?${query}` : ""}`),
	resolveTransaction: (referenceId, body) => call(`/admin/transactions/reconciliation/${encodeURIComponent(referenceId)}/resolve`, json("POST", body)),
	recoverFinancialEffects: (referenceId) => call(`/admin/transactions/reconciliation/${encodeURIComponent(referenceId)}/recover-financial-effects`, { method: "POST" }),
	requestReversal: (referenceId, reason, idempotencyKey) => call(`/admin/transactions/${encodeURIComponent(referenceId)}/reversal`, {
		...json("POST", { reason }),
		headers: { "Idempotency-Key": idempotencyKey }
	}),
	reversals: (query = "") => call(`/admin/transactions/reversals${query ? `?${query}` : ""}`),
	reversal: (referenceId) => call(`/admin/transactions/reversals/${encodeURIComponent(referenceId)}`),
	processReversal: (referenceId) => call(`/admin/transactions/reversals/${encodeURIComponent(referenceId)}/process`, { method: "POST" }),
	kycReview: {
		list: (query = "") => call(`/kyc/review${query ? `?${query}` : ""}`, { cache: "no-store" }),
		get: (identityId, accountType) => call(`/kyc/review/${encodeURIComponent(identityId)}?accountType=${accountType}`, { cache: "no-store" }),
		document: (identityId, accountType, documentId, status, rejectionReason) => call(`/kyc/review/${encodeURIComponent(identityId)}/documents/${encodeURIComponent(documentId)}?accountType=${accountType}`, json("PATCH", {
			status,
			...rejectionReason ? { rejectionReason } : {}
		})),
		video: (identityId, accountType, status, rejectionReason) => call(`/kyc/review/${encodeURIComponent(identityId)}/video?accountType=${accountType}`, json("PATCH", {
			status,
			...rejectionReason ? { rejectionReason } : {}
		})),
		approve: (identityId, accountType, remarks) => call(`/kyc/review/${encodeURIComponent(identityId)}/approve?accountType=${accountType}`, json("POST", { ...remarks ? { remarks } : {} })),
		reject: (identityId, accountType, remarks) => call(`/kyc/review/${encodeURIComponent(identityId)}/reject?accountType=${accountType}`, json("POST", { remarks }))
	},
	commissionRules: {
		list: () => call("/commission-rules"),
		get: (id) => call(`/commission-rules/${encodeURIComponent(id)}`),
		create: (body) => call("/commission-rules", json("POST", body)),
		update: (id, body) => call(`/commission-rules/${encodeURIComponent(id)}`, json("PATCH", body)),
		deactivate: (id) => call(`/commission-rules/${encodeURIComponent(id)}`, { method: "DELETE" })
	},
	commissionDistributions: {
		list: (commissionRuleId) => call(`/commission-distributions/distributions${commissionRuleId ? `?commissionRuleId=${encodeURIComponent(commissionRuleId)}` : ""}`),
		get: (id) => call(`/commission-distributions/distributions/${encodeURIComponent(id)}`),
		create: (body) => call("/commission-distributions/distributions", json("POST", body)),
		update: (id, body) => call(`/commission-distributions/distributions/${encodeURIComponent(id)}`, json("PATCH", body)),
		deactivate: (id) => call(`/commission-distributions/distributions/${encodeURIComponent(id)}`, { method: "DELETE" })
	},
	commissionHierarchy: {
		list: (serviceType) => call(`/commission-hierarchy${serviceType ? `?serviceType=${encodeURIComponent(serviceType)}` : ""}`),
		create: (body) => call("/commission-hierarchy", json("POST", body)),
		update: (id, body) => call(`/commission-hierarchy/${encodeURIComponent(id)}`, json("PATCH", body)),
		remove: (id) => call(`/commission-hierarchy/${encodeURIComponent(id)}`, { method: "DELETE" }),
		resolve: (sourceUserId, serviceType) => call(`/commission-hierarchy/resolve/${encodeURIComponent(sourceUserId)}?serviceType=${encodeURIComponent(serviceType)}`),
		parents: (childUserId, serviceType) => call(`/commission-hierarchy/child/${encodeURIComponent(childUserId)}/parents${serviceType ? `?serviceType=${encodeURIComponent(serviceType)}` : ""}`),
		children: (parentUserId) => call(`/commission-hierarchy/parent/${encodeURIComponent(parentUserId)}/children`),
		get: (id) => call(`/commission-hierarchy/${encodeURIComponent(id)}`)
	}
};
function asArray(value) {
	if (Array.isArray(value)) return value;
	if (!value || typeof value !== "object") return [];
	const object = value;
	for (const key of [
		"data",
		"items",
		"results",
		"records",
		"roles",
		"permissions",
		"packages",
		"transactions",
		"logs"
	]) if (Array.isArray(object[key])) return object[key];
	if (object.data && typeof object.data === "object") return asArray(object.data);
	return [];
}
//#endregion
export { asArray as a, getAdminSession as c, adminRequiresDeviceVerification as i, updateAdminOnboarding as l, adminApi as n, clearAdminSession as o, adminAuthApi as r, getAdminActor as s, AdminApiError as t };
