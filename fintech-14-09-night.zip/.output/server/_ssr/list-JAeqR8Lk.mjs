import { r as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { D as ShieldCheck, M as Search, R as RefreshCw, Rt as Eye, dn as BadgeCheck, ft as LoaderCircle, o as WalletCards, on as Building2, p as UserCog, r as X, u as UserRound, vt as Landmark } from "../_libs/lucide-react.mjs";
import { a as useEffectiveAccess, r as UI_PERMISSION } from "./section-tabs-INzhwNW3.mjs";
import { n as adminApi, s as getAdminActor } from "./admin-api-BMvykyWe.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-BjKbHz5M.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/list-JAeqR8Lk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var control$1 = "rounded-xl border border-border bg-white px-3 py-2.5 text-sm outline-none focus:border-primary";
function MemberDetailDialog({ detail, close }) {
	const { can } = useEffectiveAccess();
	const privileged = getAdminActor()?.kind === "SUPER_ADMIN";
	const canChangeAeps = privileged || can(UI_PERMISSION.AEPS_MERCHANT_STATUS_UPDATE, ["SUPER_ADMIN", "ADMIN"]);
	const canViewLedger = privileged || can(UI_PERMISSION.WALLET_LEDGER_VIEW, ["SUPER_ADMIN", "ADMIN"]);
	const [member, setMember] = (0, import_react.useState)(detail);
	const [ledger, setLedger] = (0, import_react.useState)(null);
	const [ledgerLoading, setLedgerLoading] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [notice, setNotice] = (0, import_react.useState)("");
	const [aepsStatus, setAepsStatus] = (0, import_react.useState)("ACTIVE");
	const [reason, setReason] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => setMember(detail), [detail]);
	const identity = member.identity;
	const kyc = member.kyc;
	const aeps = member.aeps;
	const bankAccounts = member.bankAccounts ?? [];
	const balances = member.wallets?.wallets;
	async function refreshMember() {
		setMember(await adminApi.operations.member(identity.id));
	}
	async function changeAepsStatus() {
		if (!canChangeAeps) return;
		if (aepsStatus !== "ACTIVE" && !reason.trim()) {
			setError("Enter a reason before suspending or blocking AEPS access.");
			return;
		}
		setBusy(true);
		setError("");
		setNotice("");
		try {
			await adminApi.operations.updateAepsMerchantStatus(identity.id, aepsStatus, reason);
			await refreshMember();
			setReason("");
			setNotice(`AEPS merchant status changed to ${aepsStatus}.`);
		} catch (value) {
			setError(messageOf$1(value));
		} finally {
			setBusy(false);
		}
	}
	async function loadLedger() {
		if (!canViewLedger) return;
		setLedgerLoading(true);
		setError("");
		try {
			setLedger(await adminApi.operations.walletLedger(identity.id, "page=1&limit=20"));
		} catch (value) {
			setError(messageOf$1(value));
		} finally {
			setLedgerLoading(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[100] grid place-items-center bg-secondary/60 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-h-[92vh] w-full max-w-5xl overflow-y-auto rounded-2xl bg-white p-6 shadow-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-black uppercase text-primary",
							children: "Consolidated member"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-2xl font-black",
							children: identity.fullName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: [
								identity.loginId,
								" · ",
								identity.role?.name?.replaceAll("_", " ")
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: close,
						className: "cursor-pointer rounded-xl border border-border p-3",
						"aria-label": "Close member details",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					})]
				}),
				member.partialErrors?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Message, {
					tone: "warning",
					children: [
						"Some live sections could not be loaded: ",
						member.partialErrors.join("; "),
						"."
					]
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Message, {
					tone: "error",
					children: error
				}) : null,
				notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Message, {
					tone: "success",
					children: notice
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid gap-4 lg:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
							icon: UserRound,
							title: "Identity & contact",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Details, { rows: [
								["Account status", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status$1, { value: identity.status }, "account-status")],
								["Login ID", identity.loginId],
								["Username", identity.username],
								["Email", identity.email],
								["Phone", identity.phoneNumber],
								["Onboarding", formatLabel(identity.onboardingStatus)],
								["Last login", formatDate(identity.lastLoginAt)]
							] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
							icon: Building2,
							title: "Business & location",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Details, { rows: [
								["Shop", identity.shopName],
								["City", identity.shopCity || identity.city],
								["State", identity.shopState || identity.state],
								["PIN code", identity.pincode],
								["Member since", formatDate(identity.createdAt)]
							] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
							icon: BadgeCheck,
							title: "KYC",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Details, { rows: [
								["Status", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status$1, { value: text(kyc?.status, "NOT STARTED") }, "kyc-status")],
								["Submitted", formatDate(kyc?.submittedAt)],
								["Remarks", text(kyc?.remarks)]
							] })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
							icon: ShieldCheck,
							title: "AEPS merchant",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Details, { rows: [
								["Provider", text(aeps?.provider, "VIMOPAY")],
								["Merchant ID", text(aeps?.providerMerchantId)],
								["Status", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status$1, { value: text(aeps?.status, "NOT STARTED") }, "aeps-status")],
								["Onboarding step", formatLabel(aeps?.onboardingStep)],
								["Registration", yesNo(aeps?.providerRegistrationCompleted)],
								["Onboarding complete", yesNo(aeps?.onboardingCompleted)],
								["Service active", yesNo(aeps?.serviceActivated)],
								["Last 2FA", formatDate(aeps?.lastTwoFactorAuthAt)],
								["Reason", text(aeps?.statusReason)]
							] }), canChangeAeps && text(aeps?.status, "NOT_STARTED") !== "NOT_STARTED" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 border-t border-border pt-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-black uppercase text-muted-foreground",
									children: "Change AEPS access"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-2 grid gap-2 sm:grid-cols-[180px_1fr_auto]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
											value: aepsStatus,
											onChange: (event) => setAepsStatus(event.target.value),
											className: control$1,
											children: [
												"ACTIVE",
												"SUSPENDED",
												"BLOCKED"
											].map((status) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: status }, status))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: reason,
											onChange: (event) => setReason(event.target.value),
											placeholder: aepsStatus === "ACTIVE" ? "Reason (optional)" : "Reason (required)",
											className: control$1
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											disabled: busy,
											onClick: () => void changeAepsStatus(),
											className: "cursor-pointer rounded-xl bg-primary px-4 py-2 text-sm font-bold text-white disabled:cursor-not-allowed disabled:opacity-50",
											children: busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
												className: "animate-spin",
												size: 18
											}) : "Update"
										})
									]
								})]
							}) : null]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
					icon: Landmark,
					title: `Bank accounts (${bankAccounts.length})`,
					className: "mt-4",
					children: bankAccounts.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-3 md:grid-cols-2",
						children: bankAccounts.map((bank) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BankCard, { bank }, bank.id))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No bank accounts are available for this member." })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
					icon: WalletCards,
					title: "Wallets & ledger",
					className: "mt-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Balance, {
									label: "Main wallet",
									value: balances?.main
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Balance, {
									label: "AEPS wallet",
									value: balances?.aeps
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Balance, {
									label: "Profit wallet",
									value: balances?.profit
								})
							]
						}),
						canViewLedger ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: ledgerLoading,
							onClick: () => void loadLedger(),
							className: "mt-4 flex cursor-pointer items-center gap-2 rounded-xl border border-border px-4 py-2 text-sm font-bold disabled:cursor-not-allowed",
							children: [ledgerLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
								className: "animate-spin",
								size: 16
							}), ledger ? "Refresh ledger" : "Load wallet ledger"]
						}) : null,
						ledger ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LedgerTable, { ledger }) : null
					]
				})
			]
		})
	});
}
function Section({ icon: Icon, title, children, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: `rounded-xl border border-border p-4 ${className}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
			className: "mb-4 flex items-center gap-2 font-black",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
					size: 18,
					className: "text-primary"
				}),
				" ",
				title
			]
		}), children]
	});
}
function Details({ rows }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
		className: "grid gap-3 sm:grid-cols-2",
		children: rows.map(([label, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-lg bg-muted/60 p-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
				className: "text-[10px] font-black uppercase text-muted-foreground",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
				className: "mt-1 break-words text-sm font-semibold",
				children: value || "—"
			})]
		}, label))
	});
}
function BankCard({ bank }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-xl bg-muted/60 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-black",
				children: bank.bankName
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				children: ["••••", bank.accountNumberLast4]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status$1, { value: bank.verificationStatus })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Details, { rows: [
			["Holder", bank.accountHolderName],
			["IFSC", bank.ifsc],
			["Type", bank.accountType],
			["Ownership", formatLabel(bank.ownershipStatus)],
			["Account status", formatLabel(bank.status)],
			["Default", bank.isDefault ? "Yes" : "No"]
		] })]
	});
}
function Balance({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-muted p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs font-bold text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xl font-black",
			children: value == null ? "Unavailable" : money(value)
		})]
	});
}
function LedgerTable({ ledger }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4 overflow-x-auto rounded-xl border border-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[760px] text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "bg-muted/70 text-xs uppercase text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
						"Reference",
						"Wallet",
						"Service",
						"Type",
						"Amount",
						"Balance",
						"Status",
						"Date"
					].map((label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-3 py-2",
						children: label
					}, label)) })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
					className: "divide-y divide-border",
					children: ledger.data.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2 font-mono text-xs",
							children: entry.referenceId
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2",
							children: entry.walletType
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2",
							children: formatLabel(entry.serviceType)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2",
							children: entry.type
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2 font-bold",
							children: money(entry.amount)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2",
							children: money(entry.closingBalance)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status$1, { value: entry.status })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-3 py-2 text-xs",
							children: formatDate(entry.createdAt)
						})
					] }, entry.id))
				})]
			}),
			!ledger.data.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Empty, { children: "No wallet ledger entries found." }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "border-t border-border px-3 py-2 text-xs text-muted-foreground",
				children: [
					"Showing ",
					ledger.data.length,
					" of ",
					ledger.total,
					" entries"
				]
			})
		]
	});
}
function Status$1({ value }) {
	const normalized = value.toUpperCase().replaceAll(" ", "_");
	const good = [
		"ACTIVE",
		"APPROVED",
		"VERIFIED",
		"SUCCESS",
		"ENABLED"
	].includes(normalized);
	const bad = [
		"BLOCKED",
		"SUSPENDED",
		"REJECTED",
		"FAILED",
		"DISABLED"
	].includes(normalized);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-flex rounded-full px-2 py-1 text-[10px] font-black ${good ? "bg-emerald-50 text-emerald-700" : bad ? "bg-red-50 text-red-700" : "bg-amber-50 text-amber-700"}`,
		children: formatLabel(value)
	});
}
function Message({ tone, children }) {
	const style = {
		warning: "bg-amber-50 text-amber-800",
		error: "bg-red-50 text-red-700",
		success: "bg-emerald-50 text-emerald-700"
	}[tone];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: `mt-4 rounded-xl p-3 text-sm font-semibold ${style}`,
		children
	});
}
function Empty({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-6 text-center text-sm text-muted-foreground",
		children
	});
}
function text(value, fallback = "—") {
	return value == null || value === "" ? fallback : String(value);
}
function yesNo(value) {
	return value === true ? "Yes" : value === false ? "No" : "—";
}
function formatLabel(value) {
	return text(value).replaceAll("_", " ");
}
function formatDate(value) {
	if (!value) return "—";
	const date = new Date(String(value));
	return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString("en-IN");
}
function money(value) {
	const amount = Number(value);
	return Number.isFinite(amount) ? `₹${amount.toLocaleString("en-IN", { minimumFractionDigits: 2 })}` : "—";
}
function messageOf$1(value) {
	return value instanceof Error ? value.message : "The request could not be completed.";
}
var control = "rounded-xl border border-border bg-white px-3 py-2.5 text-sm outline-none focus:border-primary";
var messageOf = (value) => value instanceof Error ? value.message : "The member request could not be completed.";
function AdminMemberListPage() {
	const actor = getAdminActor();
	const { can } = useEffectiveAccess();
	const privileged = actor?.kind === "SUPER_ADMIN";
	const canList = privileged || can(UI_PERMISSION.MEMBER_LIST, ["SUPER_ADMIN", "ADMIN"]);
	const canView = privileged || can(UI_PERMISSION.MEMBER_VIEW, ["SUPER_ADMIN", "ADMIN"]);
	const canUpdate = privileged || can(UI_PERMISSION.MEMBER_STATUS_UPDATE, ["SUPER_ADMIN", "ADMIN"]);
	const [items, setItems] = (0, import_react.useState)([]);
	const [page, setPage] = (0, import_react.useState)(1);
	const [pages, setPages] = (0, import_react.useState)(1);
	const [total, setTotal] = (0, import_react.useState)(0);
	const [filters, setFilters] = (0, import_react.useState)({
		search: "",
		role: "",
		status: "",
		kycStatus: "",
		aepsStatus: ""
	});
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [notice, setNotice] = (0, import_react.useState)("");
	const [detail, setDetail] = (0, import_react.useState)(null);
	const [statusTarget, setStatusTarget] = (0, import_react.useState)(null);
	const [nextStatus, setNextStatus] = (0, import_react.useState)("ACTIVE");
	const [reason, setReason] = (0, import_react.useState)("");
	const load = (0, import_react.useCallback)(async (targetPage = 1) => {
		if (!canList) return;
		setLoading(true);
		setError("");
		try {
			const query = new URLSearchParams({
				page: String(targetPage),
				limit: "20"
			});
			Object.entries(filters).forEach(([key, value]) => value.trim() && query.set(key, value.trim()));
			const response = await adminApi.operations.members(query.toString());
			setItems(response.data || []);
			setPage(response.pagination.page || targetPage);
			setPages(Math.max(response.pagination.totalPages || 1, 1));
			setTotal(response.pagination.total || 0);
		} catch (value) {
			setError(messageOf(value));
		} finally {
			setLoading(false);
		}
	}, [canList, filters]);
	(0, import_react.useEffect)(() => {
		const timer = window.setTimeout(() => void load(1), 250);
		return () => window.clearTimeout(timer);
	}, [load]);
	async function inspect(identityId) {
		if (!canView) return setError(`Permission ${UI_PERMISSION.MEMBER_VIEW} is required.`);
		setBusy(true);
		setError("");
		try {
			setDetail(await adminApi.operations.member(identityId));
		} catch (value) {
			setError(messageOf(value));
		} finally {
			setBusy(false);
		}
	}
	async function updateStatus() {
		if (!statusTarget || !canUpdate) return;
		if (nextStatus !== "ACTIVE" && !reason.trim()) {
			setError("Enter a reason for restricting this member account.");
			return;
		}
		setBusy(true);
		setError("");
		try {
			await adminApi.operations.updateMemberStatus(statusTarget.id, nextStatus, reason);
			setNotice(`${statusTarget.loginId} status changed to ${nextStatus}.`);
			setStatusTarget(null);
			setReason("");
			await load(page);
		} catch (value) {
			setError(messageOf(value));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "merchants",
		eyebrow: "Network operations",
		title: "Member directory",
		description: "Search consolidated member, KYC and AEPS status and manage the account lifecycle.",
		children: [
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banner, {
				tone: "error",
				children: error
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banner, {
				tone: "success",
				children: notice
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 md:grid-cols-2 xl:grid-cols-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "relative md:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
								className: "absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground",
								size: 16
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: filters.search,
								onChange: (event) => setFilters((current) => ({
									...current,
									search: event.target.value
								})),
								placeholder: "Name, login ID, email or username",
								className: `${control} w-full pl-9`
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
							value: filters.role,
							set: (role) => setFilters((v) => ({
								...v,
								role
							})),
							label: "All roles",
							values: [
								"ADMIN",
								"MASTER_DISTRIBUTOR",
								"DISTRIBUTOR",
								"RETAILER"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
							value: filters.status,
							set: (status) => setFilters((v) => ({
								...v,
								status
							})),
							label: "All account statuses",
							values: [
								"ACTIVE",
								"INACTIVE",
								"SUSPENDED",
								"BLOCKED"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => void load(1),
							className: `${control} flex items-center justify-center gap-2 font-bold`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
								size: 16,
								className: loading ? "animate-spin" : ""
							}), " Refresh"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
							value: filters.kycStatus,
							set: (kycStatus) => setFilters((v) => ({
								...v,
								kycStatus
							})),
							label: "All KYC statuses",
							values: [
								"NOT_STARTED",
								"PENDING",
								"UNDER_REVIEW",
								"APPROVED",
								"REJECTED"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
							value: filters.aepsStatus,
							set: (aepsStatus) => setFilters((v) => ({
								...v,
								aepsStatus
							})),
							label: "All AEPS statuses",
							values: [
								"NOT_STARTED",
								"ONBOARDING",
								"UNDER_REVIEW",
								"ACTIVE",
								"REJECTED",
								"BLOCKED"
							]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 overflow-x-auto rounded-xl border border-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[900px] text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-muted/60 text-xs uppercase text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
								"Member",
								"Role",
								"Account",
								"KYC",
								"AEPS",
								"Location",
								"Actions"
							].map((label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: label
							}, label)) })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-border",
							children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 7,
								className: "h-44 text-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mx-auto animate-spin text-primary" })
							}) }) : items.length ? items.map((member) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-4 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-extrabold",
										children: member.fullName
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground",
										children: [
											member.loginId,
											" · ",
											member.email
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-bold",
									children: member.role?.name?.replaceAll("_", " ")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: member.status })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: member.kycStatus })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: member.aeps?.status || "NOT_STARTED" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 text-xs",
									children: [member.city, member.state].filter(Boolean).join(", ") || "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											disabled: !canView || busy,
											onClick: () => void inspect(member.id),
											className: "cursor-pointer rounded-lg border border-border p-2",
											title: "View member",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 16 })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											disabled: !canUpdate || busy,
											onClick: () => {
												setStatusTarget(member);
												setNextStatus(member.status);
												setReason("");
											},
											className: "cursor-pointer rounded-lg border border-border p-2",
											title: "Change member status",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCog, { size: 16 })
										})]
									})
								})
							] }, member.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 7,
								className: "h-44 text-center text-muted-foreground",
								children: "No members match these filters."
							}) })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center justify-between text-xs font-bold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [total, " members"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: page <= 1 || loading,
								onClick: () => void load(page - 1),
								className: control,
								children: "Previous"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Page ",
								page,
								" of ",
								pages
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: page >= pages || loading,
								onClick: () => void load(page + 1),
								className: control,
								children: "Next"
							})
						]
					})]
				})
			] }),
			detail && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MemberDetailDialog, {
				detail,
				close: () => setDetail(null)
			}),
			statusTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-[100] grid place-items-center bg-secondary/60 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md rounded-2xl bg-white p-6 shadow-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-black uppercase text-primary",
								children: "Account lifecycle"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xl font-black",
								children: statusTarget.fullName
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setStatusTarget(null),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-5 block text-xs font-bold",
							children: ["New status", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: nextStatus,
								onChange: (event) => setNextStatus(event.target.value),
								className: `${control} mt-2 w-full`,
								children: [
									"ACTIVE",
									"INACTIVE",
									"SUSPENDED",
									"BLOCKED"
								].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: value }, value))
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-4 block text-xs font-bold",
							children: [
								"Reason ",
								nextStatus === "ACTIVE" ? "(optional)" : "(required)",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									value: reason,
									onChange: (event) => setReason(event.target.value),
									rows: 3,
									className: `${control} mt-2 w-full`
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: busy,
							onClick: () => void updateStatus(),
							className: "mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-bold text-white disabled:opacity-50",
							children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
								className: "animate-spin",
								size: 16
							}), " Save status"]
						})
					]
				})
			})
		]
	});
}
function Filter({ value, set, label, values }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
		value,
		onChange: (event) => set(event.target.value),
		className: control,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: "",
			children: label
		}), values.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))]
	});
}
function Status({ value }) {
	const good = [
		"ACTIVE",
		"APPROVED",
		"VERIFIED"
	].includes(value);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-full px-2 py-1 text-[10px] font-black ${good ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}`,
		children: value.replaceAll("_", " ")
	});
}
function Banner({ tone, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: `mb-4 rounded-xl p-3 text-sm font-semibold ${tone === "error" ? "bg-red-50 text-red-700" : "bg-emerald-50 text-emerald-700"}`,
		children
	});
}
var SplitComponent = AdminMemberListPage;
//#endregion
export { SplitComponent as component };
