import { r as __toESM } from "../_runtime.mjs";
import { a as credentialsPending, c as getSession, d as logo_default, l as identityVerificationPending, m as normalizeRole, p as managementBasePath, u as isManagementRole } from "./role-hierarchy-3Eppvhsl.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as ShieldCheck, G as Plug, It as FileChartColumnIncreasing, Jt as CircleUser, M as Search, P as Scale, Y as Percent, a as Wallet, cn as Bell, ht as LayoutDashboard, it as Menu, jt as FingerprintPattern, k as Settings, ln as Banknote, lt as LogOut, nt as MessageSquareText, on as Building2, r as X, s as Users, ut as Lock, vt as Landmark } from "../_libs/lucide-react.mjs";
import { a as useEffectiveAccess, i as canAccessUiArea, n as SectionTabs, t as PermissionBoundary } from "./section-tabs-INzhwNW3.mjs";
import { c as getAdminSession, r as adminAuthApi, s as getAdminActor } from "./admin-api-BMvykyWe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin-layout-BjKbHz5M.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var items = [
	{
		area: "dashboard",
		label: "Command center",
		to: "/admin",
		icon: LayoutDashboard
	},
	{
		area: "profile",
		label: "My profile",
		to: "/admin/profile",
		icon: CircleUser
	},
	{
		area: "merchants",
		label: "Member management",
		to: "/admin/merchants",
		icon: Users
	},
	{
		area: "transactions",
		label: "Transactions",
		to: "/admin/transactions",
		icon: Banknote
	},
	{
		area: "banking",
		label: "Bank operations",
		to: "/admin/banking",
		icon: Landmark
	},
	{
		area: "kyc",
		label: "KYC approvals",
		to: "/admin/kyc",
		icon: ShieldCheck
	},
	{
		area: "aeps",
		label: "AEPS management",
		to: "/admin/aeps",
		icon: FingerprintPattern
	},
	{
		area: "commissions",
		label: "Commission setup",
		to: "/admin/commissions",
		icon: Percent
	},
	{
		area: "settlements",
		label: "Wallet & settlements",
		to: "/admin/settlements",
		icon: Wallet
	},
	{
		area: "access",
		label: "Roles & access",
		to: "/admin/access",
		icon: Building2
	},
	{
		area: "reports",
		label: "All reports",
		to: "/admin/reports",
		icon: FileChartColumnIncreasing
	},
	{
		area: "api",
		label: "API settings",
		to: "/admin/api-settings",
		icon: Plug
	},
	{
		area: "settings",
		label: "System settings",
		to: "/admin/settings",
		icon: Settings
	},
	{
		area: "legal",
		label: "Legal documents",
		to: "/admin/legal",
		icon: Scale
	},
	{
		area: "sms",
		label: "SMS settings",
		to: "/admin/sms",
		icon: MessageSquareText
	}
];
var distributorItems = [
	{
		area: "dashboard",
		label: "Dashboard",
		to: "/admin",
		icon: LayoutDashboard
	},
	{
		area: "merchants",
		label: "Retailers",
		to: "/admin/retailers",
		icon: Users
	},
	{
		area: "aeps",
		label: "AEPS",
		to: "/admin/aeps",
		icon: FingerprintPattern
	},
	{
		area: "banking",
		label: "Bank accounts",
		to: "/admin/profile/bank",
		icon: Landmark
	},
	{
		area: "commissions",
		label: "Commission & earnings",
		to: "/admin/commission",
		icon: Percent
	},
	{
		area: "settlements",
		label: "Wallet",
		to: "/admin/wallet",
		icon: Wallet
	},
	{
		area: "reports",
		label: "Reports",
		to: "/admin/reports",
		icon: FileChartColumnIncreasing
	},
	{
		area: "sms",
		label: "Support",
		to: "/admin/support",
		icon: MessageSquareText
	},
	{
		area: "profile",
		label: "Profile & KYC",
		to: "/admin/profile",
		icon: CircleUser
	},
	{
		area: "settings",
		label: "Settings",
		to: "/admin/settings",
		icon: Settings
	}
];
var masterDistributorItems = [
	{
		area: "dashboard",
		label: "Dashboard",
		to: "/admin",
		icon: LayoutDashboard
	},
	{
		area: "merchants",
		label: "Network",
		to: "/admin/network/distributors",
		icon: Users
	},
	{
		area: "aeps",
		label: "AEPS",
		to: "/admin/aeps",
		icon: FingerprintPattern
	},
	{
		area: "banking",
		label: "Bank accounts",
		to: "/admin/profile/bank",
		icon: Landmark
	},
	{
		area: "commissions",
		label: "Commission & earnings",
		to: "/admin/commission",
		icon: Percent
	},
	{
		area: "settlements",
		label: "Wallet & funds",
		to: "/admin/wallet",
		icon: Wallet
	},
	{
		area: "reports",
		label: "Network reports",
		to: "/admin/reports",
		icon: FileChartColumnIncreasing
	},
	{
		area: "kyc",
		label: "KYC monitoring",
		to: "/admin/kyc",
		icon: ShieldCheck
	},
	{
		area: "sms",
		label: "Support",
		to: "/admin/support",
		icon: MessageSquareText
	},
	{
		area: "profile",
		label: "Profile",
		to: "/admin/profile",
		icon: CircleUser
	},
	{
		area: "settings",
		label: "Settings",
		to: "/admin/settings",
		icon: Settings
	}
];
var permissionArea = {
	dashboard: "dashboard",
	profile: "profile",
	merchants: "members",
	transactions: "transactions",
	banking: "banking",
	kyc: "kyc",
	aeps: "aeps",
	commissions: "commissions",
	settlements: "settlements",
	access: "access",
	reports: "reports",
	api: "api",
	settings: "settings",
	legal: "legal",
	sms: "sms"
};
function AdminSidebar({ active, mobile = false, onClose }) {
	const identity = getSession()?.identity;
	const credentialsPending$1 = credentialsPending(identity);
	const role = normalizeRole(identity?.role);
	const base = managementBasePath(role);
	const actor = getAdminActor();
	const { access } = useEffectiveAccess();
	async function logout() {
		const destination = getAdminActor()?.kind === "SUPER_ADMIN" ? "/admin/login" : "/login";
		try {
			await adminAuthApi.logout();
		} finally {
			window.location.assign(destination);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: `${mobile ? "fixed inset-y-0 left-0 z-50 shadow-2xl" : "sticky top-[74px] hidden h-[calc(100vh-74px)] self-start lg:flex"} w-[278px] shrink-0 flex-col overflow-hidden border-r border-border bg-white p-5`,
		children: [
			mobile && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: onClose,
				"aria-label": "Close menu",
				className: "ml-auto grid h-10 w-10 place-items-center rounded-xl hover:bg-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 20 })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl bg-secondary p-5 text-white",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-extrabold uppercase tracking-[.18em] text-primary",
						children: "UMOBIPAY"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xl font-black",
						children: role === "MASTER_DISTRIBUTOR" ? "Master Distributor" : role === "DISTRIBUTOR" ? "Distributor Console" : "Admin Console"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-white/55",
						children: "Secure operations workspace"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				"aria-label": "Admin navigation",
				className: "mt-6 min-h-0 flex-1 space-y-1 overflow-y-auto pr-1",
				children: (role === "DISTRIBUTOR" ? distributorItems : role === "MASTER_DISTRIBUTOR" ? masterDistributorItems : items).map(({ area, label, to, icon: Icon }) => {
					const uiArea = area === "sms" && (role === "DISTRIBUTOR" || role === "MASTER_DISTRIBUTOR") ? "support" : area === "settlements" && (role === "DISTRIBUTOR" || role === "MASTER_DISTRIBUTOR") ? "wallet" : permissionArea[area];
					const permissionDenied = !canAccessUiArea(uiArea, {
						role: role || actor?.role,
						access: actor?.kind === "IDENTITY_ADMIN" ? access : null,
						dedicatedSuperAdmin: actor?.kind === "SUPER_ADMIN"
					});
					const locked = credentialsPending$1 && area !== "settings" || permissionDenied;
					const destination = `${base}${to.slice(6)}`;
					return locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						title: permissionDenied ? "Your active packages do not grant this section" : "Change temporary password and MPIN in Settings to unlock",
						className: "flex cursor-not-allowed items-center gap-3 rounded-xl px-3 py-3 text-sm font-bold text-muted-foreground/55",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 19 }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1",
								children: label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { size: 14 })
						]
					}, area) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: destination,
						onClick: onClose,
						className: `flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-bold transition ${active === area ? "bg-primary text-white shadow-md shadow-primary/20" : "text-secondary hover:bg-secondary/5"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 19 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
					}, area);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: logout,
				className: "mt-4 flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-bold text-red-600 hover:bg-red-50",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { size: 19 }), " Sign out"]
			})
		]
	});
}
var tabs = (base, values) => values.map(([label, path]) => ({
	label,
	href: `${base}${path}`
}));
function managementSectionTabs(roleValue, area) {
	const role = normalizeRole(roleValue);
	if (role === "MASTER_DISTRIBUTOR") {
		const base = "/master-distributor";
		return {
			merchants: tabs(base, [
				["Distributors", "/network/distributors"],
				["Retailers", "/network/retailers"],
				["Network Tree", "/network/tree"]
			]),
			transactions: tabs(base, [
				["All Transactions", "/transactions"],
				["Successful", "/transactions?status=SUCCESS"],
				["Pending", "/transactions?status=PENDING"],
				["Failed", "/transactions?status=FAILED"]
			]),
			aeps: tabs(base, [
				["My AEPS", "/aeps"],
				["Network transactions", "/transactions"],
				["Successful", "/transactions?status=SUCCESS"],
				["Pending", "/transactions?status=PENDING"],
				["Failed", "/transactions?status=FAILED"]
			]),
			commissions: tabs(base, [
				["Commission History", "/commission"],
				["Daily Earnings", "/commission?view=daily"],
				["Monthly Earnings", "/commission?view=monthly"]
			]),
			settlements: tabs(base, [["Balance", "/wallet"], ["Transfer Fund", "/wallet/transfer"]]),
			reports: tabs(base, [
				["Business Report", "/reports"],
				["Distributor Report", "/reports?view=distributors"],
				["Retailer Report", "/reports?view=retailers"],
				["Transaction Report", "/reports?view=transactions"],
				["Commission Report", "/reports?view=commission"]
			]),
			kyc: tabs(base, [["Distributor KYC", "/kyc"], ["Retailer Status", "/kyc?view=retailers"]]),
			sms: tabs(base, [["Raise Ticket", "/support"], ["My Tickets", "/support?view=tickets"]]),
			profile: tabs(base, [
				["Personal Details", "/profile"],
				["KYC", "/profile/kyc"],
				["Bank Details", "/profile/bank"]
			])
		}[area] || [];
	}
	if (role === "DISTRIBUTOR") {
		const base = "/distributor";
		return {
			merchants: tabs(base, [
				["All Retailers", "/retailers"],
				["Add Retailer", "/retailers/add"],
				["Retailer Details", "/retailers?view=details"]
			]),
			transactions: tabs(base, [
				["Transactions", "/aeps/transactions"],
				["Cash Withdrawal", "/aeps/cash-withdrawal"],
				["Balance Enquiry", "/aeps/balance-enquiry"],
				["Mini Statement", "/aeps/mini-statement"]
			]),
			aeps: tabs(base, [
				["My AEPS", "/aeps"],
				["Network transactions", "/aeps/transactions"],
				["Cash Withdrawal", "/aeps/cash-withdrawal"],
				["Balance Enquiry", "/aeps/balance-enquiry"],
				["Mini Statement", "/aeps/mini-statement"]
			]),
			commissions: tabs(base, [
				["Commission History", "/commission"],
				["Daily Earnings", "/commission?view=daily"],
				["Monthly Earnings", "/commission?view=monthly"]
			]),
			settlements: tabs(base, [["Balance", "/wallet"], ["Transfer Fund", "/wallet/transfer"]]),
			reports: tabs(base, [["Transaction Report", "/reports"], ["Retailer-wise Report", "/reports?view=retailers"]]),
			sms: tabs(base, [["Raise Complaint", "/support"], ["My Tickets", "/support?view=tickets"]]),
			profile: tabs(base, [
				["Personal Details", "/profile"],
				["KYC", "/profile/kyc"],
				["Bank Details", "/profile/bank"]
			])
		}[area] || [];
	}
	if (role === "ADMIN") {
		if (area === "profile") return tabs("/admin", [
			["Personal Details", "/profile"],
			["KYC", "/profile/kyc"],
			["Bank Details", "/profile/bank"]
		]);
		if (area === "aeps") return tabs("/admin", [
			["My AEPS", "/aeps"],
			["Merchants", "/merchants/list"],
			["Transactions", "/transactions"],
			["Provider controls", "/api-settings"]
		]);
		return [];
	}
	return [];
}
var adminWorkspaceReady = false;
function AdminLayout({ active, eyebrow, title, description, children }) {
	const [ready, setReady] = (0, import_react.useState)(adminWorkspaceReady);
	const [menu, setMenu] = (0, import_react.useState)(false);
	const actor = getAdminActor();
	const identity = getSession()?.identity;
	const { access } = useEffectiveAccess();
	(0, import_react.useEffect)(() => {
		if (!getAdminActor()) return window.location.replace("/login");
		if (getAdminSession()?.onboardingRequired) return window.location.replace("/admin/onboarding");
		const identitySession = getSession();
		const base = managementBasePath(identitySession?.identity.role);
		if (base !== "/admin" && window.location.pathname.startsWith("/admin")) return window.location.replace(`${base}${window.location.pathname.slice(6)}`);
		if (identitySession && isManagementRole(identitySession.identity.role) && credentialsPending(identitySession.identity)) {
			if (active !== "settings") return window.location.replace(identityVerificationPending(identitySession) ? `${base}/account-setup` : `${base}/settings`);
		}
		adminWorkspaceReady = true;
		setReady(true);
	}, [active]);
	(0, import_react.useEffect)(() => {
		document.body.style.overflow = menu ? "hidden" : "";
		return () => {
			document.body.style.overflow = "";
		};
	}, [menu]);
	if (!ready) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center bg-[#f3f8f6] text-sm font-bold text-secondary",
		children: "Loading secure workspace..."
	});
	const permissionArea = {
		dashboard: "dashboard",
		profile: "profile",
		merchants: "members",
		transactions: "transactions",
		banking: "banking",
		kyc: "kyc",
		aeps: "aeps",
		commissions: "commissions",
		settlements: "settlements",
		access: "access",
		reports: "reports",
		api: "api",
		settings: "settings",
		legal: "legal",
		sms: identity?.role === "DISTRIBUTOR" || identity?.role === "MASTER_DISTRIBUTOR" ? "support" : "sms"
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#f3f8f6] text-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "sticky top-0 z-40 flex h-[74px] items-center border-b border-border bg-white px-4 sm:px-7",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setMenu(true),
					"aria-label": "Open admin menu",
					className: "mr-3 grid h-10 w-10 place-items-center rounded-xl border border-border lg:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { size: 20 })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: logo_default,
					alt: "UMOBIPAY",
					className: "h-9 w-auto"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto hidden w-72 items-center gap-2 rounded-xl bg-muted px-3 py-2.5 text-muted-foreground md:flex",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { size: 17 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs",
						children: "Search operations"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					"aria-label": "Notifications",
					className: "ml-3 grid h-10 w-10 place-items-center rounded-xl border border-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { size: 18 })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-3 hidden rounded-xl border border-border px-4 py-2 sm:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-extrabold",
						children: actor?.name || "Administrator"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[10px] text-muted-foreground",
						children: actor?.role || "ADMIN"
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-h-[calc(100vh-74px)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminSidebar, { active }),
				menu && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					"aria-label": "Close menu overlay",
					onClick: () => setMenu(false),
					className: "fixed inset-0 z-40 bg-secondary/45 lg:hidden"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminSidebar, {
					active,
					mobile: true,
					onClose: () => setMenu(false)
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "min-w-0 flex-1 p-5 sm:p-8 lg:p-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-[1500px]",
						children: [
							eyebrow && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-extrabold uppercase tracking-[.18em] text-primary",
								children: eyebrow
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-1 text-3xl font-black sm:text-4xl",
								children: title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 max-w-3xl text-sm leading-6 text-muted-foreground",
								children: description
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTabs, { tabs: managementSectionTabs(identity?.role, active) })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: managementSectionTabs(identity?.role, active).length ? "" : "mt-7",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionBoundary, {
									area: active === "settlements" && (identity?.role === "DISTRIBUTOR" || identity?.role === "MASTER_DISTRIBUTOR") ? "wallet" : permissionArea[active],
									role: identity?.role || actor?.role,
									access: actor?.kind === "IDENTITY_ADMIN" ? access : null,
									dedicatedSuperAdmin: actor?.kind === "SUPER_ADMIN",
									children
								})
							})
						]
					})
				})
			]
		})]
	});
}
function AdminPanel({ children, className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: `rounded-2xl border border-border bg-white p-5 shadow-sm sm:p-6 ${className}`,
		children
	});
}
function ServiceState({ title, description, status = "Ready for integration" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col justify-between gap-5 sm:flex-row sm:items-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-xl font-black",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 max-w-2xl text-sm leading-6 text-muted-foreground",
			children: description
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "w-fit whitespace-nowrap rounded-full bg-emerald-50 px-3 py-1.5 text-xs font-extrabold text-emerald-700",
			children: status
		})]
	}) });
}
//#endregion
export { AdminPanel as n, ServiceState as r, AdminLayout as t };
