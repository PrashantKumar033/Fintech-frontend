import { r as __toESM } from "../_runtime.mjs";
import { a as credentialsPending, c as getSession, d as logo_default, f as logout, r as authenticatedRequest, t as ApiError } from "./role-hierarchy-3Eppvhsl.mjs";
import { i as require_react, r as require_jsx_runtime, t as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as ShieldCheck, It as FileChartColumnIncreasing, V as Receipt, Yt as CircleDollarSign, a as Wallet, cn as Bell, dn as BadgeCheck, ht as LayoutDashboard, it as Menu, jt as FingerprintPattern, k as Settings, lt as LogOut, r as X, s as Users, ut as Lock, vt as Landmark } from "../_libs/lucide-react.mjs";
import { a as useEffectiveAccess, i as canAccessUiArea, n as SectionTabs, t as PermissionBoundary } from "./section-tabs-INzhwNW3.mjs";
import { t as createIdempotencyKey } from "./idempotency-key-BtLMYz3w.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/business-page-BTimK3aC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var form = (fields, files) => {
	const data = new FormData();
	Object.entries(fields).forEach(([key, value]) => value && data.append(key, value));
	Object.entries(files).forEach(([key, value]) => data.append(key, value));
	return data;
};
var complianceApi = {
	banks: (token) => authenticatedRequest("/identity/get-my-bank-accounts", {}, token),
	bank: (token, id) => authenticatedRequest(`/identity/get-my-bank-account/${id}`, {}, token),
	primaryBank: (token) => authenticatedRequest("/identity/my-bank-accounts/primary", {}, token),
	bankDirectory: (token) => authenticatedRequest("/bank/list", {}, token),
	addBank: (token, body, idempotencyKey = createIdempotencyKey("bank-create")) => authenticatedRequest("/identity/bank-accounts", {
		method: "POST",
		headers: { "Idempotency-Key": idempotencyKey },
		body: JSON.stringify(body)
	}, token),
	updateBank: (token, id, body, idempotencyKey) => authenticatedRequest(`/identity/update-my-bank-account/${id}`, {
		method: "PATCH",
		headers: idempotencyKey ? { "Idempotency-Key": idempotencyKey } : void 0,
		body: JSON.stringify(body)
	}, token),
	deleteBank: (token, id) => authenticatedRequest(`/identity/delete-my-bank-account/${id}`, { method: "DELETE" }, token),
	setPrimary: (token, id) => authenticatedRequest(`/identity/my-bank-accounts/${id}/set-primary`, { method: "PATCH" }, token),
	getKyc: (token) => authenticatedRequest("/kyc/me", { cache: "no-store" }, token),
	createKyc: (token) => authenticatedRequest("/kyc/create", {
		method: "POST",
		body: JSON.stringify({})
	}, token),
	bundle: (token) => authenticatedRequest("/kyc/me/documents?page=1&limit=100", { cache: "no-store" }, token),
	uploadDocument: (token, documentType, documentNumber, file) => authenticatedRequest("/kyc/document", {
		method: "POST",
		headers: { "Idempotency-Key": createIdempotencyKey("kyc-document") },
		body: form({
			documentType,
			documentNumber
		}, { file })
	}, token),
	uploadAadhaar: (token, documentNumber, frontImage, backImage) => authenticatedRequest("/kyc/aadhaar", {
		method: "POST",
		headers: { "Idempotency-Key": createIdempotencyKey("kyc-aadhaar") },
		body: form({ documentNumber }, {
			frontImage,
			backImage
		})
	}, token),
	uploadVideo: (token, file) => authenticatedRequest("/kyc/video", {
		method: "POST",
		headers: { "Idempotency-Key": createIdempotencyKey("kyc-video") },
		body: form({}, { file })
	}, token),
	updateDocument: (token, documentType, documentNumber, file) => authenticatedRequest("/kyc/document", {
		method: "PUT",
		body: form({
			documentType,
			documentNumber
		}, { file })
	}, token),
	updateAadhaar: (token, documentNumber, frontImage, backImage) => authenticatedRequest("/kyc/aadhaar", {
		method: "PUT",
		body: form({ documentNumber }, {
			...frontImage ? { frontImage } : {},
			...backImage ? { backImage } : {}
		})
	}, token),
	deleteDocument: (token, id) => authenticatedRequest(`/kyc/document/${id}`, { method: "DELETE" }, token),
	deleteVideo: (token, id) => authenticatedRequest(`/kyc/video/${id}`, { method: "DELETE" }, token),
	submitKyc: (token) => authenticatedRequest("/kyc/submit", {
		method: "POST",
		headers: { "Idempotency-Key": createIdempotencyKey("kyc-submit") },
		body: JSON.stringify({})
	}, token)
};
function complianceMessage(error) {
	return error instanceof ApiError ? error.message : error instanceof Error ? error.message : "Request failed.";
}
function useServiceReadiness(enabled = true) {
	const session = typeof window === "undefined" ? null : getSession();
	return useQuery({
		queryKey: ["service-readiness", session?.identity.id],
		enabled: enabled && !!session,
		staleTime: 6e4,
		refetchOnMount: "always",
		gcTime: 6e5,
		queryFn: async () => {
			const token = getSession()?.accessToken;
			if (!token) throw new ApiError("Your session has expired.", 401);
			const [kycResult, bankResult] = await Promise.allSettled([complianceApi.getKyc(token), complianceApi.banks(token)]);
			const kycStatus = kycResult.status === "fulfilled" ? kycResult.value.status : kycResult.reason instanceof ApiError && kycResult.reason.status === 404 ? "NOT_STARTED" : "UNAVAILABLE";
			const hasVerifiedBank = bankResult.status === "fulfilled" && bankResult.value.some((bank) => bank.status === "ACTIVE" && bank.verificationStatus === "VERIFIED" && bank.ownershipStatus === "VERIFIED");
			return {
				kycStatus,
				hasVerifiedBank,
				aepsUnlocked: kycStatus === "APPROVED" && hasVerifiedBank
			};
		}
	});
}
var retailerSectionTabs = {
	aeps: [
		{
			label: "AEPS Services",
			href: "/retailer/aeps"
		},
		{
			label: "Cash Withdrawal",
			href: "/retailer/aeps?service=cash-withdrawal"
		},
		{
			label: "Balance Enquiry",
			href: "/retailer/aeps?service=balance-enquiry"
		},
		{
			label: "Mini Statement",
			href: "/retailer/aeps?service=mini-statement"
		},
		{
			label: "Transaction Status",
			href: "/retailer/transactions"
		}
	],
	transactions: [
		{
			label: "All Transactions",
			href: "/retailer/transactions"
		},
		{
			label: "Successful",
			href: "/retailer/transactions?status=SUCCESS"
		},
		{
			label: "Pending",
			href: "/retailer/transactions?status=PENDING"
		},
		{
			label: "Failed",
			href: "/retailer/transactions?status=FAILED"
		}
	],
	wallet: [{
		label: "Wallet Balance",
		href: "/retailer/wallet"
	}, {
		label: "Transfer Fund",
		href: "/retailer/wallet/transfer"
	}],
	reports: [
		{
			label: "Account Activity",
			href: "/activity"
		},
		{
			label: "AEPS Report",
			href: "/activity?view=aeps"
		},
		{
			label: "Wallet Report",
			href: "/activity?view=wallet"
		},
		{
			label: "Commission Report",
			href: "/activity?view=commission"
		}
	],
	settings: [
		{
			label: "Personal Details",
			href: "/retailer/settings?tab=profile"
		},
		{
			label: "Login & Security",
			href: "/retailer/settings?tab=security"
		},
		{
			label: "Preferences",
			href: "/retailer/settings?tab=preferences"
		}
	]
};
function BusinessPage({ identity, active, eyebrow, title, description, showPageHeader = true, onSettingsClick, children }) {
	const [mobileMenuOpen, setMobileMenuOpen] = (0, import_react.useState)(false);
	const securityLocked = credentialsPending(identity);
	const readiness = useServiceReadiness(active !== "kyc");
	const { access } = useEffectiveAccess();
	(0, import_react.useEffect)(() => {
		if (securityLocked && active !== "settings") window.location.replace("/retailer/settings");
	}, [active, securityLocked]);
	(0, import_react.useEffect)(() => {
		if (!mobileMenuOpen) return;
		const closeOnEscape = (event) => {
			if (event.key === "Escape") setMobileMenuOpen(false);
		};
		const previousOverflow = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		window.addEventListener("keydown", closeOnEscape);
		return () => {
			document.body.style.overflow = previousOverflow;
			window.removeEventListener("keydown", closeOnEscape);
		};
	}, [mobileMenuOpen]);
	const nav = [
		{
			key: "dashboard",
			label: "Dashboard",
			to: "/retailer/dashboard",
			icon: LayoutDashboard,
			locked: false,
			area: "dashboard"
		},
		{
			key: "kyc",
			label: "KYC verification",
			to: "/retailer/kyc",
			icon: ShieldCheck,
			locked: false,
			area: "kyc",
			status: readiness.data?.kycStatus?.replaceAll("_", " ")
		},
		{
			key: "bank",
			label: "Bank accounts",
			to: "/retailer/bank",
			icon: Landmark,
			locked: false,
			area: "banking",
			status: readiness.data?.hasVerifiedBank ? "VERIFIED" : void 0
		},
		{
			key: "aeps",
			label: "AEPS",
			to: "/retailer/aeps",
			icon: FingerprintPattern,
			locked: !readiness.data?.aepsUnlocked,
			area: "aeps"
		},
		{
			key: "members",
			label: "Member management",
			icon: Users,
			locked: true,
			area: "members"
		},
		{
			key: "wallet",
			label: "Wallet & transfer",
			to: "/retailer/wallet",
			icon: Wallet,
			locked: false,
			area: "wallet"
		},
		{
			key: "transactions",
			label: "Transactions",
			to: "/retailer/transactions",
			icon: Receipt,
			locked: false,
			area: "transactions"
		},
		{
			key: "reports",
			label: "Account activity",
			to: "/activity",
			icon: FileChartColumnIncreasing,
			locked: false,
			area: "reports"
		},
		{
			key: "commission",
			label: "Commission",
			icon: CircleDollarSign,
			locked: true,
			area: "commissions"
		},
		{
			key: "settings",
			label: "Settings",
			to: "/retailer/settings",
			icon: Settings,
			locked: false,
			area: "settings"
		}
	];
	async function signOut() {
		setMobileMenuOpen(false);
		await logout();
		window.location.assign("/login");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#f5f8f8] text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-40 border-b border-border/70 bg-card/95 backdrop-blur-xl",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-16 items-center gap-3 px-4 lg:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setMobileMenuOpen(true),
						className: "grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-border bg-background text-secondary lg:hidden",
						"aria-label": "Open navigation menu",
						"aria-expanded": mobileMenuOpen,
						"aria-controls": "retailer-navigation",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { size: 19 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/retailer/dashboard",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: logo_default,
							className: "h-9",
							alt: "UMOBIPAY"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: "relative grid h-10 w-10 place-items-center rounded-xl border border-border bg-background text-secondary",
							"aria-label": "Notifications",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { size: 18 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-2 top-2 h-2 w-2 rounded-full bg-primary" })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden items-center gap-3 rounded-xl border border-border px-3 py-1.5 sm:flex",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-8 w-8 place-items-center rounded-lg bg-secondary font-bold text-white",
								children: identity.fullName?.[0] || "U"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "max-w-36",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-xs font-bold text-secondary",
									children: identity.fullName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-[10px] text-muted-foreground",
									children: identity.loginId
								})]
							})]
						})]
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex",
			children: [
				mobileMenuOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": "Close navigation menu",
					onClick: () => setMobileMenuOpen(false),
					className: "fixed inset-0 z-40 bg-secondary/45 backdrop-blur-[2px] lg:hidden"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					id: "retailer-navigation",
					className: `fixed inset-y-0 left-0 z-50 flex w-[min(18rem,86vw)] shrink-0 flex-col border-r border-border bg-card p-4 shadow-2xl transition-transform duration-200 lg:sticky lg:top-16 lg:z-20 lg:h-[calc(100vh-4rem)] lg:w-72 lg:translate-x-0 lg:shadow-none ${mobileMenuOpen ? "translate-x-0" : "-translate-x-full"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex items-center justify-between px-1 lg:hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: logo_default,
								className: "h-8",
								alt: "UMOBIPAY"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setMobileMenuOpen(false),
								className: "grid h-9 w-9 place-items-center rounded-xl border border-border text-secondary",
								"aria-label": "Close navigation menu",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-5 rounded-2xl bg-secondary p-4 text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-11 w-11 place-items-center rounded-xl bg-white/10 text-lg font-extrabold",
									children: identity.fullName?.[0] || "U"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm font-bold",
										children: identity.fullName
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-white/60",
										children: identity.role
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex items-center gap-2 border-t border-white/10 pt-3 text-xs text-emerald-300",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { size: 14 }),
									" ",
									identity.status,
									" account"
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "space-y-1 overflow-y-auto",
							children: nav.map(({ key, label, icon: Icon, locked, status, to, area }) => {
								const permissionDenied = area ? !canAccessUiArea(area, {
									role: identity.role,
									access
								}) : false;
								return key === "settings" && onSettingsClick ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										onSettingsClick();
										setMobileMenuOpen(false);
									},
									className: `flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition ${active === key ? "bg-primary text-white shadow-sm" : "text-secondary hover:bg-mint"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 17 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
								}, key) : securityLocked && key !== "settings" || locked || permissionDenied ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									title: permissionDenied ? "Your active packages do not grant this section" : key === "aeps" ? "KYC approval and verified bank account required" : securityLocked ? "Change temporary password and MPIN in Settings to unlock" : "Coming soon",
									className: "flex cursor-not-allowed items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold text-muted-foreground/55",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 17 }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
											size: 12,
											className: "ml-auto"
										})
									]
								}, key) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to,
									onClick: () => setMobileMenuOpen(false),
									className: `flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition ${active === key ? "bg-primary text-white shadow-sm" : "text-secondary hover:bg-mint"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 17 }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }),
										status && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "ml-auto max-w-20 truncate rounded-full bg-emerald-50 px-2 py-0.5 text-[9px] font-extrabold text-emerald-700",
											children: status
										})
									]
								}, key);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: signOut,
							className: "mt-auto flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold text-destructive hover:bg-destructive/10",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { size: 17 }), " Sign out"]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "min-w-0 flex-1 p-4 sm:p-6 lg:p-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-[1500px]",
						children: [
							showPageHeader && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-7",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mb-4 flex gap-2 overflow-x-auto lg:hidden",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/retailer/kyc",
												className: `min-w-max rounded-xl px-4 py-2 text-xs font-bold ${active === "kyc" ? "bg-secondary text-white" : "bg-card text-secondary"}`,
												children: "KYC"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/retailer/bank",
												className: `min-w-max rounded-xl px-4 py-2 text-xs font-bold ${active === "bank" ? "bg-secondary text-white" : "bg-card text-secondary"}`,
												children: "Bank Accounts"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/retailer/wallet",
												className: `min-w-max rounded-xl px-4 py-2 text-xs font-bold ${active === "wallet" ? "bg-secondary text-white" : "bg-card text-secondary"}`,
												children: "Wallet"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/retailer/transactions",
												className: `min-w-max rounded-xl px-4 py-2 text-xs font-bold ${active === "transactions" ? "bg-secondary text-white" : "bg-card text-secondary"}`,
												children: "Transactions"
											}),
											readiness.data?.aepsUnlocked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/retailer/aeps",
												className: `min-w-max rounded-xl px-4 py-2 text-xs font-bold ${active === "aeps" ? "bg-secondary text-white" : "bg-card text-secondary"}`,
												children: "AEPS"
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "flex min-w-max items-center gap-2 rounded-xl bg-muted px-4 py-2 text-xs font-bold text-muted-foreground",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, { size: 12 }), " AEPS"]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-extrabold uppercase tracking-[.2em] text-primary",
										children: eyebrow
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "mt-1 text-3xl font-extrabold text-secondary",
										children: title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 max-w-2xl text-sm text-muted-foreground",
										children: description
									})
								]
							}),
							showPageHeader && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionTabs, { tabs: retailerSectionTabs[active] || [] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionBoundary, {
								area: active === "bank" ? "banking" : active === "transactions" ? "transactions" : active === "reports" ? "reports" : active,
								role: identity.role,
								access,
								children
							})
						]
					})
				})
			]
		})]
	});
}
function ServiceNotice({ ok, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex gap-3 rounded-xl p-4 text-sm font-semibold ${ok ? "bg-emerald-50 text-emerald-800" : "bg-red-50 text-red-700"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, {
			size: 18,
			className: "shrink-0"
		}), children]
	});
}
//#endregion
export { useServiceReadiness as a, complianceMessage as i, ServiceNotice as n, complianceApi as r, BusinessPage as t };
