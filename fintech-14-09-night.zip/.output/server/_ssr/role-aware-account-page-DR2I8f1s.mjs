import { m as normalizeRole, u as isManagementRole } from "./role-hierarchy-3Eppvhsl.mjs";
import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as AdminLayout } from "./admin-layout-BjKbHz5M.mjs";
import { t as BusinessPage } from "./business-page-BTimK3aC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/role-aware-account-page-DR2I8f1s.js
var import_jsx_runtime = require_jsx_runtime();
function RoleAwareAccountPage({ identity, section, eyebrow, title, description, children }) {
	const role = normalizeRole(identity.role);
	if (isManagementRole(role)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: section === "bank" && role !== "ADMIN" ? "banking" : "profile",
		eyebrow,
		title,
		description,
		children
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BusinessPage, {
		identity,
		active: section,
		eyebrow,
		title,
		description,
		children
	});
}
//#endregion
export { RoleAwareAccountPage as t };
