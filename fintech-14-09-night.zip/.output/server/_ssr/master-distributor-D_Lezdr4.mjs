import { o as MasterDashboard } from "./router-CdmUoS7N.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/master-distributor-D_Lezdr4.js
var SplitComponent = MasterDashboard;
//#endregion
export { SplitComponent as component };
