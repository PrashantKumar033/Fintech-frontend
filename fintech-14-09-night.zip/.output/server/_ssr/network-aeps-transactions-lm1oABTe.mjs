import { r as __toESM } from "../_runtime.mjs";
import { c as getSession } from "./role-hierarchy-3Eppvhsl.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { R as RefreshCw, ft as LoaderCircle } from "../_libs/lucide-react.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-BjKbHz5M.mjs";
import { n as operationsApi, r as operationsMessage } from "./operations-api-DqEJBnjJ.mjs";
import { t as TransactionDetailDialog } from "./transaction-detail-dialog-C-Y-eyAy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/network-aeps-transactions-lm1oABTe.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var statuses = [
	"",
	"SUCCESS",
	"FAILED",
	"PENDING",
	"PROCESSING",
	"UNKNOWN",
	"REVERSED"
];
var operations = [
	"",
	"BE",
	"MS",
	"CW",
	"AP",
	"CD"
];
var operationLabels = {
	BE: "Balance enquiry",
	MS: "Mini statement",
	CW: "Cash withdrawal",
	AP: "Aadhaar Pay",
	CD: "Cash deposit"
};
function NetworkAepsTransactions({ title, description, operation, initialStatus = "", activeArea = "transactions" }) {
	const token = getSession()?.accessToken ?? "";
	const [result, setResult] = (0, import_react.useState)(null);
	const [page, setPage] = (0, import_react.useState)(1);
	const [status, setStatus] = (0, import_react.useState)(initialStatus);
	const [operationFilter, setOperationFilter] = (0, import_react.useState)(operation ?? "");
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)("");
	const [refreshKey, setRefreshKey] = (0, import_react.useState)(0);
	const [selectedReference, setSelectedReference] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setStatus(initialStatus);
		setPage(1);
	}, [initialStatus]);
	(0, import_react.useEffect)(() => {
		setOperationFilter(operation ?? "");
		setPage(1);
	}, [operation]);
	(0, import_react.useEffect)(() => {
		let active = true;
		setLoading(true);
		setError("");
		operationsApi.networkTransactions(token, {
			page,
			limit: 25,
			status: status || void 0,
			operation: (operation ?? operationFilter) || void 0
		}).then((response) => {
			if (active) setResult(response);
		}).catch((reason) => {
			if (active) setError(operationsMessage(reason));
		}).finally(() => {
			if (active) setLoading(false);
		});
		return () => {
			active = false;
		};
	}, [
		operation,
		operationFilter,
		page,
		refreshKey,
		status,
		token
	]);
	const range = (0, import_react.useMemo)(() => {
		if (!result?.total) return "0 records";
		return `${(result.page - 1) * result.limit + 1}-${Math.min(result.page * result.limit, result.total)} of ${result.total}`;
	}, [result]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: activeArea,
		eyebrow: "AEPS network monitoring",
		title,
		description,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-3",
					children: [!operation && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1 text-xs font-bold text-secondary",
						children: ["Operation", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: operationFilter,
							onChange: (event) => {
								setOperationFilter(event.target.value);
								setPage(1);
							},
							className: "cursor-pointer rounded-xl border border-border bg-white px-4 py-3 text-sm font-medium",
							children: operations.map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value,
								children: value ? operationLabels[value] : "All operations"
							}, value || "ALL"))
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1 text-xs font-bold text-secondary",
						children: ["Status", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: status,
							onChange: (event) => {
								setStatus(event.target.value);
								setPage(1);
							},
							className: "cursor-pointer rounded-xl border border-border bg-white px-4 py-3 text-sm font-medium",
							children: statuses.map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value,
								children: value || "All statuses"
							}, value || "ALL"))
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setRefreshKey((value) => value + 1),
					disabled: loading,
					className: "inline-flex cursor-pointer items-center gap-2 rounded-xl border border-border px-4 py-3 text-sm font-bold disabled:cursor-not-allowed disabled:opacity-50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
						size: 16,
						className: loading ? "animate-spin" : ""
					}), "Refresh"]
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-4 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 overflow-x-auto",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[920px] text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border text-xs uppercase text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Retailer / identity"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Reference"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Operation"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Provider"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Amount"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Date"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: result?.data.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border/60",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-bold",
										children: row.sourceRole || "RETAILER"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "max-w-[190px] truncate text-xs text-muted-foreground",
										title: row.identityId,
										children: row.identityId || "-"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setSelectedReference(row.referenceId),
										className: "cursor-pointer font-bold text-primary hover:underline",
										children: row.referenceId
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3",
									children: operationLabels[row.operation] ?? row.operation
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3",
									children: row.provider
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "p-3",
									children: ["₹", Number(row.amount || 0).toLocaleString("en-IN")]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3 font-bold",
									children: row.status
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3",
									children: new Date(row.createdAt).toLocaleString("en-IN")
								})
							]
						}, row.id || `${row.identityId}:${row.referenceId}`)) })]
					}),
					loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid min-h-40 place-items-center",
						"aria-label": "Loading transactions",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin text-primary" })
					}),
					!loading && !error && !result?.data.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-10 text-center text-sm text-muted-foreground",
						children: "No matching AEPS transactions were found in your assigned network."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-center justify-between gap-3 border-t border-border pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs font-semibold text-muted-foreground",
					children: range
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: loading || page <= 1,
						onClick: () => setPage((value) => Math.max(1, value - 1)),
						className: "cursor-pointer rounded-xl border border-border px-4 py-2 text-sm font-bold disabled:cursor-not-allowed disabled:opacity-40",
						children: "Previous"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: loading || !result || page >= result.totalPages,
						onClick: () => setPage((value) => value + 1),
						className: "cursor-pointer rounded-xl border border-border px-4 py-2 text-sm font-bold disabled:cursor-not-allowed disabled:opacity-40",
						children: "Next"
					})]
				})]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransactionDetailDialog, {
			accessToken: token,
			referenceId: selectedReference,
			scope: "network",
			onClose: () => setSelectedReference(null)
		})]
	});
}
//#endregion
export { NetworkAepsTransactions as t };
