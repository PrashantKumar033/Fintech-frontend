import { r as AdminIdentitySetup } from "./router-CdmUoS7N.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-setup-D0yq6wvG.js
var SplitComponent = AdminIdentitySetup;
//#endregion
export { SplitComponent as component };
