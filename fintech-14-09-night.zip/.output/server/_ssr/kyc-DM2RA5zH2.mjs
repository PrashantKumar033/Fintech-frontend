import { r as __toESM } from "../_runtime.mjs";
import { a as credentialsPending, c as getSession, p as managementBasePath, t as ApiError, u as isManagementRole, y as signedInHome } from "./role-hierarchy-3Eppvhsl.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { Ft as FileCheckCorner, Mt as FileUp, R as RefreshCw, _ as Trash2, dn as BadgeCheck, jt as FingerprintPattern, nn as Camera } from "../_libs/lucide-react.mjs";
import { a as useEffectiveAccess, r as UI_PERMISSION } from "./section-tabs-INzhwNW3.mjs";
import { t as ActionPermissionNotice } from "./action-permission-notice-CGOJQx-x.mjs";
import { i as complianceMessage, n as ServiceNotice, r as complianceApi } from "./business-page-BTimK3aC.mjs";
import { t as RoleAwareAccountPage } from "./role-aware-account-page-DR2I8f1s.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kyc-DM2RA5zH2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var docs = [
	{
		type: "PAN_CARD",
		label: "PAN card",
		number: true
	},
	{
		type: "SIGNATURE",
		label: "Signature",
		number: false
	},
	{
		type: "SHOP_FRONT",
		label: "Shop front",
		number: false
	},
	{
		type: "BUSINESS_PROOF",
		label: "Business proof",
		number: true
	}
];
function KycPage() {
	const { can } = useEffectiveAccess();
	const canManageKyc = can(UI_PERMISSION.KYC_MANAGE, [
		"ADMIN",
		"MASTER_DISTRIBUTOR",
		"DISTRIBUTOR",
		"RETAILER"
	]);
	const navigate = useNavigate(), [session, setSession] = (0, import_react.useState)(null), [kyc, setKyc] = (0, import_react.useState)(null), [bundle, setBundle] = (0, import_react.useState)(null), [loading, setLoading] = (0, import_react.useState)(true), [busy, setBusy] = (0, import_react.useState)(""), [message, setMessage] = (0, import_react.useState)(null);
	async function load(token, background = false) {
		if (!background) setLoading(true);
		try {
			const profile = await complianceApi.getKyc(token);
			setKyc(profile);
			setBundle(await complianceApi.bundle(token));
		} catch (error) {
			if (error instanceof ApiError && error.status === 404) {
				setKyc(null);
				setBundle(null);
			} else setMessage({
				ok: false,
				text: `KYC service: ${complianceMessage(error)}`
			});
		} finally {
			if (!background) setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		const value = getSession();
		if (!value) {
			navigate({ to: "/login" });
			return;
		}
		if (credentialsPending(value.identity)) {
			window.location.replace(signedInHome(value));
			return;
		}
		setSession(value);
		load(value.accessToken);
	}, [navigate]);
	const uploaded = (0, import_react.useMemo)(() => new Set(bundle?.documents.map((d) => d.documentType) || []), [bundle]);
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "animate-spin text-primary" })
	});
	const activeSession = session;
	async function run(name, task, text) {
		if (!canManageKyc) {
			setMessage({
				ok: false,
				text: `Permission ${UI_PERMISSION.KYC_MANAGE} is required.`
			});
			return;
		}
		setBusy(name);
		setMessage(null);
		try {
			await task();
			await load(activeSession.accessToken, true);
			setMessage({
				ok: true,
				text
			});
		} catch (e) {
			setMessage({
				ok: false,
				text: complianceMessage(e)
			});
		} finally {
			setBusy("");
		}
	}
	const editable = !!kyc && (kyc.status === "PENDING" || kyc.status === "REJECTED"), complete = docs.every((d) => uploaded.has(d.type)) && uploaded.has("AADHAAR_FRONT") && uploaded.has("AADHAAR_BACK") && !!bundle?.video;
	const missingItems = [
		...docs.filter((document) => !uploaded.has(document.type)).map((document) => document.label),
		...!uploaded.has("AADHAAR_FRONT") || !uploaded.has("AADHAAR_BACK") ? ["Aadhaar front & back"] : [],
		...!bundle?.video ? ["Verification video"] : []
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(RoleAwareAccountPage, {
		identity: session.identity,
		section: "kyc",
		eyebrow: "Identity & compliance",
		title: "KYC verification",
		description: "Submit business documents and track approval status. KYC is the first prerequisite for AEPS.",
		children: [
			!canManageKyc && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionPermissionNotice, {
					permission: UI_PERMISSION.KYC_MANAGE,
					title: "KYC application is read-only",
					text: "Document changes and final submission are not enabled for your active package."
				})
			}),
			message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceNotice, {
					ok: message.ok,
					children: message.text
				})
			}),
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid h-72 place-items-center rounded-2xl bg-card",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "animate-spin text-primary" })
			}) : !kyc ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "rounded-2xl border border-border bg-card p-8 shadow-soft",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-xl text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-mint text-secondary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { size: 30 })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-5 text-2xl font-extrabold text-secondary",
							children: "Start business verification"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: "Create your KYC application, then upload the required documents securely."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: !canManageKyc || !!busy,
							onClick: () => run("create", () => complianceApi.createKyc(session.accessToken), "KYC application created."),
							className: "mt-6 rounded-xl bg-secondary px-6 py-3 text-sm font-bold text-white",
							children: "Create KYC application"
						})
					]
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 lg:grid-cols-[1fr_320px]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "space-y-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-extrabold uppercase tracking-wider text-primary",
									children: "Application status"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 text-xl font-extrabold text-secondary",
									children: kyc.status.replaceAll("_", " ")
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `rounded-full px-3 py-1.5 text-xs font-extrabold ${kyc.status === "APPROVED" ? "bg-emerald-50 text-emerald-700" : kyc.status === "REJECTED" ? "bg-red-50 text-red-700" : "bg-amber-50 text-amber-700"}`,
									children: kyc.status
								})]
							}), kyc.remarks && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-4 rounded-xl bg-red-50 p-4 text-sm text-red-700",
								children: ["Reviewer remarks: ", kyc.remarks]
							})]
						}),
						editable && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-extrabold text-secondary",
										children: "1. Business documents"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-muted-foreground",
										children: "JPEG, PNG or PDF as supported by the KYC service."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-5 grid gap-4 sm:grid-cols-2",
										children: docs.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocumentCard, {
											label: d.label,
											needNumber: d.number,
											done: uploaded.has(d.type),
											existingNumber: bundle?.documents.find((item) => item.documentType === d.type)?.documentNumber || "",
											disabled: !canManageKyc || !!busy,
											upload: (file, number) => run(d.type, () => complianceApi.uploadDocument(session.accessToken, d.type, number, file), `${d.label} uploaded.`),
											replace: (file, number) => run(`replace-${d.type}`, () => complianceApi.updateDocument(session.accessToken, d.type, number, file), `${d.label} replaced and queued for verification.`)
										}, d.type))
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AadhaarCard, {
								done: uploaded.has("AADHAAR_FRONT") && uploaded.has("AADHAAR_BACK"),
								disabled: !canManageKyc || !!busy,
								upload: (number, front, back) => run("aadhaar", () => uploaded.has("AADHAAR_FRONT") || uploaded.has("AADHAAR_BACK") ? complianceApi.updateAadhaar(session.accessToken, number, front, back) : complianceApi.uploadAadhaar(session.accessToken, number, front, back), uploaded.has("AADHAAR_FRONT") || uploaded.has("AADHAAR_BACK") ? "Aadhaar images replaced and queued for verification." : "Aadhaar uploaded.")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(VideoCard, {
								done: !!bundle?.video,
								disabled: !canManageKyc || !!busy,
								upload: (file) => run("video", () => complianceApi.uploadVideo(session.accessToken, file), "Verification video uploaded.")
							}),
							!complete && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								role: "alert",
								className: "rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-bold",
									children: "Complete these items before final submission:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1",
									children: missingItems.join(", ")
								})]
							}),
							complete && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-800",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-extrabold",
									children: "All required uploads are complete."
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1",
									children: "Your KYC is still a draft. Use the button below to submit it to the admin review queue."
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: !canManageKyc || !complete || !!busy,
								onClick: () => run("submit", () => complianceApi.submitKyc(session.accessToken), "KYC submitted for review."),
								className: "w-full rounded-xl bg-primary py-4 text-sm font-extrabold text-white disabled:cursor-not-allowed disabled:opacity-40",
								children: busy === "submit" ? "Submitting KYC..." : "Submit KYC now — send to admin review"
							})
						] }),
						kyc.status === "UNDER_REVIEW" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceNotice, {
							ok: true,
							children: "Application submitted. The compliance team is reviewing your documents."
						}),
						kyc.status === "APPROVED" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-2xl bg-secondary p-7 text-white",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FingerprintPattern, { size: 28 }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-4 text-xl font-extrabold",
									children: "KYC approved"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-white/65",
									children: "Your identity prerequisite is ready. Continue to the independent AEPS onboarding service."
								}),
								isManagementRole(session.identity.role) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: managementBasePath(session.identity.role),
									className: "mt-5 inline-flex rounded-xl bg-primary px-5 py-3 text-sm font-bold",
									children: "Return to dashboard"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/retailer/aeps",
									className: "mt-5 inline-flex rounded-xl bg-primary px-5 py-3 text-sm font-bold",
									children: "Continue to AEPS"
								})
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sticky top-6 space-y-4",
					children: [editable && (bundle?.documents.length || bundle?.video) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-extrabold text-secondary",
							children: "Uploaded files"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 space-y-2",
							children: [bundle.documents.map((document) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 rounded-xl bg-muted p-3 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheckCorner, {
										size: 15,
										className: "text-emerald-600"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "min-w-0 flex-1 truncate font-semibold",
										children: document.documentType.replaceAll("_", " ")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										disabled: !canManageKyc || !!busy,
										"aria-label": `Delete ${document.documentType}`,
										onClick: () => run(`delete-${document.id}`, () => complianceApi.deleteDocument(session.accessToken, document.id), "Document removed. You can upload a replacement."),
										className: "text-red-600 disabled:opacity-40",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 15 })
									})
								]
							}, document.id)), bundle.video && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2 rounded-xl bg-muted p-3 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, {
										size: 15,
										className: "text-emerald-600"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1 font-semibold",
										children: "Verification video"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										disabled: !canManageKyc || !!busy,
										"aria-label": "Delete verification video",
										onClick: () => run("delete-video", () => complianceApi.deleteVideo(session.accessToken, bundle.video.id), "Verification video removed."),
										className: "text-red-600 disabled:opacity-40",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 15 })
									})
								]
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-extrabold text-secondary",
							children: "Application checklist"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5 space-y-3",
							children: [
								...docs.map((d) => [d.label, uploaded.has(d.type)]),
								["Aadhaar front & back", uploaded.has("AADHAAR_FRONT") && uploaded.has("AADHAAR_BACK")],
								["Verification video", !!bundle?.video]
							].map(([label, done]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-3 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `grid h-7 w-7 place-items-center rounded-full ${done ? "bg-emerald-50 text-emerald-600" : "bg-muted text-muted-foreground"}`,
									children: done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheckCorner, { size: 14 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileUp, { size: 14 })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: done ? "font-semibold text-secondary" : "text-muted-foreground",
									children: label
								})]
							}, label))
						})]
					})]
				}) })]
			})
		]
	});
}
function DocumentCard({ label, needNumber, done, existingNumber, disabled, upload, replace }) {
	const [number, setNumber] = (0, import_react.useState)(existingNumber);
	const [file, setFile] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const submit = () => {
		setError("");
		const value = number.trim().toUpperCase();
		if (needNumber && !value) return setError(`${label} number is required.`);
		if (label === "PAN card" && !/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(value)) return setError("Enter a valid PAN, for example ABCDE1234F.");
		if (!file) return setError(`Select the ${label} file.`);
		if (![
			"application/pdf",
			"image/jpeg",
			"image/png"
		].includes(file.type)) return setError("Only PDF, JPG, JPEG and PNG files are allowed.");
		if (file.size > 10485760) return setError("Document must not exceed 10 MB.");
		if (done) replace(file, value);
		else upload(file, value);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-background p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-bold text-secondary",
					children: label
				}), done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, {
					size: 17,
					className: "text-emerald-600"
				})]
			}),
			needNumber && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				value: number,
				onChange: (e) => {
					setNumber(e.target.value.toUpperCase());
					setError("");
				},
				placeholder: "Document number",
				className: "mt-3 w-full rounded-lg border border-border bg-card px-3 py-2 text-xs"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				disabled,
				type: "file",
				accept: "image/jpeg,image/png,application/pdf",
				onChange: (e) => {
					setFile(e.target.files?.[0] || null);
					setError("");
				},
				className: "mt-3 block w-full text-xs"
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-2 text-xs font-semibold text-red-600",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled,
				onClick: submit,
				className: "mt-3 w-full rounded-lg bg-secondary px-3 py-2 text-xs font-bold text-white disabled:opacity-50",
				children: disabled ? "Uploading…" : done ? `Replace ${label}` : `Upload ${label}`
			})
		]
	});
}
function VideoCard({ done, disabled, upload }) {
	const [file, setFile] = (0, import_react.useState)(null), [error, setError] = (0, import_react.useState)("");
	const submit = () => {
		setError("");
		if (!file) return setError("Select or record a verification video.");
		if (![
			"video/mp4",
			"video/webm",
			"video/quicktime"
		].includes(file.type)) return setError("Only MP4, WebM and MOV videos are allowed.");
		if (file.size > 104857600) return setError("Video must not exceed 100 MB.");
		upload(file);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-10 w-10 place-items-center rounded-xl bg-mint",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { size: 18 })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-extrabold text-secondary",
					children: ["3. Live verification video ", done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-emerald-600",
						children: "✓"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Record or select an MP4, WebM or MOV video up to 100 MB."
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				disabled: disabled || done,
				type: "file",
				accept: "video/mp4,video/webm,video/quicktime,.mov",
				capture: "user",
				onChange: (e) => {
					setFile(e.target.files?.[0] || null);
					setError("");
				},
				className: "mt-5 block w-full text-sm"
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-2 text-xs font-semibold text-red-600",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled,
				onClick: submit,
				className: "mt-4 rounded-xl bg-secondary px-5 py-2.5 text-sm font-bold text-white disabled:opacity-50",
				children: done ? "Video uploaded" : disabled ? "Uploading…" : "Upload verification video"
			})
		]
	});
}
function AadhaarCard({ done, disabled, upload }) {
	const [number, setNumber] = (0, import_react.useState)(""), [front, setFront] = (0, import_react.useState)(null), [back, setBack] = (0, import_react.useState)(null), [error, setError] = (0, import_react.useState)("");
	const submit = () => {
		setError("");
		if (number.length !== 12) return setError("Enter a valid 12-digit Aadhaar number.");
		if (!front || !back) return setError("Select both Aadhaar front and back images.");
		if (![front, back].every((file) => ["image/jpeg", "image/png"].includes(file.type))) return setError("Aadhaar files must be JPG, JPEG or PNG images.");
		if ([front, back].some((file) => file.size > 5242880)) return setError("Each Aadhaar image must not exceed 5 MB.");
		upload(number, front, back);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "font-extrabold text-secondary",
				children: ["2. Aadhaar verification ", done && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-emerald-600",
					children: "✓"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: "Upload clear front and back images together."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: number,
						onChange: (e) => {
							setNumber(e.target.value.replace(/\D/g, "").slice(0, 12));
							setError("");
						},
						placeholder: "12-digit Aadhaar",
						className: "rounded-xl border border-border px-3 py-2 text-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs font-bold text-muted-foreground",
						children: ["FRONT IMAGE", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/jpeg,image/png",
							onChange: (e) => {
								setFront(e.target.files?.[0] || null);
								setError("");
							},
							className: "mt-2 block w-full font-normal"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "text-xs font-bold text-muted-foreground",
						children: ["BACK IMAGE", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/jpeg,image/png",
							onChange: (e) => {
								setBack(e.target.files?.[0] || null);
								setError("");
							},
							className: "mt-2 block w-full font-normal"
						})]
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-3 text-xs font-semibold text-red-600",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				disabled,
				onClick: submit,
				className: "mt-5 rounded-xl bg-secondary px-5 py-2.5 text-sm font-bold text-white disabled:opacity-40",
				children: disabled ? "Uploading…" : done ? "Replace Aadhaar images" : "Upload Aadhaar"
			})
		]
	});
}
//#endregion
export { KycPage as component };
