import { r as AdminIdentitySetup } from "./router-CdmUoS7N.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-setup-OMQ6uJ0d.js
var SplitComponent = AdminIdentitySetup;
//#endregion
export { SplitComponent as component };
