import { i as CreateMemberPage } from "./router-CdmUoS7N.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/add-NwLCBVoD.js
var SplitComponent = CreateMemberPage;
//#endregion
export { SplitComponent as component };
