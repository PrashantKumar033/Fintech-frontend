import { r as __toESM } from "../_runtime.mjs";
import { c as getSession } from "./role-hierarchy-3Eppvhsl.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { M as Search, O as ShieldAlert, R as RefreshCw, T as SlidersHorizontal, W as Plus, X as PenLine, Xt as CircleCheck, Y as Percent, c as UsersRound, en as ChevronDown, ft as LoaderCircle, gt as Layers, r as X, rn as Calculator, xt as IndianRupee } from "../_libs/lucide-react.mjs";
import { a as useEffectiveAccess, r as UI_PERMISSION } from "./section-tabs-INzhwNW3.mjs";
import { c as getAdminSession, n as adminApi, s as getAdminActor, t as AdminApiError } from "./admin-api-BMvykyWe.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-BjKbHz5M.mjs";
import { v as Route$55 } from "./router-CdmUoS7N.mjs";
import { n as operationsApi, r as operationsMessage } from "./operations-api-DqEJBnjJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/commissions-7gMPYmW0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var field = "rounded-xl border border-border bg-white px-3 py-3 text-sm outline-none focus:border-primary";
function CommissionCalculator() {
	const identity = getSession()?.identity;
	const [userId, setUserId] = (0, import_react.useState)(identity?.id || "");
	const [role, setRole] = (0, import_react.useState)(identity?.role || "RETAILER");
	const [serviceType, setServiceType] = (0, import_react.useState)("AEPS");
	const [operator, setOperator] = (0, import_react.useState)("");
	const [amount, setAmount] = (0, import_react.useState)("");
	const [result, setResult] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function submit(event) {
		event.preventDefault();
		const token = getSession()?.accessToken || getAdminSession()?.accessToken;
		if (!token) return setError("Sign in again before calculating commission.");
		setBusy(true);
		setError("");
		setResult(null);
		try {
			setResult(await operationsApi.calculateCommission(token, {
				userId: userId.trim(),
				role: role.trim().toUpperCase(),
				serviceType: serviceType.trim().toUpperCase(),
				operator: operator.trim().toUpperCase() || void 0,
				transactionAmount: Number(amount),
				idempotencyKey: crypto.randomUUID()
			}));
		} catch (requestError) {
			setError(operationsMessage(requestError));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
		className: "mt-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, { size: 18 })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-black",
					children: "Commission preview"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Run the live backend calculation before applying a rule to a transaction."
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "mt-4 grid gap-3 md:grid-cols-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: userId,
						onChange: (e) => setUserId(e.target.value),
						placeholder: "User UUID",
						className: field
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: role,
						onChange: (e) => setRole(e.target.value),
						placeholder: "Role",
						className: field
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						value: serviceType,
						onChange: (e) => setServiceType(e.target.value),
						placeholder: "Service",
						className: field
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: operator,
						onChange: (e) => setOperator(e.target.value),
						placeholder: "Operator (optional)",
						className: field
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							required: true,
							min: "0.01",
							step: "0.01",
							type: "number",
							value: amount,
							onChange: (e) => setAmount(e.target.value),
							placeholder: "Amount",
							className: `${field} min-w-0 flex-1`
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: busy,
							className: "rounded-xl bg-primary px-4 text-xs font-extrabold text-white disabled:opacity-50",
							children: busy ? "…" : "Calculate"
						})]
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 rounded-xl bg-red-50 p-3 text-sm text-red-700",
				children: error
			}),
			result && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-3 max-h-72 overflow-auto rounded-xl bg-secondary p-4 text-xs text-white",
				children: JSON.stringify(result, null, 2)
			})
		]
	});
}
var inputClass = "w-full rounded-xl border border-border bg-white px-3.5 py-3 text-sm text-secondary outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/15 disabled:cursor-not-allowed disabled:bg-muted disabled:text-muted-foreground";
var emptyRuleDraft = {
	serviceType: "",
	operator: "",
	role: "RETAILER",
	commissionType: "FIXED",
	commissionValue: "",
	minAmount: "",
	maxAmount: "",
	priority: "0",
	isActive: true
};
var emptyDistributionDraft = {
	commissionRuleId: "",
	recipientRole: "",
	distributionType: "FIXED",
	distributionValue: "",
	priority: "0",
	isActive: true
};
function normalizeCode(value) {
	return value.trim().toUpperCase();
}
function numberOrUndefined(value) {
	if (!value.trim()) return void 0;
	return Number(value);
}
function money(value) {
	if (value === null || value === void 0 || value === "") return "No limit";
	const amount = Number(value);
	if (!Number.isFinite(amount)) return String(value);
	return new Intl.NumberFormat("en-IN", {
		style: "currency",
		currency: "INR",
		minimumFractionDigits: 2
	}).format(amount);
}
function dateTime(value) {
	if (!value) return "Not available";
	const parsed = new Date(value);
	if (Number.isNaN(parsed.getTime())) return "Not available";
	return new Intl.DateTimeFormat("en-IN", {
		dateStyle: "medium",
		timeStyle: "short"
	}).format(parsed);
}
function ruleRate(rule) {
	const value = Number(rule.commissionValue);
	if (rule.commissionType === "PERCENTAGE") return `${Number.isFinite(value) ? value : rule.commissionValue}%`;
	return money(rule.commissionValue);
}
function distributionRate(distribution) {
	const value = Number(distribution.distributionValue);
	if (distribution.distributionType === "PERCENTAGE") return `${Number.isFinite(value) ? value : distribution.distributionValue}% of commission pool`;
	return `${money(distribution.distributionValue)} from commission pool`;
}
function draftFromRule(rule) {
	return {
		serviceType: rule.serviceType || "",
		operator: rule.operator || "",
		role: rule.role || "RETAILER",
		commissionType: rule.commissionType,
		commissionValue: String(rule.commissionValue ?? ""),
		minAmount: rule.minAmount === null || rule.minAmount === void 0 ? "" : String(rule.minAmount),
		maxAmount: rule.maxAmount === null || rule.maxAmount === void 0 ? "" : String(rule.maxAmount),
		priority: String(rule.priority ?? 0),
		isActive: Boolean(rule.isActive)
	};
}
function draftFromDistribution(distribution) {
	return {
		commissionRuleId: distribution.commissionRuleId,
		recipientRole: distribution.recipientRole || "",
		distributionType: distribution.distributionType,
		distributionValue: String(distribution.distributionValue ?? ""),
		priority: String(distribution.priority ?? 0),
		isActive: Boolean(distribution.isActive)
	};
}
function activeTotals(distributions) {
	return distributions.reduce((totals, item) => {
		if (!item.isActive) return totals;
		const value = Number(item.distributionValue);
		if (!Number.isFinite(value)) return totals;
		if (item.distributionType === "PERCENTAGE") totals.percentage += value;
		else totals.fixed += value;
		return totals;
	}, {
		percentage: 0,
		fixed: 0
	});
}
function distributionHealth(rule, distributions) {
	if (!rule) return {
		tone: "warn",
		title: "Select a commission rule",
		detail: "Choose a rule to review its active distribution setup."
	};
	const totals = activeTotals(distributions);
	if (totals.percentage > 100.000001) return {
		tone: "danger",
		title: "Distribution setup can exceed the commission pool",
		detail: `Active percentage shares total ${totals.percentage.toFixed(4)}%. The backend checks the full pool at execution and will reject an over-allocation.`
	};
	if (rule.commissionType === "FIXED") {
		const pool = Number(rule.commissionValue);
		if (Number.isFinite(pool)) {
			const configured = totals.fixed + pool * totals.percentage / 100;
			if (configured > pool + .005) return {
				tone: "danger",
				title: "Configured shares are larger than this fixed commission pool",
				detail: `${money(configured)} is configured against a ${money(pool)} pool. Reduce a fixed or percentage share before activating this setup.`
			};
			const remainder = Math.max(0, pool - configured);
			return {
				tone: "good",
				title: "Distribution fits this fixed commission pool",
				detail: `${money(configured)} is configured for hierarchy recipients. Up to ${money(remainder)} remains for the source merchant when all configured recipients are eligible.`
			};
		}
	}
	if (totals.fixed > 0) {
		const rulePercent = Number(rule.commissionValue);
		const minAmount = Number(rule.minAmount);
		if (rule.commissionType === "PERCENTAGE" && Number.isFinite(rulePercent) && Number.isFinite(minAmount) && minAmount > 0) {
			const minPool = minAmount * rulePercent / 100;
			const configuredAtMin = totals.fixed + minPool * totals.percentage / 100;
			if (configuredAtMin > minPool + .005) return {
				tone: "danger",
				title: "Fixed shares can exceed the pool at the start of this slab",
				detail: `At ${money(minAmount)}, the estimated commission pool is ${money(minPool)}, but active shares need about ${money(configuredAtMin)}.`
			};
		}
		return {
			tone: "warn",
			title: "Mixed fixed and percentage shares need runtime room",
			detail: `Active setup has ${money(totals.fixed)} fixed plus ${totals.percentage.toFixed(4)}% of the pool. The backend makes the final over-allocation check for each real transaction.`
		};
	}
	return {
		tone: "good",
		title: "Percentage setup is within the commission pool",
		detail: `${totals.percentage.toFixed(4)}% is configured for hierarchy recipients. The unallocated part stays with the source merchant.`
	};
}
function Commissions() {
	const search = Route$55.useSearch();
	const navigate = Route$55.useNavigate();
	const actor = getAdminActor();
	const { can } = useEffectiveAccess();
	const allowed = (code) => actor?.kind === "SUPER_ADMIN" || can(code, ["ADMIN"]);
	const supportedAdminRole = actor?.role === "SUPER_ADMIN" || actor?.role === "ADMIN";
	const canViewRules = supportedAdminRole && allowed(UI_PERMISSION.COMMISSION_RULE_VIEW);
	const canViewDistributions = supportedAdminRole && allowed(UI_PERMISSION.COMMISSION_DISTRIBUTION_VIEW);
	const canManage = canViewRules || canViewDistributions;
	const canCreateRule = allowed(UI_PERMISSION.COMMISSION_RULE_CREATE);
	const canUpdateRule = allowed(UI_PERMISSION.COMMISSION_RULE_UPDATE);
	const canDeactivateRule = allowed(UI_PERMISSION.COMMISSION_RULE_DEACTIVATE);
	const canCreateDistribution = allowed(UI_PERMISSION.COMMISSION_DISTRIBUTION_CREATE);
	const canUpdateDistribution = allowed(UI_PERMISSION.COMMISSION_DISTRIBUTION_UPDATE);
	const canDeactivateDistribution = allowed(UI_PERMISSION.COMMISSION_DISTRIBUTION_DEACTIVATE);
	const view = search.view === "distributions" ? "DISTRIBUTIONS" : "RULES";
	const [rules, setRules] = (0, import_react.useState)([]);
	const [distributions, setDistributions] = (0, import_react.useState)([]);
	const [rulesLoading, setRulesLoading] = (0, import_react.useState)(canManage);
	const [distributionsLoading, setDistributionsLoading] = (0, import_react.useState)(canManage);
	const [error, setError] = (0, import_react.useState)("");
	const [notice, setNotice] = (0, import_react.useState)("");
	const [saving, setSaving] = (0, import_react.useState)(false);
	const [ruleQuery, setRuleQuery] = (0, import_react.useState)("");
	const [ruleStatus, setRuleStatus] = (0, import_react.useState)("ALL");
	const [ruleRoleFilter, setRuleRoleFilter] = (0, import_react.useState)("ALL");
	const [ruleEditorOpen, setRuleEditorOpen] = (0, import_react.useState)(false);
	const [editingRuleId, setEditingRuleId] = (0, import_react.useState)(null);
	const [ruleDraft, setRuleDraft] = (0, import_react.useState)(emptyRuleDraft);
	const [loadingRule, setLoadingRule] = (0, import_react.useState)(false);
	const [pendingRuleStatus, setPendingRuleStatus] = (0, import_react.useState)(null);
	const [selectedRuleId, setSelectedRuleId] = (0, import_react.useState)("");
	const [distributionQuery, setDistributionQuery] = (0, import_react.useState)("");
	const [distributionStatus, setDistributionStatus] = (0, import_react.useState)("ALL");
	const [distributionEditorOpen, setDistributionEditorOpen] = (0, import_react.useState)(false);
	const [editingDistributionId, setEditingDistributionId] = (0, import_react.useState)(null);
	const [distributionDraft, setDistributionDraft] = (0, import_react.useState)(emptyDistributionDraft);
	const [loadingDistribution, setLoadingDistribution] = (0, import_react.useState)(false);
	const [pendingDistributionStatus, setPendingDistributionStatus] = (0, import_react.useState)(null);
	async function loadRules() {
		if (!canManage) return;
		setRulesLoading(true);
		try {
			setRules(await adminApi.commissionRules.list());
		} catch (caught) {
			setError(caught instanceof AdminApiError ? caught.message : "Unable to load commission rules.");
		} finally {
			setRulesLoading(false);
		}
	}
	async function loadDistributions() {
		if (!canManage) return;
		setDistributionsLoading(true);
		try {
			setDistributions(await adminApi.commissionDistributions.list());
		} catch (caught) {
			setError(caught instanceof AdminApiError ? caught.message : "Unable to load commission distributions.");
		} finally {
			setDistributionsLoading(false);
		}
	}
	async function refreshAll() {
		setError("");
		await Promise.all([loadRules(), loadDistributions()]);
	}
	(0, import_react.useEffect)(() => {
		if (!canManage) return;
		Promise.all([loadRules(), loadDistributions()]);
	}, [canManage]);
	(0, import_react.useEffect)(() => {
		if (!rules.length) {
			setSelectedRuleId("");
			return;
		}
		if (selectedRuleId && rules.some((rule) => rule.id === selectedRuleId)) return;
		setSelectedRuleId(rules.find((rule) => rule.isActive)?.id || rules[0].id);
	}, [rules, selectedRuleId]);
	const visibleRules = (0, import_react.useMemo)(() => {
		const search = ruleQuery.trim().toLowerCase();
		return rules.filter((rule) => {
			if (ruleStatus === "ACTIVE" && !rule.isActive) return false;
			if (ruleStatus === "INACTIVE" && rule.isActive) return false;
			if (ruleRoleFilter !== "ALL" && rule.role !== ruleRoleFilter) return false;
			if (!search) return true;
			return `${rule.serviceType} ${rule.operator || ""} ${rule.role} ${rule.commissionType} ${rule.id}`.toLowerCase().includes(search);
		});
	}, [
		rules,
		ruleQuery,
		ruleStatus,
		ruleRoleFilter
	]);
	const selectedRule = (0, import_react.useMemo)(() => rules.find((rule) => rule.id === selectedRuleId), [rules, selectedRuleId]);
	const selectedRuleDistributions = (0, import_react.useMemo)(() => distributions.filter((item) => item.commissionRuleId === selectedRuleId), [distributions, selectedRuleId]);
	const visibleDistributions = (0, import_react.useMemo)(() => {
		const search = distributionQuery.trim().toLowerCase();
		return selectedRuleDistributions.filter((item) => {
			if (distributionStatus === "ACTIVE" && !item.isActive) return false;
			if (distributionStatus === "INACTIVE" && item.isActive) return false;
			if (!search) return true;
			return `${item.recipientRole} ${item.distributionType} ${item.id}`.toLowerCase().includes(search);
		});
	}, [
		selectedRuleDistributions,
		distributionQuery,
		distributionStatus
	]);
	const activeRuleCount = rules.filter((rule) => rule.isActive).length;
	const inactiveRuleCount = rules.length - activeRuleCount;
	const serviceCount = new Set(rules.map((rule) => rule.serviceType)).size;
	const activeSelectedDistributions = selectedRuleDistributions.filter((item) => item.isActive);
	const selectedTotals = activeTotals(activeSelectedDistributions);
	const health = (0, import_react.useMemo)(() => distributionHealth(selectedRule, activeSelectedDistributions), [selectedRule, activeSelectedDistributions]);
	function switchView(nextView) {
		navigate({
			search: { view: nextView === "DISTRIBUTIONS" ? "distributions" : "rules" },
			replace: true
		});
		setError("");
		setNotice("");
		setPendingRuleStatus(null);
		setPendingDistributionStatus(null);
		setRuleEditorOpen(false);
		setDistributionEditorOpen(false);
	}
	function startCreateRule() {
		if (!canCreateRule) return setError(`Permission ${UI_PERMISSION.COMMISSION_RULE_CREATE} is required.`);
		setEditingRuleId(null);
		setRuleDraft(emptyRuleDraft);
		setError("");
		setNotice("");
		setRuleEditorOpen(true);
	}
	async function startEditRule(rule) {
		if (!canUpdateRule) return setError(`Permission ${UI_PERMISSION.COMMISSION_RULE_UPDATE} is required.`);
		setRuleEditorOpen(true);
		setEditingRuleId(rule.id);
		setRuleDraft(draftFromRule(rule));
		setLoadingRule(true);
		setError("");
		setNotice("");
		try {
			const fresh = await adminApi.commissionRules.get(rule.id);
			setRuleDraft(draftFromRule(fresh));
		} catch (caught) {
			setError(caught instanceof AdminApiError ? caught.message : "Unable to load the latest rule details.");
		} finally {
			setLoadingRule(false);
		}
	}
	function validateRuleDraft() {
		if (!normalizeCode(ruleDraft.serviceType)) return "Service type is required.";
		if (!ruleDraft.role.trim()) return "Role is required.";
		if (!ruleDraft.commissionValue.trim()) return "Commission value is required.";
		const commissionValue = Number(ruleDraft.commissionValue);
		if (!Number.isFinite(commissionValue) || commissionValue < 0) return "Commission value must be 0 or more.";
		if (ruleDraft.commissionType === "PERCENTAGE" && commissionValue > 100) return "Percentage commission cannot be more than 100%.";
		const minAmount = numberOrUndefined(ruleDraft.minAmount);
		const maxAmount = numberOrUndefined(ruleDraft.maxAmount);
		if (minAmount !== void 0 && (!Number.isFinite(minAmount) || minAmount < 0)) return "Minimum amount must be 0 or more.";
		if (maxAmount !== void 0 && (!Number.isFinite(maxAmount) || maxAmount < 0)) return "Maximum amount must be 0 or more.";
		if (minAmount !== void 0 && maxAmount !== void 0 && minAmount > maxAmount) return "Minimum amount cannot be greater than maximum amount.";
		const priority = Number(ruleDraft.priority || 0);
		if (!Number.isInteger(priority)) return "Priority must be a whole number.";
		return null;
	}
	async function submitRule(event) {
		event.preventDefault();
		const required = editingRuleId ? UI_PERMISSION.COMMISSION_RULE_UPDATE : UI_PERMISSION.COMMISSION_RULE_CREATE;
		if (editingRuleId ? !canUpdateRule : !canCreateRule) return setError(`Permission ${required} is required.`);
		setError("");
		setNotice("");
		const validationError = validateRuleDraft();
		if (validationError) return setError(validationError);
		const minAmount = numberOrUndefined(ruleDraft.minAmount);
		const maxAmount = numberOrUndefined(ruleDraft.maxAmount);
		const operator = normalizeCode(ruleDraft.operator);
		const common = {
			serviceType: normalizeCode(ruleDraft.serviceType),
			role: normalizeCode(ruleDraft.role),
			commissionType: ruleDraft.commissionType,
			commissionValue: Number(ruleDraft.commissionValue),
			priority: Number(ruleDraft.priority || 0),
			isActive: ruleDraft.isActive
		};
		setSaving(true);
		try {
			if (editingRuleId) {
				const body = {
					...common,
					operator: operator || null,
					minAmount: minAmount ?? null,
					maxAmount: maxAmount ?? null
				};
				await adminApi.commissionRules.update(editingRuleId, body);
				setNotice("Commission rule updated successfully.");
			} else {
				const body = {
					...common,
					...operator ? { operator } : {},
					...minAmount !== void 0 ? { minAmount } : {},
					...maxAmount !== void 0 ? { maxAmount } : {}
				};
				await adminApi.commissionRules.create(body);
				setNotice("Commission rule created successfully.");
			}
			setRuleEditorOpen(false);
			setEditingRuleId(null);
			setRuleDraft(emptyRuleDraft);
			await loadRules();
		} catch (caught) {
			setError(caught instanceof AdminApiError ? caught.message : "Unable to save the commission rule.");
		} finally {
			setSaving(false);
		}
	}
	async function confirmRuleStatusChange() {
		if (!pendingRuleStatus) return;
		const { rule, nextActive } = pendingRuleStatus;
		if (nextActive ? !canUpdateRule : !canDeactivateRule) return setError(`Permission ${nextActive ? UI_PERMISSION.COMMISSION_RULE_UPDATE : UI_PERMISSION.COMMISSION_RULE_DEACTIVATE} is required.`);
		setSaving(true);
		setError("");
		setNotice("");
		try {
			if (nextActive) {
				await adminApi.commissionRules.update(rule.id, { isActive: true });
				setNotice("Commission rule reactivated successfully.");
			} else {
				await adminApi.commissionRules.deactivate(rule.id);
				setNotice("Commission rule deactivated. Historical commission links remain preserved.");
			}
			setRules((current) => current.map((item) => item.id === rule.id ? {
				...item,
				isActive: nextActive
			} : item));
			setPendingRuleStatus(null);
		} catch (caught) {
			setError(caught instanceof AdminApiError ? caught.message : "Unable to change the rule status.");
		} finally {
			setSaving(false);
		}
	}
	function startCreateDistribution() {
		if (!canCreateDistribution) return setError(`Permission ${UI_PERMISSION.COMMISSION_DISTRIBUTION_CREATE} is required.`);
		if (!selectedRuleId) {
			setError("Create a commission rule first, then select it before adding a distribution.");
			return;
		}
		setEditingDistributionId(null);
		setDistributionDraft({
			...emptyDistributionDraft,
			commissionRuleId: selectedRuleId
		});
		setError("");
		setNotice("");
		setDistributionEditorOpen(true);
	}
	async function startEditDistribution(distribution) {
		if (!canUpdateDistribution) return setError(`Permission ${UI_PERMISSION.COMMISSION_DISTRIBUTION_UPDATE} is required.`);
		setDistributionEditorOpen(true);
		setEditingDistributionId(distribution.id);
		setDistributionDraft(draftFromDistribution(distribution));
		setLoadingDistribution(true);
		setError("");
		setNotice("");
		try {
			const fresh = await adminApi.commissionDistributions.get(distribution.id);
			setDistributionDraft(draftFromDistribution(fresh));
			setSelectedRuleId(fresh.commissionRuleId);
		} catch (caught) {
			setError(caught instanceof AdminApiError ? caught.message : "Unable to load the latest distribution details.");
		} finally {
			setLoadingDistribution(false);
		}
	}
	function proposedDistributionHealth(draft, editingId) {
		const rule = rules.find((item) => item.id === draft.commissionRuleId);
		if (!rule) return distributionHealth(void 0, []);
		const base = distributions.filter((item) => item.commissionRuleId === draft.commissionRuleId && item.id !== editingId);
		if (!draft.isActive) return distributionHealth(rule, base.filter((item) => item.isActive));
		const proposed = {
			id: editingId || "__PROPOSED__",
			commissionRuleId: draft.commissionRuleId,
			recipientRole: normalizeCode(draft.recipientRole),
			distributionType: draft.distributionType,
			distributionValue: Number(draft.distributionValue),
			priority: Number(draft.priority || 0),
			isActive: true
		};
		return distributionHealth(rule, [...base.filter((item) => item.isActive), proposed]);
	}
	function validateDistributionDraft() {
		if (!distributionDraft.commissionRuleId.trim()) return "Commission rule is required.";
		if (!normalizeCode(distributionDraft.recipientRole)) return "Recipient role is required.";
		if (!distributionDraft.distributionValue.trim()) return "Distribution value is required.";
		const value = Number(distributionDraft.distributionValue);
		if (!Number.isFinite(value) || value < 0) return "Distribution value must be 0 or more.";
		if (distributionDraft.distributionType === "PERCENTAGE" && value > 100) return "Percentage distribution cannot be more than 100%.";
		const priority = Number(distributionDraft.priority || 0);
		if (!Number.isInteger(priority)) return "Priority must be a whole number.";
		const recipientRole = normalizeCode(distributionDraft.recipientRole);
		const duplicate = distributions.find((item) => item.commissionRuleId === distributionDraft.commissionRuleId && normalizeCode(item.recipientRole) === recipientRole && item.id !== editingDistributionId);
		if (duplicate) return duplicate.isActive ? `This rule already has an active ${recipientRole} distribution. Edit that row instead.` : `This rule already has an inactive ${recipientRole} distribution. Reactivate or edit that row instead of creating a duplicate.`;
		const proposedHealth = proposedDistributionHealth(distributionDraft, editingDistributionId);
		if (distributionDraft.isActive && proposedHealth.tone === "danger") return `This active setup would over-allocate the commission pool. ${proposedHealth.detail}`;
		return null;
	}
	async function submitDistribution(event) {
		event.preventDefault();
		const required = editingDistributionId ? UI_PERMISSION.COMMISSION_DISTRIBUTION_UPDATE : UI_PERMISSION.COMMISSION_DISTRIBUTION_CREATE;
		if (editingDistributionId ? !canUpdateDistribution : !canCreateDistribution) return setError(`Permission ${required} is required.`);
		setError("");
		setNotice("");
		const validationError = validateDistributionDraft();
		if (validationError) return setError(validationError);
		const common = {
			recipientRole: normalizeCode(distributionDraft.recipientRole),
			distributionType: distributionDraft.distributionType,
			distributionValue: Number(distributionDraft.distributionValue),
			priority: Number(distributionDraft.priority || 0),
			isActive: distributionDraft.isActive
		};
		setSaving(true);
		try {
			if (editingDistributionId) {
				const body = common;
				await adminApi.commissionDistributions.update(editingDistributionId, body);
				setNotice("Commission distribution updated successfully.");
			} else {
				const body = {
					commissionRuleId: distributionDraft.commissionRuleId,
					...common
				};
				await adminApi.commissionDistributions.create(body);
				setNotice("Commission distribution created successfully.");
			}
			setSelectedRuleId(distributionDraft.commissionRuleId);
			setDistributionEditorOpen(false);
			setEditingDistributionId(null);
			setDistributionDraft(emptyDistributionDraft);
			await loadDistributions();
		} catch (caught) {
			setError(caught instanceof AdminApiError ? caught.message : "Unable to save the commission distribution.");
		} finally {
			setSaving(false);
		}
	}
	async function confirmDistributionStatusChange() {
		if (!pendingDistributionStatus) return;
		const { distribution, nextActive } = pendingDistributionStatus;
		if (nextActive ? !canUpdateDistribution : !canDeactivateDistribution) return setError(`Permission ${nextActive ? UI_PERMISSION.COMMISSION_DISTRIBUTION_UPDATE : UI_PERMISSION.COMMISSION_DISTRIBUTION_DEACTIVATE} is required.`);
		setError("");
		setNotice("");
		if (nextActive) {
			const nextHealth = proposedDistributionHealth(draftFromDistribution({
				...distribution,
				isActive: true
			}), distribution.id);
			if (nextHealth.tone === "danger") {
				setPendingDistributionStatus(null);
				setError(`Cannot reactivate this share yet. ${nextHealth.detail}`);
				return;
			}
		}
		setSaving(true);
		try {
			if (nextActive) {
				await adminApi.commissionDistributions.update(distribution.id, { isActive: true });
				setNotice("Commission distribution reactivated successfully.");
			} else {
				await adminApi.commissionDistributions.deactivate(distribution.id);
				setNotice("Commission distribution deactivated. Historical allocation records remain safe.");
			}
			setDistributions((current) => current.map((item) => item.id === distribution.id ? {
				...item,
				isActive: nextActive
			} : item));
			setPendingDistributionStatus(null);
		} catch (caught) {
			setError(caught instanceof AdminApiError ? caught.message : "Unable to change the distribution status.");
		} finally {
			setSaving(false);
		}
	}
	if (!canManage) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "commissions",
		eyebrow: "Pricing",
		title: "Commission setup",
		description: "Global commission rules and distributions are restricted to Admin and Super Admin accounts.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-3 rounded-xl bg-amber-50 p-4 text-amber-900",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {
				size: 20,
				className: "mt-0.5 shrink-0"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm font-black",
				children: [
					"Global commission editing is not available for ",
					actor?.role || "this role",
					"."
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs leading-5",
				children: "Distributor and Master Distributor pages should show their scoped commission data. They should not change the global rule engine."
			})] })]
		}) })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "commissions",
		eyebrow: "Pricing",
		title: "Commission setup",
		description: "Manage the commission pool rules and the hierarchy shares paid from each matched rule.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "inline-flex rounded-xl border border-border bg-white p-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => switchView("RULES"),
						className: `rounded-lg px-4 py-2.5 text-xs font-extrabold transition ${view === "RULES" ? "bg-secondary text-white" : "text-muted-foreground hover:bg-muted"}`,
						children: "Commission Rules"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => switchView("DISTRIBUTIONS"),
						className: `rounded-lg px-4 py-2.5 text-xs font-extrabold transition ${view === "DISTRIBUTIONS" ? "bg-secondary text-white" : "text-muted-foreground hover:bg-muted"}`,
						children: "Distribution Setup"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin/commissions/hierarchy",
						className: "rounded-lg px-4 py-2.5 text-xs font-extrabold text-muted-foreground transition hover:bg-muted",
						children: "Hierarchy"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommissionCalculator, {}),
			view === "RULES" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid gap-4 md:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
						icon: SlidersHorizontal,
						label: "Total rules",
						value: rules.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
						icon: CircleCheck,
						label: "Active",
						value: activeRuleCount,
						tone: "good"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
						icon: X,
						label: "Inactive",
						value: inactiveRuleCount
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
						icon: Percent,
						label: "Services",
						value: serviceCount
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid gap-4 md:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
						icon: UsersRound,
						label: "Recipients",
						value: activeSelectedDistributions.length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricSummary, {
						icon: Percent,
						label: "Percentage shares",
						value: `${selectedTotals.percentage.toFixed(2)}%`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricSummary, {
						icon: IndianRupee,
						label: "Fixed shares",
						value: money(selectedTotals.fixed)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricSummary, {
						icon: Layers,
						label: "Rule status",
						value: selectedRule?.isActive ? "ACTIVE" : selectedRule ? "INACTIVE" : "—"
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-5 rounded-xl bg-red-50 p-4 text-sm font-semibold text-red-700",
				children: error
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 rounded-xl bg-emerald-50 p-4 text-sm font-semibold text-emerald-700",
				children: notice
			}),
			view === "RULES" && pendingRuleStatus && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
				className: "mt-5 border-amber-200 bg-amber-50/60",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-black text-secondary",
						children: [pendingRuleStatus.nextActive ? "Reactivate" : "Deactivate", " this commission rule?"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs leading-5 text-muted-foreground",
						children: [
							pendingRuleStatus.rule.serviceType,
							" · ",
							pendingRuleStatus.rule.role,
							" ·",
							" ",
							pendingRuleStatus.rule.operator || "Any operator",
							" ·",
							" ",
							money(pendingRuleStatus.rule.minAmount),
							" to ",
							money(pendingRuleStatus.rule.maxAmount)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs leading-5 text-amber-900",
						children: pendingRuleStatus.nextActive ? "The rule will become eligible for matching again." : "The backend soft-deactivates the rule. Old commission records keep their rule link."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: saving,
							onClick: () => setPendingRuleStatus(null),
							className: "rounded-xl border border-border bg-white px-4 py-2 text-xs font-extrabold text-secondary disabled:opacity-50",
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: saving,
							onClick: () => void confirmRuleStatusChange(),
							className: "inline-flex items-center gap-2 rounded-xl bg-secondary px-4 py-2 text-xs font-extrabold text-white disabled:opacity-50",
							children: [saving && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
								size: 14,
								className: "animate-spin"
							}), " Confirm"]
						})]
					})
				]
			}),
			view === "DISTRIBUTIONS" && pendingDistributionStatus && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
				className: "mt-5 border-amber-200 bg-amber-50/60",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-black text-secondary",
						children: [pendingDistributionStatus.nextActive ? "Reactivate" : "Deactivate", " this distribution?"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs leading-5 text-muted-foreground",
						children: [
							pendingDistributionStatus.distribution.recipientRole,
							" ·",
							" ",
							distributionRate(pendingDistributionStatus.distribution),
							" · Priority",
							" ",
							pendingDistributionStatus.distribution.priority
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs leading-5 text-amber-900",
						children: pendingDistributionStatus.nextActive ? "The recipient role will be used again when this rule matches and an eligible hierarchy user exists." : "The DELETE endpoint is a soft deactivation. Old distribution transactions keep their historical link."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: saving,
							onClick: () => setPendingDistributionStatus(null),
							className: "rounded-xl border border-border bg-white px-4 py-2 text-xs font-extrabold text-secondary disabled:opacity-50",
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: saving,
							onClick: () => void confirmDistributionStatusChange(),
							className: "inline-flex items-center gap-2 rounded-xl bg-secondary px-4 py-2 text-xs font-extrabold text-white disabled:opacity-50",
							children: [saving && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
								size: 14,
								className: "animate-spin"
							}), " Confirm"]
						})]
					})
				]
			}),
			view === "RULES" && ruleEditorOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-extrabold uppercase tracking-wider text-primary",
							children: editingRuleId ? "Edit rule" : "New rule"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-xl font-black",
							children: editingRuleId ? "Update commission rule" : "Create commission rule"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Service, operator and role codes are normalized to uppercase by the backend."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							setRuleEditorOpen(false);
							setEditingRuleId(null);
							setRuleDraft(emptyRuleDraft);
						},
						"aria-label": "Close rule editor",
						className: "grid h-9 w-9 place-items-center rounded-xl border border-border text-muted-foreground hover:bg-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 16 })
					})]
				}), loadingRule ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex items-center gap-2 rounded-xl bg-muted p-4 text-sm font-semibold text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
						size: 16,
						className: "animate-spin"
					}), " Loading latest rule…"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submitRule,
					className: "mt-6 space-y-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 md:grid-cols-2 xl:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
									label: "Service type *",
									hint: "Example: AEPS or ADD_MONEY",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: ruleDraft.serviceType,
										onChange: (event) => setRuleDraft((current) => ({
											...current,
											serviceType: event.target.value
										})),
										placeholder: "AEPS",
										list: "commission-services",
										className: inputClass
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("datalist", {
										id: "commission-services",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "AEPS" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "ADD_MONEY" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "AEPS_CASH_DEPOSIT_COMPENSATION" })
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
									label: "Operator / provider",
									hint: "Optional. Leave blank for any operator.",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: ruleDraft.operator,
										onChange: (event) => setRuleDraft((current) => ({
											...current,
											operator: event.target.value
										})),
										placeholder: "VIMOPAY",
										list: "commission-operators",
										className: inputClass
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("datalist", {
										id: "commission-operators",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "VIMOPAY" })
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Source role *",
									hint: "Role whose transaction matches this rule.",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: ruleDraft.role,
										onChange: (event) => setRuleDraft((current) => ({
											...current,
											role: event.target.value
										})),
										className: inputClass,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "RETAILER",
												children: "RETAILER"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "DISTRIBUTOR",
												children: "DISTRIBUTOR"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "MASTER_DISTRIBUTOR",
												children: "MASTER_DISTRIBUTOR"
											})
										]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Priority",
									hint: "Higher priority is evaluated first among matching rules.",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										step: "1",
										value: ruleDraft.priority,
										onChange: (event) => setRuleDraft((current) => ({
											...current,
											priority: event.target.value
										})),
										className: inputClass
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-4 md:grid-cols-2 xl:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Commission type *",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
										value: ruleDraft.commissionType,
										onChange: (event) => setRuleDraft((current) => ({
											...current,
											commissionType: event.target.value
										})),
										className: inputClass,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "FIXED",
											children: "FIXED"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "PERCENTAGE",
											children: "PERCENTAGE"
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: ruleDraft.commissionType === "PERCENTAGE" ? "Commission % *" : "Commission amount *",
									hint: ruleDraft.commissionType === "PERCENTAGE" ? "0 to 100" : "Amount cannot be negative.",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground",
											children: ruleDraft.commissionType === "PERCENTAGE" ? "%" : "₹"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											min: "0",
											max: ruleDraft.commissionType === "PERCENTAGE" ? "100" : void 0,
											step: "0.0001",
											value: ruleDraft.commissionValue,
											onChange: (event) => setRuleDraft((current) => ({
												...current,
												commissionValue: event.target.value
											})),
											className: `${inputClass} pl-9`
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Minimum transaction amount",
									hint: "Blank means no lower limit.",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndianRupee, {
											size: 14,
											className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											min: "0",
											step: "0.01",
											value: ruleDraft.minAmount,
											onChange: (event) => setRuleDraft((current) => ({
												...current,
												minAmount: event.target.value
											})),
											className: `${inputClass} pl-9`
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Maximum transaction amount",
									hint: "Blank means no upper limit.",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndianRupee, {
											size: 14,
											className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											min: "0",
											step: "0.01",
											value: ruleDraft.maxAmount,
											onChange: (event) => setRuleDraft((current) => ({
												...current,
												maxAmount: event.target.value
											})),
											className: `${inputClass} pl-9`
										})]
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex w-fit cursor-pointer items-center gap-3 rounded-xl border border-border px-4 py-3 text-sm font-bold text-secondary",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: ruleDraft.isActive,
								onChange: (event) => setRuleDraft((current) => ({
									...current,
									isActive: event.target.checked
								})),
								className: "h-4 w-4 accent-primary"
							}), "Rule is active"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-3 border-t border-border pt-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => {
									setRuleEditorOpen(false);
									setEditingRuleId(null);
									setRuleDraft(emptyRuleDraft);
								},
								className: "rounded-xl border border-border px-5 py-3 text-xs font-extrabold text-secondary hover:bg-muted",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								disabled: saving,
								className: "inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-3 text-xs font-extrabold text-white disabled:opacity-60",
								children: [saving ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
									size: 15,
									className: "animate-spin"
								}) : editingRuleId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { size: 15 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), saving ? "Saving…" : editingRuleId ? "Save changes" : "Create rule"]
							})]
						})
					]
				})]
			}),
			view === "RULES" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-black",
						children: "Configured rules"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [
							visibleRules.length,
							" of ",
							rules.length,
							" rule",
							rules.length === 1 ? "" : "s",
							" shown."
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 sm:flex-row sm:flex-wrap",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex min-w-0 items-center gap-2 rounded-xl border border-border px-3 py-2.5 sm:w-72",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
									size: 15,
									className: "text-muted-foreground"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: ruleQuery,
									onChange: (event) => setRuleQuery(event.target.value),
									placeholder: "Search service, operator, role…",
									className: "min-w-0 flex-1 bg-transparent text-xs outline-none"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								value: ruleStatus,
								onChange: (value) => setRuleStatus(value),
								options: [
									"ALL",
									"ACTIVE",
									"INACTIVE"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								value: ruleRoleFilter,
								onChange: setRuleRoleFilter,
								options: [
									"ALL",
									"RETAILER",
									"DISTRIBUTOR",
									"MASTER_DISTRIBUTOR"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => void refreshAll(),
								disabled: rulesLoading || distributionsLoading,
								className: "inline-flex items-center justify-center gap-2 rounded-xl border border-border px-4 py-2.5 text-xs font-extrabold text-secondary hover:bg-muted disabled:opacity-50",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
										size: 14,
										className: rulesLoading || distributionsLoading ? "animate-spin" : ""
									}),
									" ",
									"Refresh"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: startCreateRule,
								disabled: !canCreateRule,
								className: "inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-xs font-extrabold text-white",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " New rule"]
							})
						]
					})]
				}), rulesLoading && !rules.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingBox, { text: "Loading commission rules…" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 overflow-x-auto rounded-xl border border-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "min-w-[1050px] w-full text-left text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-muted/70 text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Service / operator"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Role"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Slab"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Commission pool"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Distributions"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Priority"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "px-4 py-3 text-right",
									children: "Actions"
								})
							] })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
							className: "divide-y divide-border",
							children: [visibleRules.map((rule) => {
								const linked = distributions.filter((item) => item.commissionRuleId === rule.id);
								const activeLinked = linked.filter((item) => item.isActive).length;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "bg-white align-top hover:bg-muted/25",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-4",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "font-black text-secondary",
													children: rule.serviceType
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-1 text-[11px] text-muted-foreground",
													children: rule.operator || "Any operator"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-2 max-w-48 truncate font-mono text-[9px] text-muted-foreground",
													title: rule.id,
													children: rule.id
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-4 font-extrabold text-secondary",
											children: rule.role
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "font-bold text-secondary",
												children: [
													money(rule.minAmount),
													" → ",
													money(rule.maxAmount)
												]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-black text-secondary",
												children: ruleRate(rule)
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-[10px] text-muted-foreground",
												children: rule.commissionType
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
												type: "button",
												onClick: () => {
													setSelectedRuleId(rule.id);
													switchView("DISTRIBUTIONS");
												},
												className: "rounded-lg border border-border px-3 py-2 font-extrabold text-secondary hover:bg-muted",
												children: [
													activeLinked,
													" active / ",
													linked.length,
													" total"
												]
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-4 font-black text-secondary",
											children: rule.priority
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { active: rule.isActive })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-end gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													disabled: !canUpdateRule,
													onClick: () => void startEditRule(rule),
													className: "inline-flex items-center gap-1 rounded-lg border border-border px-3 py-2 font-extrabold text-secondary hover:bg-muted",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { size: 12 }), " Edit"]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													disabled: rule.isActive ? !canDeactivateRule : !canUpdateRule,
													onClick: () => setPendingRuleStatus({
														rule,
														nextActive: !rule.isActive
													}),
													className: `rounded-lg border px-3 py-2 font-extrabold ${rule.isActive ? "border-amber-200 text-amber-800 hover:bg-amber-50" : "border-emerald-200 text-emerald-700 hover:bg-emerald-50"}`,
													children: rule.isActive ? "Deactivate" : "Reactivate"
												})]
											})
										})
									]
								}, rule.id);
							}), !visibleRules.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 8,
								className: "px-4 py-12 text-center text-sm text-muted-foreground",
								children: "No commission rules match the current filters."
							}) })]
						})]
					})
				})]
			}),
			view === "DISTRIBUTIONS" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
					className: "mt-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-extrabold uppercase tracking-wider text-primary",
										children: "Distribution rule"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-1 text-xl font-black",
										children: "Choose the commission pool to split"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-muted-foreground",
										children: "Each recipient role can have one distribution configuration per commission rule."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-4 max-w-3xl",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Commission rule *",
											hint: "Distributions run only when this rule wins the commission match.",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
												value: selectedRuleId,
												onChange: (event) => {
													setSelectedRuleId(event.target.value);
													setDistributionEditorOpen(false);
													setPendingDistributionStatus(null);
													setError("");
													setNotice("");
												},
												className: inputClass,
												disabled: !rules.length,
												children: [!rules.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
													value: "",
													children: "No commission rules found"
												}), rules.map((rule) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
													value: rule.id,
													children: [
														rule.isActive ? "ACTIVE" : "INACTIVE",
														" · ",
														rule.serviceType,
														" ·",
														" ",
														rule.operator || "ANY",
														" · ",
														rule.role,
														" · ",
														ruleRate(rule),
														" ·",
														" ",
														money(rule.minAmount),
														" to ",
														money(rule.maxAmount)
													]
												}, rule.id))]
											})
										})
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => void refreshAll(),
									disabled: rulesLoading || distributionsLoading,
									className: "inline-flex items-center justify-center gap-2 rounded-xl border border-border px-4 py-2.5 text-xs font-extrabold text-secondary hover:bg-muted disabled:opacity-50",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
											size: 14,
											className: rulesLoading || distributionsLoading ? "animate-spin" : ""
										}),
										" ",
										"Refresh"
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: startCreateDistribution,
									disabled: !canCreateDistribution || !selectedRuleId,
									className: "inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-xs font-extrabold text-white disabled:cursor-not-allowed disabled:opacity-50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), " New distribution"]
								})]
							})]
						}),
						selectedRule && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoBox, {
									label: "Service / provider",
									value: `${selectedRule.serviceType} · ${selectedRule.operator || "Any operator"}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoBox, {
									label: "Source role",
									value: selectedRule.role
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoBox, {
									label: "Commission pool",
									value: `${ruleRate(selectedRule)} · ${selectedRule.commissionType}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoBox, {
									label: "Transaction slab",
									value: `${money(selectedRule.minAmount)} → ${money(selectedRule.maxAmount)}`
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 rounded-xl bg-muted/60 p-4 text-xs leading-5 text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
									className: "text-secondary",
									children: "How this backend flow works:"
								}),
								" PERCENTAGE distributions are calculated from the matched ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "commission pool" }),
								", not from the gross transaction. Active distributions run by priority. If the matching hierarchy user is missing or not eligible, that share is skipped and stays in the source merchant's remainder. The backend also rejects any real execution that would allocate more than the full commission pool."
							]
						})
					]
				}),
				selectedRule && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `mt-5 rounded-xl border p-4 ${health.tone === "good" ? "border-emerald-200 bg-emerald-50" : health.tone === "danger" ? "border-red-200 bg-red-50" : "border-amber-200 bg-amber-50"}`,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `text-sm font-black ${health.tone === "good" ? "text-emerald-800" : health.tone === "danger" ? "text-red-800" : "text-amber-900"}`,
							children: health.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `mt-1 text-xs leading-5 ${health.tone === "good" ? "text-emerald-700" : health.tone === "danger" ? "text-red-700" : "text-amber-800"}`,
							children: health.detail
						}),
						!selectedRule.isActive && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs font-bold text-amber-900",
							children: "This commission rule is INACTIVE, so its distributions will not run until the rule is reactivated."
						})
					]
				}),
				distributionEditorOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
					className: "mt-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-extrabold uppercase tracking-wider text-primary",
								children: editingDistributionId ? "Edit distribution" : "New distribution"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 text-xl font-black",
								children: editingDistributionId ? "Update hierarchy share" : "Add a hierarchy share"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted-foreground",
								children: "A new distribution needs a valid ACTIVE recipient role. Reactivating an existing distribution also requires the role to be active."
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setDistributionEditorOpen(false);
								setEditingDistributionId(null);
								setDistributionDraft(emptyDistributionDraft);
							},
							"aria-label": "Close distribution editor",
							className: "grid h-9 w-9 place-items-center rounded-xl border border-border text-muted-foreground hover:bg-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 16 })
						})]
					}), loadingDistribution ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 flex items-center gap-2 rounded-xl bg-muted p-4 text-sm font-semibold text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
							size: 16,
							className: "animate-spin"
						}), " Loading latest distribution…"]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: submitDistribution,
						className: "mt-6 space-y-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 md:grid-cols-2 xl:grid-cols-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "xl:col-span-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
											label: "Commission rule *",
											hint: editingDistributionId ? "A distribution cannot be moved to another rule. Create a new one instead." : "Choose the commission pool that this share belongs to.",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
												value: distributionDraft.commissionRuleId,
												onChange: (event) => setDistributionDraft((current) => ({
													...current,
													commissionRuleId: event.target.value
												})),
												className: inputClass,
												disabled: Boolean(editingDistributionId),
												children: rules.map((rule) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
													value: rule.id,
													children: [
														rule.serviceType,
														" · ",
														rule.operator || "ANY",
														" · ",
														rule.role,
														" ·",
														" ",
														ruleRate(rule)
													]
												}, rule.id))
											})
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
										label: "Recipient role *",
										hint: "One config per recipient role per rule. Custom active role codes are supported.",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											value: distributionDraft.recipientRole,
											onChange: (event) => setDistributionDraft((current) => ({
												...current,
												recipientRole: event.target.value
											})),
											placeholder: "DISTRIBUTOR",
											list: "commission-recipient-roles",
											className: inputClass
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("datalist", {
											id: "commission-recipient-roles",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "RETAILER" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "DISTRIBUTOR" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { value: "MASTER_DISTRIBUTOR" })
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Distribution type *",
										hint: "PERCENTAGE means percentage of commission pool.",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
											value: distributionDraft.distributionType,
											onChange: (event) => setDistributionDraft((current) => ({
												...current,
												distributionType: event.target.value
											})),
											className: inputClass,
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "FIXED",
												children: "FIXED"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
												value: "PERCENTAGE",
												children: "PERCENTAGE"
											})]
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Priority",
										hint: "Higher priority is processed first.",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											step: "1",
											value: distributionDraft.priority,
											onChange: (event) => setDistributionDraft((current) => ({
												...current,
												priority: event.target.value
											})),
											className: inputClass
										})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid gap-4 md:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: distributionDraft.distributionType === "PERCENTAGE" ? "Share of commission pool *" : "Fixed share from commission pool *",
									hint: distributionDraft.distributionType === "PERCENTAGE" ? "0 to 100. This is not a percentage of the gross transaction." : "The backend will reject execution if total active shares become larger than the actual commission pool.",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground",
											children: distributionDraft.distributionType === "PERCENTAGE" ? "%" : "₹"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "number",
											min: "0",
											max: distributionDraft.distributionType === "PERCENTAGE" ? "100" : void 0,
											step: "0.0001",
											value: distributionDraft.distributionValue,
											onChange: (event) => setDistributionDraft((current) => ({
												...current,
												distributionValue: event.target.value
											})),
											className: `${inputClass} pl-9`
										})]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-end",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex w-full cursor-pointer items-center gap-3 rounded-xl border border-border px-4 py-3 text-sm font-bold text-secondary",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "checkbox",
											checked: distributionDraft.isActive,
											onChange: (event) => setDistributionDraft((current) => ({
												...current,
												isActive: event.target.checked
											})),
											className: "h-4 w-4 accent-primary"
										}), "Distribution is active"]
									})
								})]
							}),
							distributionDraft.commissionRuleId && distributionDraft.distributionValue.trim() && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DraftHealth, { health: proposedDistributionHealth(distributionDraft, editingDistributionId) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-3 border-t border-border pt-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setDistributionEditorOpen(false);
										setEditingDistributionId(null);
										setDistributionDraft(emptyDistributionDraft);
									},
									className: "rounded-xl border border-border px-5 py-3 text-xs font-extrabold text-secondary hover:bg-muted",
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									disabled: saving,
									className: "inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-3 text-xs font-extrabold text-white disabled:opacity-60",
									children: [saving ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
										size: 15,
										className: "animate-spin"
									}) : editingDistributionId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { size: 15 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 15 }), saving ? "Saving…" : editingDistributionId ? "Save distribution" : "Create distribution"]
								})]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
					className: "mt-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-black",
							children: "Recipient distributions"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: selectedRule ? `${visibleDistributions.length} of ${selectedRuleDistributions.length} distribution${selectedRuleDistributions.length === 1 ? "" : "s"} shown for the selected rule.` : "Select a commission rule first."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2 sm:flex-row sm:flex-wrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex min-w-0 items-center gap-2 rounded-xl border border-border px-3 py-2.5 sm:w-72",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
									size: 15,
									className: "text-muted-foreground"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: distributionQuery,
									onChange: (event) => setDistributionQuery(event.target.value),
									placeholder: "Search recipient role…",
									className: "min-w-0 flex-1 bg-transparent text-xs outline-none"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
								value: distributionStatus,
								onChange: (value) => setDistributionStatus(value),
								options: [
									"ALL",
									"ACTIVE",
									"INACTIVE"
								]
							})]
						})]
					}), distributionsLoading && !distributions.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoadingBox, { text: "Loading commission distributions…" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 overflow-x-auto rounded-xl border border-border",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "min-w-[900px] w-full text-left text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "bg-muted/70 text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3",
										children: "Recipient role"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3",
										children: "Share"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3",
										children: "Priority"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3",
										children: "Status"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3",
										children: "Updated"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3",
										children: "Distribution ID"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-4 py-3 text-right",
										children: "Actions"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", {
								className: "divide-y divide-border",
								children: [visibleDistributions.map((distribution) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "bg-white align-top hover:bg-muted/25",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-black text-secondary",
												children: distribution.recipientRole
											}), selectedRule?.role === distribution.recipientRole && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-[10px] font-bold text-amber-700",
												children: "Same as source role"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "px-4 py-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-black text-secondary",
												children: distributionRate(distribution)
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-[10px] text-muted-foreground",
												children: distribution.distributionType
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-4 font-black text-secondary",
											children: distribution.priority
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { active: distribution.isActive })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-4 text-[11px] text-muted-foreground",
											children: dateTime(distribution.updatedAt || distribution.createdAt)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "max-w-52 truncate font-mono text-[9px] text-muted-foreground",
												title: distribution.id,
												children: distribution.id
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-4 py-4",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-end gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													disabled: !canUpdateDistribution,
													onClick: () => void startEditDistribution(distribution),
													className: "inline-flex items-center gap-1 rounded-lg border border-border px-3 py-2 font-extrabold text-secondary hover:bg-muted",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { size: 12 }), " Edit"]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													disabled: distribution.isActive ? !canDeactivateDistribution : !canUpdateDistribution,
													onClick: () => setPendingDistributionStatus({
														distribution,
														nextActive: !distribution.isActive
													}),
													className: `rounded-lg border px-3 py-2 font-extrabold ${distribution.isActive ? "border-amber-200 text-amber-800 hover:bg-amber-50" : "border-emerald-200 text-emerald-700 hover:bg-emerald-50"}`,
													children: distribution.isActive ? "Deactivate" : "Reactivate"
												})]
											})
										})
									]
								}, distribution.id)), !visibleDistributions.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									colSpan: 7,
									className: "px-4 py-12 text-center text-sm text-muted-foreground",
									children: selectedRule ? "No distributions match the current filters for this rule." : "Create a commission rule before adding distributions."
								}) })]
							})]
						})
					})]
				})
			] })
		]
	});
}
function Summary({ icon: Icon, label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `grid h-10 w-10 place-items-center rounded-xl ${tone === "good" ? "bg-emerald-50 text-emerald-700" : "bg-primary/10 text-primary"}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 18 })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-2xl font-black text-secondary",
			children: value
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-4 text-xs font-extrabold uppercase tracking-wider text-muted-foreground",
		children: label
	})] });
}
function MetricSummary({ icon: Icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 18 })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "truncate text-lg font-black text-secondary",
			title: value,
			children: value
		})]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-4 text-xs font-extrabold uppercase tracking-wider text-muted-foreground",
		children: label
	})] });
}
function Field({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs font-extrabold text-secondary",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2",
				children
			}),
			hint && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1.5 block text-[10px] leading-4 text-muted-foreground",
				children: hint
			})
		]
	});
}
function Select({ value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
			value,
			onChange: (event) => onChange(event.target.value),
			className: "appearance-none rounded-xl border border-border bg-white py-2.5 pl-3 pr-8 text-xs font-extrabold text-secondary outline-none",
			children: options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: option,
				children: option
			}, option))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {
			size: 13,
			className: "pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground"
		})]
	});
}
function StatusPill({ active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-full px-2 py-1 text-[9px] font-extrabold ${active ? "bg-emerald-50 text-emerald-700" : "bg-muted text-muted-foreground"}`,
		children: active ? "ACTIVE" : "INACTIVE"
	});
}
function LoadingBox({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-6 flex items-center justify-center gap-2 rounded-xl border border-dashed border-border py-12 text-sm font-semibold text-muted-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
				size: 17,
				className: "animate-spin"
			}),
			" ",
			text
		]
	});
}
function InfoBox({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-white p-3.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1.5 text-xs font-black text-secondary",
			children: value
		})]
	});
}
function DraftHealth({ health }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-xl border p-4 ${health.tone === "good" ? "border-emerald-200 bg-emerald-50" : health.tone === "danger" ? "border-red-200 bg-red-50" : "border-amber-200 bg-amber-50"}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: `text-xs font-black ${health.tone === "good" ? "text-emerald-800" : health.tone === "danger" ? "text-red-800" : "text-amber-900"}`,
			children: health.title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: `mt-1 text-[11px] leading-5 ${health.tone === "good" ? "text-emerald-700" : health.tone === "danger" ? "text-red-700" : "text-amber-800"}`,
			children: health.detail
		})]
	});
}
//#endregion
export { Commissions as component };
