import { a as DistributorDashboard } from "./router-CdmUoS7N.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/distributor-DeHfLpX3.js
var SplitComponent = DistributorDashboard;
//#endregion
export { SplitComponent as component };
