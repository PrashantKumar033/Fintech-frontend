import { r as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { D as ShieldCheck, R as RefreshCw, ft as LoaderCircle, r as X, v as ToggleLeft, vn as Activity } from "../_libs/lucide-react.mjs";
import { a as useEffectiveAccess, r as UI_PERMISSION } from "./section-tabs-INzhwNW3.mjs";
import { n as adminApi, s as getAdminActor } from "./admin-api-BMvykyWe.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-BjKbHz5M.mjs";
import { r as SuperAdminAepsTwoFactor } from "./super-admin-aeps-two-factor-DELSlSQn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-settings-CA4UIdY-.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ApiSettings() {
	const { can } = useEffectiveAccess();
	const privileged = getAdminActor()?.kind === "SUPER_ADMIN";
	const canView = privileged || can(UI_PERMISSION.AEPS_PROVIDER_STATUS_VIEW, ["SUPER_ADMIN", "ADMIN"]);
	const canUpdate = privileged || can(UI_PERMISSION.AEPS_PROVIDER_SERVICE_STATUS_UPDATE, ["SUPER_ADMIN", "ADMIN"]);
	const [data, setData] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [notice, setNotice] = (0, import_react.useState)("");
	const [target, setTarget] = (0, import_react.useState)(null);
	const [reason, setReason] = (0, import_react.useState)("");
	const [workspace, setWorkspace] = (0, import_react.useState)("providers");
	const load = (0, import_react.useCallback)(async () => {
		if (!canView) return;
		setLoading(true);
		setError("");
		try {
			setData(await adminApi.operations.aepsProviderStatus());
		} catch (value) {
			setError(messageOf(value));
		} finally {
			setLoading(false);
		}
	}, [canView]);
	(0, import_react.useEffect)(() => void load(), [load]);
	async function confirmToggle() {
		if (!target || !canUpdate) return;
		const nextEnabled = !target.service.isEnabled;
		if (!nextEnabled && !reason.trim()) {
			setError("Enter a reason before disabling an AEPS operation.");
			return;
		}
		setBusy(true);
		setError("");
		setNotice("");
		try {
			await adminApi.operations.updateAepsProviderServiceStatus(target.provider, target.service.operation, nextEnabled, reason);
			setNotice(`${target.service.name} ${nextEnabled ? "enabled" : "disabled"}.`);
			setTarget(null);
			setReason("");
			await load();
		} catch (value) {
			setError(messageOf(value));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "api",
		eyebrow: "Integrations",
		title: "AEPS platform controls",
		description: "Manage provider availability, daily 2FA fees and financial reconciliation from live backend contracts.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-5 flex w-fit max-w-full gap-1 overflow-x-auto rounded-2xl border border-border bg-white p-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setWorkspace("providers"),
				className: `cursor-pointer whitespace-nowrap rounded-xl px-5 py-3 text-sm font-black ${workspace === "providers" ? "bg-secondary text-white" : "text-secondary"}`,
				children: "Provider services"
			}), privileged ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => setWorkspace("twoFactor"),
				className: `cursor-pointer whitespace-nowrap rounded-xl px-5 py-3 text-sm font-black ${workspace === "twoFactor" ? "bg-secondary text-white" : "text-secondary"}`,
				children: "2FA fees & reconciliation"
			}) : null]
		}), workspace === "twoFactor" && privileged ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuperAdminAepsTwoFactor, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banner, {
				tone: "error",
				children: error
			}) : null,
			notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Banner, {
				tone: "success",
				children: notice
			}) : null,
			!canView ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "py-10 text-center text-sm text-muted-foreground",
				children: [
					"Permission ",
					UI_PERMISSION.AEPS_PROVIDER_STATUS_VIEW,
					" is required."
				]
			}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-4 flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => void load(),
					disabled: loading,
					className: "flex cursor-pointer items-center gap-2 rounded-xl border border-border bg-white px-4 py-2 text-sm font-bold disabled:cursor-not-allowed",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
						size: 16,
						className: loading ? "animate-spin" : ""
					}), " Refresh"]
				})
			}), loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPanel, {
				className: "grid min-h-64 place-items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin text-primary" })
			}) : data?.providers.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-5",
				children: data.providers.map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { size: 20 })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-black",
							children: provider.provider
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								provider.enabledServices,
								" of ",
								provider.totalServices,
								" operations enabled"
							]
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProviderStatus, { value: provider.status })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-3",
					children: provider.services.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-xl border border-border p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-black text-primary",
									children: service.operation
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-black",
									children: service.name
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `rounded-full px-2 py-1 text-[10px] font-black ${service.isEnabled ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`,
									children: service.isEnabled ? "ENABLED" : "DISABLED"
								})]
							}),
							service.reason ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 rounded-lg bg-red-50 p-2 text-xs text-red-700",
								children: service.reason
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-[11px] text-muted-foreground",
								children: service.updatedAt ? `Last updated ${new Date(service.updatedAt).toLocaleString("en-IN")}` : "Using default enabled configuration"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								disabled: !canUpdate,
								onClick: () => {
									setTarget({
										provider: provider.provider,
										service
									});
									setReason("");
									setError("");
								},
								className: "mt-4 flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border border-border py-2 text-sm font-bold disabled:cursor-not-allowed disabled:opacity-50",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleLeft, { size: 17 }),
									" ",
									service.isEnabled ? "Disable" : "Enable"
								]
							})
						]
					}, service.operation))
				})] }, provider.provider))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "py-10 text-center text-sm text-muted-foreground",
				children: "No AEPS provider configuration was returned."
			}) })] }),
			target ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-[110] grid place-items-center bg-secondary/60 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md rounded-2xl bg-white p-6 shadow-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-black uppercase text-primary",
								children: "Provider control"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "text-xl font-black",
								children: [
									target.service.isEnabled ? "Disable" : "Enable",
									" ",
									target.service.name
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setTarget(null),
								className: "cursor-pointer rounded-xl border border-border p-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
							})]
						}),
						!target.service.isEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 rounded-xl bg-emerald-50 p-3 text-sm text-emerald-700",
							children: "This operation will become available immediately."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-4 block text-xs font-black uppercase",
							children: ["Disable reason", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: reason,
								onChange: (event) => setReason(event.target.value),
								rows: 4,
								placeholder: "Explain why this operation is being disabled",
								className: "mt-2 w-full rounded-xl border border-border p-3 text-sm font-normal normal-case outline-none focus:border-primary"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => void confirmToggle(),
							disabled: busy,
							className: "mt-5 flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-bold text-white disabled:cursor-not-allowed disabled:opacity-50",
							children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
								className: "animate-spin",
								size: 18
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 18 }), "Confirm change"]
						})
					]
				})
			}) : null
		] })]
	});
}
function ProviderStatus({ value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-full px-3 py-1 text-xs font-black ${value === "ENABLED" ? "bg-emerald-50 text-emerald-700" : value === "DISABLED" ? "bg-red-50 text-red-700" : "bg-amber-50 text-amber-700"}`,
		children: value.replaceAll("_", " ")
	});
}
function Banner({ tone, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: `mb-4 rounded-xl p-3 text-sm font-semibold ${tone === "error" ? "bg-red-50 text-red-700" : "bg-emerald-50 text-emerald-700"}`,
		children
	});
}
function messageOf(value) {
	return value instanceof Error ? value.message : "The provider request could not be completed.";
}
//#endregion
export { ApiSettings as component };
