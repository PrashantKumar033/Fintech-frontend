import { r as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { xt as IndianRupee } from "../_libs/lucide-react.mjs";
import { a as asArray } from "./admin-api-BMvykyWe.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-BjKbHz5M.mjs";
import { t as distributorApi } from "./distributor-api-Cdddeabb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/commission-lQ9Ta-93.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CommissionPage() {
	const [rows, setRows] = (0, import_react.useState)([]), [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		distributorApi.commissions().then((value) => setRows(asArray(value))).catch((e) => setError(e instanceof Error ? e.message : "Commission data unavailable."));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "commissions",
		eyebrow: "Earnings",
		title: "Commission history",
		description: "Configured commission distributions available from the current backend.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IndianRupee, { className: "text-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-xs font-bold uppercase text-muted-foreground",
							children: "Distribution records"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-3xl font-black",
							children: rows.length
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-black",
						children: "Daily earnings"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted-foreground",
						children: "Dedicated earning-ledger API pending."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-black",
						children: "Monthly earnings"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted-foreground",
						children: "Dedicated earning-ledger API pending."
					})] })
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 rounded-xl bg-amber-50 p-4 text-sm text-amber-800",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
				className: "mt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-black",
					children: "Commission records"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Transaction-wise earned, pending and settled history requires a protected commission-ledger endpoint. No demo earnings are shown."
				})]
			})
		]
	});
}
//#endregion
export { CommissionPage as component };
