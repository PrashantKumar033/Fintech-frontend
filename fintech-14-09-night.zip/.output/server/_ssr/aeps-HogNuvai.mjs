import { t as AepsWorkspace } from "./aeps-workspace-zdUc5Afl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/aeps-HogNuvai.js
var SplitComponent = AepsWorkspace;
//#endregion
export { SplitComponent as component };
