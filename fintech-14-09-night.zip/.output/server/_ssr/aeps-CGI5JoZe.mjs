import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { A as Settings2, jt as FingerprintPattern, s as Users } from "../_libs/lucide-react.mjs";
import { s as getAdminActor } from "./admin-api-BMvykyWe.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-BjKbHz5M.mjs";
import { t as AepsWorkspace } from "./aeps-workspace-zdUc5Afl.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/aeps-CGI5JoZe.js
var import_jsx_runtime = require_jsx_runtime();
function AdminAepsPage() {
	if (getAdminActor()?.kind === "IDENTITY_ADMIN") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AepsWorkspace, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "aeps",
		eyebrow: "Assisted banking",
		title: "AEPS management",
		description: "Monitor merchants and transactions, reconcile provider activity and manage VimoPay service availability.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 md:grid-cols-3",
			children: [
				{
					title: "AEPS merchants",
					description: "Review merchant onboarding and update or synchronize merchant status.",
					to: "/admin/merchants/list",
					icon: Users
				},
				{
					title: "AEPS transactions",
					description: "Monitor provider transactions, reconciliation and reversals.",
					to: "/admin/transactions",
					icon: FingerprintPattern
				},
				{
					title: "Provider controls",
					description: "Check VimoPay availability and control individual AEPS operations.",
					to: "/admin/api-settings",
					icon: Settings2
				}
			].map(({ title, description, to, icon: Icon }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to,
				className: "block cursor-pointer",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
					className: "h-full transition hover:border-primary hover:shadow-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "text-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 text-lg font-black",
							children: title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-6 text-muted-foreground",
							children: description
						})
					]
				})
			}, title))
		})
	});
}
//#endregion
export { AdminAepsPage as component };
