import { r as __toESM } from "../_runtime.mjs";
import { d as logo_default, n as authApi, t as ApiError } from "./role-hierarchy-3Eppvhsl.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as ShieldCheck, Rt as Eye, _n as ArrowLeft, ft as LoaderCircle, hn as ArrowRight, l as User, tt as MessageSquare, yt as KeyRound, zt as EyeOff } from "../_libs/lucide-react.mjs";
import { n as SiteNav, t as SiteFooter } from "./site-footer-v-UByBCe.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/forgot-password-DbAS2FE8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var labels = [
	"Verify",
	"OTP",
	"New Password",
	"Done"
];
var inputClass = "w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-secondary outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20";
function ForgotPasswordPage() {
	const navigate = useNavigate();
	const [step, setStep] = (0, import_react.useState)(1);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [draftId, setDraftId] = (0, import_react.useState)("");
	const [loginId, setLoginId] = (0, import_react.useState)("");
	const [panNumber, setPanNumber] = (0, import_react.useState)("");
	const [aadharLast4, setAadharLast4] = (0, import_react.useState)("");
	const [otp, setOtp] = (0, import_react.useState)("");
	const [shownOtp, setShownOtp] = (0, import_react.useState)("");
	const [newPassword, setNewPassword] = (0, import_react.useState)("");
	const [confirmPassword, setConfirmPassword] = (0, import_react.useState)("");
	const [showNewPassword, setShowNewPassword] = (0, import_react.useState)(false);
	const [showConfirmPassword, setShowConfirmPassword] = (0, import_react.useState)(false);
	async function run(fn) {
		setError("");
		setLoading(true);
		try {
			await fn();
		} catch (e) {
			setError(e instanceof ApiError ? e.message : "Kuch galat ho gaya, dobara try karo.");
		} finally {
			setLoading(false);
		}
	}
	function handleSubmit(e) {
		e.preventDefault();
		if (step === 1) {
			run(async () => {
				const r = await authApi.forgotPasswordVerifyUser({
					loginId: loginId.trim(),
					panNumber: panNumber.trim().toUpperCase(),
					aadharLast4: aadharLast4.trim()
				});
				setDraftId(r.draftId);
				setShownOtp(r.otp || "");
				setStep(2);
			});
			return;
		}
		if (step === 2) {
			run(async () => {
				await authApi.forgotPasswordVerifyOtp(draftId, otp.trim());
				setStep(3);
			});
			return;
		}
		if (step === 3) {
			run(async () => {
				if (newPassword !== confirmPassword) throw new ApiError("Password match nahi kar raha.", 0);
				await authApi.forgotPasswordReset({
					draftId,
					newPassword,
					confirmPassword
				});
				setStep(4);
			});
			return;
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen overflow-x-clip bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"aria-hidden": true,
				className: "pointer-events-none fixed inset-0 -z-10 bg-grid opacity-30"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto flex min-h-[calc(100vh-5rem)] max-w-7xl items-center px-6 py-16",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid w-full gap-12 lg:grid-cols-[1.1fr_1fr] lg:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "hidden lg:block",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "inline-flex items-center gap-2 rounded-full border border-accent/30 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-accent",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 13 }), " Account recovery"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "mt-6 font-display text-5xl font-extrabold leading-tight text-secondary",
								children: [
									"Reset your",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-gradient-warm",
										children: "UMOBIPAY password"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 max-w-sm text-foreground/70",
								children: "Temporary password bhool gaye? Koi baat nahi — apni details verify karke naya password 3 aasan steps mein set kar sakte ho."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-8 space-y-3",
								children: [
									{
										icon: User,
										text: "Login ID, PAN aur Aadhaar se identity verify karo"
									},
									{
										icon: MessageSquare,
										text: "Registered phone number pe OTP verify karo"
									},
									{
										icon: KeyRound,
										text: "Apna naya password set karo"
									}
								].map(({ icon: Icon, text }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-3 rounded-2xl border border-border bg-card px-5 py-3.5 shadow-soft",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-mint",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 16 })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-medium text-secondary",
										children: text
									})]
								}, text))
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "gradient-border rounded-[2rem] bg-card p-8 shadow-elegant sm:p-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: logo_default,
								alt: "UMOBIPAY logo",
								className: "h-10 w-auto"
							}),
							step < 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6 flex gap-1",
								children: labels.slice(0, 3).map((l, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-1.5 rounded-full ${i + 1 <= step ? "bg-primary" : "bg-muted"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: `mt-1 text-xs font-semibold ${i + 1 === step ? "text-primary" : "text-muted-foreground"}`,
										children: l
									})]
								}, l))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: handleSubmit,
								className: "mt-6 space-y-4",
								children: [
									step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-xl font-extrabold text-secondary",
											children: "Verify your identity"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted-foreground",
											children: "Login ID, PAN aur Aadhaar ke last 4 digit se identity confirm karo."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "text-xs font-semibold uppercase tracking-widest text-muted-foreground",
											children: "Login ID"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											className: inputClass,
											value: loginId,
											onChange: (e) => setLoginId(e.target.value),
											required: true
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "text-xs font-semibold uppercase tracking-widest text-muted-foreground",
											children: "PAN Number"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											className: inputClass,
											value: panNumber,
											onChange: (e) => setPanNumber(e.target.value),
											maxLength: 10,
											required: true
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "text-xs font-semibold uppercase tracking-widest text-muted-foreground",
											children: "Aadhaar — Last 4 digits"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											className: inputClass,
											value: aadharLast4,
											onChange: (e) => setAadharLast4(e.target.value),
											maxLength: 4,
											required: true
										})] })
									] }),
									step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-xl font-extrabold text-secondary",
											children: "Enter OTP"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted-foreground",
											children: "Aapke registered phone number pe OTP bheja gaya hai."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											className: inputClass,
											value: otp,
											onChange: (e) => setOtp(e.target.value),
											maxLength: 6,
											required: true
										}),
										shownOtp && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "rounded-xl bg-primary/10 px-4 py-3 text-sm text-primary",
											children: ["Development OTP: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: shownOtp })]
										})
									] }),
									step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-xl font-extrabold text-secondary",
											children: "Set new password"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "text-xs font-semibold uppercase tracking-widest text-muted-foreground",
											children: "New Password"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: showNewPassword ? "text" : "password",
												className: `${inputClass} pr-11`,
												value: newPassword,
												onChange: (e) => setNewPassword(e.target.value),
												minLength: 8,
												required: true
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setShowNewPassword(!showNewPassword),
												"aria-label": "Toggle password visibility",
												className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground",
												children: showNewPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { size: 17 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 17 })
											})]
										})] }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "text-xs font-semibold uppercase tracking-widest text-muted-foreground",
											children: "Confirm New Password"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "relative",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: showConfirmPassword ? "text" : "password",
												className: `${inputClass} pr-11`,
												value: confirmPassword,
												onChange: (e) => setConfirmPassword(e.target.value),
												required: true
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setShowConfirmPassword(!showConfirmPassword),
												"aria-label": "Toggle password visibility",
												className: "absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground",
												children: showConfirmPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { size: 17 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 17 })
											})]
										})] })
									] }),
									step === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col items-center gap-3 py-6 text-center",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {
												className: "text-primary",
												size: 40
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "text-xl font-extrabold text-secondary",
												children: "Password reset ho gaya!"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm text-muted-foreground",
												children: "Ab naye password se login karo."
											})
										]
									}),
									error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "rounded-xl bg-destructive/10 px-4 py-3 text-sm font-medium text-destructive",
										children: error
									}),
									step < 4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-3 pt-2",
										children: [step > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											type: "button",
											onClick: () => setStep(step - 1),
											className: "grid h-11 w-11 shrink-0 place-items-center rounded-full border border-border",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { size: 17 })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "submit",
											disabled: loading,
											className: "flex flex-1 items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground disabled:opacity-60",
											children: [loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
												className: "animate-spin",
												size: 16
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { size: 16 }), "Continue"]
										})]
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => navigate({ to: "/login" }),
										className: "w-full rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground",
										children: "Go to Login"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-6 text-center text-sm text-muted-foreground",
								children: [
									"Yaad aa gaya password?",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/login",
										className: "font-semibold text-primary",
										children: "Sign in"
									})
								]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { ForgotPasswordPage as component };
