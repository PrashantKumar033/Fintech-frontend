import { r as __toESM } from "../_runtime.mjs";
import { b as syncMyPermissions, i as clearSession, n as authApi, s as getEffectiveAccess, t as ApiError } from "./role-hierarchy-3Eppvhsl.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { D as ShieldCheck, Gt as Clock3, J as PhoneCall, M as Search, R as RefreshCw, _ as Trash2, _t as Laptop, ct as MailCheck, dn as BadgeCheck, ft as LoaderCircle, i as Wifi, lt as LogOut, ot as MapPin, r as X, w as Smartphone, yt as KeyRound } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-verification-center-08e6xS8_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function dateTime(value) {
	if (!value) return "Not available";
	const parsed = new Date(value);
	if (Number.isNaN(parsed.getTime())) return "Not available";
	return new Intl.DateTimeFormat("en-IN", {
		dateStyle: "medium",
		timeStyle: "short"
	}).format(parsed);
}
function userAgentLabel(userAgent) {
	if (!userAgent) return "Unknown browser";
	return `${userAgent.includes("Edg/") ? "Microsoft Edge" : userAgent.includes("Chrome/") ? "Chrome" : userAgent.includes("Firefox/") ? "Firefox" : userAgent.includes("Safari/") && !userAgent.includes("Chrome/") ? "Safari" : "Browser"} on ${userAgent.includes("Windows") ? "Windows" : userAgent.includes("Android") ? "Android" : /iPhone|iPad|iPod/.test(userAgent) ? "iOS" : userAgent.includes("Mac OS") ? "macOS" : userAgent.includes("Linux") ? "Linux" : "Unknown OS"}`;
}
function sessionName(session) {
	return session.device?.trim() || userAgentLabel(session.userAgent);
}
function DeviceIcon({ session }) {
	const agent = `${session.device || ""} ${session.userAgent || ""}`.toLowerCase();
	if (agent.includes("android") || agent.includes("iphone") || agent.includes("mobile")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { size: 19 });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Laptop, { size: 19 });
}
function IdentitySecurityCenter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 2xl:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActiveSessionsPanel, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EffectiveAccessPanel, {})]
	});
}
function ActiveSessionsPanel() {
	const [sessions, setSessions] = (0, import_react.useState)([]);
	const [selected, setSelected] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [notice, setNotice] = (0, import_react.useState)("");
	const [pending, setPending] = (0, import_react.useState)(null);
	const current = sessions.find((item) => item.isCurrent);
	const otherCount = sessions.filter((item) => !item.isCurrent).length;
	async function load() {
		setLoading(true);
		setError("");
		try {
			setSessions(await authApi.getSessions());
		} catch (caught) {
			setError(caught instanceof ApiError ? caught.message : "Unable to load active sessions.");
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	async function viewDetails(session) {
		setError("");
		try {
			setSelected(await authApi.getSessionDetails(session.id));
		} catch (caught) {
			setError(caught instanceof ApiError ? caught.message : "Unable to load session details.");
		}
	}
	async function confirmAction() {
		if (!pending) return;
		setBusy(true);
		setError("");
		setNotice("");
		try {
			if (pending.kind === "session") {
				if ((await authApi.revokeSession(pending.session.id)).isCurrent) {
					clearSession();
					window.location.assign("/login");
					return;
				}
				setNotice("Session revoked successfully.");
			} else if (pending.kind === "others") {
				const result = await authApi.revokeOtherSessions();
				setNotice(`${result.revokedCount} other session${result.revokedCount === 1 ? "" : "s"} revoked.`);
			} else {
				await authApi.revokeAllSessions();
				clearSession();
				window.location.assign("/login");
				return;
			}
			setPending(null);
			setSelected(null);
			await load();
		} catch (caught) {
			setError(caught instanceof ApiError ? caught.message : "Unable to revoke the selected session.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-border bg-white p-5 shadow-sm sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-extrabold uppercase tracking-[.16em] text-primary",
						children: "Account security"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-xl font-black text-secondary",
						children: "Active sessions & devices"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-6 text-muted-foreground",
						children: "Review signed-in devices and revoke any session you do not recognize."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => void load(),
					disabled: loading || busy,
					className: "inline-flex items-center justify-center gap-2 rounded-xl border border-border px-3 py-2.5 text-xs font-extrabold text-secondary hover:bg-muted disabled:opacity-50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
						size: 15,
						className: loading ? "animate-spin" : ""
					}), " Refresh"]
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-4 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700",
				children: error
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 rounded-xl bg-emerald-50 p-3 text-sm font-semibold text-emerald-700",
				children: notice
			}),
			pending && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `mt-4 rounded-xl border p-4 ${pending.kind === "all" || pending.kind === "session" && pending.session.isCurrent ? "border-red-200 bg-red-50" : "border-amber-200 bg-amber-50"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-black text-secondary",
						children: pending.kind === "session" ? pending.session.isCurrent ? "Sign out this current device?" : "Revoke this device session?" : pending.kind === "others" ? "Sign out all other devices?" : "Sign out every device?"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs leading-5 text-muted-foreground",
						children: pending.kind === "session" && pending.session.isCurrent ? "Your current session will be revoked and you will return to the login screen." : pending.kind === "all" ? "Every active session, including this one, will be revoked. You will need to sign in again." : "The selected session tokens will stop working after the backend revokes them."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: busy,
							onClick: () => setPending(null),
							className: "rounded-xl border border-border bg-white px-4 py-2 text-xs font-extrabold text-secondary disabled:opacity-50",
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: busy,
							onClick: () => void confirmAction(),
							className: "inline-flex items-center gap-2 rounded-xl bg-red-600 px-4 py-2 text-xs font-extrabold text-white disabled:opacity-50",
							children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
								size: 14,
								className: "animate-spin"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { size: 14 }), "Confirm revoke"]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-muted/40 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold uppercase tracking-wider text-muted-foreground",
						children: "Active sessions"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-2xl font-black text-secondary",
						children: loading ? "…" : sessions.length
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border bg-muted/40 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-bold uppercase tracking-wider text-muted-foreground",
						children: "Other devices"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-2xl font-black text-secondary",
						children: loading ? "…" : otherCount
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 space-y-3",
				children: loading && !sessions.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-center gap-2 rounded-xl border border-dashed border-border py-10 text-sm font-semibold text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
						size: 17,
						className: "animate-spin"
					}), " Loading secure sessions…"]
				}) : sessions.length ? sessions.map((session) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `rounded-xl border p-4 ${session.isCurrent ? "border-emerald-200 bg-emerald-50/50" : "border-border bg-white"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `grid h-10 w-10 shrink-0 place-items-center rounded-xl ${session.isCurrent ? "bg-emerald-100 text-emerald-700" : "bg-muted text-secondary"}`,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeviceIcon, { session })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm font-black text-secondary",
										children: sessionName(session)
									}), session.isCurrent && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-extrabold text-emerald-700",
										children: "CURRENT"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: ["Last used ", dateTime(session.lastUsedAt || session.createdAt)]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 flex flex-wrap gap-x-4 gap-y-2 text-[11px] font-semibold text-muted-foreground",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wifi, { size: 12 }),
											" ",
											session.ipAddress || "IP unavailable"
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "inline-flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { size: 12 }),
											" Expires ",
											dateTime(session.expiresAt)
										]
									})]
								})
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex flex-wrap gap-2 border-t border-border/70 pt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => void viewDetails(session),
							className: "rounded-lg border border-border px-3 py-2 text-[11px] font-extrabold text-secondary hover:bg-muted",
							children: "View details"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setPending({
								kind: "session",
								session
							}),
							className: "inline-flex items-center gap-1.5 rounded-lg border border-red-200 px-3 py-2 text-[11px] font-extrabold text-red-700 hover:bg-red-50",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 13 }),
								" ",
								session.isCurrent ? "Sign out this device" : "Revoke"
							]
						})]
					})]
				}, session.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-xl border border-dashed border-border py-10 text-center text-sm text-muted-foreground",
					children: "No active sessions were returned by the backend."
				})
			}),
			selected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 rounded-xl border border-primary/20 bg-primary/5 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-extrabold uppercase tracking-wider text-primary",
							children: "Session details"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm font-black text-secondary",
							children: sessionName(selected)
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setSelected(null),
							"aria-label": "Close session details",
							className: "grid h-8 w-8 place-items-center rounded-lg border border-border bg-white text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 14 })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 grid gap-3 text-xs sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
								label: "Session ID",
								value: selected.id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
								label: "IP address",
								value: selected.ipAddress || "Not available"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
								label: "Created",
								value: dateTime(selected.createdAt)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
								label: "Last used",
								value: dateTime(selected.lastUsedAt)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
								label: "Expires",
								value: dateTime(selected.expiresAt)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, {
								label: "Location",
								value: selected.latitude != null && selected.longitude != null ? `Captured (${selected.locationAccuracy ? `±${Math.round(selected.locationAccuracy)}m` : "accuracy unavailable"})` : "Not captured",
								icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { size: 12 })
							})
						]
					}),
					selected.userAgent && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 break-all rounded-lg bg-white p-3 text-[11px] leading-5 text-muted-foreground",
						children: selected.userAgent
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex flex-wrap gap-2 border-t border-border pt-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: !otherCount || busy || loading,
					onClick: () => setPending({ kind: "others" }),
					className: "rounded-xl border border-border px-4 py-2.5 text-xs font-extrabold text-secondary hover:bg-muted disabled:cursor-not-allowed disabled:opacity-40",
					children: "Sign out other devices"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: !sessions.length || busy || loading,
					onClick: () => setPending({ kind: "all" }),
					className: "rounded-xl border border-red-200 px-4 py-2.5 text-xs font-extrabold text-red-700 hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-40",
					children: "Sign out all devices"
				})]
			}),
			current && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-[11px] leading-5 text-muted-foreground",
				children: ["Current session: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-bold text-secondary",
					children: current.id
				})]
			})
		]
	});
}
function EffectiveAccessPanel() {
	const [access, setAccess] = (0, import_react.useState)(() => getEffectiveAccess());
	const [loading, setLoading] = (0, import_react.useState)(!access);
	const [error, setError] = (0, import_react.useState)("");
	const [query, setQuery] = (0, import_react.useState)("");
	async function load() {
		setLoading(true);
		setError("");
		try {
			setAccess(await syncMyPermissions());
		} catch (caught) {
			setError(caught instanceof ApiError ? caught.message : "Unable to load your effective permissions.");
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		load();
	}, []);
	const permissions = (0, import_react.useMemo)(() => {
		const normalized = query.trim().toLowerCase();
		if (!access || !normalized) return access?.permissions || [];
		return access.permissions.filter((item) => `${item.code} ${item.name} ${item.description || ""}`.toLowerCase().includes(normalized));
	}, [access, query]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-border bg-white p-5 shadow-sm sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-extrabold uppercase tracking-[.16em] text-primary",
						children: "Effective authorization"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-xl font-black text-secondary",
						children: "Your packages & permissions"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm leading-6 text-muted-foreground",
						children: [
							"This data comes from ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
								className: "rounded bg-muted px-1.5 py-0.5 text-xs",
								children: "/auth/me/permissions"
							}),
							" for the signed-in identity."
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => void load(),
					disabled: loading,
					className: "inline-flex items-center justify-center gap-2 rounded-xl border border-border px-3 py-2.5 text-xs font-extrabold text-secondary hover:bg-muted disabled:opacity-50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
						size: 15,
						className: loading ? "animate-spin" : ""
					}), " Refresh access"]
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-4 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700",
				children: error
			}),
			loading && !access ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex items-center justify-center gap-2 rounded-xl border border-dashed border-border py-12 text-sm font-semibold text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
					size: 17,
					className: "animate-spin"
				}), " Resolving permissions…"]
			}) : access ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 grid gap-3 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Role",
							value: access.role?.name || "Unknown",
							ok: access.role?.isActive
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Packages",
							value: String(access.packages?.length || 0)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
							label: "Permissions",
							value: String(access.permissionCodes?.length || 0)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-extrabold uppercase tracking-wider text-muted-foreground",
						children: "Assigned packages"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 flex flex-wrap gap-2",
						children: access.packages?.length ? access.packages.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "rounded-full border border-primary/20 bg-primary/5 px-3 py-1.5 text-xs font-extrabold text-primary",
							children: [
								item.name,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-medium opacity-70",
									children: [
										"(",
										item.code,
										")"
									]
								})
							]
						}, item.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground",
							children: "No active package is currently assigned to this role."
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-extrabold uppercase tracking-wider text-muted-foreground",
							children: "Effective permissions"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 rounded-xl border border-border bg-white px-3 py-2 text-xs text-muted-foreground sm:w-64",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { size: 14 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: query,
								onChange: (event) => setQuery(event.target.value),
								placeholder: "Search permission",
								className: "min-w-0 flex-1 bg-transparent outline-none"
							})]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 max-h-[430px] space-y-2 overflow-y-auto pr-1",
						children: permissions.length ? permissions.map((permission) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-xl border border-border p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-emerald-50 text-emerald-700",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { size: 14 })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "break-all text-xs font-black text-secondary",
											children: permission.code
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-xs font-semibold text-muted-foreground",
											children: permission.name
										}),
										permission.description && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-[11px] leading-5 text-muted-foreground",
											children: permission.description
										})
									]
								})]
							})
						}, permission.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-xl border border-dashed border-border py-8 text-center text-xs text-muted-foreground",
							children: query ? "No permission matches your search." : "No active effective permissions were returned."
						})
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex gap-3 rounded-xl bg-emerald-50 p-4 text-xs leading-5 text-emerald-800",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, {
						size: 18,
						className: "mt-0.5 shrink-0"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Backend remains the final authority." }), " This frontend cache helps the UI understand your access, but protected backend routes must still enforce their own guards and permissions."] })]
				})
			] }) : null
		]
	});
}
function Stat({ label, value, ok }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-muted/40 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-1 flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-lg font-black text-secondary",
				children: value
			}), ok !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `rounded-full px-2 py-0.5 text-[9px] font-extrabold ${ok ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"}`,
				children: ok ? "ACTIVE" : "INACTIVE"
			})]
		})]
	});
}
function Detail({ label, value, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg bg-white p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dt", {
			className: "flex items-center gap-1 text-[10px] font-extrabold uppercase tracking-wider text-muted-foreground",
			children: [icon, label]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "mt-1 break-all font-bold text-secondary",
			children: value
		})]
	});
}
function ContactVerificationCenter({ identity }) {
	const [channel, setChannel] = (0, import_react.useState)("phone");
	const [destination, setDestination] = (0, import_react.useState)(identity.phoneNumber || "");
	const [otp, setOtp] = (0, import_react.useState)("");
	const [sent, setSent] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [message, setMessage] = (0, import_react.useState)(null);
	function switchChannel(next) {
		setChannel(next);
		setDestination(next === "phone" ? identity.phoneNumber || "" : identity.email || "");
		setOtp("");
		setSent(false);
		setMessage(null);
	}
	async function send(event) {
		event.preventDefault();
		setBusy(true);
		setMessage(null);
		try {
			const result = channel === "phone" ? await authApi.sendPhoneOtp(destination.trim()) : await authApi.sendEmailOtp(destination.trim());
			setSent(true);
			setMessage({
				ok: true,
				text: result.otp ? `${result.message} Development OTP: ${result.otp}` : result.message
			});
		} catch (error) {
			setMessage({
				ok: false,
				text: error instanceof ApiError ? error.message : "Unable to send OTP."
			});
		} finally {
			setBusy(false);
		}
	}
	async function verify() {
		setBusy(true);
		setMessage(null);
		try {
			const result = channel === "phone" ? await authApi.verifyPhoneOtp(destination.trim(), otp) : await authApi.verifyEmailOtp(destination.trim(), otp);
			setMessage({
				ok: true,
				text: result.message || `${channel === "phone" ? "Phone" : "Email"} verified successfully.`
			});
			setOtp("");
			setSent(false);
		} catch (error) {
			setMessage({
				ok: false,
				text: error instanceof ApiError ? error.message : "Unable to verify OTP."
			});
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-border bg-card p-5 shadow-soft sm:p-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 20 })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-extrabold text-secondary",
					children: "Contact OTP verification"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Send and verify a fresh OTP for the registered phone number or email address."
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5 flex rounded-xl bg-muted p-1",
				children: ["phone", "email"].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => switchChannel(item),
					className: `flex-1 rounded-lg py-2 text-sm font-bold capitalize ${channel === item ? "bg-white text-secondary shadow-sm" : "text-muted-foreground"}`,
					children: item
				}, item))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: send,
				className: "mt-5 grid gap-3 sm:grid-cols-[1fr_auto]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mb-1.5 block text-xs font-extrabold uppercase text-muted-foreground",
					children: channel === "phone" ? "Phone number" : "Email address"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 rounded-xl border border-border bg-white px-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground",
						children: channel === "phone" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneCall, { size: 16 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MailCheck, { size: 16 })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						required: true,
						type: channel === "phone" ? "tel" : "email",
						value: destination,
						onChange: (event) => setDestination(event.target.value),
						className: "min-w-0 flex-1 py-3 text-sm outline-none"
					})]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					disabled: busy,
					className: "self-end rounded-xl bg-primary px-5 py-3 text-sm font-extrabold text-white disabled:opacity-60",
					children: busy ? "Sending…" : sent ? "Resend OTP" : "Send OTP"
				})]
			}),
			sent && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid gap-3 sm:grid-cols-[1fr_auto]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					"aria-label": "OTP",
					value: otp,
					onChange: (event) => setOtp(event.target.value.replace(/\D/g, "").slice(0, 6)),
					inputMode: "numeric",
					placeholder: "Enter 6-digit OTP",
					className: "rounded-xl border border-border bg-white px-4 py-3 text-sm outline-none focus:border-primary"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy || otp.length !== 6,
					onClick: () => void verify(),
					className: "rounded-xl border border-primary px-5 py-3 text-sm font-extrabold text-primary disabled:opacity-40",
					children: "Verify OTP"
				})]
			}),
			message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "status",
				className: `mt-4 rounded-xl p-3 text-sm font-semibold ${message.ok ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`,
				children: message.text
			})
		]
	});
}
//#endregion
export { IdentitySecurityCenter as n, ContactVerificationCenter as t };
