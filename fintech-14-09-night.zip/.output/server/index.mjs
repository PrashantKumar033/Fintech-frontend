globalThis.__nitro_main__ = import.meta.url;
import { n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx+unenv.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/assets/about-CEOGhgT9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f34-hH6GGYka9otAPAXh+bwKMVY2UPo\"",
		"mtime": "2026-09-14T12:53:32.902Z",
		"size": 7988,
		"path": "../public/assets/about-CEOGhgT9.js"
	},
	"/assets/about-team-DwbCHxeD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"37-IthA4GHevoQlQvxSznY+8LuRhZk\"",
		"mtime": "2026-09-14T12:53:32.904Z",
		"size": 55,
		"path": "../public/assets/about-team-DwbCHxeD.js"
	},
	"/assets/account-setup-BjHRAVQx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4f-avDKUVMcmMIyKQETZlXQllszKWg\"",
		"mtime": "2026-09-14T12:53:32.918Z",
		"size": 79,
		"path": "../public/assets/account-setup-BjHRAVQx.js"
	},
	"/assets/account-setup-DEnutxeq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4f-avDKUVMcmMIyKQETZlXQllszKWg\"",
		"mtime": "2026-09-14T12:53:32.920Z",
		"size": 79,
		"path": "../public/assets/account-setup-DEnutxeq.js"
	},
	"/assets/account-setup-DFvyVdPn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4f-avDKUVMcmMIyKQETZlXQllszKWg\"",
		"mtime": "2026-09-14T12:53:32.921Z",
		"size": 79,
		"path": "../public/assets/account-setup-DFvyVdPn.js"
	},
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"23c-+gdLmXKV53M3ee0X2Fl3YIHyorY\"",
		"mtime": "2026-09-11T08:02:54.620Z",
		"size": 572,
		"path": "../public/favicon.svg"
	},
	"/assets/action-permission-notice-C-ZShizo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"299-UWuM2atERvQ2lD9+YH4kLDV+sFM\"",
		"mtime": "2026-09-14T12:53:32.936Z",
		"size": 665,
		"path": "../public/assets/action-permission-notice-C-ZShizo.js"
	},
	"/assets/account-setup-o639ESEk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1fa7-tQiPr6eBsv+aXsIT2jXwGN7L6Lk\"",
		"mtime": "2026-09-14T12:53:32.934Z",
		"size": 8103,
		"path": "../public/assets/account-setup-o639ESEk.js"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"ae-hLVBrSrDdpIw3Xl0dJPRkupPepQ\"",
		"mtime": "2026-07-29T05:26:37.436Z",
		"size": 174,
		"path": "../public/robots.txt"
	},
	"/assets/activity-BG6uB5b9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e8-SYADMK+yXceAwIovWTActY3V0Ck\"",
		"mtime": "2026-09-14T12:53:32.956Z",
		"size": 232,
		"path": "../public/assets/activity-BG6uB5b9.js"
	},
	"/assets/activity-CiC3tlYd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1037-DlIsQBFoDyiYN62Xft1TW957X5c\"",
		"mtime": "2026-09-14T12:53:32.968Z",
		"size": 4151,
		"path": "../public/assets/activity-CiC3tlYd.js"
	},
	"/assets/add-B85Lwhe6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4b-ezegHCR/T2L3VwqW2HyYmN3fhRc\"",
		"mtime": "2026-09-14T12:53:32.976Z",
		"size": 75,
		"path": "../public/assets/add-B85Lwhe6.js"
	},
	"/assets/add-BGXUmKC_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4b-ezegHCR/T2L3VwqW2HyYmN3fhRc\"",
		"mtime": "2026-09-14T12:53:32.983Z",
		"size": 75,
		"path": "../public/assets/add-BGXUmKC_.js"
	},
	"/assets/add-vNIgw5pw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4b-ezegHCR/T2L3VwqW2HyYmN3fhRc\"",
		"mtime": "2026-09-14T12:53:32.989Z",
		"size": 75,
		"path": "../public/assets/add-vNIgw5pw.js"
	},
	"/assets/admin-api-PLzwbARO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2b6b-cyZ3bpXpbEQMkaiU93eCV5s1aAM\"",
		"mtime": "2026-09-14T12:53:32.989Z",
		"size": 11115,
		"path": "../public/assets/admin-api-PLzwbARO.js"
	},
	"/assets/about-team-BRJ1zQsx.png": {
		"type": "image/png",
		"etag": "\"68178-kAigvuzDojcB1vLXvBRdHqlBq1Q\"",
		"mtime": "2026-09-14T12:53:35.044Z",
		"size": 426360,
		"path": "../public/assets/about-team-BRJ1zQsx.png"
	},
	"/assets/admin-feature-grid-B1Y2iFRf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4f2-lb7FYA/fLOq1z/jt3O3/KhUTdas\"",
		"mtime": "2026-09-14T12:53:33.002Z",
		"size": 1266,
		"path": "../public/assets/admin-feature-grid-B1Y2iFRf.js"
	},
	"/assets/admin-layout-CjKDu6I3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36d5-hQFthyQEjaqBrHscZvVohQ7ZEQI\"",
		"mtime": "2026-09-14T12:53:33.016Z",
		"size": 14037,
		"path": "../public/assets/admin-layout-CjKDu6I3.js"
	},
	"/assets/admin-profile-page-DzSFM_ot.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c1f-lQj+QdvNiCGPPaOYttMzFc0RDLs\"",
		"mtime": "2026-09-14T12:53:33.022Z",
		"size": 3103,
		"path": "../public/assets/admin-profile-page-DzSFM_ot.js"
	},
	"/assets/admin-settings-page-pdPVeYS7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2184-ap1/d9u5jjmNFrPPZBMhziuTKnc\"",
		"mtime": "2026-09-14T12:53:33.054Z",
		"size": 8580,
		"path": "../public/assets/admin-settings-page-pdPVeYS7.js"
	},
	"/assets/aeps-4L9nq9Ot.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"50-xPpUNo7IwtkoTpy61rNlcztIs6I\"",
		"mtime": "2026-09-14T12:53:33.059Z",
		"size": 80,
		"path": "../public/assets/aeps-4L9nq9Ot.js"
	},
	"/assets/aeps-Cbh-aqDn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"50-xPpUNo7IwtkoTpy61rNlcztIs6I\"",
		"mtime": "2026-09-14T12:53:33.152Z",
		"size": 80,
		"path": "../public/assets/aeps-Cbh-aqDn.js"
	},
	"/assets/aeps-CVho8LVV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"607-/LneS4QQAhytWf9vATiJ/H4SL7s\"",
		"mtime": "2026-09-14T12:53:33.150Z",
		"size": 1543,
		"path": "../public/assets/aeps-CVho8LVV.js"
	},
	"/assets/aeps-sthdYi5i.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"50-xPpUNo7IwtkoTpy61rNlcztIs6I\"",
		"mtime": "2026-09-14T12:53:33.192Z",
		"size": 80,
		"path": "../public/assets/aeps-sthdYi5i.js"
	},
	"/assets/aeps-workspace-CYbPiMUZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"9b65-t5r2pBlw8qa32kCLGcNLW7F2Twk\"",
		"mtime": "2026-09-14T12:53:33.200Z",
		"size": 39781,
		"path": "../public/assets/aeps-workspace-CYbPiMUZ.js"
	},
	"/assets/api-settings-CP2sT_oO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1db7-yiPN6wjICqkAsZGABcIlLbojQ08\"",
		"mtime": "2026-09-14T12:53:33.235Z",
		"size": 7607,
		"path": "../public/assets/api-settings-CP2sT_oO.js"
	},
	"/assets/arrow-right-DIOMHBQg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a3-OG/ZyFLbywq10/yfCl2kQRZR4EI\"",
		"mtime": "2026-09-14T12:53:33.257Z",
		"size": 163,
		"path": "../public/assets/arrow-right-DIOMHBQg.js"
	},
	"/assets/arrow-left-EURBdOAR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a3-Q57ZB+riD0Qn28fWjHWvxKnPHFg\"",
		"mtime": "2026-09-14T12:53:33.238Z",
		"size": 163,
		"path": "../public/assets/arrow-left-EURBdOAR.js"
	},
	"/assets/badge-check-CO4P0cYM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13a-RFjngEzpo1dXW60GE+ghxkq/olg\"",
		"mtime": "2026-09-14T12:53:33.403Z",
		"size": 314,
		"path": "../public/assets/badge-check-CO4P0cYM.js"
	},
	"/assets/arrow-right-left-j40-1V7u.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f6-gYsuiUbgPQuAr0/DXcc16SOirv8\"",
		"mtime": "2026-09-14T12:53:33.263Z",
		"size": 246,
		"path": "../public/assets/arrow-right-left-j40-1V7u.js"
	},
	"/assets/audit-detail-dialog-DafViTI-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e76-ZhcQIYdfb5oWuZrKAVlJjpEkRYs\"",
		"mtime": "2026-09-14T12:53:33.399Z",
		"size": 3702,
		"path": "../public/assets/audit-detail-dialog-DafViTI-.js"
	},
	"/assets/arrow-up-right-DntXdoRl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-ofDc0mD0XOgBjLxDoX3zn8zNwKE\"",
		"mtime": "2026-09-14T12:53:33.287Z",
		"size": 165,
		"path": "../public/assets/arrow-up-right-DntXdoRl.js"
	},
	"/assets/balance-enquiry-CWmj9FTu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"142-8Jub283sGpIGVNKKEVql6wBIpIs\"",
		"mtime": "2026-09-14T12:53:33.404Z",
		"size": 322,
		"path": "../public/assets/balance-enquiry-CWmj9FTu.js"
	},
	"/assets/bank-B3Co5IcX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"343a-4rh2bdr00ATabJ0M7Cfo/Sl6r/o\"",
		"mtime": "2026-09-14T12:53:33.440Z",
		"size": 13370,
		"path": "../public/assets/bank-B3Co5IcX.js"
	},
	"/assets/bank-B5I1uYM_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"534-rMf+JpFOll/V+FYZbXMIYCZilSk\"",
		"mtime": "2026-09-14T12:53:33.463Z",
		"size": 1332,
		"path": "../public/assets/bank-B5I1uYM_.js"
	},
	"/assets/bank-C-TALfbl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b4-4xxGhLRu2EXx1IkA4f0jRMvCDEg\"",
		"mtime": "2026-09-14T12:53:33.465Z",
		"size": 180,
		"path": "../public/assets/bank-C-TALfbl.js"
	},
	"/assets/bank-Cw81rFnA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b4-4xxGhLRu2EXx1IkA4f0jRMvCDEg\"",
		"mtime": "2026-09-14T12:53:33.502Z",
		"size": 180,
		"path": "../public/assets/bank-Cw81rFnA.js"
	},
	"/assets/bank-Ckzd-gIa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b4-4xxGhLRu2EXx1IkA4f0jRMvCDEg\"",
		"mtime": "2026-09-14T12:53:33.476Z",
		"size": 180,
		"path": "../public/assets/bank-Ckzd-gIa.js"
	},
	"/assets/banking-BpVz5oQL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3e20-KuNFsK1gnreko7dhpFkLpV3Dw08\"",
		"mtime": "2026-09-14T12:53:33.504Z",
		"size": 15904,
		"path": "../public/assets/banking-BpVz5oQL.js"
	},
	"/assets/banknote-8ucSb4IQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f3-yjfxCrN+3H+jLfbVIhesbuhCcZw\"",
		"mtime": "2026-09-14T12:53:33.514Z",
		"size": 243,
		"path": "../public/assets/banknote-8ucSb4IQ.js"
	},
	"/assets/building-2-B60lMiOH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17d-06hkeiwRiBSinKMr7T4+pYL3k3o\"",
		"mtime": "2026-09-14T12:53:33.518Z",
		"size": 381,
		"path": "../public/assets/building-2-B60lMiOH.js"
	},
	"/assets/business-page-DKg6V5tc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5569-Q23ZbgqYtIx6b2q0O2gGDi4aCqM\"",
		"mtime": "2026-09-14T12:53:33.518Z",
		"size": 21865,
		"path": "../public/assets/business-page-DKg6V5tc.js"
	},
	"/assets/circle-check-Ri-EdMSx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b0-+ueTCZD0+QGxCS9DNjvtq+YfSo8\"",
		"mtime": "2026-09-14T12:53:33.540Z",
		"size": 176,
		"path": "../public/assets/circle-check-Ri-EdMSx.js"
	},
	"/assets/cash-withdrawal-DmFiP7RD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"142-jAbkK+u62NLwcWX9ZlvygDP/ZSo\"",
		"mtime": "2026-09-14T12:53:33.540Z",
		"size": 322,
		"path": "../public/assets/cash-withdrawal-DmFiP7RD.js"
	},
	"/assets/clock-3-BY_mV_q5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a7-3b5bvqRYuaqu4/fW4wNAXg9/0Tg\"",
		"mtime": "2026-09-14T12:53:33.563Z",
		"size": 167,
		"path": "../public/assets/clock-3-BY_mV_q5.js"
	},
	"/assets/commission-BA-zXpBq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"743-o49Uszn3G5PrDlGinzGGr3rsa7Y\"",
		"mtime": "2026-09-14T12:53:33.565Z",
		"size": 1859,
		"path": "../public/assets/commission-BA-zXpBq.js"
	},
	"/assets/commissions-CuzUe-IM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"580-kJUDmWedRqPMiyF4E1lxi8wE0nc\"",
		"mtime": "2026-09-14T12:53:33.580Z",
		"size": 1408,
		"path": "../public/assets/commissions-CuzUe-IM.js"
	},
	"/assets/commission-vtkHNdHt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6cd-APXN/7yzFkCW1GnM9wE2U1wDKls\"",
		"mtime": "2026-09-14T12:53:33.576Z",
		"size": 1741,
		"path": "../public/assets/commission-vtkHNdHt.js"
	},
	"/assets/commissions-r0Xvu9bf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ba6f-RUJcr7coDvCxUJBjt0zbepL8gCY\"",
		"mtime": "2026-09-14T12:53:33.600Z",
		"size": 47727,
		"path": "../public/assets/commissions-r0Xvu9bf.js"
	},
	"/assets/contact-B-IJW9Tt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a810-O8FePkEmNvRLtf3CxaVl3wIdENg\"",
		"mtime": "2026-09-14T12:53:33.602Z",
		"size": 43024,
		"path": "../public/assets/contact-B-IJW9Tt.js"
	},
	"/assets/contact-verification-center-YS-L9Avh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"50ff-ltNxrG8Hr6M+kAWoP3PCW83+xWo\"",
		"mtime": "2026-09-14T12:53:33.615Z",
		"size": 20735,
		"path": "../public/assets/contact-verification-center-YS-L9Avh.js"
	},
	"/assets/credit-card-mnJY4ttf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cd-HwIVzeKn6j2BXfJq17cd1SH206w\"",
		"mtime": "2026-09-14T12:53:33.627Z",
		"size": 205,
		"path": "../public/assets/credit-card-mnJY4ttf.js"
	},
	"/assets/dashboard-ByXwHwVw.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1296-kShQGCrE/gbi0vf7R3eKrTNmq9w\"",
		"mtime": "2026-09-14T12:53:33.630Z",
		"size": 4758,
		"path": "../public/assets/dashboard-ByXwHwVw.js"
	},
	"/assets/contact-support-D_4WeYmN.png": {
		"type": "image/png",
		"etag": "\"5a28c-TZT9uwmZSKAQdU2viuM/v16Dmd8\"",
		"mtime": "2026-09-14T12:53:35.048Z",
		"size": 369292,
		"path": "../public/assets/contact-support-D_4WeYmN.png"
	},
	"/assets/dashboard-CHT1MbvC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d74-4FxP7D5+VAtX7MQ6AZu2apFA2VQ\"",
		"mtime": "2026-09-14T12:53:33.651Z",
		"size": 3444,
		"path": "../public/assets/dashboard-CHT1MbvC.js"
	},
	"/assets/dashboard-NLZ77cvL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2333-98yheKZf2k8yISU+bLbmkLIlEPo\"",
		"mtime": "2026-09-14T12:53:33.653Z",
		"size": 9011,
		"path": "../public/assets/dashboard-NLZ77cvL.js"
	},
	"/assets/distributor-api-l68PhcDW.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17f-KrwkzwpiNzkYRvIbHYMyQe+e49g\"",
		"mtime": "2026-09-14T12:53:33.654Z",
		"size": 383,
		"path": "../public/assets/distributor-api-l68PhcDW.js"
	},
	"/assets/distributor-CsC330xV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4b-McCelcFgw4626fuLL9jKkCYB71c\"",
		"mtime": "2026-09-14T12:53:33.654Z",
		"size": 75,
		"path": "../public/assets/distributor-CsC330xV.js"
	},
	"/assets/distributors-CIT7QHDU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7fd-BAYyPLqrAWHApdKGUyIKh+S+9Yc\"",
		"mtime": "2026-09-14T12:53:33.654Z",
		"size": 2045,
		"path": "../public/assets/distributors-CIT7QHDU.js"
	},
	"/assets/eye-BWpUro50.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fe-/oY45D/CXioq60xLV/awroqhznM\"",
		"mtime": "2026-09-14T12:53:33.665Z",
		"size": 254,
		"path": "../public/assets/eye-BWpUro50.js"
	},
	"/assets/eye-off-Q3psqXMi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ac-XuQTHdUkCR0TH8ftQk19Tf5fj18\"",
		"mtime": "2026-09-14T12:53:33.667Z",
		"size": 428,
		"path": "../public/assets/eye-off-Q3psqXMi.js"
	},
	"/assets/file-check-corner-CcuLjC_j.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"139-p2S9nCYhwXANuBFKjiezCYmPsx0\"",
		"mtime": "2026-09-14T12:53:33.679Z",
		"size": 313,
		"path": "../public/assets/file-check-corner-CcuLjC_j.js"
	},
	"/assets/fileRoute-CW4_dn4B.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10de-+OqWYzhMyDcDY/KYK5W9RKKsBNw\"",
		"mtime": "2026-09-14T12:53:33.681Z",
		"size": 4318,
		"path": "../public/assets/fileRoute-CW4_dn4B.js"
	},
	"/assets/flame-CbMIO3LU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c5-A4u8JcN/OhJLpiu6OKmQG3i+hKQ\"",
		"mtime": "2026-09-14T12:53:33.685Z",
		"size": 197,
		"path": "../public/assets/flame-CbMIO3LU.js"
	},
	"/assets/forgot-password-CWPVkyK8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2157-IOHLU/IBFYmd7TGSm9ihAcnp/bQ\"",
		"mtime": "2026-09-14T12:53:33.685Z",
		"size": 8535,
		"path": "../public/assets/forgot-password-CWPVkyK8.js"
	},
	"/assets/gift-B78tDi6e.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15b-OaCcptLfjNdbGLA3jJH9TeEZRxY\"",
		"mtime": "2026-09-14T12:53:33.692Z",
		"size": 347,
		"path": "../public/assets/gift-B78tDi6e.js"
	},
	"/assets/headphones-CkZysue-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"eb-pUh9Oj0wxV18xIjl3svwVmnGUSA\"",
		"mtime": "2026-09-14T12:53:33.720Z",
		"size": 235,
		"path": "../public/assets/headphones-CkZysue-.js"
	},
	"/assets/hierarchy-CjTm_yCf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2a0b-Yf+fajvFPrzWpFLpuEI2KNbHtkA\"",
		"mtime": "2026-09-14T12:53:33.737Z",
		"size": 10763,
		"path": "../public/assets/hierarchy-CjTm_yCf.js"
	},
	"/assets/history-C8O4i2_H.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26b-ftz4S5RfDYZxs3rTqtPOLYkPJeQ\"",
		"mtime": "2026-09-14T12:53:33.737Z",
		"size": 619,
		"path": "../public/assets/history-C8O4i2_H.js"
	},
	"/assets/idempotency-key-CMznALKj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ee-hCyLPxuSAOrIEq5e+AojKA0K7+U\"",
		"mtime": "2026-09-14T12:53:33.753Z",
		"size": 494,
		"path": "../public/assets/idempotency-key-CMznALKj.js"
	},
	"/assets/indian-rupee-hvlpcZ2x.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"121-znT/8JPkqsQGldTUZm2uZNLsYBg\"",
		"mtime": "2026-09-14T12:53:33.770Z",
		"size": 289,
		"path": "../public/assets/indian-rupee-hvlpcZ2x.js"
	},
	"/assets/key-round-D7jhaZnn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"161-v7diAt9IDOLdzkT2Uu5YOLhofS4\"",
		"mtime": "2026-09-14T12:53:33.772Z",
		"size": 353,
		"path": "../public/assets/key-round-D7jhaZnn.js"
	},
	"/assets/kyc-Bo82uonk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b3-nq7JKzA2EKjk1obzsSF/K5RRSOQ\"",
		"mtime": "2026-09-14T12:53:33.784Z",
		"size": 179,
		"path": "../public/assets/kyc-Bo82uonk.js"
	},
	"/assets/kyc-BXr62YVK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b3-nq7JKzA2EKjk1obzsSF/K5RRSOQ\"",
		"mtime": "2026-09-14T12:53:33.784Z",
		"size": 179,
		"path": "../public/assets/kyc-BXr62YVK.js"
	},
	"/assets/index-ChY8e6Cm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4d9f9-eOHuT88QOjSyocjrJGQKptqK/Uw\"",
		"mtime": "2026-09-14T12:53:32.895Z",
		"size": 317945,
		"path": "../public/assets/index-ChY8e6Cm.js"
	},
	"/assets/kyc-CavdwrzA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f6-1OkE7az6MF3c4Pci0vYX630E3+A\"",
		"mtime": "2026-09-14T12:53:33.797Z",
		"size": 502,
		"path": "../public/assets/kyc-CavdwrzA.js"
	},
	"/assets/kyc-CK8tVGQl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"500-1mMUbPDGoBGtalC6TzZJev/HdiQ\"",
		"mtime": "2026-09-14T12:53:33.788Z",
		"size": 1280,
		"path": "../public/assets/kyc-CK8tVGQl.js"
	},
	"/assets/kyc-CSDrXiF-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3337-maYI/Id6kKCcrmom/zZKSxsTgEI\"",
		"mtime": "2026-09-14T12:53:33.788Z",
		"size": 13111,
		"path": "../public/assets/kyc-CSDrXiF-.js"
	},
	"/assets/kyc-CShOT_9R.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3d7b-k9eHPTjRBmiMe+MZ6Px3w8n4fns\"",
		"mtime": "2026-09-14T12:53:33.793Z",
		"size": 15739,
		"path": "../public/assets/kyc-CShOT_9R.js"
	},
	"/assets/kyc-D9IbwFQG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b3-nq7JKzA2EKjk1obzsSF/K5RRSOQ\"",
		"mtime": "2026-09-14T12:53:33.801Z",
		"size": 179,
		"path": "../public/assets/kyc-D9IbwFQG.js"
	},
	"/assets/landmark-c8WuP_Jk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"18e-vqPWFCffQa9spaanhFiv06VqVEI\"",
		"mtime": "2026-09-14T12:53:33.801Z",
		"size": 398,
		"path": "../public/assets/landmark-c8WuP_Jk.js"
	},
	"/assets/layers-e1UUzRcd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a3-mw28ZkJd+WfQnMGZCiFTfE8IhYI\"",
		"mtime": "2026-09-14T12:53:33.811Z",
		"size": 419,
		"path": "../public/assets/layers-e1UUzRcd.js"
	},
	"/assets/legal-DlYOIX8l.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4dc-5zTuGvc4uNojGG7Rctp5ibi4bPs\"",
		"mtime": "2026-09-14T12:53:33.813Z",
		"size": 1244,
		"path": "../public/assets/legal-DlYOIX8l.js"
	},
	"/assets/list-BucygLCa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7c43-gdiopzC74c3BHwEFl91yjg38QYQ\"",
		"mtime": "2026-09-14T12:53:33.826Z",
		"size": 31811,
		"path": "../public/assets/list-BucygLCa.js"
	},
	"/assets/list-D_HC79Sj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4891-THc4w/j57wbLgKe0UePsxxA89PA\"",
		"mtime": "2026-09-14T12:53:33.839Z",
		"size": 18577,
		"path": "../public/assets/list-D_HC79Sj.js"
	},
	"/assets/link-CUOYqXrb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6229-wsb0jeBrioOA+Cc42Mw3mmhEvPs\"",
		"mtime": "2026-09-14T12:53:33.823Z",
		"size": 25129,
		"path": "../public/assets/link-CUOYqXrb.js"
	},
	"/assets/loader-circle-DMWgVcVe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8e-KkWg5en80fIBMfatpeuDnwvI1Kc\"",
		"mtime": "2026-09-14T12:53:33.856Z",
		"size": 142,
		"path": "../public/assets/loader-circle-DMWgVcVe.js"
	},
	"/assets/lock-DPko6kiH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cc-O1HiGdvBJ+piSEvhLjnxUXVUZFo\"",
		"mtime": "2026-09-14T12:53:33.856Z",
		"size": 204,
		"path": "../public/assets/lock-DPko6kiH.js"
	},
	"/assets/login-BOvET8tM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1cc1-ng/mmz8QU3ztlnaNw5Vo5SPh7p4\"",
		"mtime": "2026-09-14T12:53:33.866Z",
		"size": 7361,
		"path": "../public/assets/login-BOvET8tM.js"
	},
	"/assets/lock-keyhole-BAwU8jyC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fd-mbxHWu9S5QCueJZ2CxvnWpel2WA\"",
		"mtime": "2026-09-14T12:53:33.856Z",
		"size": 253,
		"path": "../public/assets/lock-keyhole-BAwU8jyC.js"
	},
	"/assets/map-pin-CnfjHzz8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"101-Wz8eyzPCblNw7yxwGwSmh069fXA\"",
		"mtime": "2026-09-14T12:53:33.891Z",
		"size": 257,
		"path": "../public/assets/map-pin-CnfjHzz8.js"
	},
	"/assets/login-BW0t_C7Y.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d43-wIHBu3+ADt37kR8M74V0ZYsiGl4\"",
		"mtime": "2026-09-14T12:53:33.875Z",
		"size": 7491,
		"path": "../public/assets/login-BW0t_C7Y.js"
	},
	"/assets/master-distributor-api-7fY6LAIM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"182-F00Y1icmBprLgHiQZbCMA85Zxrc\"",
		"mtime": "2026-09-14T12:53:33.913Z",
		"size": 386,
		"path": "../public/assets/master-distributor-api-7fY6LAIM.js"
	},
	"/assets/master-distributor-DJ_EhJ2W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4b-Na6B4KWh7ppCdaSnuVdLUEDe+ck\"",
		"mtime": "2026-09-14T12:53:33.891Z",
		"size": 75,
		"path": "../public/assets/master-distributor-DJ_EhJ2W.js"
	},
	"/assets/merchants-BqRLD-Dp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2608-Se9I4lsMiBaSzlkJE9EwKnv4umc\"",
		"mtime": "2026-09-14T12:53:33.930Z",
		"size": 9736,
		"path": "../public/assets/merchants-BqRLD-Dp.js"
	},
	"/assets/mini-statement-Bg_rTK2F.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"140-oTcinL8PUostqnDUSxavvWnmg08\"",
		"mtime": "2026-09-14T12:53:33.974Z",
		"size": 320,
		"path": "../public/assets/mini-statement-Bg_rTK2F.js"
	},
	"/assets/logo-Bhmma_C9.png": {
		"type": "image/png",
		"etag": "\"2ddff-0PKSMIEG7yFwqAMo6IVoX/fnEUQ\"",
		"mtime": "2026-09-14T12:53:35.060Z",
		"size": 187903,
		"path": "../public/assets/logo-Bhmma_C9.png"
	},
	"/assets/module-placeholder-N-zEusxc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"308-TWA3mF0v0jWu/ne0gIHvBf661DQ\"",
		"mtime": "2026-09-14T12:53:33.993Z",
		"size": 776,
		"path": "../public/assets/module-placeholder-N-zEusxc.js"
	},
	"/assets/mail-DK3PFsL4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d3-kFeHhAagOYn7px/ZnsxRab51dRM\"",
		"mtime": "2026-09-14T12:53:33.886Z",
		"size": 211,
		"path": "../public/assets/mail-DK3PFsL4.js"
	},
	"/assets/management-route-page-rIP1KYQl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6bd-tnZa9F+nkSKpqK4XnQVIxmup2Z0\"",
		"mtime": "2026-09-14T12:53:33.888Z",
		"size": 1725,
		"path": "../public/assets/management-route-page-rIP1KYQl.js"
	},
	"/assets/network-aeps-transactions-DpWQm-up.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15d0-FWpYivXjz5J/qxzRPnO0C1+oDKg\"",
		"mtime": "2026-09-14T12:53:34.024Z",
		"size": 5584,
		"path": "../public/assets/network-aeps-transactions-DpWQm-up.js"
	},
	"/assets/network-disieQDl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17e-eFBe56DOnGsTkwD7cospmerZqxQ\"",
		"mtime": "2026-09-14T12:53:34.049Z",
		"size": 382,
		"path": "../public/assets/network-disieQDl.js"
	},
	"/assets/notifications-C_bQuqQa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"183-p09qtnf0e1Sqh4ojks+gPr0ISIs\"",
		"mtime": "2026-09-14T12:53:34.051Z",
		"size": 387,
		"path": "../public/assets/notifications-C_bQuqQa.js"
	},
	"/assets/operations-api-Br1pvC-H.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7f5-Jgwbyj2OMy+AUhlBqBtGfpIRtEQ\"",
		"mtime": "2026-09-14T12:53:34.093Z",
		"size": 2037,
		"path": "../public/assets/operations-api-Br1pvC-H.js"
	},
	"/assets/onboarding-BRSj_qZM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1386-4IqQQ+flZhY6Yni5WWlYI2R8Qm0\"",
		"mtime": "2026-09-14T12:53:34.091Z",
		"size": 4998,
		"path": "../public/assets/onboarding-BRSj_qZM.js"
	},
	"/assets/pen-line-BEbgLAfO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"113-j1lmnxneQKT0lzSlFB1TVlKzz+Q\"",
		"mtime": "2026-09-14T12:53:34.113Z",
		"size": 275,
		"path": "../public/assets/pen-line-BEbgLAfO.js"
	},
	"/assets/phone-CpLrNlTk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"140-wwtb7AL385C/mb7T2W2QpRILG6Y\"",
		"mtime": "2026-09-14T12:53:34.132Z",
		"size": 320,
		"path": "../public/assets/phone-CpLrNlTk.js"
	},
	"/assets/phone-mock-k9LxT-WD.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"110-OS1X2QJKgf5DldYfJj3tWjyz+SA\"",
		"mtime": "2026-09-14T12:53:34.134Z",
		"size": 272,
		"path": "../public/assets/phone-mock-k9LxT-WD.js"
	},
	"/assets/plus-CSCsroA1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"97-nigCDcQKG53NX4mqAEIJnbNd4IM\"",
		"mtime": "2026-09-14T12:53:34.145Z",
		"size": 151,
		"path": "../public/assets/plus-CSCsroA1.js"
	},
	"/assets/policy-page-BegyrtvR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15d3-1if4NCfZgoHMtjnxsNJ3JxGuXjQ\"",
		"mtime": "2026-09-14T12:53:34.158Z",
		"size": 5587,
		"path": "../public/assets/policy-page-BegyrtvR.js"
	},
	"/assets/preload-helper-CNW_eQwo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6cc-aQQEWpsHv0UeljC2eikVAMaaUe4\"",
		"mtime": "2026-09-14T12:53:34.158Z",
		"size": 1740,
		"path": "../public/assets/preload-helper-CNW_eQwo.js"
	},
	"/assets/privacy-9a_sljUR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"77e-DqB8J/mNHVFiqgHP5RoZq8tdngI\"",
		"mtime": "2026-09-14T12:53:34.179Z",
		"size": 1918,
		"path": "../public/assets/privacy-9a_sljUR.js"
	},
	"/assets/profile-B0Ep4QGY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"54-QR2qlKc11PFsmX8rGbS+z9EepBc\"",
		"mtime": "2026-09-14T12:53:34.181Z",
		"size": 84,
		"path": "../public/assets/profile-B0Ep4QGY.js"
	},
	"/assets/profile-DwVHSKBg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"54-QR2qlKc11PFsmX8rGbS+z9EepBc\"",
		"mtime": "2026-09-14T12:53:34.201Z",
		"size": 84,
		"path": "../public/assets/profile-DwVHSKBg.js"
	},
	"/assets/QueryClientProvider-D2ORKNlU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3b89-derVDY6/MTXlgq1bc0woBEQglqo\"",
		"mtime": "2026-09-14T12:53:32.897Z",
		"size": 15241,
		"path": "../public/assets/QueryClientProvider-D2ORKNlU.js"
	},
	"/assets/receipt-YWqKnsde.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"122-vQrMnEJar1PXJEaB+HwTEqFniAs\"",
		"mtime": "2026-09-14T12:53:34.219Z",
		"size": 290,
		"path": "../public/assets/receipt-YWqKnsde.js"
	},
	"/assets/receipt-text-BZ5J3ywr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"295-gYDnVotA/nHZGDFEg1Wo/tHeeHU\"",
		"mtime": "2026-09-14T12:53:34.243Z",
		"size": 661,
		"path": "../public/assets/receipt-text-BZ5J3ywr.js"
	},
	"/assets/refresh-cw-BB0Ms_XJ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13f-QZpDwXZXebRKacaEtU4SE5wPexw\"",
		"mtime": "2026-09-14T12:53:34.243Z",
		"size": 319,
		"path": "../public/assets/refresh-cw-BB0Ms_XJ.js"
	},
	"/assets/refund-policy-CFmtURfV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"760-jCmji59bN5TxGlM26V5A58Hkm2A\"",
		"mtime": "2026-09-14T12:53:34.255Z",
		"size": 1888,
		"path": "../public/assets/refund-policy-CFmtURfV.js"
	},
	"/assets/register-DFGaGVqY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"293e-z4CL4/d/FE8Gd3jhL3q7QLNUP1g\"",
		"mtime": "2026-09-14T12:53:34.257Z",
		"size": 10558,
		"path": "../public/assets/register-DFGaGVqY.js"
	},
	"/assets/reports-BQgWTaiA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16bb-zHiUxRoE0K9ipTXiuDxWwSv6Cuo\"",
		"mtime": "2026-09-14T12:53:34.272Z",
		"size": 5819,
		"path": "../public/assets/reports-BQgWTaiA.js"
	},
	"/assets/reports-BzBYb1vE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6ea-cLqXTqXsxJC22UscCumuaiIETAo\"",
		"mtime": "2026-09-14T12:53:34.275Z",
		"size": 1770,
		"path": "../public/assets/reports-BzBYb1vE.js"
	},
	"/assets/reports-DssR8LxN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"657-QmyGbSJ8qZk64qglzM4PWqiUYts\"",
		"mtime": "2026-09-14T12:53:34.301Z",
		"size": 1623,
		"path": "../public/assets/reports-DssR8LxN.js"
	},
	"/assets/profile-DU9bWzoH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"54-QR2qlKc11PFsmX8rGbS+z9EepBc\"",
		"mtime": "2026-09-14T12:53:34.201Z",
		"size": 84,
		"path": "../public/assets/profile-DU9bWzoH.js"
	},
	"/assets/phone-mock-BUsrpQeV.png": {
		"type": "image/png",
		"etag": "\"11dd3c-1TGh9FZDQ9TYMICEBtATKUQo49Y\"",
		"mtime": "2026-09-14T12:53:35.080Z",
		"size": 1170748,
		"path": "../public/assets/phone-mock-BUsrpQeV.png"
	},
	"/assets/requests-Qd56cSxr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"300-ZCpPyEjci99dvM2RabbjyHilS6U\"",
		"mtime": "2026-09-14T12:53:34.317Z",
		"size": 768,
		"path": "../public/assets/requests-Qd56cSxr.js"
	},
	"/assets/retailers-Ce4p7YC5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"212-5+hcD3wFSqjrndMzJVlcpLxWSFE\"",
		"mtime": "2026-09-14T12:53:34.326Z",
		"size": 530,
		"path": "../public/assets/retailers-Ce4p7YC5.js"
	},
	"/assets/retailers-DXpVNXmG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"af2-GQ/kQsgqEva/IVIp95JzwD4l/vA\"",
		"mtime": "2026-09-14T12:53:34.339Z",
		"size": 2802,
		"path": "../public/assets/retailers-DXpVNXmG.js"
	},
	"/assets/rocket-BWMbra_E.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c2-qXlO7K33+bhp71TPJ9xzFt5YJ5M\"",
		"mtime": "2026-09-14T12:53:34.343Z",
		"size": 450,
		"path": "../public/assets/rocket-BWMbra_E.js"
	},
	"/assets/role-aware-account-page-CiVz-ac6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f7-dX1C1PpHdbRw789rreMLtOrzTCs\"",
		"mtime": "2026-09-14T12:53:34.357Z",
		"size": 503,
		"path": "../public/assets/role-aware-account-page-CiVz-ac6.js"
	},
	"/assets/role-hierarchy-ZhAUf5VZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2471-FYApuNh0eGGN/l48qjXWBljpKGI\"",
		"mtime": "2026-09-14T12:53:34.361Z",
		"size": 9329,
		"path": "../public/assets/role-hierarchy-ZhAUf5VZ.js"
	},
	"/assets/rotate-ccw-DHVP3kLv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c6-oltdAc3tIgJaGARapfB3HLChgnc\"",
		"mtime": "2026-09-14T12:53:34.383Z",
		"size": 198,
		"path": "../public/assets/rotate-ccw-DHVP3kLv.js"
	},
	"/assets/routes-ztfxpDd_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8bd1-srkQ11R/hrjLXI9KLeeW080QrVA\"",
		"mtime": "2026-09-14T12:53:34.383Z",
		"size": 35793,
		"path": "../public/assets/routes-ztfxpDd_.js"
	},
	"/assets/search-_56X_4ZM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ac-wX8xtGonkjqnfyZNQZbI5dWoLAA\"",
		"mtime": "2026-09-14T12:53:34.408Z",
		"size": 172,
		"path": "../public/assets/search-_56X_4ZM.js"
	},
	"/assets/section-tabs-Ct7uJb-j.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2c20-NSVFXCEl1ufhlyFHUWENvx0AT4E\"",
		"mtime": "2026-09-14T12:53:34.430Z",
		"size": 11296,
		"path": "../public/assets/section-tabs-Ct7uJb-j.js"
	},
	"/assets/send-BO-ATnct.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"120-4Nf4cIeXVMmal7HSEFYVoAGvrn0\"",
		"mtime": "2026-09-14T12:53:34.430Z",
		"size": 288,
		"path": "../public/assets/send-BO-ATnct.js"
	},
	"/assets/services-BesZBRSZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19ec-AyyVYpLby8wFcFk2gUT06CSlurc\"",
		"mtime": "2026-09-14T12:53:34.452Z",
		"size": 6636,
		"path": "../public/assets/services-BesZBRSZ.js"
	},
	"/assets/settings-2-De3sl87W.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fa-8TohnE3LA0QTzVWHceD+ZUmogr8\"",
		"mtime": "2026-09-14T12:53:34.479Z",
		"size": 250,
		"path": "../public/assets/settings-2-De3sl87W.js"
	},
	"/assets/settings-5ZTVFYIt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2b6c-mtGDcBx96n+RsijRL3DaS6sd9VQ\"",
		"mtime": "2026-09-14T12:53:34.481Z",
		"size": 11116,
		"path": "../public/assets/settings-5ZTVFYIt.js"
	},
	"/assets/settings-CMJjSh0c.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"55-9U1H6GC2qwRghpdo17uric5Cvrw\"",
		"mtime": "2026-09-14T12:53:34.499Z",
		"size": 85,
		"path": "../public/assets/settings-CMJjSh0c.js"
	},
	"/assets/settings-D2tVyaUS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"55-9U1H6GC2qwRghpdo17uric5Cvrw\"",
		"mtime": "2026-09-14T12:53:34.517Z",
		"size": 85,
		"path": "../public/assets/settings-D2tVyaUS.js"
	},
	"/assets/settings-ebcc25kx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"55-9U1H6GC2qwRghpdo17uric5Cvrw\"",
		"mtime": "2026-09-14T12:53:34.539Z",
		"size": 85,
		"path": "../public/assets/settings-ebcc25kx.js"
	},
	"/assets/settlements-B25m6lNh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"21e-uYBu+PdNzwBabbukVsenIMEakDg\"",
		"mtime": "2026-09-14T12:53:34.555Z",
		"size": 542,
		"path": "../public/assets/settlements-B25m6lNh.js"
	},
	"/assets/shield-check-nsx3hwtR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13e-x5AYtHt4SmHrMrpY+PETI74YJow\"",
		"mtime": "2026-09-14T12:53:34.588Z",
		"size": 318,
		"path": "../public/assets/shield-check-nsx3hwtR.js"
	},
	"/assets/shield-GFJR3qco.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10e-a6RdbZhCIBDUBQ1Ntztlp1excys\"",
		"mtime": "2026-09-14T12:53:34.576Z",
		"size": 270,
		"path": "../public/assets/shield-GFJR3qco.js"
	},
	"/assets/smartphone-Dtuc_YQ_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c3-uvxOODglw06GIm6dyAt8Bpf2SOc\"",
		"mtime": "2026-09-14T12:53:34.618Z",
		"size": 195,
		"path": "../public/assets/smartphone-Dtuc_YQ_.js"
	},
	"/assets/site-footer-DvX51RSQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e92-7MQf5XAywCD7ib7Zqf+LQV2NgBw\"",
		"mtime": "2026-09-14T12:53:34.607Z",
		"size": 7826,
		"path": "../public/assets/site-footer-DvX51RSQ.js"
	},
	"/assets/sms-vVdpVIHP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6e2-/Ys4Glu7qWgx8VrbdDRlcAx+qzo\"",
		"mtime": "2026-09-14T12:53:34.630Z",
		"size": 1762,
		"path": "../public/assets/sms-vVdpVIHP.js"
	},
	"/assets/store-C7I1y9vS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f0-0jLoDIoMQSD+whVgEZcF5aP4qDE\"",
		"mtime": "2026-09-14T12:53:34.642Z",
		"size": 496,
		"path": "../public/assets/store-C7I1y9vS.js"
	},
	"/assets/styles-Ck4tHDco.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"2081a-6lD+7ZnlBiCcR1YxRiF1aUxBhXs\"",
		"mtime": "2026-09-14T12:53:35.091Z",
		"size": 133146,
		"path": "../public/assets/styles-Ck4tHDco.css"
	},
	"/assets/super-admin-aeps-two-factor-DR39rRBp.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26ca-JhiFY4obVVzeCtLB8t37htyzNH8\"",
		"mtime": "2026-09-14T12:53:34.655Z",
		"size": 9930,
		"path": "../public/assets/super-admin-aeps-two-factor-DR39rRBp.js"
	},
	"/assets/support-B4mWAR-n.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"46c-nelB5xtzln1Vl0lQ76dPJL3mhZk\"",
		"mtime": "2026-09-14T12:53:34.689Z",
		"size": 1132,
		"path": "../public/assets/support-B4mWAR-n.js"
	},
	"/assets/support-BGAIJQ1Z.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"183-9VXyox96+a27+rx+cYOvWtCo+Pk\"",
		"mtime": "2026-09-14T12:53:34.691Z",
		"size": 387,
		"path": "../public/assets/support-BGAIJQ1Z.js"
	},
	"/assets/terms-DsmOiGIM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8b3-GF1Iihaco9ct0s1KIrwmoTDMl9c\"",
		"mtime": "2026-09-14T12:53:34.696Z",
		"size": 2227,
		"path": "../public/assets/terms-DsmOiGIM.js"
	},
	"/assets/transaction-detail-dialog-Cv8UhahY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1652-HKUxmXaJUZWTSOtMBaCM73Dryzg\"",
		"mtime": "2026-09-14T12:53:34.697Z",
		"size": 5714,
		"path": "../public/assets/transaction-detail-dialog-Cv8UhahY.js"
	},
	"/assets/testi-1-60byFK3Z.jpg": {
		"type": "image/jpeg",
		"etag": "\"1397b-eSCXp8wG42dhukRfCoDAhQiZDa8\"",
		"mtime": "2026-09-14T12:53:35.096Z",
		"size": 80251,
		"path": "../public/assets/testi-1-60byFK3Z.jpg"
	},
	"/assets/testi-2-CXzvTJjx.jpg": {
		"type": "image/jpeg",
		"etag": "\"15e94-cGEzoN7S/P3959lQx3PXn0Yv9f0\"",
		"mtime": "2026-09-14T12:53:35.110Z",
		"size": 89748,
		"path": "../public/assets/testi-2-CXzvTJjx.jpg"
	},
	"/assets/transactions-CwWk99QC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4e6-ykzJv2FjmqsvrZZimquMCzU+Tsg\"",
		"mtime": "2026-09-14T12:53:34.723Z",
		"size": 1254,
		"path": "../public/assets/transactions-CwWk99QC.js"
	},
	"/assets/transactions-BGPu4nVh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"79e1-yeHOExmIVIDm9mhx42uwpRVc5VI\"",
		"mtime": "2026-09-14T12:53:34.707Z",
		"size": 31201,
		"path": "../public/assets/transactions-BGPu4nVh.js"
	},
	"/assets/transactions-D1xmk6mB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"162e-dSVaP9loN+m06Ba48SLKdW+iP1Q\"",
		"mtime": "2026-09-14T12:53:34.730Z",
		"size": 5678,
		"path": "../public/assets/transactions-D1xmk6mB.js"
	},
	"/assets/transactions-DeOu2sXt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"145-Bz5mQlLIowU5VRrkht+47ERpLeE\"",
		"mtime": "2026-09-14T12:53:34.764Z",
		"size": 325,
		"path": "../public/assets/transactions-DeOu2sXt.js"
	},
	"/assets/testi-3-D_aSGUBz.jpg": {
		"type": "image/jpeg",
		"etag": "\"f7b4-SYGVix0+AeElOkKlivLOMj/zCOs\"",
		"mtime": "2026-09-14T12:53:35.126Z",
		"size": 63412,
		"path": "../public/assets/testi-3-D_aSGUBz.jpg"
	},
	"/assets/transactions-DQA82aqR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"19b-thiXRhpPGHmMurnGEk38C7ryeOc\"",
		"mtime": "2026-09-14T12:53:34.746Z",
		"size": 411,
		"path": "../public/assets/transactions-DQA82aqR.js"
	},
	"/assets/transfer-Co2_mgIu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"37f4-VoxZ1qtrGzYuEwPgUwGCUeSFlNA\"",
		"mtime": "2026-09-14T12:53:34.781Z",
		"size": 14324,
		"path": "../public/assets/transfer-Co2_mgIu.js"
	},
	"/assets/transfer-DfPuUWk7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3847-EkJEM4OVH//UQpTcXUDeM1OqQjU\"",
		"mtime": "2026-09-14T12:53:34.801Z",
		"size": 14407,
		"path": "../public/assets/transfer-DfPuUWk7.js"
	},
	"/assets/transfer-llYPqKtN.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"378e-kjmKlExEYvOySFw+Bq+xoDJYd9M\"",
		"mtime": "2026-09-14T12:53:34.818Z",
		"size": 14222,
		"path": "../public/assets/transfer-llYPqKtN.js"
	},
	"/assets/trash-2-B7ATp5um.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"146-ioumqNJ4FRUtB6JV/kEETzl76gg\"",
		"mtime": "2026-09-14T12:53:34.832Z",
		"size": 326,
		"path": "../public/assets/trash-2-B7ATp5um.js"
	},
	"/assets/tree-DoRnz6gd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"74c-aVSJWdz0AoURk4Jr6VMIz6b+BbU\"",
		"mtime": "2026-09-14T12:53:34.839Z",
		"size": 1868,
		"path": "../public/assets/tree-DoRnz6gd.js"
	},
	"/assets/tv-CazN8OPa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"104-haBeMutdYFcNnmz591UF/KeGHgg\"",
		"mtime": "2026-09-14T12:53:34.841Z",
		"size": 260,
		"path": "../public/assets/tv-CazN8OPa.js"
	},
	"/assets/user-CkZhT4EA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c2-hPQw8lGOLndHhGBaOCJC/dj2Ftk\"",
		"mtime": "2026-09-14T12:53:34.898Z",
		"size": 194,
		"path": "../public/assets/user-CkZhT4EA.js"
	},
	"/assets/user-plus-CG_sYZIH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"134-/zR9aui/nPmJNrgH3BtqseCT5B8\"",
		"mtime": "2026-09-14T12:53:34.915Z",
		"size": 308,
		"path": "../public/assets/user-plus-CG_sYZIH.js"
	},
	"/assets/useNavigate-DT7ghfdY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bd-NRw/P+j8Y9+d6YilTDLWWsCfPGM\"",
		"mtime": "2026-09-14T12:53:34.855Z",
		"size": 189,
		"path": "../public/assets/useNavigate-DT7ghfdY.js"
	},
	"/assets/useRouter-Dpb7RwMI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2144-OAWOWZt+i/sSs5fMTIk74KvSiew\"",
		"mtime": "2026-09-14T12:53:34.857Z",
		"size": 8516,
		"path": "../public/assets/useRouter-Dpb7RwMI.js"
	},
	"/assets/user-round-check-CxooL4PK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ad-NiH9LULfqaWEKbWjn+1Q9+Iu+ew\"",
		"mtime": "2026-09-14T12:53:34.920Z",
		"size": 429,
		"path": "../public/assets/user-round-check-CxooL4PK.js"
	},
	"/assets/wallet-BCjdEuAy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f7d-6jwesJXYh7ou2K5HyZQogV0WOBY\"",
		"mtime": "2026-09-14T12:53:34.920Z",
		"size": 3965,
		"path": "../public/assets/wallet-BCjdEuAy.js"
	},
	"/assets/wallet-BptaCP8F.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f25-OALAIfRwaZ6hq4T4xFMAdxg1p6M\"",
		"mtime": "2026-09-14T12:53:34.965Z",
		"size": 3877,
		"path": "../public/assets/wallet-BptaCP8F.js"
	},
	"/assets/wallet-cards--re0rWJC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"146-XQZSt8o9DQQjTEFcqAcmBYEEmsM\"",
		"mtime": "2026-09-14T12:53:34.996Z",
		"size": 326,
		"path": "../public/assets/wallet-cards--re0rWJC.js"
	},
	"/assets/wallet-Dwe8CdpI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f88-biLNg5wHQAjzNIpDdZ9i/r3IjcA\"",
		"mtime": "2026-09-14T12:53:34.982Z",
		"size": 3976,
		"path": "../public/assets/wallet-Dwe8CdpI.js"
	},
	"/assets/wallet-qY7Rwdfy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"34a-M/cgYaMmwDC+8BTQDQCBee1YKV4\"",
		"mtime": "2026-09-14T12:53:34.998Z",
		"size": 842,
		"path": "../public/assets/wallet-qY7Rwdfy.js"
	},
	"/assets/wifi-K6XhXeBU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"116-oTUgHseUW7KR+kS6OtBvq38WGXI\"",
		"mtime": "2026-09-14T12:53:34.998Z",
		"size": 278,
		"path": "../public/assets/wifi-K6XhXeBU.js"
	},
	"/assets/x-BK5C6BIu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"120-BykbAA9xqr8gyPyxA12YVGiM6Mc\"",
		"mtime": "2026-09-14T12:53:35.013Z",
		"size": 288,
		"path": "../public/assets/x-BK5C6BIu.js"
	},
	"/assets/zap-DWWMsIkU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"104-RrWMPggGexCXKoQIcKudFlr55x8\"",
		"mtime": "2026-09-14T12:53:35.030Z",
		"size": 260,
		"path": "../public/assets/zap-DWWMsIkU.js"
	},
	"/assets/_-43e_bI2X.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bc-G9VA4og0O5sk840Ei+LBcISxgcU\"",
		"mtime": "2026-09-14T12:53:32.900Z",
		"size": 188,
		"path": "../public/assets/_-43e_bI2X.js"
	},
	"/assets/_-Q_0qYCWT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ca-YbXnxptON1tniymjjK7TRkXfCfw\"",
		"mtime": "2026-09-14T12:53:32.901Z",
		"size": 202,
		"path": "../public/assets/_-Q_0qYCWT.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_ExPMG0 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_ExPMG0
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
