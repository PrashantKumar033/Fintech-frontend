//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BgYb4DIN.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/activity",
			"/contact",
			"/forgot-password",
			"/login",
			"/privacy",
			"/refund-policy",
			"/register",
			"/services",
			"/terms",
			"/admin/account-setup",
			"/admin/login",
			"/admin/onboarding",
			"/distributor/$",
			"/distributor/account-setup",
			"/distributor/dashboard",
			"/master-distributor/$",
			"/master-distributor/account-setup",
			"/master-distributor/dashboard",
			"/retailer/account-setup",
			"/retailer/dashboard",
			"/retailer/settings",
			"/admin/",
			"/distributor/",
			"/master-distributor/",
			"/admin/commissions/hierarchy",
			"/admin/profile/bank",
			"/admin/profile/kyc",
			"/distributor/aeps/balance-enquiry",
			"/distributor/aeps/cash-withdrawal",
			"/distributor/aeps/mini-statement",
			"/distributor/aeps/transactions",
			"/distributor/profile/bank",
			"/distributor/profile/kyc",
			"/distributor/wallet/transfer",
			"/master-distributor/profile/bank",
			"/master-distributor/profile/kyc",
			"/master-distributor/wallet/history",
			"/master-distributor/wallet/requests",
			"/master-distributor/wallet/transfer",
			"/retailer/wallet/transfer",
			"/admin/access/",
			"/admin/aeps/",
			"/admin/api-settings/",
			"/admin/banking/",
			"/admin/commissions/",
			"/admin/kyc/",
			"/admin/legal/",
			"/admin/merchants/",
			"/admin/profile/",
			"/admin/reports/",
			"/admin/settings/",
			"/admin/settlements/",
			"/admin/sms/",
			"/admin/transactions/",
			"/distributor/aeps/",
			"/distributor/commission/",
			"/distributor/profile/",
			"/distributor/reports/",
			"/distributor/retailers/",
			"/distributor/settings/",
			"/distributor/support/",
			"/distributor/wallet/",
			"/master-distributor/aeps/",
			"/master-distributor/commission/",
			"/master-distributor/kyc/",
			"/master-distributor/notifications/",
			"/master-distributor/profile/",
			"/master-distributor/reports/",
			"/master-distributor/settings/",
			"/master-distributor/support/",
			"/master-distributor/transactions/",
			"/master-distributor/wallet/",
			"/retailer/aeps/",
			"/retailer/bank/",
			"/retailer/kyc/",
			"/retailer/transactions/",
			"/retailer/wallet/",
			"/admin/merchants/add/",
			"/admin/merchants/list/",
			"/distributor/retailers/add/",
			"/master-distributor/network/distributors/",
			"/master-distributor/network/retailers/",
			"/master-distributor/network/tree/",
			"/master-distributor/network/distributors/add/"
		],
		preloads: [
			"/assets/index-ChY8e6Cm.js",
			"/assets/useRouter-Dpb7RwMI.js",
			"/assets/link-CUOYqXrb.js",
			"/assets/fileRoute-CW4_dn4B.js",
			"/assets/preload-helper-CNW_eQwo.js",
			"/assets/QueryClientProvider-D2ORKNlU.js",
			"/assets/list-BucygLCa.js",
			"/assets/commissions-CuzUe-IM.js",
			"/assets/account-setup-o639ESEk.js",
			"/assets/dashboard-CHT1MbvC.js",
			"/assets/dashboard-ByXwHwVw.js",
			"/assets/merchants-BqRLD-Dp.js",
			"/assets/transactions-CwWk99QC.js",
			"/assets/bank-B5I1uYM_.js",
			"/assets/kyc-CK8tVGQl.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-ChY8e6Cm.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-ztfxpDd_.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/arrow-right-DIOMHBQg.js",
			"/assets/arrow-up-right-DntXdoRl.js",
			"/assets/banknote-8ucSb4IQ.js",
			"/assets/tv-CazN8OPa.js",
			"/assets/circle-check-Ri-EdMSx.js",
			"/assets/credit-card-mnJY4ttf.js",
			"/assets/eye-BWpUro50.js",
			"/assets/site-footer-DvX51RSQ.js",
			"/assets/wallet-qY7Rwdfy.js",
			"/assets/layers-e1UUzRcd.js",
			"/assets/lock-DPko6kiH.js",
			"/assets/plus-CSCsroA1.js",
			"/assets/receipt-YWqKnsde.js",
			"/assets/rocket-BWMbra_E.js",
			"/assets/send-BO-ATnct.js",
			"/assets/shield-GFJR3qco.js",
			"/assets/smartphone-Dtuc_YQ_.js",
			"/assets/phone-mock-k9LxT-WD.js",
			"/assets/zap-DWWMsIkU.js"
		]
	},
	"/about": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-CEOGhgT9.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/arrow-right-DIOMHBQg.js",
			"/assets/site-footer-DvX51RSQ.js",
			"/assets/headphones-CkZysue-.js",
			"/assets/rocket-BWMbra_E.js",
			"/assets/shield-check-nsx3hwtR.js",
			"/assets/phone-mock-k9LxT-WD.js",
			"/assets/zap-DWWMsIkU.js",
			"/assets/about-team-DwbCHxeD.js"
		]
	},
	"/activity": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/activity.tsx",
		children: void 0,
		preloads: [
			"/assets/activity-CiC3tlYd.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-DKg6V5tc.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/eye-BWpUro50.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/audit-detail-dialog-DafViTI-.js",
			"/assets/operations-api-Br1pvC-H.js"
		]
	},
	"/contact": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-B-IJW9Tt.js",
			"/assets/clock-3-BY_mV_q5.js",
			"/assets/site-footer-DvX51RSQ.js",
			"/assets/mail-DK3PFsL4.js",
			"/assets/map-pin-CnfjHzz8.js",
			"/assets/phone-CpLrNlTk.js",
			"/assets/send-BO-ATnct.js"
		]
	},
	"/forgot-password": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/forgot-password.tsx",
		children: void 0,
		preloads: [
			"/assets/forgot-password-CWPVkyK8.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/arrow-left-EURBdOAR.js",
			"/assets/arrow-right-DIOMHBQg.js",
			"/assets/eye-off-Q3psqXMi.js",
			"/assets/eye-BWpUro50.js",
			"/assets/site-footer-DvX51RSQ.js",
			"/assets/key-round-D7jhaZnn.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/shield-check-nsx3hwtR.js",
			"/assets/user-CkZhT4EA.js"
		]
	},
	"/login": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-BW0t_C7Y.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/arrow-right-DIOMHBQg.js",
			"/assets/eye-off-Q3psqXMi.js",
			"/assets/eye-BWpUro50.js",
			"/assets/site-footer-DvX51RSQ.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/lock-DPko6kiH.js",
			"/assets/shield-GFJR3qco.js",
			"/assets/smartphone-Dtuc_YQ_.js",
			"/assets/admin-api-PLzwbARO.js"
		]
	},
	"/privacy": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/privacy.tsx",
		children: void 0,
		preloads: [
			"/assets/privacy-9a_sljUR.js",
			"/assets/policy-page-BegyrtvR.js",
			"/assets/shield-check-nsx3hwtR.js"
		]
	},
	"/refund-policy": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/refund-policy.tsx",
		children: void 0,
		preloads: [
			"/assets/refund-policy-CFmtURfV.js",
			"/assets/policy-page-BegyrtvR.js",
			"/assets/rotate-ccw-DHVP3kLv.js"
		]
	},
	"/register": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-DFGaGVqY.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/arrow-left-EURBdOAR.js",
			"/assets/arrow-right-DIOMHBQg.js",
			"/assets/circle-check-Ri-EdMSx.js",
			"/assets/site-footer-DvX51RSQ.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/rocket-BWMbra_E.js",
			"/assets/shield-check-nsx3hwtR.js"
		]
	},
	"/services": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/services.tsx",
		children: void 0,
		preloads: [
			"/assets/services-BesZBRSZ.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/arrow-right-DIOMHBQg.js",
			"/assets/badge-check-CO4P0cYM.js",
			"/assets/banknote-8ucSb4IQ.js",
			"/assets/circle-check-Ri-EdMSx.js",
			"/assets/credit-card-mnJY4ttf.js",
			"/assets/site-footer-DvX51RSQ.js",
			"/assets/flame-CbMIO3LU.js",
			"/assets/landmark-c8WuP_Jk.js",
			"/assets/receipt-text-BZ5J3ywr.js",
			"/assets/send-BO-ATnct.js",
			"/assets/shield-check-nsx3hwtR.js",
			"/assets/smartphone-Dtuc_YQ_.js",
			"/assets/store-C7I1y9vS.js",
			"/assets/wifi-K6XhXeBU.js",
			"/assets/zap-DWWMsIkU.js",
			"/assets/about-team-DwbCHxeD.js"
		]
	},
	"/terms": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/terms.tsx",
		children: void 0,
		preloads: [
			"/assets/terms-DsmOiGIM.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/policy-page-BegyrtvR.js"
		]
	},
	"/admin/login": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-BOvET8tM.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/arrow-right-DIOMHBQg.js",
			"/assets/eye-off-Q3psqXMi.js",
			"/assets/eye-BWpUro50.js",
			"/assets/lock-keyhole-BAwU8jyC.js",
			"/assets/shield-check-nsx3hwtR.js",
			"/assets/admin-api-PLzwbARO.js"
		]
	},
	"/admin/onboarding": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/onboarding.tsx",
		children: void 0,
		preloads: [
			"/assets/onboarding-BRSj_qZM.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/arrow-right-DIOMHBQg.js",
			"/assets/circle-check-Ri-EdMSx.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/lock-keyhole-BAwU8jyC.js",
			"/assets/shield-check-nsx3hwtR.js",
			"/assets/admin-api-PLzwbARO.js"
		]
	},
	"/distributor/$": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/$.tsx",
		children: void 0,
		preloads: ["/assets/_-43e_bI2X.js", "/assets/management-route-page-rIP1KYQl.js"]
	},
	"/distributor/account-setup": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/account-setup.tsx",
		children: void 0,
		preloads: ["/assets/account-setup-DFvyVdPn.js"]
	},
	"/master-distributor/$": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/$.tsx",
		children: void 0,
		preloads: ["/assets/_-Q_0qYCWT.js", "/assets/management-route-page-rIP1KYQl.js"]
	},
	"/master-distributor/account-setup": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/account-setup.tsx",
		children: void 0,
		preloads: ["/assets/account-setup-DEnutxeq.js"]
	},
	"/retailer/account-setup": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/account-setup.tsx",
		children: void 0,
		preloads: ["/assets/account-setup-BjHRAVQx.js"]
	},
	"/retailer/dashboard": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-NLZ77cvL.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-DKg6V5tc.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/activity-BG6uB5b9.js",
			"/assets/badge-check-CO4P0cYM.js",
			"/assets/banknote-8ucSb4IQ.js",
			"/assets/building-2-B60lMiOH.js",
			"/assets/tv-CazN8OPa.js",
			"/assets/credit-card-mnJY4ttf.js",
			"/assets/wallet-qY7Rwdfy.js",
			"/assets/flame-CbMIO3LU.js",
			"/assets/gift-B78tDi6e.js",
			"/assets/headphones-CkZysue-.js",
			"/assets/indian-rupee-hvlpcZ2x.js",
			"/assets/landmark-c8WuP_Jk.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/shield-GFJR3qco.js",
			"/assets/smartphone-Dtuc_YQ_.js",
			"/assets/wifi-K6XhXeBU.js",
			"/assets/operations-api-Br1pvC-H.js"
		]
	},
	"/retailer/settings": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-5ZTVFYIt.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-DKg6V5tc.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/badge-check-CO4P0cYM.js",
			"/assets/section-tabs-Ct7uJb-j.js",
			"/assets/eye-off-Q3psqXMi.js",
			"/assets/eye-BWpUro50.js",
			"/assets/key-round-D7jhaZnn.js",
			"/assets/contact-verification-center-YS-L9Avh.js",
			"/assets/mail-DK3PFsL4.js",
			"/assets/network-disieQDl.js",
			"/assets/phone-CpLrNlTk.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/shield-check-nsx3hwtR.js",
			"/assets/shield-GFJR3qco.js",
			"/assets/user-CkZhT4EA.js"
		]
	},
	"/distributor/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/index.tsx",
		children: void 0,
		preloads: ["/assets/distributor-CsC330xV.js"]
	},
	"/master-distributor/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/index.tsx",
		children: void 0,
		preloads: ["/assets/master-distributor-DJ_EhJ2W.js"]
	},
	"/admin/commissions/hierarchy": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/commissions/hierarchy.tsx",
		children: void 0,
		preloads: [
			"/assets/hierarchy-CjTm_yCf.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/section-tabs-Ct7uJb-j.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/plus-CSCsroA1.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/search-_56X_4ZM.js",
			"/assets/trash-2-B7ATp5um.js",
			"/assets/admin-api-PLzwbARO.js",
			"/assets/action-permission-notice-C-ZShizo.js"
		]
	},
	"/admin/profile/bank": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/profile/bank.tsx",
		children: void 0,
		preloads: ["/assets/bank-Ckzd-gIa.js"]
	},
	"/admin/profile/kyc": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/profile/kyc.tsx",
		children: void 0,
		preloads: ["/assets/kyc-Bo82uonk.js"]
	},
	"/distributor/aeps/balance-enquiry": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/balance-enquiry.tsx",
		children: void 0,
		preloads: ["/assets/balance-enquiry-CWmj9FTu.js", "/assets/network-aeps-transactions-DpWQm-up.js"]
	},
	"/distributor/aeps/cash-withdrawal": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/cash-withdrawal.tsx",
		children: void 0,
		preloads: ["/assets/cash-withdrawal-DmFiP7RD.js", "/assets/network-aeps-transactions-DpWQm-up.js"]
	},
	"/distributor/aeps/mini-statement": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/mini-statement.tsx",
		children: void 0,
		preloads: ["/assets/mini-statement-Bg_rTK2F.js", "/assets/network-aeps-transactions-DpWQm-up.js"]
	},
	"/distributor/aeps/transactions": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/transactions.tsx",
		children: void 0,
		preloads: ["/assets/transactions-DeOu2sXt.js", "/assets/network-aeps-transactions-DpWQm-up.js"]
	},
	"/distributor/profile/bank": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/profile/bank.tsx",
		children: void 0,
		preloads: ["/assets/bank-Cw81rFnA.js"]
	},
	"/distributor/profile/kyc": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/profile/kyc.tsx",
		children: void 0,
		preloads: ["/assets/kyc-BXr62YVK.js"]
	},
	"/distributor/wallet/transfer": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/wallet/transfer.tsx",
		children: void 0,
		preloads: [
			"/assets/transfer-llYPqKtN.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/arrow-right-left-j40-1V7u.js",
			"/assets/arrow-right-DIOMHBQg.js",
			"/assets/section-tabs-Ct7uJb-j.js",
			"/assets/user-round-check-CxooL4PK.js",
			"/assets/circle-check-Ri-EdMSx.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/indian-rupee-hvlpcZ2x.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/shield-check-nsx3hwtR.js",
			"/assets/wallet-cards--re0rWJC.js",
			"/assets/distributor-api-l68PhcDW.js",
			"/assets/action-permission-notice-C-ZShizo.js",
			"/assets/operations-api-Br1pvC-H.js"
		]
	},
	"/master-distributor/profile/bank": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/profile/bank.tsx",
		children: void 0,
		preloads: ["/assets/bank-C-TALfbl.js"]
	},
	"/master-distributor/profile/kyc": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/profile/kyc.tsx",
		children: void 0,
		preloads: ["/assets/kyc-D9IbwFQG.js"]
	},
	"/master-distributor/wallet/history": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/wallet/history.tsx",
		children: void 0,
		preloads: [
			"/assets/history-C8O4i2_H.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/module-placeholder-N-zEusxc.js"
		]
	},
	"/master-distributor/wallet/requests": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/wallet/requests.tsx",
		children: void 0,
		preloads: [
			"/assets/requests-Qd56cSxr.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/module-placeholder-N-zEusxc.js"
		]
	},
	"/master-distributor/wallet/transfer": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/wallet/transfer.tsx",
		children: void 0,
		preloads: [
			"/assets/transfer-Co2_mgIu.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/arrow-right-left-j40-1V7u.js",
			"/assets/arrow-right-DIOMHBQg.js",
			"/assets/section-tabs-Ct7uJb-j.js",
			"/assets/user-round-check-CxooL4PK.js",
			"/assets/circle-check-Ri-EdMSx.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/indian-rupee-hvlpcZ2x.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/shield-check-nsx3hwtR.js",
			"/assets/wallet-cards--re0rWJC.js",
			"/assets/master-distributor-api-7fY6LAIM.js",
			"/assets/action-permission-notice-C-ZShizo.js",
			"/assets/operations-api-Br1pvC-H.js"
		]
	},
	"/retailer/wallet/transfer": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/wallet/transfer.tsx",
		children: void 0,
		preloads: [
			"/assets/transfer-DfPuUWk7.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-DKg6V5tc.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/arrow-right-left-j40-1V7u.js",
			"/assets/arrow-right-DIOMHBQg.js",
			"/assets/section-tabs-Ct7uJb-j.js",
			"/assets/user-round-check-CxooL4PK.js",
			"/assets/circle-check-Ri-EdMSx.js",
			"/assets/indian-rupee-hvlpcZ2x.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/shield-check-nsx3hwtR.js",
			"/assets/wallet-cards--re0rWJC.js",
			"/assets/action-permission-notice-C-ZShizo.js",
			"/assets/operations-api-Br1pvC-H.js"
		]
	},
	"/admin/aeps/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/aeps/index.tsx",
		children: void 0,
		preloads: [
			"/assets/aeps-CVho8LVV.js",
			"/assets/aeps-workspace-CYbPiMUZ.js",
			"/assets/section-tabs-Ct7uJb-j.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/wallet-qY7Rwdfy.js",
			"/assets/settings-2-De3sl87W.js",
			"/assets/admin-api-PLzwbARO.js"
		]
	},
	"/admin/api-settings/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/api-settings/index.tsx",
		children: void 0,
		preloads: [
			"/assets/api-settings-CP2sT_oO.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/activity-BG6uB5b9.js",
			"/assets/section-tabs-Ct7uJb-j.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/x-BK5C6BIu.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/shield-check-nsx3hwtR.js",
			"/assets/admin-api-PLzwbARO.js",
			"/assets/super-admin-aeps-two-factor-DR39rRBp.js"
		]
	},
	"/admin/banking/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/banking/index.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-BpVz5oQL.js",
			"/assets/section-tabs-Ct7uJb-j.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/eye-BWpUro50.js",
			"/assets/landmark-c8WuP_Jk.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/x-BK5C6BIu.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/search-_56X_4ZM.js",
			"/assets/admin-api-PLzwbARO.js",
			"/assets/super-admin-aeps-two-factor-DR39rRBp.js"
		]
	},
	"/admin/commissions/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/commissions/index.tsx",
		children: void 0,
		preloads: [
			"/assets/commissions-r0Xvu9bf.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/section-tabs-Ct7uJb-j.js",
			"/assets/circle-check-Ri-EdMSx.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/indian-rupee-hvlpcZ2x.js",
			"/assets/layers-e1UUzRcd.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/x-BK5C6BIu.js",
			"/assets/pen-line-BEbgLAfO.js",
			"/assets/plus-CSCsroA1.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/search-_56X_4ZM.js",
			"/assets/admin-api-PLzwbARO.js",
			"/assets/operations-api-Br1pvC-H.js"
		]
	},
	"/admin/kyc/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/kyc/index.tsx",
		children: void 0,
		preloads: [
			"/assets/kyc-CSDrXiF-.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/section-tabs-Ct7uJb-j.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/eye-BWpUro50.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/x-BK5C6BIu.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/admin-api-PLzwbARO.js",
			"/assets/action-permission-notice-C-ZShizo.js"
		]
	},
	"/admin/legal/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/legal/index.tsx",
		children: void 0,
		preloads: [
			"/assets/legal-DlYOIX8l.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/section-tabs-Ct7uJb-j.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/file-check-corner-CcuLjC_j.js",
			"/assets/lock-keyhole-BAwU8jyC.js",
			"/assets/admin-feature-grid-B1Y2iFRf.js"
		]
	},
	"/admin/profile/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/profile/index.tsx",
		children: void 0,
		preloads: ["/assets/profile-DwVHSKBg.js", "/assets/admin-profile-page-DzSFM_ot.js"]
	},
	"/admin/reports/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/reports/index.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-BQgWTaiA.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/eye-BWpUro50.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/search-_56X_4ZM.js",
			"/assets/admin-api-PLzwbARO.js",
			"/assets/audit-detail-dialog-DafViTI-.js"
		]
	},
	"/admin/settings/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/settings/index.tsx",
		children: void 0,
		preloads: ["/assets/settings-CMJjSh0c.js", "/assets/admin-settings-page-pdPVeYS7.js"]
	},
	"/admin/settlements/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/settlements/index.tsx",
		children: void 0,
		preloads: ["/assets/settlements-B25m6lNh.js", "/assets/admin-layout-CjKDu6I3.js"]
	},
	"/admin/sms/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/sms/index.tsx",
		children: void 0,
		preloads: [
			"/assets/sms-vVdpVIHP.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/admin-feature-grid-B1Y2iFRf.js"
		]
	},
	"/admin/transactions/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/transactions/index.tsx",
		children: void 0,
		preloads: [
			"/assets/transactions-BGPu4nVh.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/section-tabs-Ct7uJb-j.js",
			"/assets/circle-check-Ri-EdMSx.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/eye-BWpUro50.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/x-BK5C6BIu.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/rotate-ccw-DHVP3kLv.js",
			"/assets/search-_56X_4ZM.js",
			"/assets/wallet-cards--re0rWJC.js",
			"/assets/admin-api-PLzwbARO.js",
			"/assets/action-permission-notice-C-ZShizo.js",
			"/assets/idempotency-key-CMznALKj.js"
		]
	},
	"/distributor/aeps/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/index.tsx",
		children: void 0,
		preloads: ["/assets/aeps-Cbh-aqDn.js", "/assets/aeps-workspace-CYbPiMUZ.js"]
	},
	"/distributor/commission/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/commission/index.tsx",
		children: void 0,
		preloads: [
			"/assets/commission-BA-zXpBq.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/indian-rupee-hvlpcZ2x.js",
			"/assets/admin-api-PLzwbARO.js",
			"/assets/distributor-api-l68PhcDW.js"
		]
	},
	"/distributor/profile/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/profile/index.tsx",
		children: void 0,
		preloads: ["/assets/profile-B0Ep4QGY.js", "/assets/admin-profile-page-DzSFM_ot.js"]
	},
	"/distributor/reports/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/reports/index.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-DssR8LxN.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/distributor-api-l68PhcDW.js"
		]
	},
	"/distributor/retailers/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/retailers/index.tsx",
		children: void 0,
		preloads: [
			"/assets/retailers-DXpVNXmG.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/store-C7I1y9vS.js",
			"/assets/user-plus-CG_sYZIH.js",
			"/assets/distributor-api-l68PhcDW.js"
		]
	},
	"/distributor/settings/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/settings/index.tsx",
		children: void 0,
		preloads: ["/assets/settings-D2tVyaUS.js", "/assets/admin-settings-page-pdPVeYS7.js"]
	},
	"/distributor/support/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/support/index.tsx",
		children: void 0,
		preloads: [
			"/assets/support-B4mWAR-n.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/headphones-CkZysue-.js"
		]
	},
	"/distributor/wallet/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/wallet/index.tsx",
		children: void 0,
		preloads: [
			"/assets/wallet-BptaCP8F.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/arrow-right-left-j40-1V7u.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/wallet-qY7Rwdfy.js",
			"/assets/gift-B78tDi6e.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/shield-check-nsx3hwtR.js",
			"/assets/wallet-cards--re0rWJC.js",
			"/assets/distributor-api-l68PhcDW.js",
			"/assets/operations-api-Br1pvC-H.js"
		]
	},
	"/master-distributor/aeps/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/aeps/index.tsx",
		children: void 0,
		preloads: ["/assets/aeps-sthdYi5i.js", "/assets/aeps-workspace-CYbPiMUZ.js"]
	},
	"/master-distributor/commission/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/commission/index.tsx",
		children: void 0,
		preloads: [
			"/assets/commission-vtkHNdHt.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/indian-rupee-hvlpcZ2x.js",
			"/assets/admin-api-PLzwbARO.js",
			"/assets/master-distributor-api-7fY6LAIM.js"
		]
	},
	"/master-distributor/kyc/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/kyc/index.tsx",
		children: void 0,
		preloads: [
			"/assets/kyc-CavdwrzA.js",
			"/assets/shield-check-nsx3hwtR.js",
			"/assets/module-placeholder-N-zEusxc.js"
		]
	},
	"/master-distributor/notifications/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/notifications/index.tsx",
		children: void 0,
		preloads: [
			"/assets/notifications-C_bQuqQa.js",
			"/assets/section-tabs-Ct7uJb-j.js",
			"/assets/module-placeholder-N-zEusxc.js"
		]
	},
	"/master-distributor/profile/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/profile/index.tsx",
		children: void 0,
		preloads: ["/assets/profile-DU9bWzoH.js", "/assets/admin-profile-page-DzSFM_ot.js"]
	},
	"/master-distributor/reports/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/reports/index.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-BzBYb1vE.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/master-distributor-api-7fY6LAIM.js"
		]
	},
	"/master-distributor/settings/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/settings/index.tsx",
		children: void 0,
		preloads: ["/assets/settings-ebcc25kx.js", "/assets/admin-settings-page-pdPVeYS7.js"]
	},
	"/master-distributor/support/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/support/index.tsx",
		children: void 0,
		preloads: [
			"/assets/support-BGAIJQ1Z.js",
			"/assets/headphones-CkZysue-.js",
			"/assets/module-placeholder-N-zEusxc.js"
		]
	},
	"/master-distributor/transactions/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/transactions/index.tsx",
		children: void 0,
		preloads: ["/assets/transactions-DQA82aqR.js", "/assets/network-aeps-transactions-DpWQm-up.js"]
	},
	"/master-distributor/wallet/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/wallet/index.tsx",
		children: void 0,
		preloads: [
			"/assets/wallet-BCjdEuAy.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/arrow-right-left-j40-1V7u.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/wallet-qY7Rwdfy.js",
			"/assets/gift-B78tDi6e.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/shield-check-nsx3hwtR.js",
			"/assets/wallet-cards--re0rWJC.js",
			"/assets/master-distributor-api-7fY6LAIM.js",
			"/assets/operations-api-Br1pvC-H.js"
		]
	},
	"/retailer/aeps/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/aeps/index.tsx",
		children: void 0,
		preloads: ["/assets/aeps-4L9nq9Ot.js", "/assets/aeps-workspace-CYbPiMUZ.js"]
	},
	"/retailer/bank/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/bank/index.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-B3Co5IcX.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-DKg6V5tc.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/badge-check-CO4P0cYM.js",
			"/assets/section-tabs-Ct7uJb-j.js",
			"/assets/building-2-B60lMiOH.js",
			"/assets/landmark-c8WuP_Jk.js",
			"/assets/map-pin-CnfjHzz8.js",
			"/assets/pen-line-BEbgLAfO.js",
			"/assets/plus-CSCsroA1.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/shield-check-nsx3hwtR.js",
			"/assets/trash-2-B7ATp5um.js",
			"/assets/action-permission-notice-C-ZShizo.js",
			"/assets/idempotency-key-CMznALKj.js",
			"/assets/role-aware-account-page-CiVz-ac6.js"
		]
	},
	"/retailer/kyc/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/kyc/index.tsx",
		children: void 0,
		preloads: [
			"/assets/kyc-CShOT_9R.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-DKg6V5tc.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/badge-check-CO4P0cYM.js",
			"/assets/section-tabs-Ct7uJb-j.js",
			"/assets/file-check-corner-CcuLjC_j.js",
			"/assets/wallet-qY7Rwdfy.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/trash-2-B7ATp5um.js",
			"/assets/action-permission-notice-C-ZShizo.js",
			"/assets/role-aware-account-page-CiVz-ac6.js"
		]
	},
	"/retailer/transactions/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/transactions/index.tsx",
		children: void 0,
		preloads: [
			"/assets/transactions-D1xmk6mB.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-DKg6V5tc.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/transaction-detail-dialog-Cv8UhahY.js",
			"/assets/receipt-YWqKnsde.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/search-_56X_4ZM.js",
			"/assets/operations-api-Br1pvC-H.js"
		]
	},
	"/retailer/wallet/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/wallet/index.tsx",
		children: void 0,
		preloads: [
			"/assets/wallet-Dwe8CdpI.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-DKg6V5tc.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/arrow-right-left-j40-1V7u.js",
			"/assets/wallet-qY7Rwdfy.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/shield-check-nsx3hwtR.js",
			"/assets/wallet-cards--re0rWJC.js",
			"/assets/operations-api-Br1pvC-H.js"
		]
	},
	"/admin/merchants/add/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/merchants/add/index.tsx",
		children: void 0,
		preloads: ["/assets/add-B85Lwhe6.js"]
	},
	"/admin/merchants/list/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/merchants/list/index.tsx",
		children: void 0,
		preloads: [
			"/assets/list-D_HC79Sj.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/badge-check-CO4P0cYM.js",
			"/assets/section-tabs-Ct7uJb-j.js",
			"/assets/building-2-B60lMiOH.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/eye-BWpUro50.js",
			"/assets/landmark-c8WuP_Jk.js",
			"/assets/loader-circle-DMWgVcVe.js",
			"/assets/x-BK5C6BIu.js",
			"/assets/refresh-cw-BB0Ms_XJ.js",
			"/assets/search-_56X_4ZM.js",
			"/assets/shield-check-nsx3hwtR.js",
			"/assets/wallet-cards--re0rWJC.js",
			"/assets/admin-api-PLzwbARO.js"
		]
	},
	"/distributor/retailers/add/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/retailers/add/index.tsx",
		children: void 0,
		preloads: ["/assets/add-vNIgw5pw.js"]
	},
	"/master-distributor/network/distributors/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/network/distributors/index.tsx",
		children: void 0,
		preloads: [
			"/assets/distributors-CIT7QHDU.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/network-disieQDl.js",
			"/assets/user-plus-CG_sYZIH.js",
			"/assets/master-distributor-api-7fY6LAIM.js"
		]
	},
	"/master-distributor/network/retailers/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/network/retailers/index.tsx",
		children: void 0,
		preloads: [
			"/assets/retailers-Ce4p7YC5.js",
			"/assets/store-C7I1y9vS.js",
			"/assets/module-placeholder-N-zEusxc.js"
		]
	},
	"/master-distributor/network/tree/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/network/tree/index.tsx",
		children: void 0,
		preloads: [
			"/assets/tree-DoRnz6gd.js",
			"/assets/role-hierarchy-ZhAUf5VZ.js",
			"/assets/section-tabs-Ct7uJb-j.js",
			"/assets/admin-layout-CjKDu6I3.js",
			"/assets/network-disieQDl.js",
			"/assets/master-distributor-api-7fY6LAIM.js"
		]
	},
	"/master-distributor/network/distributors/add/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/network/distributors/add/index.tsx",
		children: void 0,
		preloads: ["/assets/add-BGXUmKC_.js"]
	}
} });
//#endregion
export { tsrStartManifest };
