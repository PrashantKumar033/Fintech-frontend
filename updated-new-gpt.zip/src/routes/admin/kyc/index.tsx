import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useState } from "react";
import { Check, Eye, Loader2, RefreshCw, X } from "lucide-react";
import { ActionPermissionNotice } from "@/components/action-permission-notice";
import { AdminLayout, AdminPanel } from "@/components/admin/admin-layout";
import { useEffectiveAccess } from "@/hooks/use-effective-access";
import {
  adminApi,
  getAdminActor,
  type KycReviewDetail,
  type KycReviewListItem,
  type KycReviewStatus,
} from "@/lib/admin-api";
import { UI_PERMISSION } from "@/lib/ui-permissions";

export const Route = createFileRoute("/admin/kyc/")({ component: Kyc });
const statuses: Array<"" | KycReviewStatus> = [
  "",
  "PENDING",
  "UNDER_REVIEW",
  "APPROVED",
  "REJECTED",
];
const messageOf = (error: unknown) =>
  error instanceof Error ? error.message : "The KYC request could not be completed.";
const when = (value?: string | null) => (value ? new Date(value).toLocaleString("en-IN") : "—");

function Kyc() {
  const actor = getAdminActor();
  const { can } = useEffectiveAccess();
  const dedicatedSuperAdmin = actor?.kind === "SUPER_ADMIN";
  const canView = dedicatedSuperAdmin || can(UI_PERMISSION.KYC_VIEW, ["ADMIN"]);
  const canManage = dedicatedSuperAdmin || can(UI_PERMISSION.KYC_MANAGE, ["ADMIN"]);
  const [items, setItems] = useState<KycReviewListItem[]>([]);
  const [status, setStatus] = useState<"" | KycReviewStatus>("UNDER_REVIEW");
  const [page, setPage] = useState(1),
    [pages, setPages] = useState(1),
    [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false),
    [busy, setBusy] = useState(false);
  const [error, setError] = useState(""),
    [notice, setNotice] = useState("");
  const [detail, setDetail] = useState<KycReviewDetail | null>(null);
  const [remarks, setRemarks] = useState("");

  const load = useCallback(
    async (targetPage = 1) => {
      if (!canView) return;
      setLoading(true);
      setError("");
      try {
        const query = new URLSearchParams({ page: String(targetPage), limit: "20" });
        if (status) query.set("status", status);
        const response = await adminApi.kycReview.list(query.toString());
        setItems(response.data || []);
        setPage(response.pagination?.page || targetPage);
        setPages(Math.max(response.pagination?.totalPages || 1, 1));
        setTotal(response.pagination?.total || 0);
      } catch (caught) {
        setError(messageOf(caught));
      } finally {
        setLoading(false);
      }
    },
    [canView, status],
  );

  useEffect(() => {
    void load(1);
  }, [load]);

  async function inspect(item: KycReviewListItem) {
    setBusy(true);
    setError("");
    try {
      setDetail(await adminApi.kycReview.get(item.identityId, item.accountType));
    } catch (caught) {
      setError(messageOf(caught));
    } finally {
      setBusy(false);
    }
  }

  async function mutate(task: () => Promise<unknown>, success: string) {
    if (!canManage) return setError(`Permission ${UI_PERMISSION.KYC_MANAGE} is required.`);
    setBusy(true);
    setError("");
    setNotice("");
    try {
      await task();
      setNotice(success);
      if (detail) setDetail(await adminApi.kycReview.get(detail.identityId, detail.accountType));
      await load(page);
    } catch (caught) {
      setError(messageOf(caught));
    } finally {
      setBusy(false);
    }
  }

  function rejectionReason(label: string) {
    const reason = window.prompt(`Enter rejection reason for ${label}:`)?.trim();
    if (!reason) setError("A rejection reason is required.");
    return reason || null;
  }

  return (
    <AdminLayout
      active="kyc"
      eyebrow="Compliance"
      title="KYC approvals"
      description="Review documents and video evidence, then record the final KYC decision."
    >
      {!canView && (
        <ActionPermissionNotice
          permission={UI_PERMISSION.KYC_VIEW}
          title="KYC review queue is not enabled"
        />
      )}
      {canView && !canManage && (
        <div className="mb-5">
          <ActionPermissionNotice
            permission={UI_PERMISSION.KYC_MANAGE}
            title="KYC queue is read-only"
          />
        </div>
      )}
      {error && (
        <p
          role="alert"
          className="mb-4 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700"
        >
          {error}
        </p>
      )}
      {notice && (
        <p className="mb-4 rounded-xl bg-emerald-50 p-3 text-sm font-semibold text-emerald-700">
          {notice}
        </p>
      )}
      {canView && (
        <AdminPanel>
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <h2 className="text-xl font-black">Compliance review queue</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                {total} applications match the current filter.
              </p>
            </div>
            <div className="flex gap-2">
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as typeof status)}
                className="rounded-xl border border-border bg-white px-3 py-2.5 text-sm"
              >
                {statuses.map((value) => (
                  <option key={value || "ALL"} value={value}>
                    {value || "ALL STATUSES"}
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={() => void load(page)}
                disabled={loading}
                className="rounded-xl border border-border p-3 disabled:opacity-50"
              >
                <RefreshCw size={16} className={loading ? "animate-spin" : ""} />
              </button>
            </div>
          </div>
          <div className="mt-5 overflow-x-auto">
            <table className="w-full min-w-[760px] text-left text-sm">
              <thead>
                <tr className="border-b border-border text-xs uppercase text-muted-foreground">
                  <th className="p-3">Account</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Evidence</th>
                  <th className="p-3">Submitted</th>
                  <th className="p-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item) => (
                  <tr key={item.id} className="border-b border-border/70">
                    <td className="p-3">
                      <p className="font-bold">{item.identityId}</p>
                      <p className="text-xs text-muted-foreground">{item.accountType}</p>
                    </td>
                    <td className="p-3">
                      <Status value={item.status} />
                    </td>
                    <td className="p-3">
                      {item._count?.documents || 0} documents ·{" "}
                      {item.video ? `video ${item.video.status}` : "no video"}
                    </td>
                    <td className="p-3">{when(item.submittedAt || item.createdAt)}</td>
                    <td className="p-3 text-right">
                      <button
                        type="button"
                        onClick={() => void inspect(item)}
                        disabled={busy}
                        className="inline-flex items-center gap-2 rounded-lg border border-border px-3 py-2 font-bold disabled:opacity-50"
                      >
                        <Eye size={15} /> Review
                      </button>
                    </td>
                  </tr>
                ))}
                {!loading && !items.length && (
                  <tr>
                    <td colSpan={5} className="p-10 text-center text-muted-foreground">
                      No KYC applications found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          <div className="mt-4 flex items-center justify-between">
            <button
              disabled={page <= 1 || loading}
              onClick={() => void load(page - 1)}
              className="rounded-lg border border-border px-3 py-2 text-xs font-bold disabled:opacity-40"
            >
              Previous
            </button>
            <span className="text-xs font-bold">
              Page {page} of {pages}
            </span>
            <button
              disabled={page >= pages || loading}
              onClick={() => void load(page + 1)}
              className="rounded-lg border border-border px-3 py-2 text-xs font-bold disabled:opacity-40"
            >
              Next
            </button>
          </div>
        </AdminPanel>
      )}
      {detail && (
        <div
          className="fixed inset-0 z-50 grid place-items-center bg-black/50 p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-2xl bg-white p-6 shadow-xl">
            <div className="flex justify-between gap-4">
              <div>
                <p className="text-xs font-black uppercase text-primary">{detail.accountType}</p>
                <h2 className="mt-1 text-xl font-black">KYC {detail.identityId}</h2>
                <Status value={detail.status} />
              </div>
              <button
                aria-label="Close review"
                onClick={() => setDetail(null)}
                className="rounded-xl border border-border p-2"
              >
                <X />
              </button>
            </div>
            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              {detail.documents.map((document) => (
                <article key={document.id} className="rounded-xl border border-border p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h3 className="font-black">{document.documentType.replaceAll("_", " ")}</h3>
                      <p className="text-xs text-muted-foreground">
                        {document.status}
                        {document.verificationStatus ? ` · ${document.verificationStatus}` : ""}
                      </p>
                    </div>
                    {document.previewUrl && (
                      <a
                        href={document.previewUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-xs font-bold text-primary"
                      >
                        Preview
                      </a>
                    )}
                  </div>
                  {canManage && detail.status === "UNDER_REVIEW" && (
                    <div className="mt-4 flex gap-2">
                      <button
                        disabled={busy}
                        onClick={() =>
                          void mutate(
                            () =>
                              adminApi.kycReview.document(
                                detail.identityId,
                                detail.accountType,
                                document.id,
                                "APPROVED",
                              ),
                            `${document.documentType} approved.`,
                          )
                        }
                        className="flex-1 rounded-lg bg-emerald-50 py-2 text-xs font-bold text-emerald-700"
                      >
                        <Check className="mr-1 inline" size={14} />
                        Approve
                      </button>
                      <button
                        disabled={busy}
                        onClick={() => {
                          const reason = rejectionReason(document.documentType);
                          if (reason)
                            void mutate(
                              () =>
                                adminApi.kycReview.document(
                                  detail.identityId,
                                  detail.accountType,
                                  document.id,
                                  "REJECTED",
                                  reason,
                                ),
                              `${document.documentType} rejected.`,
                            );
                        }}
                        className="flex-1 rounded-lg bg-red-50 py-2 text-xs font-bold text-red-700"
                      >
                        <X className="mr-1 inline" size={14} />
                        Reject
                      </button>
                    </div>
                  )}
                </article>
              ))}
            </div>
            {detail.video && (
              <article className="mt-3 rounded-xl border border-border p-4">
                <div className="flex justify-between">
                  <div>
                    <h3 className="font-black">Verification video</h3>
                    <p className="text-xs text-muted-foreground">{detail.video.status}</p>
                  </div>
                  {detail.video.previewUrl && (
                    <a
                      href={detail.video.previewUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="text-xs font-bold text-primary"
                    >
                      Preview video
                    </a>
                  )}
                </div>
                {canManage && detail.status === "UNDER_REVIEW" && (
                  <div className="mt-4 flex gap-2">
                    <button
                      disabled={busy}
                      onClick={() =>
                        void mutate(
                          () =>
                            adminApi.kycReview.video(
                              detail.identityId,
                              detail.accountType,
                              "APPROVED",
                            ),
                          "Video approved.",
                        )
                      }
                      className="rounded-lg bg-emerald-50 px-4 py-2 text-xs font-bold text-emerald-700"
                    >
                      Approve video
                    </button>
                    <button
                      disabled={busy}
                      onClick={() => {
                        const reason = rejectionReason("verification video");
                        if (reason)
                          void mutate(
                            () =>
                              adminApi.kycReview.video(
                                detail.identityId,
                                detail.accountType,
                                "REJECTED",
                                reason,
                              ),
                            "Video rejected.",
                          );
                      }}
                      className="rounded-lg bg-red-50 px-4 py-2 text-xs font-bold text-red-700"
                    >
                      Reject video
                    </button>
                  </div>
                )}
              </article>
            )}
            <textarea
              value={remarks}
              onChange={(e) => setRemarks(e.target.value)}
              maxLength={1000}
              placeholder="Final reviewer remarks"
              className="mt-5 min-h-24 w-full rounded-xl border border-border p-3 text-sm"
            />
            {canManage && detail.status === "UNDER_REVIEW" && (
              <div className="mt-3 flex justify-end gap-2">
                <button
                  disabled={busy}
                  onClick={() => {
                    if (!remarks.trim()) return setError("Rejection remarks are required.");
                    void mutate(
                      () =>
                        adminApi.kycReview.reject(
                          detail.identityId,
                          detail.accountType,
                          remarks.trim(),
                        ),
                      "KYC rejected.",
                    );
                  }}
                  className="rounded-xl border border-red-200 px-5 py-3 text-sm font-bold text-red-700"
                >
                  Reject KYC
                </button>
                <button
                  disabled={busy}
                  onClick={() =>
                    void mutate(
                      () =>
                        adminApi.kycReview.approve(
                          detail.identityId,
                          detail.accountType,
                          remarks.trim() || undefined,
                        ),
                      "KYC approved.",
                    )
                  }
                  className="rounded-xl bg-primary px-5 py-3 text-sm font-bold text-white"
                >
                  {busy ? <Loader2 className="animate-spin" size={17} /> : "Approve KYC"}
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </AdminLayout>
  );
}

function Status({ value }: { value: string }) {
  const tone =
    value === "APPROVED"
      ? "bg-emerald-50 text-emerald-700"
      : value === "REJECTED"
        ? "bg-red-50 text-red-700"
        : "bg-amber-50 text-amber-700";
  return (
    <span className={`mt-1 inline-flex rounded-full px-2.5 py-1 text-[10px] font-black ${tone}`}>
      {value.replaceAll("_", " ")}
    </span>
  );
}
