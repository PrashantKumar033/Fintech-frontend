import { r as __toESM } from "../_runtime.mjs";
import { c as getSession } from "./role-hierarchy-B8AZOwBW.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { Y as Network, s as Users } from "../_libs/lucide-react.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-Cf_Fn8iZ.mjs";
import { t as masterDistributorApi } from "./master-distributor-api-DnCFiedI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tree-CdLaa-m0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	const s = getSession(), [rows, setRows] = (0, import_react.useState)([]), [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (s) masterDistributorApi.distributors(s.identity.id).then((v) => setRows(Array.isArray(v) ? v : [])).catch((e) => setError(e instanceof Error ? e.message : "Network unavailable."));
	}, [s?.identity.id]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "merchants",
		eyebrow: "Hierarchy",
		title: "Distribution network",
		description: "Your direct Distributor branches from the live hierarchy service.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 rounded-xl bg-red-50 p-3 text-sm text-red-700",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-primary p-4 text-primary-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Network, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 font-black",
					children: "Master Distributor"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ml-6 border-l border-border pl-6",
				children: [rows.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "my-4 rounded-xl border border-border p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-black",
							children: ["Distributor ", r.childUserId || r.id]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: r.isActive === false ? "Inactive" : "Active"
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 rounded-lg bg-muted p-2 text-xs text-muted-foreground",
						children: "Retailer branch aggregation pending backend support."
					})]
				}, r.id || i)), !rows.length && !error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-8 text-sm text-muted-foreground",
					children: "No direct Distributor branches found."
				})]
			})
		] })
	});
}
//#endregion
export { Page as component };
