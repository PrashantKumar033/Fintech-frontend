import { r as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { F as RefreshCw, It as Eye, Qt as Check, lt as LoaderCircle, r as X } from "../_libs/lucide-react.mjs";
import { a as useEffectiveAccess, r as UI_PERMISSION } from "./section-tabs-DrewjFLo.mjs";
import { n as adminApi, s as getAdminActor } from "./admin-api-DUkIMU28.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-Cf_Fn8iZ.mjs";
import { t as ActionPermissionNotice } from "./action-permission-notice-CGOJQx-x.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kyc-5U9EUHGO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var statuses = [
	"",
	"PENDING",
	"UNDER_REVIEW",
	"APPROVED",
	"REJECTED"
];
var messageOf = (error) => error instanceof Error ? error.message : "The KYC request could not be completed.";
var when = (value) => value ? new Date(value).toLocaleString("en-IN") : "—";
function Kyc() {
	const actor = getAdminActor();
	const { can } = useEffectiveAccess();
	const dedicatedSuperAdmin = actor?.kind === "SUPER_ADMIN";
	const canView = dedicatedSuperAdmin || can(UI_PERMISSION.KYC_VIEW, ["ADMIN"]);
	const canManage = dedicatedSuperAdmin || can(UI_PERMISSION.KYC_MANAGE, ["ADMIN"]);
	const [items, setItems] = (0, import_react.useState)([]);
	const [status, setStatus] = (0, import_react.useState)("UNDER_REVIEW");
	const [page, setPage] = (0, import_react.useState)(1), [pages, setPages] = (0, import_react.useState)(1), [total, setTotal] = (0, import_react.useState)(0);
	const [loading, setLoading] = (0, import_react.useState)(false), [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(""), [notice, setNotice] = (0, import_react.useState)("");
	const [detail, setDetail] = (0, import_react.useState)(null);
	const [remarks, setRemarks] = (0, import_react.useState)("");
	const load = (0, import_react.useCallback)(async (targetPage = 1) => {
		if (!canView) return;
		setLoading(true);
		setError("");
		try {
			const query = new URLSearchParams({
				page: String(targetPage),
				limit: "20"
			});
			if (status) query.set("status", status);
			const response = await adminApi.kycReview.list(query.toString());
			setItems(response.data || []);
			setPage(response.pagination?.page || targetPage);
			setPages(Math.max(response.pagination?.totalPages || 1, 1));
			setTotal(response.pagination?.total || 0);
		} catch (caught) {
			setError(messageOf(caught));
		} finally {
			setLoading(false);
		}
	}, [canView, status]);
	(0, import_react.useEffect)(() => {
		load(1);
	}, [load]);
	async function inspect(item) {
		setBusy(true);
		setError("");
		try {
			setDetail(await adminApi.kycReview.get(item.identityId, item.accountType));
		} catch (caught) {
			setError(messageOf(caught));
		} finally {
			setBusy(false);
		}
	}
	async function mutate(task, success) {
		if (!canManage) return setError(`Permission ${UI_PERMISSION.KYC_MANAGE} is required.`);
		setBusy(true);
		setError("");
		setNotice("");
		try {
			await task();
			setNotice(success);
			if (detail) setDetail(await adminApi.kycReview.get(detail.identityId, detail.accountType));
			await load(page);
		} catch (caught) {
			setError(messageOf(caught));
		} finally {
			setBusy(false);
		}
	}
	function rejectionReason(label) {
		const reason = window.prompt(`Enter rejection reason for ${label}:`)?.trim();
		if (!reason) setError("A rejection reason is required.");
		return reason || null;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "kyc",
		eyebrow: "Compliance",
		title: "KYC approvals",
		description: "Review documents and video evidence, then record the final KYC decision.",
		children: [
			!canView && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionPermissionNotice, {
				permission: UI_PERMISSION.KYC_VIEW,
				title: "KYC review queue is not enabled"
			}),
			canView && !canManage && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionPermissionNotice, {
					permission: UI_PERMISSION.KYC_MANAGE,
					title: "KYC queue is read-only"
				})
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mb-4 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700",
				children: error
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-4 rounded-xl bg-emerald-50 p-3 text-sm font-semibold text-emerald-700",
				children: notice
			}),
			canView && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-black",
						children: "Compliance review queue"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: [total, " applications match the current filter."]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: status,
							onChange: (e) => setStatus(e.target.value),
							className: "rounded-xl border border-border bg-white px-3 py-2.5 text-sm",
							children: statuses.map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value,
								children: value || "ALL STATUSES"
							}, value || "ALL"))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => void load(page),
							disabled: loading,
							className: "rounded-xl border border-border p-3 disabled:opacity-50",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
								size: 16,
								className: loading ? "animate-spin" : ""
							})
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[760px] text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border text-xs uppercase text-muted-foreground",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Account"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Status"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Evidence"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3",
									children: "Submitted"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "p-3 text-right",
									children: "Action"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border/70",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-bold",
										children: item.identityId
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground",
										children: item.accountType
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: item.status })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "p-3",
									children: [
										item._count?.documents || 0,
										" documents ·",
										" ",
										item.video ? `video ${item.video.status}` : "no video"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3",
									children: when(item.submittedAt || item.createdAt)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "p-3 text-right",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										onClick: () => void inspect(item),
										disabled: busy,
										className: "inline-flex items-center gap-2 rounded-lg border border-border px-3 py-2 font-bold disabled:opacity-50",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 15 }), " Review"]
									})
								})
							]
						}, item.id)), !loading && !items.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							colSpan: 5,
							className: "p-10 text-center text-muted-foreground",
							children: "No KYC applications found."
						}) })] })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center justify-between",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: page <= 1 || loading,
							onClick: () => void load(page - 1),
							className: "rounded-lg border border-border px-3 py-2 text-xs font-bold disabled:opacity-40",
							children: "Previous"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs font-bold",
							children: [
								"Page ",
								page,
								" of ",
								pages
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: page >= pages || loading,
							onClick: () => void load(page + 1),
							className: "rounded-lg border border-border px-3 py-2 text-xs font-bold disabled:opacity-40",
							children: "Next"
						})
					]
				})
			] }),
			detail && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-50 grid place-items-center bg-black/50 p-4",
				role: "dialog",
				"aria-modal": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-2xl bg-white p-6 shadow-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-black uppercase text-primary",
									children: detail.accountType
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
									className: "mt-1 text-xl font-black",
									children: ["KYC ", detail.identityId]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: detail.status })
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								"aria-label": "Close review",
								onClick: () => setDetail(null),
								className: "rounded-xl border border-border p-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-6 grid gap-3 sm:grid-cols-2",
							children: detail.documents.map((document) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "rounded-xl border border-border p-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-black",
										children: document.documentType.replaceAll("_", " ")
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground",
										children: [document.status, document.verificationStatus ? ` · ${document.verificationStatus}` : ""]
									})] }), document.previewUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: document.previewUrl,
										target: "_blank",
										rel: "noreferrer",
										className: "text-xs font-bold text-primary",
										children: "Preview"
									})]
								}), canManage && detail.status === "UNDER_REVIEW" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-4 flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										disabled: busy,
										onClick: () => void mutate(() => adminApi.kycReview.document(detail.identityId, detail.accountType, document.id, "APPROVED"), `${document.documentType} approved.`),
										className: "flex-1 rounded-lg bg-emerald-50 py-2 text-xs font-bold text-emerald-700",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {
											className: "mr-1 inline",
											size: 14
										}), "Approve"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										disabled: busy,
										onClick: () => {
											const reason = rejectionReason(document.documentType);
											if (reason) mutate(() => adminApi.kycReview.document(detail.identityId, detail.accountType, document.id, "REJECTED", reason), `${document.documentType} rejected.`);
										},
										className: "flex-1 rounded-lg bg-red-50 py-2 text-xs font-bold text-red-700",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {
											className: "mr-1 inline",
											size: 14
										}), "Reject"]
									})]
								})]
							}, document.id))
						}),
						detail.video && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "mt-3 rounded-xl border border-border p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-black",
									children: "Verification video"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: detail.video.status
								})] }), detail.video.previewUrl && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: detail.video.previewUrl,
									target: "_blank",
									rel: "noreferrer",
									className: "text-xs font-bold text-primary",
									children: "Preview video"
								})]
							}), canManage && detail.status === "UNDER_REVIEW" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									disabled: busy,
									onClick: () => void mutate(() => adminApi.kycReview.video(detail.identityId, detail.accountType, "APPROVED"), "Video approved."),
									className: "rounded-lg bg-emerald-50 px-4 py-2 text-xs font-bold text-emerald-700",
									children: "Approve video"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									disabled: busy,
									onClick: () => {
										const reason = rejectionReason("verification video");
										if (reason) mutate(() => adminApi.kycReview.video(detail.identityId, detail.accountType, "REJECTED", reason), "Video rejected.");
									},
									className: "rounded-lg bg-red-50 px-4 py-2 text-xs font-bold text-red-700",
									children: "Reject video"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							value: remarks,
							onChange: (e) => setRemarks(e.target.value),
							maxLength: 1e3,
							placeholder: "Final reviewer remarks",
							className: "mt-5 min-h-24 w-full rounded-xl border border-border p-3 text-sm"
						}),
						canManage && detail.status === "UNDER_REVIEW" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: busy,
								onClick: () => {
									if (!remarks.trim()) return setError("Rejection remarks are required.");
									mutate(() => adminApi.kycReview.reject(detail.identityId, detail.accountType, remarks.trim()), "KYC rejected.");
								},
								className: "rounded-xl border border-red-200 px-5 py-3 text-sm font-bold text-red-700",
								children: "Reject KYC"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: busy,
								onClick: () => void mutate(() => adminApi.kycReview.approve(detail.identityId, detail.accountType, remarks.trim() || void 0), "KYC approved."),
								className: "rounded-xl bg-primary px-5 py-3 text-sm font-bold text-white",
								children: busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
									className: "animate-spin",
									size: 17
								}) : "Approve KYC"
							})]
						})
					]
				})
			})
		]
	});
}
function Status({ value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `mt-1 inline-flex rounded-full px-2.5 py-1 text-[10px] font-black ${value === "APPROVED" ? "bg-emerald-50 text-emerald-700" : value === "REJECTED" ? "bg-red-50 text-red-700" : "bg-amber-50 text-amber-700"}`,
		children: value.replaceAll("_", " ")
	});
}
//#endregion
export { Kyc as component };
