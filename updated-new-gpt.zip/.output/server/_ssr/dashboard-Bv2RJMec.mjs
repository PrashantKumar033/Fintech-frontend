import { r as __toESM } from "../_runtime.mjs";
import { a as credentialsPending, c as getSession, y as signedInHome } from "./role-hierarchy-B8AZOwBW.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { Dt as Fuel, Et as Gift, F as RefreshCw, Kt as CircleDollarSign, Ot as Flame, Rt as Droplets, S as Smartphone, St as Headphones, U as Plane, Vt as CreditCard, Yt as ChevronRight, a as Wallet, dt as Lightbulb, gn as Activity, gt as Landmark, i as Wifi, kt as FingerprintPattern, ln as BadgeCheck, nn as Bus, p as Tv, rn as Building2, sn as Banknote, w as Shield, yt as IndianRupee } from "../_libs/lucide-react.mjs";
import { t as BusinessPage } from "./business-page-CoovTN0N.mjs";
import { n as operationsApi } from "./operations-api-DCS6pUHX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-Bv2RJMec.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var serviceGroups = [
	{
		title: "Money transfer & payments",
		eyebrow: "DMT / AEPS",
		services: [
			["Wallet to Wallet", Wallet],
			["Money Transfer", Banknote],
			["Credit Card Bills", CreditCard],
			["CMS", Building2],
			["DMT 2", RefreshCw]
		]
	},
	{
		title: "Bills & utilities",
		eyebrow: "BBPS",
		services: [
			["Electricity", Lightbulb],
			["Water", Droplets],
			["Gas", Flame],
			["LPG Booking", Fuel],
			["Insurance", Shield],
			["EMI", IndianRupee],
			["FASTag", CreditCard],
			["Loan", Landmark]
		]
	},
	{
		title: "Aadhaar enabled services",
		eyebrow: "AEPS",
		services: [
			["AEPS", FingerprintPattern],
			["Aadhaar Pay", BadgeCheck],
			["Settlement", Landmark],
			["Cash Deposit", Banknote],
			["Settlement 2", CircleDollarSign]
		]
	},
	{
		title: "Recharge & travel",
		eyebrow: "RECHARGE",
		services: [
			["Mobile Recharge", Smartphone],
			["DTH", Tv],
			["Broadband", Wifi],
			["Bus Booking", Bus],
			["Flight Booking", Plane]
		]
	}
];
function DashboardPage() {
	const navigate = useNavigate();
	const [session, setSession] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const sync = () => {
			const stored = getSession();
			if (!stored) {
				navigate({ to: "/login" });
				return;
			}
			setSession(stored);
			if (credentialsPending(stored.identity)) window.location.replace(signedInHome(stored));
		};
		sync();
		window.addEventListener("pageshow", sync);
		return () => window.removeEventListener("pageshow", sync);
	}, [navigate]);
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "animate-spin text-primary" })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BusinessPage, {
		identity: session.identity,
		active: "dashboard",
		showPageHeader: false,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardHome, { identity: session.identity })
	});
}
function DashboardHome({ identity }) {
	const firstName = identity.fullName?.split(" ")[0] || identity.username;
	const [balances, setBalances] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const activeSession = getSession();
		if (activeSession) operationsApi.balances(activeSession.accessToken, identity.id).then(setBalances).catch(() => setBalances(null));
	}, [identity.id]);
	const money = (value = 0) => new Intl.NumberFormat("en-IN", {
		style: "currency",
		currency: "INR"
	}).format(value);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-[1500px] space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative overflow-hidden rounded-[1.25rem] bg-secondary p-6 text-secondary-foreground shadow-elegant sm:p-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-16 -top-20 h-64 w-64 rounded-full bg-primary/20 blur-3xl" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex flex-col justify-between gap-6 xl:flex-row xl:items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-white/65",
							children: "Good to see you again"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-1 text-3xl font-extrabold sm:text-4xl",
							children: [
								"Hi, ",
								firstName,
								"!"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xl text-sm text-white/65",
							children: "Manage payments, assisted banking and your retailer business from one secure workspace."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroMetric, {
								label: "Main wallet",
								value: money(balances?.wallets.main)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroMetric, {
								label: "AEPS wallet",
								value: money(balances?.wallets.aeps)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroMetric, {
								label: "Profit",
								value: money(balances?.wallets.profit)
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
						icon: Wallet,
						label: "Available balance",
						value: money(balances?.wallets.main),
						note: "Live main wallet balance"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
						icon: Activity,
						label: "Today's transactions",
						value: "0",
						note: "No activity yet"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
						icon: IndianRupee,
						label: "Today's volume",
						value: "₹0.00",
						note: "All services"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
						icon: Gift,
						label: "Monthly commission",
						value: "₹0.00",
						note: "Current month"
					})
				]
			}),
			serviceGroups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ServiceSection, {
				title: group.title,
				eyebrow: group.eyebrow,
				services: group.services
			}, group.title)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col justify-between gap-4 rounded-2xl border border-border bg-card p-5 shadow-soft sm:flex-row sm:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-11 w-11 place-items-center rounded-xl bg-primary/10 text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Headphones, { size: 20 })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-bold text-secondary",
						children: "Offline service & support"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Need assistance with a transaction or service?"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "rounded-xl bg-secondary px-5 py-3 text-sm font-semibold text-secondary-foreground",
					children: "Contact service desk"
				})]
			})
		]
	});
}
function HeroMetric({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-24 rounded-2xl border border-white/10 bg-white/10 p-3 backdrop-blur",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] uppercase tracking-wider text-white/55",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-lg font-extrabold",
			children: value
		})]
	});
}
function Summary({ icon: Icon, label, value, note }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-card p-5 shadow-soft",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "grid h-10 w-10 place-items-center rounded-xl bg-mint text-secondary",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 18 })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "rounded-full bg-emerald-50 px-2 py-1 text-[10px] font-bold text-emerald-700",
					children: "LIVE"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs font-semibold uppercase tracking-wider text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-2xl font-extrabold text-secondary",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted-foreground",
				children: note
			})
		]
	});
}
function ServiceSection({ title, eyebrow, services }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-border bg-card p-5 shadow-soft sm:p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-end justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[10px] font-extrabold uppercase tracking-[.2em] text-primary",
				children: eyebrow
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 text-lg font-extrabold text-secondary",
				children: title
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				className: "hidden items-center gap-1 text-xs font-bold text-secondary sm:flex",
				children: ["View all ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { size: 14 })]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-5 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5 2xl:grid-cols-8",
			children: services.map(([label, Icon]) => {
				const active = label === "AEPS" || label === "Aadhaar Pay" || label === "Cash Deposit";
				const card = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-11 w-11 place-items-center rounded-xl bg-card text-secondary shadow-sm transition group-hover:bg-primary group-hover:text-primary-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 20 })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-3 block text-xs font-bold leading-tight text-secondary",
						children: label
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `mt-1 block text-[10px] ${active ? "font-bold text-primary" : "text-muted-foreground"}`,
						children: active ? "Open service" : "Coming soon"
					})
				] });
				return active ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/retailer/aeps",
					className: "group rounded-2xl border border-border bg-background p-4 text-left transition hover:-translate-y-0.5 hover:border-primary/40 hover:bg-mint hover:shadow-soft",
					children: card
				}, label) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: true,
					className: "group rounded-2xl border border-border bg-background p-4 text-left opacity-70",
					children: card
				}, label);
			})
		})]
	});
}
//#endregion
export { DashboardPage as component };
