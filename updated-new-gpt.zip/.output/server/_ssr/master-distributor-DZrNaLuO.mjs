import { o as MasterDashboard } from "./router-DughR4Dc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/master-distributor-DZrNaLuO.js
var SplitComponent = MasterDashboard;
//#endregion
export { SplitComponent as component };
