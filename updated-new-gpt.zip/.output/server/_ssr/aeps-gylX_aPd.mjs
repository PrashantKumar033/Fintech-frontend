import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { gt as Landmark, jt as FileText, sn as Banknote } from "../_libs/lucide-react.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-Cf_Fn8iZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/aeps-gylX_aPd.js
var import_jsx_runtime = require_jsx_runtime();
function AepsOverview() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "transactions",
		eyebrow: "Assisted banking",
		title: "AEPS monitoring",
		description: "Distributor-facing monitoring modules. Customer biometric execution remains a Retailer operation.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 md:grid-cols-2",
			children: [
				[
					"Transactions",
					"Monitor AEPS activity",
					"/distributor/aeps/transactions",
					FileText
				],
				[
					"Cash withdrawal",
					"Operational reference page",
					"/distributor/aeps/cash-withdrawal",
					Banknote
				],
				[
					"Balance enquiry",
					"Operational reference page",
					"/distributor/aeps/balance-enquiry",
					Landmark
				],
				[
					"Mini statement",
					"Operational reference page",
					"/distributor/aeps/mini-statement",
					FileText
				]
			].map(([title, text, to, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: to,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
					className: "h-full transition hover:border-primary",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "text-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 text-lg font-black",
							children: title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: text
						})
					]
				})
			}, title))
		})
	});
}
//#endregion
export { AepsOverview as component };
