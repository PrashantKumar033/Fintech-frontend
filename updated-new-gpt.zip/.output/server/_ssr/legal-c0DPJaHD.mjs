import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { E as ShieldAlert, I as RefreshCcw, Nt as FileCheckCorner, ct as LockKeyhole } from "../_libs/lucide-react.mjs";
import { t as AdminLayout } from "./admin-layout-Cf_Fn8iZ.mjs";
import { t as AdminFeatureGrid } from "./admin-feature-grid-SQgrkdcH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/legal-c0DPJaHD.js
var import_jsx_runtime = require_jsx_runtime();
function Legal() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "legal",
		eyebrow: "Content governance",
		title: "Legal documents",
		description: "Manage customer-facing policy content with a controlled publication workflow.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminFeatureGrid, { features: [
			{
				title: "Terms & conditions",
				description: "Draft and publish platform terms and conditions.",
				icon: FileCheckCorner
			},
			{
				title: "Privacy policy",
				description: "Maintain privacy, data-use and consent documentation.",
				icon: LockKeyhole
			},
			{
				title: "Refund policy",
				description: "Manage refund and cancellation policy content.",
				icon: RefreshCcw
			},
			{
				title: "Security tips",
				description: "Publish account and transaction security guidance.",
				icon: ShieldAlert
			}
		] })
	});
}
//#endregion
export { Legal as component };
