//#region node_modules/.nitro/vite/services/ssr/assets/about-team-B3yE-m2r.js
var about_team_default = "/assets/about-team-BRJ1zQsx.png";
//#endregion
export { about_team_default as t };
