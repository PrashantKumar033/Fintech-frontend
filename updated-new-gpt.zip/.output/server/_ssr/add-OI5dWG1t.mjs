import { i as CreateMemberPage } from "./router-DughR4Dc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/add-OI5dWG1t.js
var SplitComponent = CreateMemberPage;
//#endregion
export { SplitComponent as component };
