import { r as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { T as ShieldCheck, lt as LoaderCircle, r as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/audit-detail-dialog-DPdYiEwE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var label = (value) => value.replace(/([A-Z])/g, " $1").replaceAll("_", " ").trim();
var time = (value) => {
	if (!value) return "—";
	const parsed = new Date(value);
	return Number.isNaN(parsed.getTime()) ? value : parsed.toLocaleString("en-IN");
};
function AuditDetailDialog({ auditId, loadAudit, onClose }) {
	const [detail, setDetail] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		let active = true;
		setDetail(null);
		setError("");
		setLoading(true);
		loadAudit(auditId).then((result) => {
			if (active) setDetail(result);
		}).catch((value) => {
			if (!active) return;
			setError(value instanceof Error ? value.message : "Unable to load audit detail.");
		}).finally(() => {
			if (active) setLoading(false);
		});
		return () => {
			active = false;
		};
	}, [auditId, loadAudit]);
	const fields = detail ? [
		["Event ID", detail.eventId],
		["Login ID", detail.loginId],
		["Role", detail.role],
		["Service", detail.service],
		["Action", detail.action],
		["Status", detail.status],
		["HTTP Method", detail.httpMethod],
		["Endpoint", detail.endpoint],
		["Status Code", detail.statusCode],
		["IP Address", detail.ipAddress],
		["Identity ID", detail.identityId],
		["Session ID", detail.sessionId],
		["Created At", time(detail.createdAt)]
	] : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[110] grid place-items-center bg-secondary/60 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "audit-detail-title",
			className: "max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 20 })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[10px] font-extrabold uppercase tracking-[0.16em] text-primary",
								children: "Audit record"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								id: "audit-detail-title",
								className: "mt-1 text-xl font-black text-secondary",
								children: detail?.action ? label(detail.action) : "Activity details"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 break-all text-xs text-muted-foreground",
								children: auditId
							})
						] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						"aria-label": "Close audit detail",
						className: "rounded-lg border border-border p-2 text-muted-foreground hover:text-secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
					})]
				}),
				loading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid min-h-52 place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-sm font-semibold text-muted-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
							size: 18,
							className: "animate-spin text-primary"
						}), "Loading audit details…"]
					})
				}),
				!loading && error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					role: "alert",
					className: "mt-5 rounded-xl bg-red-50 p-4 text-sm font-semibold text-red-700",
					children: error
				}),
				!loading && detail && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
					children: fields.map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-border bg-muted/30 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[9px] font-extrabold uppercase tracking-wide text-muted-foreground",
							children: key
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 break-all text-xs font-bold text-secondary",
							children: value === null || value === void 0 || value === "" ? "—" : String(value)
						})]
					}, key))
				}), detail.metadata && Object.keys(detail.metadata).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 rounded-xl border border-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-b border-border px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-black text-secondary",
							children: "Event metadata"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-[10px] text-muted-foreground",
							children: "Extra context stored by the audit service for this event."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "max-h-72 overflow-auto whitespace-pre-wrap break-words p-4 text-[11px] leading-5 text-secondary",
						children: JSON.stringify(detail.metadata, null, 2)
					})]
				})] })
			]
		})
	});
}
//#endregion
export { AuditDetailDialog as t };
