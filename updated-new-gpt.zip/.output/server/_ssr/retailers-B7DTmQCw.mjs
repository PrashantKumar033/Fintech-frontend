import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { y as Store } from "../_libs/lucide-react.mjs";
import { t as MasterDistributorModulePlaceholder } from "./module-placeholder-C_Fr-5KU.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/retailers-B7DTmQCw.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MasterDistributorModulePlaceholder, {
		active: "merchants",
		icon: Store,
		title: "Downstream retailers",
		description: "Retailers managed through your Distributor network.",
		pending: "The backend does not yet expose a role-protected recursive retailer listing for a Master Distributor. This page is isolated and ready to consume that contract without exposing another network's data."
	});
}
//#endregion
export { Page as component };
