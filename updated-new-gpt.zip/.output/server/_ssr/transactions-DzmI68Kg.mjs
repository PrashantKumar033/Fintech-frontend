import { r as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { E as ShieldAlert, F as RefreshCw, It as Eye, N as RotateCcw, Wt as CircleX, k as Search, lt as LoaderCircle, o as WalletCards, qt as CircleCheck, r as X } from "../_libs/lucide-react.mjs";
import { a as useEffectiveAccess, r as UI_PERMISSION } from "./section-tabs-DrewjFLo.mjs";
import { n as adminApi, s as getAdminActor, t as AdminApiError } from "./admin-api-DUkIMU28.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-Cf_Fn8iZ.mjs";
import { t as ActionPermissionNotice } from "./action-permission-notice-CGOJQx-x.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/transactions-DzmI68Kg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var messageOf$1 = (value) => value instanceof Error ? value.message : "The operation could not be completed.";
var money = (value) => new Intl.NumberFormat("en-IN", {
	style: "currency",
	currency: "INR"
}).format(Number(value) || 0);
var time = (value) => value ? new Date(value).toLocaleString("en-IN") : "—";
var inputClass$1 = "rounded-xl border border-border bg-white px-3 py-2.5 text-xs outline-none focus:border-primary";
function AdminTransactionOperations() {
	const actor = getAdminActor();
	const { can } = useEffectiveAccess();
	const allowed = (code) => actor?.kind === "IDENTITY_ADMIN" && can(code, ["ADMIN"]);
	const canView = allowed(UI_PERMISSION.TRANSACTION_VIEW);
	const canViewIncome = allowed(UI_PERMISSION.TRANSACTION_PROVIDER_INCOME_VIEW);
	const canReconcileIncome = allowed(UI_PERMISSION.TRANSACTION_PROVIDER_INCOME_RECONCILE);
	const canRequestReversal = allowed(UI_PERMISSION.TRANSACTION_REVERSAL_REQUEST);
	const canProcessReversal = allowed(UI_PERMISSION.TRANSACTION_REVERSAL_PROCESS);
	const canRecover = allowed(UI_PERMISSION.TRANSACTION_FINANCIAL_RECOVERY);
	const [view, setView] = (0, import_react.useState)("transactions");
	const [transactions, setTransactions] = (0, import_react.useState)([]);
	const [reversals, setReversals] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [notice, setNotice] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("");
	const [detail, setDetail] = (0, import_react.useState)(null);
	const [reverseTarget, setReverseTarget] = (0, import_react.useState)(null);
	const [reason, setReason] = (0, import_react.useState)("");
	const [incomeTarget, setIncomeTarget] = (0, import_react.useState)(null);
	const [income, setIncome] = (0, import_react.useState)({ incomeSource: "VIMOPAY_WALLET" });
	const [reversalDetail, setReversalDetail] = (0, import_react.useState)(null);
	const [reversalDetailLoading, setReversalDetailLoading] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (view === "transactions" && !canView) {
			if (canViewIncome) setView("income");
			else if (canProcessReversal || canRequestReversal) setView("reversals");
		} else if (view === "income" && !canViewIncome) {
			if (canView) setView("transactions");
			else if (canProcessReversal || canRequestReversal) setView("reversals");
		} else if (view === "reversals" && !canProcessReversal && !canRequestReversal) {
			if (canView) setView("transactions");
			else if (canViewIncome) setView("income");
		}
	}, [
		view,
		canView,
		canViewIncome,
		canProcessReversal,
		canRequestReversal
	]);
	async function load() {
		if (view === "transactions" && !canView || view === "income" && !canViewIncome || view === "reversals" && !canProcessReversal && !canRequestReversal) return;
		setLoading(true);
		setError("");
		try {
			const query = new URLSearchParams({
				page: "1",
				limit: "50"
			});
			if (status) query.set("status", status);
			if (view === "transactions") setTransactions((await adminApi.providerTransactions(query.toString())).data || []);
			else if (view === "income") setTransactions((await adminApi.pendingProviderIncome(query.toString())).data || []);
			else setReversals((await adminApi.reversals(query.toString())).data || []);
		} catch (value) {
			setError(messageOf$1(value));
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		load();
	}, [view, status]);
	async function inspect(referenceId) {
		if (!canView) return setError(`Permission ${UI_PERMISSION.TRANSACTION_VIEW} is required.`);
		setBusy(true);
		setError("");
		try {
			setDetail(await adminApi.transaction(referenceId));
		} catch (value) {
			setError(messageOf$1(value));
		} finally {
			setBusy(false);
		}
	}
	async function inspectReversal(referenceId) {
		if (!canRequestReversal && !canProcessReversal) return setError("Reversal access is not granted for this account.");
		setReversalDetailLoading(true);
		setReversalDetail(null);
		setError("");
		try {
			setReversalDetail(await adminApi.reversal(referenceId));
		} catch (value) {
			setError(messageOf$1(value));
		} finally {
			setReversalDetailLoading(false);
		}
	}
	async function requestReversal() {
		if (!canRequestReversal) return setError(`Permission ${UI_PERMISSION.TRANSACTION_REVERSAL_REQUEST} is required.`);
		if (!reverseTarget || !reason.trim()) {
			setError("A reversal reason is required.");
			return;
		}
		setBusy(true);
		setError("");
		try {
			await adminApi.requestReversal(reverseTarget.referenceId, reason.trim(), crypto.randomUUID());
			setNotice(`Reversal requested for ${reverseTarget.referenceId}.`);
			setReverseTarget(null);
			setReason("");
			await load();
		} catch (value) {
			setError(messageOf$1(value));
		} finally {
			setBusy(false);
		}
	}
	async function reconcileIncome() {
		if (!canReconcileIncome) return setError(`Permission ${UI_PERMISSION.TRANSACTION_PROVIDER_INCOME_RECONCILE} is required.`);
		if (!incomeTarget) return;
		setBusy(true);
		setError("");
		try {
			await adminApi.reconcileProviderIncome(incomeTarget.referenceId, income);
			setNotice(`Provider income reconciled for ${incomeTarget.referenceId}.`);
			setIncomeTarget(null);
			await load();
		} catch (value) {
			setError(messageOf$1(value));
		} finally {
			setBusy(false);
		}
	}
	async function processReversal(item) {
		if (!canProcessReversal) return setError(`Permission ${UI_PERMISSION.TRANSACTION_REVERSAL_PROCESS} is required.`);
		if (!window.confirm(`${item.status === "FAILED" ? "Retry" : "Process"} reversal ${item.referenceId}?`)) return;
		setBusy(true);
		setError("");
		try {
			const result = await adminApi.processReversal(item.referenceId);
			setNotice(`Reversal ${item.referenceId} processed.`);
			if (reversalDetail?.referenceId === item.referenceId) setReversalDetail(result);
			await load();
		} catch (value) {
			setError(messageOf$1(value));
		} finally {
			setBusy(false);
		}
	}
	async function recover(item) {
		if (!canRecover) return setError(`Permission ${UI_PERMISSION.TRANSACTION_FINANCIAL_RECOVERY} is required.`);
		if (!window.confirm(`Retry financial effects for ${item.referenceId}?`)) return;
		setBusy(true);
		setError("");
		try {
			await adminApi.recoverFinancialEffects(item.referenceId);
			setNotice(`Financial recovery requested for ${item.referenceId}.`);
			await load();
		} catch (value) {
			setError(messageOf$1(value));
		} finally {
			setBusy(false);
		}
	}
	if (!canView && !canViewIncome && !canProcessReversal && !canRequestReversal) return null;
	const tabs = [];
	if (canView) tabs.push(["transactions", "All transactions"]);
	if (canViewIncome) tabs.push(["income", "Pending provider income"]);
	if (canProcessReversal || canRequestReversal) tabs.push(["reversals", "Reversals"]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
		className: "mb-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-black",
					children: "Transaction operations"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Provider transactions, income settlement and reversal lifecycle."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void load(),
					disabled: loading,
					title: "Refresh transaction operations",
					className: "rounded-xl border border-border p-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
						size: 16,
						className: loading ? "animate-spin" : ""
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: tabs.map(([key, text]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setView(key);
						setStatus("");
					},
					className: `rounded-xl px-4 py-2.5 text-xs font-extrabold ${view === key ? "bg-secondary text-white" : "border border-border"}`,
					children: text
				}, key))
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mt-4 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700",
				children: error
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 rounded-xl bg-emerald-50 p-3 text-sm font-semibold text-emerald-700",
				children: notice
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: status,
					onChange: (event) => setStatus(event.target.value),
					className: inputClass$1,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "All statuses"
					}), (view === "reversals" ? [
						"REQUESTED",
						"PROCESSING",
						"COMPLETED",
						"FAILED",
						"UNKNOWN"
					] : [
						"INITIATED",
						"PROCESSING",
						"SUCCESS",
						"FAILED",
						"PENDING",
						"UNKNOWN",
						"REVERSED"
					]).map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: value }, value))]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 overflow-x-auto rounded-xl border border-border",
				children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid h-40 place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin text-primary" })
				}) : view === "reversals" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReversalTable, {
					items: reversals,
					busy,
					inspect: inspectReversal,
					process: processReversal,
					canProcess: canProcessReversal
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransactionTable, {
					items: transactions,
					view,
					inspect,
					reverse: setReverseTarget,
					income: setIncomeTarget,
					recover,
					canReconcileIncome,
					canRequestReversal,
					canRecover
				})
			}),
			detail && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 rounded-xl border border-primary/30 p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-black",
						children: "Transaction detail"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setDetail(null),
						"aria-label": "Close transaction detail",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid gap-2 sm:grid-cols-3",
					children: Object.entries(detail).filter(([, value]) => value !== null && typeof value !== "object").map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-lg bg-muted p-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[9px] uppercase text-muted-foreground",
							children: key.replace(/([A-Z])/g, " $1")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "break-all text-xs font-bold",
							children: String(value)
						})]
					}, key))
				})]
			}),
			reversalDetailLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-[105] grid place-items-center bg-secondary/60 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 rounded-2xl bg-white px-6 py-5 text-sm font-bold shadow-xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
						size: 18,
						className: "animate-spin text-primary"
					}), "Loading reversal details…"]
				})
			}),
			reversalDetail && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReversalDetailDialog, {
				detail: reversalDetail,
				close: () => setReversalDetail(null)
			}),
			reverseTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
				title: "Request reversal",
				busy,
				close: () => setReverseTarget(null),
				confirm: () => void requestReversal(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "break-all text-xs",
					children: reverseTarget.referenceId
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
					value: reason,
					onChange: (event) => setReason(event.target.value),
					rows: 3,
					placeholder: "Required reversal reason",
					className: `${inputClass$1} mt-4 w-full`
				})]
			}),
			incomeTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
				title: "Reconcile provider income",
				busy,
				close: () => setIncomeTarget(null),
				confirm: () => void reconcileIncome(),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "break-all text-xs",
					children: incomeTarget.referenceId
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "number",
							min: "0.01",
							step: "0.01",
							value: income.providerIncomeAmount ?? "",
							onChange: (event) => setIncome({
								...income,
								providerIncomeAmount: event.target.value ? Number(event.target.value) : void 0
							}),
							placeholder: "Income amount (optional)",
							className: inputClass$1
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							value: income.incomeSource,
							onChange: (event) => setIncome({
								...income,
								incomeSource: event.target.value
							}),
							className: inputClass$1,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "VIMOPAY_WALLET",
								children: "VIMOPAY WALLET"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "VIMOPAY_MS",
								children: "VIMOPAY MS"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: income.externalReference ?? "",
							onChange: (event) => setIncome({
								...income,
								externalReference: event.target.value || void 0
							}),
							placeholder: "External reference (optional)",
							className: inputClass$1
						})
					]
				})]
			})
		]
	});
}
function TransactionTable({ items, view, inspect, reverse, income, recover, canReconcileIncome, canRequestReversal, canRecover }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
		className: "w-full min-w-[1000px] text-left text-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
			className: "bg-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
				"Reference",
				"User",
				"Provider",
				"Amount",
				"Status",
				"Settlement",
				"Commission",
				"Created",
				"Actions"
			].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "p-3",
				children: value
			}, value)) })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
			className: "border-t",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3 font-bold",
					children: item.referenceId
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: item.userId
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
					className: "p-3",
					children: [
						item.provider,
						" / ",
						item.operation
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3 font-bold",
					children: money(item.amount)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3 font-bold",
					children: item.status
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: item.settlementStatus || "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: item.commissionStatus || "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: time(item.createdAt)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								title: "View transaction",
								onClick: () => inspect(item.referenceId),
								className: "rounded-lg border p-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 14 })
							}),
							view === "income" && canReconcileIncome && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								title: "Reconcile income",
								onClick: () => income(item),
								className: "rounded-lg border border-emerald-200 p-2 text-emerald-700",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletCards, { size: 14 })
							}),
							view === "transactions" && canRequestReversal && item.status === "SUCCESS" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								title: "Request reversal",
								onClick: () => reverse(item),
								className: "rounded-lg border border-amber-200 p-2 text-amber-700",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { size: 14 })
							}),
							view === "transactions" && canRecover && !item.needsReconciliation && (item.settlementStatus === "FAILED" || item.commissionStatus === "FAILED") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => recover(item),
								className: "rounded-lg border px-2 py-1 font-bold text-red-700",
								children: "Recover"
							})
						]
					})
				})
			]
		}, item.referenceId)) })]
	});
}
function ReversalTable({ items, busy, inspect, process, canProcess }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
		className: "w-full min-w-[900px] text-left text-xs",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
			className: "bg-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
				"Reversal",
				"Transaction",
				"Provider",
				"Amount",
				"Status",
				"Reason",
				"Actions"
			].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "p-3",
				children: value
			}, value)) })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
			className: "border-t",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3 font-bold",
					children: item.referenceId
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: item.providerTransactionReference
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: item.provider
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: money(item.amount)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3 font-bold",
					children: item.status
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: item.failedReason || item.reason || "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: "p-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							title: "View reversal detail",
							"aria-label": `View reversal ${item.referenceId}`,
							onClick: () => void inspect(item.referenceId),
							className: "rounded-lg border border-border p-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 14 })
						}), canProcess && ["REQUESTED", "FAILED"].includes(item.status) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: busy,
							onClick: () => void process(item),
							className: "rounded-lg bg-primary px-3 py-2 font-bold text-white disabled:opacity-50",
							children: item.status === "FAILED" ? "Retry" : "Process"
						})]
					})
				})
			]
		}, item.referenceId)) })]
	});
}
function ReversalDetailDialog({ detail, close }) {
	const topFields = [
		["Reversal Reference", detail.referenceId],
		["Status", detail.status],
		["Amount", money(detail.amount)],
		["Reason", detail.reason],
		["Requested By", detail.requestedBy],
		["Processed By", detail.processedBy],
		["Principal Status", detail.principalStatus],
		["Commission Status", detail.commissionStatus],
		["Compensation Reference", detail.compensationReferenceId],
		["Principal Compensation", detail.principalCompensationReference],
		["Commission Reversal", detail.commissionReversalReference],
		["Processing At", time(detail.processingAt)],
		["Completed At", time(detail.completedAt)],
		["Created At", time(detail.createdAt)],
		["Updated At", time(detail.updatedAt)]
	];
	const transaction = detail.providerTransaction;
	const transactionFields = transaction ? [
		["Transaction Reference", transaction.referenceId],
		["Provider", transaction.provider],
		["Service", transaction.serviceType],
		["Operation", transaction.operation],
		["Original Amount", money(transaction.amount)],
		["Transaction Status", transaction.status],
		["Settlement Status", transaction.settlementStatus],
		["Commission Status", transaction.commissionStatus],
		["Commission Amount", transaction.commissionAmount],
		["Provider Transaction Ref", transaction.providerTxnRefId],
		["RRN", transaction.rrn],
		["NPCI Code", transaction.npciCode],
		["NPCI Message", transaction.npciMessage],
		["Needs Reconciliation", transaction.needsReconciliation],
		["Created At", time(transaction.createdAt)],
		["Completed At", time(transaction.completedAt)]
	] : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[110] grid place-items-center bg-secondary/60 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			className: "max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-extrabold uppercase tracking-[0.16em] text-primary",
							children: "Reversal lifecycle"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 text-xl font-black text-secondary",
							children: "Reversal details"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 break-all text-xs text-muted-foreground",
							children: detail.referenceId
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: close,
						"aria-label": "Close reversal detail",
						className: "rounded-lg border border-border p-2 text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
					children: topFields.map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailCell, {
						label: key,
						value
					}, key))
				}),
				(detail.failedReason || detail.principalFailureReason || detail.commissionFailureReason) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 rounded-xl border border-red-200 bg-red-50 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-black text-red-800",
						children: "Failure information"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid gap-2 text-xs text-red-800",
						children: [
							detail.failedReason && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Reversal:" }),
								" ",
								detail.failedReason
							] }),
							detail.principalFailureReason && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Principal:" }),
								" ",
								detail.principalFailureReason
							] }),
							detail.commissionFailureReason && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Commission:" }),
								" ",
								detail.commissionFailureReason
							] })
						]
					})]
				}),
				transaction && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 rounded-xl border border-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-b border-border px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-sm font-black text-secondary",
							children: "Original provider transaction"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-[10px] text-muted-foreground",
							children: "The provider transaction linked to this reversal."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-3 p-4 sm:grid-cols-2 lg:grid-cols-3",
						children: transactionFields.map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailCell, {
							label: key,
							value
						}, key))
					})]
				})
			]
		})
	});
}
function DetailCell({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-muted/30 p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[9px] font-extrabold uppercase tracking-wide text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 break-all text-xs font-bold text-secondary",
			children: value === null || value === void 0 || value === "" ? "—" : String(value)
		})]
	});
}
function Dialog({ title, busy, close, confirm, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-[100] grid place-items-center bg-secondary/60 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			className: "w-full max-w-lg rounded-2xl bg-white p-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-black",
					children: title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-2",
					children
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex justify-end gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: busy,
						onClick: close,
						className: "rounded-xl border px-4 py-3 text-xs font-bold",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						disabled: busy,
						onClick: confirm,
						className: "rounded-xl bg-primary px-4 py-3 text-xs font-bold text-white",
						children: busy ? "Working..." : "Confirm"
					})]
				})
			]
		})
	});
}
var inputClass = "w-full rounded-xl border border-border bg-white px-3.5 py-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/15";
var messageOf = (error) => error instanceof AdminApiError || error instanceof Error ? error.message : "The request could not be completed.";
function dateTime(value) {
	if (!value) return "—";
	const date = new Date(value);
	return Number.isNaN(date.getTime()) ? "—" : new Intl.DateTimeFormat("en-IN", {
		dateStyle: "medium",
		timeStyle: "short"
	}).format(date);
}
function amount(value) {
	const number = Number(value);
	return Number.isFinite(number) ? new Intl.NumberFormat("en-IN", {
		style: "currency",
		currency: "INR"
	}).format(number) : "—";
}
function Transactions() {
	const actor = getAdminActor();
	const { can } = useEffectiveAccess();
	const identityAdminContract = actor?.kind === "IDENTITY_ADMIN";
	const canViewTransaction = identityAdminContract && can(UI_PERMISSION.TRANSACTION_VIEW, ["ADMIN"]);
	const canViewReconciliation = identityAdminContract && can(UI_PERMISSION.TRANSACTION_RECONCILIATION_VIEW, ["ADMIN"]);
	const canResolve = identityAdminContract && can(UI_PERMISSION.TRANSACTION_RECONCILIATION_RESOLVE, ["ADMIN"]);
	const canReverse = identityAdminContract && can(UI_PERMISSION.TRANSACTION_REVERSAL_REQUEST, ["ADMIN"]);
	const [items, setItems] = (0, import_react.useState)([]), [loading, setLoading] = (0, import_react.useState)(true), [busy, setBusy] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(""), [notice, setNotice] = (0, import_react.useState)(""), [query, setQuery] = (0, import_react.useState)(""), [status, setStatus] = (0, import_react.useState)(""), [operation, setOperation] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(1), [totalPages, setTotalPages] = (0, import_react.useState)(1), [total, setTotal] = (0, import_react.useState)(0);
	const [detail, setDetail] = (0, import_react.useState)(null), [detailBusy, setDetailBusy] = (0, import_react.useState)(false), [action, setAction] = (0, import_react.useState)(null);
	const [resolution, setResolution] = (0, import_react.useState)("SUCCESS"), [note, setNote] = (0, import_react.useState)(""), [providerTxnRefId, setProviderTxnRefId] = (0, import_react.useState)(""), [rrn, setRrn] = (0, import_react.useState)("");
	async function load(targetPage = page) {
		if (!canViewReconciliation) {
			setLoading(false);
			return;
		}
		setLoading(true);
		setError("");
		try {
			const params = new URLSearchParams({
				page: String(targetPage),
				limit: "25"
			});
			if (status) params.set("status", status);
			if (operation) params.set("operation", operation);
			const result = await adminApi.reconciliation(params.toString());
			setItems(result.data || []);
			setPage(result.page || targetPage);
			setTotalPages(Math.max(result.totalPages || 1, 1));
			setTotal(result.total || 0);
		} catch (caught) {
			setError(messageOf(caught));
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		if (canViewReconciliation) load(1);
		else setLoading(false);
	}, [
		status,
		operation,
		canViewReconciliation
	]);
	const visible = (0, import_react.useMemo)(() => {
		const needle = query.trim().toLowerCase();
		return needle ? items.filter((item) => `${item.referenceId} ${item.provider || ""} ${item.serviceType || ""} ${item.userId || ""} ${item.rrn || ""}`.toLowerCase().includes(needle)) : items;
	}, [items, query]);
	async function inspect(referenceId) {
		if (!canViewTransaction) return setError(`Permission ${UI_PERMISSION.TRANSACTION_VIEW} is required.`);
		setDetailBusy(true);
		setError("");
		try {
			setDetail(await adminApi.transaction(referenceId));
		} catch (caught) {
			setError(messageOf(caught));
		} finally {
			setDetailBusy(false);
		}
	}
	function openAction(kind, item) {
		if (kind === "resolve" && !canResolve) return setError(`Permission ${UI_PERMISSION.TRANSACTION_RECONCILIATION_RESOLVE} is required.`);
		if (kind === "reverse" && !canReverse) return setError(`Permission ${UI_PERMISSION.TRANSACTION_REVERSAL_REQUEST} is required.`);
		setAction({
			kind,
			item
		});
		setResolution("SUCCESS");
		setNote("");
		setProviderTxnRefId(item.providerTxnRefId || "");
		setRrn(item.rrn || "");
		setError("");
		setNotice("");
	}
	async function submitAction(event) {
		event.preventDefault();
		if (!action) return;
		if (action.kind === "resolve" && !canResolve) return setError(`Permission ${UI_PERMISSION.TRANSACTION_RECONCILIATION_RESOLVE} is required.`);
		if (action.kind === "reverse" && !canReverse) return setError(`Permission ${UI_PERMISSION.TRANSACTION_REVERSAL_REQUEST} is required.`);
		if (!note.trim()) return setError(action.kind === "reverse" ? "Enter a reversal reason." : "Enter an operator note for the audit trail.");
		setBusy(true);
		setError("");
		setNotice("");
		try {
			if (action.kind === "resolve") {
				await adminApi.resolveTransaction(action.item.referenceId, {
					resolution,
					note: note.trim(),
					providerTxnRefId: providerTxnRefId.trim() || void 0,
					rrn: rrn.trim() || void 0
				});
				setNotice(`Transaction ${action.item.referenceId} resolved as ${resolution}.`);
			} else {
				await adminApi.requestReversal(action.item.referenceId, note.trim(), crypto.randomUUID());
				setNotice(`Reversal request submitted for ${action.item.referenceId}.`);
			}
			setAction(null);
			await load();
		} catch (caught) {
			setError(messageOf(caught));
		} finally {
			setBusy(false);
		}
	}
	if (actor?.kind !== "IDENTITY_ADMIN") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "transactions",
		eyebrow: "Payments operations",
		title: "Transactions & reconciliation",
		description: "Operational transaction endpoints require an identity Admin session.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminPanel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-2xl py-14 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {
					className: "mx-auto text-amber-600",
					size: 42
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-5 text-xl font-black",
					children: "Backend authentication contract mismatch"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-6 text-muted-foreground",
					children: "The current backend protects these routes with JwtAuthGuard, which validates an identity Admin session. Your current Super Admin token is validated by a different guard, so sending it here would return 401 Unauthorized. Requests are paused to avoid repeated failing calls."
				})
			]
		}) })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "transactions",
		eyebrow: "Payments operations",
		title: "Transactions & reconciliation",
		description: "Search uncertain provider transactions, inspect the full record, resolve reconciliation and request controlled reversals.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminTransactionOperations, {}),
			!canViewReconciliation && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionPermissionNotice, {
					permission: UI_PERMISSION.TRANSACTION_RECONCILIATION_VIEW,
					title: "Reconciliation queue is not enabled"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
						label: "Queue total",
						value: String(total)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
						label: "Pending on page",
						value: String(items.filter((item) => item.status === "PENDING").length)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Summary, {
						label: "Unknown on page",
						value: String(items.filter((item) => item.status === "UNKNOWN").length)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
				className: "mt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-black",
							children: "Reconciliation queue"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: "Every action is sent to the live admin transaction API and must be confirmed."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2 sm:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex items-center gap-2 rounded-xl border border-border bg-white px-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { size: 15 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: query,
										onChange: (e) => setQuery(e.target.value),
										placeholder: "Reference, RRN…",
										className: "min-w-0 bg-transparent py-3 text-xs outline-none"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: status,
									onChange: (e) => setStatus(e.target.value),
									className: inputClass,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "",
											children: "All statuses"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "PENDING" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: "UNKNOWN" })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: operation,
									onChange: (e) => setOperation(e.target.value),
									className: inputClass,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										children: "All operations"
									}), [
										"BE",
										"MS",
										"CW",
										"AP",
										"CD"
									].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: v }, v))]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => void load(),
									disabled: loading,
									className: "inline-flex items-center justify-center gap-2 rounded-xl bg-secondary px-4 py-3 text-xs font-extrabold text-white disabled:opacity-50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
										size: 15,
										className: loading ? "animate-spin" : ""
									}), "Refresh"]
								})
							]
						})]
					}),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "mt-5 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700",
						children: error
					}),
					notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-5 rounded-xl bg-emerald-50 p-3 text-sm font-semibold text-emerald-700",
						children: notice
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 overflow-x-auto rounded-xl border border-border",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full min-w-[1050px] text-left text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "bg-muted/60",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
										className: "text-[10px] uppercase tracking-wider text-muted-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3",
												children: "Reference"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3",
												children: "Provider / service"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3",
												children: "Operation"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3",
												children: "Amount"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3",
												children: "Status"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3",
												children: "Reason"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3",
												children: "Created"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
												className: "p-3 text-right",
												children: "Actions"
											})
										]
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: visible.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t border-border/70 align-top",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "p-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "max-w-[190px] break-all font-black",
												children: item.referenceId
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-1 text-[10px] text-muted-foreground",
												children: item.userId || "User unavailable"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "p-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-bold",
												children: item.provider || "—"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-xs text-muted-foreground",
												children: item.serviceType || "—"
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3 font-bold",
											children: item.operation || "—"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3 font-black",
											children: amount(item.amount)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: item.status || "UNKNOWN" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "max-w-[220px] p-3 text-xs leading-5 text-muted-foreground",
											children: item.reconciliationReason || item.providerStatusMessage || "Awaiting operator review"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3 text-xs",
											children: dateTime(item.createdAt)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "p-3",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex justify-end gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionButton, {
													title: "View transaction",
													onClick: () => void inspect(item.referenceId),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 15 })
												}), canResolve && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionButton, {
													title: "Resolve",
													tone: "good",
													onClick: () => openAction("resolve", item),
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { size: 15 })
												})]
											})
										})
									]
								}, item.referenceId)) })]
							}),
							loading && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-center gap-2 py-12 text-sm text-muted-foreground",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
									className: "animate-spin",
									size: 17
								}), "Loading live queue…"]
							}),
							!loading && !visible.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "py-12 text-center text-sm text-muted-foreground",
								children: "No transactions match the current filters."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-center justify-between text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-muted-foreground",
							children: [
								"Page ",
								page,
								" of ",
								totalPages
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: loading || page <= 1,
								onClick: () => void load(page - 1),
								className: "rounded-lg border border-border px-3 py-2 font-bold disabled:opacity-40",
								children: "Previous"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: loading || page >= totalPages,
								onClick: () => void load(page + 1),
								className: "rounded-lg border border-border px-3 py-2 font-bold disabled:opacity-40",
								children: "Next"
							})]
						})]
					})
				]
			}),
			(detail || detailBusy) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
				className: "mt-6 border-primary/25",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-extrabold uppercase tracking-wider text-primary",
						children: "Transaction details"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-xl font-black",
						children: detail?.referenceId || "Loading record…"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setDetail(null),
						"aria-label": "Close details",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { size: 21 })
					})]
				}), detailBusy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "py-10 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mx-auto animate-spin text-primary" })
				}) : detail && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 grid gap-3 sm:grid-cols-2 xl:grid-cols-4",
					children: Object.entries(detail).filter(([, v]) => v !== null && typeof v !== "object").map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-muted/50 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-extrabold uppercase text-muted-foreground",
							children: key.replace(/([A-Z])/g, " $1")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 break-all text-xs font-bold",
							children: String(value)
						})]
					}, key))
				})]
			}),
			action && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-[80] grid place-items-center bg-secondary/55 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submitAction,
					className: "w-full max-w-xl rounded-2xl bg-white p-6 shadow-2xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `grid h-11 w-11 place-items-center rounded-xl ${action.kind === "resolve" ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}`,
								children: action.kind === "resolve" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-extrabold uppercase text-primary",
									children: "Controlled admin action"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-xl font-black",
									children: action.kind === "resolve" ? "Resolve reconciliation" : "Request reversal"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 break-all text-xs text-muted-foreground",
									children: action.item.referenceId
								})
							] })]
						}),
						action.kind === "resolve" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-5 block text-xs font-extrabold",
							children: ["FINAL RESOLUTION", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: resolution,
								onChange: (e) => setResolution(e.target.value),
								className: `${inputClass} mt-2`,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "SUCCESS",
									children: "SUCCESS — provider confirmed"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "FAILED",
									children: "FAILED — release/rollback safely"
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs font-extrabold",
								children: ["PROVIDER TXN REF", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: providerTxnRefId,
									onChange: (e) => setProviderTxnRefId(e.target.value),
									className: `${inputClass} mt-2`
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs font-extrabold",
								children: ["RRN", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: rrn,
									onChange: (e) => setRrn(e.target.value),
									className: `${inputClass} mt-2`
								})]
							})]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-4 block text-xs font-extrabold",
							children: [action.kind === "resolve" ? "OPERATOR NOTE" : "REVERSAL REASON", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: note,
								onChange: (e) => setNote(e.target.value),
								rows: 3,
								className: `${inputClass} mt-2 resize-none`,
								placeholder: "Required for the audit trail"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex gap-3 rounded-xl bg-amber-50 p-4 text-xs leading-5 text-amber-900",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {
								size: 18,
								className: "shrink-0"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Confirm provider evidence before continuing. Financial actions are idempotent and audited by the backend." })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								disabled: busy,
								onClick: () => setAction(null),
								className: "rounded-xl border border-border px-4 py-3 text-xs font-extrabold",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								disabled: busy,
								className: `inline-flex items-center gap-2 rounded-xl px-5 py-3 text-xs font-extrabold text-white ${action.kind === "resolve" ? "bg-emerald-600" : "bg-amber-600"}`,
								children: [busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
									size: 14,
									className: "animate-spin"
								}), "Confirm action"]
							})]
						})
					]
				})
			})
		]
	});
}
function Summary({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs font-extrabold uppercase tracking-wider text-muted-foreground",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-2xl font-black text-secondary",
		children: value
	})] });
}
function Status({ value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-full px-2 py-1 text-[10px] font-extrabold ${value === "UNKNOWN" ? "bg-red-50 text-red-700" : "bg-amber-50 text-amber-800"}`,
		children: value
	});
}
function ActionButton({ title, onClick, tone, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		title,
		"aria-label": title,
		onClick,
		className: `rounded-lg border p-2 ${tone === "good" ? "border-emerald-200 text-emerald-700" : tone === "warn" ? "border-amber-200 text-amber-700" : "border-border text-secondary"}`,
		children
	});
}
//#endregion
export { Transactions as component };
