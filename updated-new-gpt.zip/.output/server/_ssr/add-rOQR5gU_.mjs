import { i as CreateMemberPage } from "./router-DughR4Dc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/add-rOQR5gU_.js
var SplitComponent = CreateMemberPage;
//#endregion
export { SplitComponent as component };
