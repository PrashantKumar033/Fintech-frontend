import { t as AdminProfilePage } from "./admin-profile-page-C29b7XLq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-BORb39c3.js
var SplitComponent = AdminProfilePage;
//#endregion
export { SplitComponent as component };
