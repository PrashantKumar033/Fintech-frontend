import { r as __toESM } from "../_runtime.mjs";
import { a as credentialsPending, c as getSession, r as authenticatedRequest, t as ApiError, y as signedInHome } from "./role-hierarchy-B8AZOwBW.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { E as ShieldAlert, F as RefreshCw, L as ReceiptText, cn as BadgeIndianRupee, gt as Landmark, kt as FingerprintPattern, lt as LoaderCircle, o as WalletCards, qt as CircleCheck, rt as MapPin, sn as Banknote } from "../_libs/lucide-react.mjs";
import { a as useEffectiveAccess, r as UI_PERMISSION } from "./section-tabs-DrewjFLo.mjs";
import { t as ActionPermissionNotice } from "./action-permission-notice-CGOJQx-x.mjs";
import { a as useServiceReadiness, t as BusinessPage } from "./business-page-CoovTN0N.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/aeps-BGfavTzd.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
async function call(token, path, init = {}) {
	return authenticatedRequest(path, init, token);
}
var get = (token, path) => call(token, path);
var post = (token, path, body, idempotencyKey) => call(token, path, {
	method: "POST",
	body: JSON.stringify(body ?? {}),
	headers: idempotencyKey ? { "Idempotency-Key": idempotencyKey } : void 0
});
var aepsApi = {
	status: (t) => get(t, "/aeps/vimopay/status"),
	banks: (t) => get(t, "/aeps/vimopay/banks"),
	states: (t) => get(t, "/aeps/vimopay/states"),
	districts: (t, stateCode) => get(t, `/aeps/vimopay/districts?stateCode=${encodeURIComponent(stateCode)}`),
	bankIins: (t, txnCode, authType) => get(t, `/aeps/vimopay/bank-iins?txnCode=${txnCode}&authType=${authType}`),
	savedBanks: (t) => get(t, "/identity/get-my-bank-accounts"),
	myKyc: (t) => get(t, "/kyc/me"),
	register: (t, body) => post(t, "/aeps/vimopay/onboarding/register", body),
	sendOtp: (t, resend = false) => post(t, `/aeps/vimopay/onboarding/otp/${resend ? "resend" : "send"}`),
	verifyOtp: (t, otp) => post(t, "/aeps/vimopay/onboarding/otp/verify", { otp }),
	ekyc: (t, pidData) => post(t, "/aeps/vimopay/onboarding/ekyc", { pidData }),
	twoFactor: (t, body) => post(t, "/aeps/vimopay/onboarding/2fa", body),
	transactionOtp: (t, operation, body) => post(t, `/aeps/vimopay/${operation === "CW" ? "cash-withdrawal" : "aadhaar-pay"}/otp`, body),
	transact: (t, operation, body, key) => {
		return post(t, `/aeps/vimopay/${{
			BE: "balance-enquiry",
			MS: "mini-statement",
			CW: "cash-withdrawal",
			AP: "aadhaar-pay",
			CD: "cash-deposit"
		}[operation]}`, body, key);
	}
};
function newIdempotencyKey() {
	if (!globalThis.crypto?.randomUUID) throw new Error("A secure browser context is required for financial transactions.");
	return globalThis.crypto.randomUUID();
}
async function capturePid(rdUrl, otp) {
	let endpoint;
	try {
		endpoint = new URL(rdUrl);
	} catch {
		throw new Error("Enter a valid RD service capture URL.");
	}
	if (!["http:", "https:"].includes(endpoint.protocol)) throw new Error("RD service URL must use HTTP or HTTPS.");
	if (otp && !/^\d{4,8}$/.test(otp)) throw new Error("RD provider OTP must contain 4 to 8 digits.");
	const options = `<?xml version="1.0"?><PidOptions ver="1.0"><Opts fCount="1" fType="2" iCount="0" pCount="0" format="0" pidVer="2.0" timeout="10000" otp="${otp || ""}" env="P" wadh="" posh="UNKNOWN"/></PidOptions>`;
	const controller = new AbortController();
	const timeout = window.setTimeout(() => controller.abort(), 12e3);
	let response;
	try {
		response = await fetch(endpoint.toString(), {
			method: "CAPTURE",
			headers: { "Content-Type": "text/xml" },
			body: options,
			signal: controller.signal
		});
	} catch (error) {
		if (error instanceof DOMException && error.name === "AbortError") throw new Error("RD device capture timed out. Check the device and retry.");
		throw new Error("Cannot connect to the RD service. Start the registered device service and confirm its capture URL.");
	} finally {
		window.clearTimeout(timeout);
	}
	const xml = await response.text();
	if (!response.ok || !xml.includes("<PidData")) throw new Error("RD capture failed. Check the device service and try again.");
	const error = xml.match(/errCode=["']([^"']+)["']/)?.[1];
	if (error && error !== "0") throw new Error(xml.match(/errInfo=["']([^"']*)["']/)?.[1] || `RD device error ${error}`);
	return xml;
}
var actionCopy = {
	REGISTER: "Complete merchant registration",
	OTP: "Verify merchant mobile",
	EKYC: "Complete biometric e-KYC",
	TWO_FACTOR_AUTH: "Complete today's biometric verification",
	AEPS_TRANSACTION: "AEPS services are ready",
	WAIT: "Registration is being processed",
	RETRY_REGISTRATION: "Registration needs attention",
	CONTACT_SUPPORT: "Contact support"
};
function AepsPage() {
	const navigate = useNavigate();
	const { can } = useEffectiveAccess();
	const actionAccess = {
		onboarding: can(UI_PERMISSION.AEPS_ONBOARDING, ["RETAILER"]),
		services: {
			BE: can(UI_PERMISSION.AEPS_BALANCE_ENQUIRY, ["RETAILER"]),
			MS: can(UI_PERMISSION.AEPS_MINI_STATEMENT, ["RETAILER"]),
			CW: can(UI_PERMISSION.AEPS_CASH_WITHDRAWAL, ["RETAILER"]),
			AP: can(UI_PERMISSION.AEPS_AADHAAR_PAY, ["RETAILER"]),
			CD: can(UI_PERMISSION.AEPS_CASH_DEPOSIT, ["RETAILER"])
		}
	};
	const [session, setSession] = (0, import_react.useState)(null);
	const [status, setStatus] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)("");
	const readiness = useServiceReadiness(!!session);
	const refresh = (0, import_react.useCallback)(async () => {
		const current = getSession();
		if (!current) return;
		setLoading(true);
		setError("");
		try {
			setStatus(await aepsApi.status(current.accessToken));
		} catch (e) {
			setError(messageOf(e));
		} finally {
			setLoading(false);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		const current = getSession();
		if (!current) {
			navigate({ to: "/login" });
			return;
		}
		if (credentialsPending(current.identity)) {
			window.location.replace(signedInHome(current));
			return;
		}
		setSession(current);
		refresh();
	}, [navigate, refresh]);
	(0, import_react.useEffect)(() => {
		if (readiness.isSuccess && !readiness.data.aepsUnlocked) navigate({ to: "/retailer/dashboard" });
	}, [
		navigate,
		readiness.data,
		readiness.isSuccess
	]);
	if (!session) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BusinessPage, {
		identity: session.identity,
		active: "aeps",
		eyebrow: "VimoPay",
		title: "Aadhaar Enabled Payment System",
		description: "Merchant onboarding and Aadhaar-enabled transactions become available after approved KYC and a verified bank account.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-5 flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: refresh,
					className: "flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-2 text-xs font-bold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { size: 14 }), " Refresh status"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-6 rounded-2xl bg-secondary p-5 text-secondary-foreground shadow-elegant",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-white/60",
							children: "AEPS merchant status"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xl font-extrabold",
							children: loading ? "Checking eligibility…" : status ? actionCopy[status.nextAction] : "Status unavailable"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-white/60",
							children: status?.providerMerchantId ? `Merchant ID: ${status.providerMerchantId}` : "Your identity is taken securely from your login session."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full bg-white/10 px-4 py-2 text-xs font-bold",
						children: status?.status || "CHECKING"
					})]
				})
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
				tone: "error",
				children: error
			}),
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Loading, {}) : status && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AepsFlow, {
				token: session.accessToken,
				status,
				refresh,
				access: actionAccess
			})
		]
	});
}
function AepsFlow({ token, status, refresh, access }) {
	if ([
		"REGISTER",
		"RETRY_REGISTRATION",
		"OTP",
		"EKYC",
		"TWO_FACTOR_AUTH"
	].includes(status.nextAction) && !access.onboarding) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionPermissionNotice, {
		permission: UI_PERMISSION.AEPS_ONBOARDING,
		title: "AEPS onboarding is not enabled"
	});
	switch (status.nextAction) {
		case "REGISTER":
		case "RETRY_REGISTRATION": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Registration, {
			token,
			retry: status.nextAction === "RETRY_REGISTRATION",
			done: refresh
		});
		case "OTP": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OnboardingOtp, {
			token,
			done: refresh
		});
		case "EKYC": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BiometricStep, {
			title: "Merchant e-KYC",
			description: "Capture a fresh fingerprint using your registered RD device.",
			submit: (pidData) => aepsApi.ekyc(token, pidData),
			done: refresh
		});
		case "TWO_FACTOR_AUTH": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DailyTwoFactor, {
			token,
			done: refresh
		});
		case "AEPS_TRANSACTION": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransactionWorkspace, {
			token,
			access
		});
		case "WAIT": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StateCard, {
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }),
			title: "Processing registration",
			text: "Please wait for the provider response. Do not submit another registration.",
			action: refresh
		});
		default: return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StateCard, {
			icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {}),
			title: "AEPS access needs support",
			text: status.reason || "Transactions are disabled for this merchant profile. Please contact the service desk."
		});
	}
}
var emptyRegistration = {
	bankAccountId: "",
	kycProfileId: "",
	vimopayBankCode: "",
	lat: "",
	long: "",
	firstName: "",
	middleName: "",
	lastName: "",
	dob: "",
	emailId: "",
	merchantPhoneNumber: "",
	merchantAddress1: "",
	merchantAddress2: "",
	merchantState: "",
	merchantDistrict: "",
	gender: "M",
	merchantPinCode: "",
	merchantPan: "",
	aadhaarNumber: "",
	shopPan: "",
	shopAddress: "",
	shopDistrict: "",
	shopState: "",
	shopPincode: "",
	shopLat: "",
	shopLong: ""
};
function Registration({ token, retry, done }) {
	const [form, setForm] = (0, import_react.useState)(emptyRegistration), [banks, setBanks] = (0, import_react.useState)([]), [states, setStates] = (0, import_react.useState)([]), [districts, setDistricts] = (0, import_react.useState)([]), [shopDistricts, setShopDistricts] = (0, import_react.useState)([]), [saved, setSaved] = (0, import_react.useState)([]), [kyc, setKyc] = (0, import_react.useState)(null), [prerequisiteErrors, setPrerequisiteErrors] = (0, import_react.useState)([]), [loadingPrerequisites, setLoadingPrerequisites] = (0, import_react.useState)(true), [busy, setBusy] = (0, import_react.useState)(false), [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		let active = true;
		Promise.allSettled([
			aepsApi.banks(token),
			aepsApi.states(token),
			aepsApi.savedBanks(token),
			aepsApi.myKyc(token)
		]).then((results) => {
			if (!active) return;
			const [bankResult, stateResult, savedResult, kycResult] = results;
			const issues = [];
			if (bankResult.status === "fulfilled") setBanks(bankResult.value);
			else issues.push(`VimoPay bank list: ${messageOf(bankResult.reason)}`);
			if (stateResult.status === "fulfilled") setStates(stateResult.value);
			else issues.push(`State list: ${messageOf(stateResult.reason)}`);
			if (savedResult.status === "fulfilled") {
				const eligible = savedResult.value.filter((account) => !account.isDeleted && account.status === "ACTIVE" && account.verificationStatus === "VERIFIED" && account.ownershipStatus === "VERIFIED" && account.accountType !== "SALARY");
				setSaved(eligible);
				if (!eligible.length) issues.push("Add an ACTIVE, VERIFIED Savings or Current bank account before AEPS registration.");
			} else issues.push(`Saved bank accounts: ${messageOf(savedResult.reason)}`);
			if (kycResult.status === "fulfilled") {
				setKyc(kycResult.value);
				if (kycResult.value.status === "APPROVED") setForm((current) => ({
					...current,
					kycProfileId: kycResult.value.id
				}));
				else issues.push(`Your KYC must be APPROVED. Current status: ${kycResult.value.status}.`);
			} else issues.push(`KYC profile: ${messageOf(kycResult.reason)}`);
			setPrerequisiteErrors(issues);
			setLoadingPrerequisites(false);
		});
		return () => {
			active = false;
		};
	}, [token]);
	(0, import_react.useEffect)(() => {
		if (!form.merchantState) return;
		aepsApi.districts(token, form.merchantState).then(setDistricts).catch((e) => setError(messageOf(e)));
	}, [form.merchantState, token]);
	(0, import_react.useEffect)(() => {
		if (!form.shopState) return;
		aepsApi.districts(token, form.shopState).then(setShopDistricts).catch((e) => setError(messageOf(e)));
	}, [form.shopState, token]);
	const set = (name, value) => setForm((f) => ({
		...f,
		[name]: value
	}));
	const locate = () => navigator.geolocation?.getCurrentPosition((p) => setForm((f) => ({
		...f,
		lat: String(p.coords.latitude),
		long: String(p.coords.longitude),
		shopLat: f.shopLat || String(p.coords.latitude),
		shopLong: f.shopLong || String(p.coords.longitude)
	})), () => setError("Location permission is required for AEPS registration."), { enableHighAccuracy: true });
	async function submit(e) {
		e.preventDefault();
		setBusy(true);
		setError("");
		try {
			await aepsApi.register(token, Object.fromEntries(Object.entries(form).filter(([, v]) => v !== "")));
			await done();
		} catch (x) {
			setError(messageOf(x));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: retry ? "Retry VimoPay registration" : "Merchant registration",
		description: "Use a verified bank account and approved KYC profile. Sensitive identity details stay only in this form until submission.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "space-y-6",
			children: [
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
					tone: "error",
					children: error
				}),
				loadingPrerequisites && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
					tone: "info",
					children: "Checking approved KYC, verified bank accounts, and VimoPay master data…"
				}),
				!loadingPrerequisites && prerequisiteErrors.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-amber-50 p-4 text-sm text-amber-900",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-extrabold",
						children: "Complete these prerequisites first:"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 list-disc space-y-1 pl-5",
						children: prerequisiteErrors.map((issue) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: issue }, issue))
					})]
				}),
				kyc?.status === "APPROVED" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 rounded-xl bg-emerald-50 p-4 text-sm font-bold text-emerald-800",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { size: 18 }), " Approved KYC selected automatically"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
							label: "Verified settlement bank",
							value: form.bankAccountId,
							onChange: (v) => set("bankAccountId", v),
							options: saved.map((b) => ({
								value: b.id,
								label: `${b.bankName || "Bank account"} ••••${b.accountNumberLast4 || ""} (${b.accountType || ""})`
							}))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
							label: "VimoPay registration bank",
							value: form.vimopayBankCode,
							onChange: (v) => set("vimopayBankCode", v),
							options: banks.map((b) => ({
								value: b.code || "",
								label: b.description
							}))
						}),
						[
							["firstName", "First name"],
							["middleName", "Middle name (optional)"],
							["lastName", "Last name"],
							[
								"dob",
								"Date of birth",
								"DD-MM-YYYY"
							],
							[
								"emailId",
								"Email",
								"name@example.com"
							],
							[
								"merchantPhoneNumber",
								"Merchant mobile",
								"10 digits"
							],
							["merchantAddress1", "Residence address line 1"],
							["merchantAddress2", "Residence address line 2 (optional)"],
							[
								"merchantPinCode",
								"Residence PIN",
								"6 digits"
							],
							[
								"merchantPan",
								"Merchant PAN",
								"ABCDE1234F"
							],
							[
								"aadhaarNumber",
								"Merchant Aadhaar",
								"12 digits"
							],
							[
								"shopPan",
								"Shop PAN",
								"ABCDE1234F"
							],
							["shopAddress", "Shop address"],
							[
								"shopPincode",
								"Shop PIN",
								"6 digits"
							]
						].map(([name, label, placeholder]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label,
							value: form[name],
							placeholder,
							onChange: (v) => set(name, sensitive(name) ? digits(v) : pan(name) ? v.toUpperCase() : v),
							required: !label.includes("optional")
						}, name)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
							label: "Gender",
							value: form.gender,
							onChange: (v) => set("gender", v),
							options: [
								{
									value: "M",
									label: "Male"
								},
								{
									value: "F",
									label: "Female"
								},
								{
									value: "O",
									label: "Other"
								}
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
							label: "Residence state",
							value: form.merchantState,
							onChange: (v) => {
								set("merchantState", v);
								set("merchantDistrict", "");
							},
							options: states.map(masterOption)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
							label: "Residence district",
							value: form.merchantDistrict,
							onChange: (v) => set("merchantDistrict", v),
							options: districts.map(masterOption)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
							label: "Shop state",
							value: form.shopState,
							onChange: (v) => {
								set("shopState", v);
								set("shopDistrict", "");
							},
							options: states.map(masterOption)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
							label: "Shop district",
							value: form.shopDistrict,
							onChange: (v) => set("shopDistrict", v),
							options: shopDistricts.map(masterOption)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Current latitude",
							value: form.lat,
							onChange: (v) => set("lat", v)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Current longitude",
							value: form.long,
							onChange: (v) => set("long", v)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Shop latitude",
							value: form.shopLat,
							onChange: (v) => set("shopLat", v)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Shop longitude",
							value: form.shopLong,
							onChange: (v) => set("shopLong", v)
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: locate,
					className: "flex items-center gap-2 text-sm font-bold text-primary",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { size: 16 }), " Use current location"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Submit, {
					busy: busy || loadingPrerequisites || prerequisiteErrors.length > 0,
					children: "Submit registration"
				})
			]
		})
	});
}
function OnboardingOtp({ token, done }) {
	const [otp, setOtp] = (0, import_react.useState)(""), [sent, setSent] = (0, import_react.useState)(false), [busy, setBusy] = (0, import_react.useState)(false), [error, setError] = (0, import_react.useState)("");
	const send = async (resend = false) => {
		setBusy(true);
		setError("");
		try {
			await aepsApi.sendOtp(token, resend);
			setSent(true);
		} catch (e) {
			setError(messageOf(e));
		} finally {
			setBusy(false);
		}
	};
	const verify = async (e) => {
		e.preventDefault();
		setBusy(true);
		setError("");
		try {
			await aepsApi.verifyOtp(token, otp);
			setOtp("");
			await done();
		} catch (x) {
			setError(messageOf(x));
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		title: "Merchant OTP verification",
		description: "Send the onboarding OTP to the registered merchant mobile, then verify it here.",
		children: [error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
			tone: "error",
			children: error
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: verify,
			className: "mt-5 max-w-md space-y-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "OTP",
				value: otp,
				onChange: (v) => setOtp(digits(v)),
				placeholder: "Enter provider OTP",
				required: true
			}), !sent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: busy,
				onClick: () => send(),
				className: "w-full rounded-xl bg-secondary py-3 text-sm font-bold text-white",
				children: "Send OTP"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Submit, {
				busy,
				children: "Verify OTP"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: busy,
				onClick: () => send(true),
				className: "w-full text-sm font-bold text-primary",
				children: "Resend OTP"
			})] })]
		})]
	});
}
function BiometricStep({ title, description, submit, done }) {
	const [pid, setPid] = (0, import_react.useState)(""), [busy, setBusy] = (0, import_react.useState)(false), [error, setError] = (0, import_react.useState)("");
	const run = async () => {
		setBusy(true);
		setError("");
		try {
			await submit(pid);
			setPid("");
			await done();
		} catch (e) {
			setError(messageOf(e));
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		title,
		description,
		children: [
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
				tone: "error",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Capture, {
				value: pid,
				onChange: setPid
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				disabled: !pid || busy,
				onClick: run,
				className: "mt-5 w-full rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground disabled:opacity-50",
				children: busy ? "Submitting…" : "Submit biometric verification"
			})
		]
	});
}
function DailyTwoFactor({ token, done }) {
	const [aadhaar, setAadhaar] = (0, import_react.useState)(""), [lat, setLat] = (0, import_react.useState)(""), [long, setLong] = (0, import_react.useState)(""), [pid, setPid] = (0, import_react.useState)(""), [deviceType, setDeviceType] = (0, import_react.useState)("mantra"), [busy, setBusy] = (0, import_react.useState)(false), [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		navigator.geolocation?.getCurrentPosition((p) => {
			setLat(String(p.coords.latitude));
			setLong(String(p.coords.longitude));
		});
	}, []);
	async function submit(e) {
		e.preventDefault();
		setBusy(true);
		setError("");
		try {
			await aepsApi.twoFactor(token, {
				aadhaarNumber: aadhaar,
				deviceType,
				pidData: pid,
				lat,
				long
			});
			setAadhaar("");
			setPid("");
			await done();
		} catch (x) {
			setError(messageOf(x));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: "Daily merchant verification",
		description: "VimoPay requires one fresh biometric 2FA per India calendar day.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "space-y-4",
			children: [
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
					tone: "error",
					children: error
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Merchant Aadhaar",
							value: aadhaar,
							onChange: (v) => setAadhaar(digits(v).slice(0, 12)),
							required: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "RD device type",
							value: deviceType,
							onChange: setDeviceType,
							required: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Latitude",
							value: lat,
							onChange: setLat,
							required: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Longitude",
							value: long,
							onChange: setLong,
							required: true
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Capture, {
					value: pid,
					onChange: setPid
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Submit, {
					busy: busy || !pid,
					children: "Complete daily 2FA"
				})
			]
		})
	});
}
var services = [
	{
		code: "BE",
		title: "Balance Enquiry",
		icon: WalletCards,
		financial: false,
		permission: UI_PERMISSION.AEPS_BALANCE_ENQUIRY
	},
	{
		code: "MS",
		title: "Mini Statement",
		icon: ReceiptText,
		financial: false,
		permission: UI_PERMISSION.AEPS_MINI_STATEMENT
	},
	{
		code: "CW",
		title: "Cash Withdrawal",
		icon: Banknote,
		financial: true,
		permission: UI_PERMISSION.AEPS_CASH_WITHDRAWAL
	},
	{
		code: "AP",
		title: "Aadhaar Pay",
		icon: BadgeIndianRupee,
		financial: true,
		permission: UI_PERMISSION.AEPS_AADHAAR_PAY
	},
	{
		code: "CD",
		title: "Cash Deposit",
		icon: Landmark,
		financial: true,
		permission: UI_PERMISSION.AEPS_CASH_DEPOSIT
	}
];
function TransactionWorkspace({ token, access }) {
	const [operation, setOperation] = (0, import_react.useState)(null), [result, setResult] = (0, import_react.useState)(null);
	if (result) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt$1, {
		result,
		again: () => {
			setResult(null);
			setOperation(null);
		}
	});
	if (operation) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransactionForm, {
		token,
		operation,
		done: setResult,
		cancel: () => setOperation(null),
		allowed: access.services[operation]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		title: "AEPS services",
		description: "Choose a service. Every biometric capture must be fresh for the current transaction.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
			children: services.map(({ code, title, icon: Icon, financial, permission }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				disabled: !access.services[code],
				title: access.services[code] ? title : `Requires ${permission}`,
				onClick: () => access.services[code] && setOperation(code),
				className: "group rounded-2xl border border-border bg-background p-5 text-left transition enabled:hover:-translate-y-0.5 enabled:hover:border-primary/50 enabled:hover:shadow-soft disabled:cursor-not-allowed disabled:opacity-45",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-12 w-12 place-items-center rounded-xl bg-mint text-secondary group-hover:bg-primary group-hover:text-white",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-4 font-extrabold text-secondary",
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: financial ? "₹100–₹10,000 • protected against duplicate debit" : "Fresh biometric authentication required"
					})
				]
			}, code))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 flex items-start gap-3 rounded-xl bg-amber-50 p-4 text-xs text-amber-900",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {
				size: 17,
				className: "shrink-0"
			}), " Never retry PENDING or UNKNOWN financial transactions. Use the platform reference shown on the receipt for support."]
		})]
	});
}
function TransactionForm({ token, operation, done, cancel, allowed }) {
	const service = services.find((x) => x.code === operation);
	const needsAmount = service.financial;
	const [form, setForm] = (0, import_react.useState)({
		aadhaarNumber: "",
		mobileNumber: "",
		bankIIN: "",
		amount: "",
		lat: "",
		long: "",
		deviceType: "mantra",
		pidData: ""
	});
	const [authType, setAuthType] = (0, import_react.useState)("BA"), [iins, setIins] = (0, import_react.useState)([]), [otp, setOtp] = (0, import_react.useState)(""), [auth, setAuth] = (0, import_react.useState)(null), [intentKey, setIntentKey] = (0, import_react.useState)(""), [busy, setBusy] = (0, import_react.useState)(false), [error, setError] = (0, import_react.useState)("");
	const highValue = (operation === "CW" || operation === "AP") && Number(form.amount) > 5e3;
	(0, import_react.useEffect)(() => {
		aepsApi.bankIins(token, operation, authType).then(setIins).catch((e) => setError(messageOf(e)));
	}, [
		authType,
		operation,
		token
	]);
	(0, import_react.useEffect)(() => {
		navigator.geolocation?.getCurrentPosition((p) => setForm((f) => ({
			...f,
			lat: String(p.coords.latitude),
			long: String(p.coords.longitude)
		})));
	}, []);
	const set = (key, value) => {
		setForm((f) => ({
			...f,
			[key]: value
		}));
		setIntentKey("");
	};
	const requestOtp = async () => {
		if (!allowed) return setError(`Permission ${service.permission} is required.`);
		setBusy(true);
		setError("");
		try {
			const a = await aepsApi.transactionOtp(token, operation, {
				aadhaarNumber: form.aadhaarNumber,
				mobileNumber: form.mobileNumber,
				amount: form.amount,
				bankIIN: form.bankIIN,
				lat: form.lat,
				long: form.long,
				appPlatform: "web",
				appVersion: "1.0.0"
			});
			setAuth(a);
			setForm((f) => ({
				...f,
				pidData: ""
			}));
		} catch (e) {
			setError(messageOf(e));
		} finally {
			setBusy(false);
		}
	};
	async function submit(e) {
		e.preventDefault();
		if (!allowed) return setError(`Permission ${service.permission} is required.`);
		const amount = Number(form.amount);
		if (needsAmount && (!Number.isFinite(amount) || amount < 100 || amount > 1e4)) {
			setError("Amount must be between ₹100 and ₹10,000.");
			return;
		}
		if (form.aadhaarNumber.length !== 12 || form.mobileNumber.length !== 10) {
			setError("Enter a valid 12-digit Aadhaar number and 10-digit mobile number.");
			return;
		}
		if (!form.bankIIN || !form.lat || !form.long) {
			setError("Select the customer bank and allow location access before continuing.");
			return;
		}
		if (highValue && !auth) {
			await requestOtp();
			return;
		}
		setBusy(true);
		setError("");
		try {
			const body = {
				...form,
				...needsAmount ? {} : { amount: void 0 },
				...auth ? { authRequestId: auth.authRequestId } : {}
			};
			const key = service.financial ? intentKey || newIdempotencyKey() : void 0;
			if (key && !intentKey) setIntentKey(key);
			done(await aepsApi.transact(token, operation, body, key));
			setIntentKey("");
			setForm((f) => ({
				...f,
				aadhaarNumber: "",
				pidData: ""
			}));
			setOtp("");
		} catch (x) {
			setError(messageOf(x));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title: service.title,
		description: "Customer Aadhaar and biometric data are held only in memory and are never stored by this page.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: submit,
			className: "space-y-5",
			children: [
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
					tone: "error",
					children: error
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Customer Aadhaar",
							value: form.aadhaarNumber,
							onChange: (v) => set("aadhaarNumber", digits(v).slice(0, 12)),
							required: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Customer mobile",
							value: form.mobileNumber,
							onChange: (v) => set("mobileNumber", digits(v).slice(0, 10)),
							required: true
						}),
						needsAmount && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Amount (₹100–₹10,000)",
							value: form.amount,
							onChange: (v) => set("amount", v.replace(/[^\d.]/g, "")),
							required: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
							label: "Authentication",
							value: authType,
							onChange: (v) => setAuthType(v),
							options: [{
								value: "BA",
								label: "Fingerprint / biometric"
							}, {
								value: "FA",
								label: "Face authentication"
							}]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
							label: "Customer bank",
							value: form.bankIIN,
							onChange: (v) => set("bankIIN", v),
							options: iins.map((i) => ({
								value: i.iin || "",
								label: i.description
							}))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "RD device type",
							value: form.deviceType,
							onChange: (v) => set("deviceType", v),
							required: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Latitude",
							value: form.lat,
							onChange: (v) => set("lat", v),
							required: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Longitude",
							value: form.long,
							onChange: (v) => set("long", v),
							required: true
						})
					]
				}),
				highValue && !auth && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Notice, {
					tone: "info",
					children: "Amounts above ₹5,000 require a provider OTP before biometric capture. Submit the details below to request it."
				}),
				auth && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-emerald-200 bg-emerald-50 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-bold text-emerald-800",
							children: "Transaction OTP sent"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-emerald-700",
							children: [
								"Authorization expires ",
								new Date(auth.expiresAt).toLocaleString(),
								". Enter the customer OTP below; it is sent only to the RD device capture request."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Provider OTP for RD capture",
								value: otp,
								onChange: (v) => setOtp(digits(v)),
								required: true
							})
						})
					]
				}),
				(!highValue || auth) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Capture, {
					value: form.pidData,
					onChange: (v) => set("pidData", v),
					otp: auth ? otp : void 0
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: cancel,
						className: "flex-1 rounded-xl border border-border py-3 text-sm font-bold",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: !allowed || busy || (!highValue || !!auth) && !form.pidData,
						className: "flex-[2] rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground disabled:opacity-50",
						children: busy ? "Processing…" : highValue && !auth ? "Send transaction OTP" : `Confirm ${service.title}`
					})]
				})
			]
		})
	});
}
function Capture({ value, onChange, otp }) {
	const [url, setUrl] = (0, import_react.useState)("http://127.0.0.1:11100/rd/capture"), [busy, setBusy] = (0, import_react.useState)(false), [error, setError] = (0, import_react.useState)("");
	const run = async () => {
		setBusy(true);
		setError("");
		try {
			onChange(await capturePid(url, otp));
		} catch (e) {
			setError(messageOf(e));
		} finally {
			setBusy(false);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-background p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-11 w-11 place-items-center rounded-xl bg-mint text-secondary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FingerprintPattern, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-extrabold text-secondary",
						children: "Registered biometric device"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Capture a new PID for this request only."
					})] }),
					value && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "ml-auto text-emerald-600" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					"aria-label": "RD service URL",
					value: url,
					onChange: (e) => setUrl(e.target.value),
					className: "min-w-0 flex-1 rounded-xl border border-border bg-card px-3 py-2 text-xs outline-none focus:border-primary"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					disabled: busy || !!otp === false && otp !== void 0,
					onClick: run,
					className: "rounded-xl bg-secondary px-5 py-2 text-xs font-bold text-white disabled:opacity-50",
					children: busy ? "Capturing…" : value ? "Capture again" : "Capture fingerprint"
				})]
			}),
			otp !== void 0 && !otp && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-amber-700",
				children: "Enter the provider OTP before biometric capture."
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs font-semibold text-red-700",
				children: error
			})
		]
	});
}
function Receipt$1({ result, again }) {
	const detail = result.result || result;
	const providerStatus = String(detail.status || result.status || "").toUpperCase();
	const success = providerStatus === "000" || providerStatus === "SUCCESS";
	const pending = providerStatus === "PENDING" || providerStatus === "UNKNOWN" || result.settlement?.status === "PENDING";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		title: success ? "Transaction successful" : pending ? "Transaction pending" : "Transaction result",
		description: "Keep the Nexus platform reference for support and transaction tracking.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `rounded-2xl p-6 text-center ${success ? "bg-emerald-50 text-emerald-900" : "bg-amber-50 text-amber-900"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
						className: "mx-auto",
						size: 42
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm font-bold",
						children: String(detail.statusDescription || detail.npciMessage || result.message || "Response received")
					}),
					detail.availableBalance != null && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-3xl font-extrabold",
						children: ["₹", String(detail.availableBalance)]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
				className: "mt-5 grid gap-3 sm:grid-cols-2",
				children: [
					["Platform reference", result.transactionReferenceId],
					["Provider merchant reference", result.merchantRefId],
					["Transaction type", result.transactionType],
					["Amount", result.amount ? `₹${result.amount}` : void 0],
					["Gross amount", result.accounting?.grossAmount ? `₹${result.accounting.grossAmount}` : void 0],
					["Commission", result.accounting?.commissionAmount ? `₹${result.accounting.commissionAmount}` : void 0],
					["Net principal", result.accounting?.netPrincipalAmount ? `₹${result.accounting.netPrincipalAmount}` : void 0],
					["Settlement", result.settlement?.status],
					["Wallet reference", result.settlement?.transactionReference],
					["Commission status", result.commission?.status],
					["Commission reference", result.commission?.commissionReference],
					["RRN", detail.rrn],
					["NPCI code", detail.npciCode],
					["Aadhaar", detail.aadhaarNo]
				].filter(([, v]) => v != null).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-border p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-xs text-muted-foreground",
						children: String(k)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 break-all text-sm font-bold text-secondary",
						children: String(v)
					})]
				}, String(k)))
			}),
			detail.transactionList != null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-4 whitespace-pre-wrap rounded-xl bg-muted p-4 text-xs",
				children: String(detail.transactionList)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: again,
				className: "mt-5 w-full rounded-xl bg-primary py-3 text-sm font-bold text-white",
				children: "Done"
			})
		]
	});
}
function Panel({ title, description, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-border bg-card p-5 shadow-soft sm:p-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-2xl font-extrabold text-secondary",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: description
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children
			})
		]
	});
}
function Field({ label, value, onChange, placeholder, required }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-bold text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			required,
			value,
			placeholder,
			onChange: (e) => onChange(e.target.value),
			autoComplete: "off",
			className: "mt-1.5 w-full rounded-xl border border-border bg-background px-3 py-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/10"
		})]
	});
}
function SelectField({ label, value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-bold text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
			required: true,
			value,
			onChange: (e) => onChange(e.target.value),
			className: "mt-1.5 w-full rounded-xl border border-border bg-background px-3 py-3 text-sm outline-none focus:border-primary",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: "",
				children: "Select…"
			}), options.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
				value: o.value,
				children: o.label
			}, o.value))]
		})]
	});
}
function Submit({ busy, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		disabled: busy,
		className: "w-full rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground disabled:opacity-50",
		children: busy ? "Please wait…" : children
	});
}
function Notice({ tone, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `mb-4 rounded-xl p-4 text-sm font-semibold ${tone === "error" ? "bg-red-50 text-red-700" : "bg-blue-50 text-blue-800"}`,
		children
	});
}
function Loading() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-64 place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin text-primary" })
	});
}
function StateCard({ icon, title, text, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
		title,
		description: text,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid place-items-center gap-4 py-8 text-primary",
			children: [icon, action && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				onClick: action,
				className: "rounded-xl bg-primary px-6 py-3 text-sm font-bold text-white",
				children: "Check again"
			})]
		})
	});
}
function messageOf(error) {
	return error instanceof ApiError || error instanceof Error ? error.message : "Something went wrong.";
}
function digits(value) {
	return value.replace(/\D/g, "");
}
function sensitive(name) {
	return [
		"merchantPhoneNumber",
		"merchantPinCode",
		"aadhaarNumber",
		"shopPincode"
	].includes(name);
}
function pan(name) {
	return name === "merchantPan" || name === "shopPan";
}
function masterOption(item) {
	return {
		value: item.code || "",
		label: item.description
	};
}
//#endregion
export { AepsPage as component };
