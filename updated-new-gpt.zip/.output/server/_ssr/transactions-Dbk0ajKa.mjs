import { r as __toESM } from "../_runtime.mjs";
import { c as getSession } from "./role-hierarchy-B8AZOwBW.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-Cf_Fn8iZ.mjs";
import { t as distributorApi } from "./distributor-api-BY5rX4_z.mjs";
import { t as TransactionDetailDialog } from "./transaction-detail-dialog-B0DNAaUn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/transactions-Dbk0ajKa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DistributorTransactions() {
	const [page, setPage] = (0, import_react.useState)(null), [status, setStatus] = (0, import_react.useState)(""), [error, setError] = (0, import_react.useState)(""), [selectedReference, setSelectedReference] = (0, import_react.useState)(null);
	const load = () => {
		setError("");
		distributorApi.transactions(`page=1&limit=50${status ? `&status=${status}` : ""}`).then(setPage).catch((e) => setError(e instanceof Error ? e.message : "Transactions could not be loaded."));
	};
	(0, import_react.useEffect)(load, [status]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "transactions",
		eyebrow: "AEPS monitoring",
		title: "Retailer AEPS transactions",
		description: "Monitor available AEPS transaction records with status filters.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					value: status,
					onChange: (e) => setStatus(e.target.value),
					className: "rounded-xl border border-border px-4 py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "All statuses"
					}), [
						"SUCCESS",
						"FAILED",
						"PENDING",
						"PROCESSING",
						"REVERSED"
					].map((value) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: value }, value))]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: load,
					className: "rounded-xl bg-primary px-4 py-3 text-sm font-bold text-white",
					children: "Refresh"
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 rounded-xl bg-red-50 p-3 text-sm text-red-700",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 overflow-x-auto",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[760px] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3",
								children: "Reference"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3",
								children: "Operation"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3",
								children: "Provider"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3",
								children: "Amount"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3",
								children: "Status"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "p-3",
								children: "Date"
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: page?.data.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border/60",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setSelectedReference(row.referenceId),
									className: "font-bold text-primary hover:underline",
									children: row.referenceId
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3",
								children: row.operation
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3",
								children: row.provider
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "p-3",
								children: ["₹", Number(row.amount).toLocaleString("en-IN")]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3 font-bold",
								children: row.status
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "p-3",
								children: new Date(row.createdAt).toLocaleString("en-IN")
							})
						]
					}, row.id)) })]
				}), !page?.data.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "py-10 text-center text-sm text-muted-foreground",
					children: "No matching transactions returned."
				})]
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TransactionDetailDialog, {
			accessToken: getSession()?.accessToken || "",
			referenceId: selectedReference,
			onClose: () => setSelectedReference(null)
		})]
	});
}
//#endregion
export { DistributorTransactions as component };
