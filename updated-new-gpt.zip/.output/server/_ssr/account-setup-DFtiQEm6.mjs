import { r as AdminIdentitySetup } from "./router-DughR4Dc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-setup-DFtiQEm6.js
var SplitComponent = AdminIdentitySetup;
//#endregion
export { SplitComponent as component };
