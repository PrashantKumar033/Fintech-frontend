//#region node_modules/.nitro/vite/services/ssr/assets/role-hierarchy-B8AZOwBW.js
var logo_default = "/assets/logo-Bhmma_C9.png";
var DEVICE_ID_KEY = "umobipay_device_id";
/** Returns a stable, opaque browser-installation identifier accepted by LoginDto. */
function getDeviceId() {
	if (typeof window === "undefined") return "umobipay-web-ssr";
	const existing = window.localStorage.getItem(DEVICE_ID_KEY)?.trim();
	if (existing && existing.length <= 100) return existing;
	const deviceId = `umobipay-web-${typeof crypto !== "undefined" && typeof crypto.randomUUID === "function" ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`}`.slice(0, 100);
	window.localStorage.setItem(DEVICE_ID_KEY, deviceId);
	return deviceId;
}
var API_URL = (typeof window !== "undefined" ? `${window.location.protocol}//${window.location.hostname}:8000` : "http://localhost:8000").replace(/\/$/, "");
if (!/^https?:\/\//.test(API_URL)) throw new Error("VITE_API_URL must be an absolute HTTP(S) URL.");
var PERMISSION_CACHE_KEY = "nexus_effective_permissions";
var ApiError = class extends Error {
	status;
	constructor(message, status) {
		super(message);
		this.status = status;
		this.name = "ApiError";
	}
};
function requiresDeviceVerification(result) {
	return "requiresDeviceVerification" in result && result.requiresDeviceVerification === true;
}
var refreshPromise = null;
function extractApiMessage(data) {
	if (typeof data === "string" && data.trim()) return data;
	if (!data || typeof data !== "object") return null;
	const payload = data;
	if (Array.isArray(payload.message)) return payload.message.map(String).join(", ");
	if (typeof payload.message === "string" && payload.message.trim()) return payload.message;
	return extractApiMessage(payload.message) || extractApiMessage(payload.error) || extractApiMessage(payload.response) || (typeof payload.error === "string" && payload.error.trim() ? payload.error : null);
}
async function request(path, body) {
	let response;
	try {
		response = await fetch(`${API_URL}${path}`, {
			method: "POST",
			credentials: "include",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify(body)
		});
	} catch (error) {
		console.error(`Auth API connection failed: ${API_URL}${path}`, error);
		throw new ApiError("We could not connect to the service. Please try again in a few moments.", 0);
	}
	const data = await response.json().catch(() => ({}));
	if (!response.ok) throw new ApiError(extractApiMessage(data) || "We could not complete your request.", response.status);
	return data;
}
async function refreshSession() {
	if (refreshPromise) return refreshPromise;
	refreshPromise = (async () => {
		let response;
		try {
			response = await fetch(`${API_URL}/auth/refresh`, {
				method: "POST",
				credentials: "include",
				headers: { Accept: "application/json" }
			});
		} catch {
			throw new ApiError("We could not refresh your session.", 0);
		}
		const data = await response.json().catch(() => ({}));
		if (!response.ok) {
			clearSession();
			redirectToLogin();
			throw new ApiError(extractApiMessage(data) || "Your session has expired. Please sign in again.", response.status);
		}
		const session = data;
		if (!session.accessToken || !session.identity) {
			clearSession();
			redirectToLogin();
			throw new ApiError("The server returned an invalid refreshed session.", 500);
		}
		const existing = getSession();
		const refreshed = {
			...session,
			onboardingRequired: session.onboardingRequired ?? existing?.onboardingRequired,
			onboardingStatus: session.onboardingStatus ?? existing?.onboardingStatus,
			nextStep: session.nextStep ?? existing?.nextStep
		};
		saveSession(refreshed.accessToken, refreshed.identity, refreshed);
		return refreshed;
	})().finally(() => {
		refreshPromise = null;
	});
	return refreshPromise;
}
async function authenticatedRequest(path, init = {}, accessToken) {
	let response;
	const send = (token) => fetch(`${API_URL}${path}`, {
		...init,
		credentials: "include",
		headers: {
			Accept: "application/json",
			...init.body && !(init.body instanceof FormData) ? { "Content-Type": "application/json" } : {},
			...init.headers,
			Authorization: `Bearer ${token}`
		}
	});
	try {
		const currentToken = getSession()?.accessToken || accessToken;
		if (!currentToken) throw new ApiError("Your session has expired. Please sign in again.", 401);
		response = await send(currentToken);
		if (response.status === 401) response = await send((await refreshSession()).accessToken);
	} catch (error) {
		if (error instanceof ApiError) throw error;
		console.error(`Auth API connection failed: ${API_URL}${path}`, error);
		throw new ApiError("We could not connect to the service. Please try again in a few moments.", 0);
	}
	const data = await response.json().catch(() => ({}));
	if (!response.ok) {
		if (response.status === 401) {
			clearSession();
			redirectToLogin();
		}
		throw new ApiError(extractApiMessage(data) || "We could not complete your request.", response.status);
	}
	return data;
}
var authApi = {
	login: (body) => request("/auth/login", {
		...body,
		deviceId: getDeviceId()
	}),
	verifyDeviceLogin: (challengeId, otp) => request("/auth/login/verify-device", {
		challengeId,
		otp
	}),
	sendPhoneOtp: (phoneNumber) => request("/auth/send-phone-otp", { phoneNumber }),
	verifyPhoneOtp: (phoneNumber, otp) => request("/auth/verify-phone-otp", {
		phoneNumber,
		otp
	}),
	sendEmailOtp: (email) => request("/auth/send-email-otp", { email }),
	verifyEmailOtp: (email, otp) => request("/auth/verify-email-otp", {
		email,
		otp
	}),
	registerRole: (role) => request("/auth/register/role", { role }),
	registerPhone: (draftId, phoneNumber) => request("/auth/register/phone", {
		draftId,
		phoneNumber
	}),
	verifyRegistrationOtp: (draftId, phoneNumber, otp) => request("/auth/register/verify-otp", {
		draftId,
		phoneNumber,
		otp
	}),
	registerPan: (draftId, panNumber) => request("/auth/register/pan", {
		draftId,
		panNumber
	}),
	registerDetails: (body) => request("/auth/register/details", body),
	changePassword: (accessToken, body) => authenticatedRequest("/auth/change-password", {
		method: "POST",
		body: JSON.stringify(body)
	}, accessToken),
	changeMpin: (accessToken, body) => authenticatedRequest("/auth/change-mpin", {
		method: "POST",
		body: JSON.stringify(body)
	}, accessToken),
	sendIdentityOnboardingPhoneOtp: (phoneNumber) => authenticatedRequest("/auth/onboarding/phone/send-otp", {
		method: "POST",
		body: JSON.stringify({ phoneNumber })
	}),
	verifyIdentityOnboardingPhoneOtp: (otp) => authenticatedRequest("/auth/onboarding/phone/verify-otp", {
		method: "POST",
		body: JSON.stringify({ otp })
	}),
	addIdentityOnboardingPan: (panNumber) => authenticatedRequest("/auth/onboarding/pan", {
		method: "POST",
		body: JSON.stringify({ panNumber })
	}),
	getSessions: () => authenticatedRequest("/auth/sessions"),
	getSessionDetails: (sessionId) => authenticatedRequest(`/auth/sessions/${encodeURIComponent(sessionId)}`),
	revokeSession: (sessionId) => authenticatedRequest(`/auth/sessions/${encodeURIComponent(sessionId)}`, { method: "DELETE" }),
	revokeOtherSessions: () => authenticatedRequest("/auth/sessions/others", { method: "DELETE" }),
	revokeAllSessions: () => authenticatedRequest("/auth/sessions", { method: "DELETE" }),
	getMyPermissions: (accessToken) => authenticatedRequest("/auth/me/permissions", {}, accessToken),
	forgotPasswordVerifyUser: (body) => request("/auth/forgot-password/verify-user", body),
	forgotPasswordVerifyOtp: (draftId, otp) => request("/auth/forgot-password/verify-otp", {
		draftId,
		otp
	}),
	forgotPasswordReset: (body) => request("/auth/forgot-password/reset", body)
};
function saveEffectiveAccess(access) {
	if (typeof window === "undefined") return;
	localStorage.setItem(PERMISSION_CACHE_KEY, JSON.stringify({
		...access,
		fetchedAt: (/* @__PURE__ */ new Date()).toISOString()
	}));
}
function getEffectiveAccess() {
	if (typeof window === "undefined") return null;
	const raw = localStorage.getItem(PERMISSION_CACHE_KEY);
	if (!raw) return null;
	try {
		return JSON.parse(raw);
	} catch {
		localStorage.removeItem(PERMISSION_CACHE_KEY);
		return null;
	}
}
async function syncMyPermissions(accessToken) {
	const access = await authApi.getMyPermissions(accessToken);
	saveEffectiveAccess(access);
	return access;
}
function saveSession(accessToken, identity, onboarding) {
	if (typeof window === "undefined") return;
	if (!onboarding) localStorage.removeItem(PERMISSION_CACHE_KEY);
	const previousIdentityRaw = localStorage.getItem("nexus_identity");
	if (!onboarding && previousIdentityRaw) try {
		if (JSON.parse(previousIdentityRaw).id !== identity.id) localStorage.removeItem("nexus_identity_onboarding");
	} catch {
		localStorage.removeItem("nexus_identity_onboarding");
	}
	localStorage.setItem("nexus_access_token", accessToken);
	localStorage.setItem("nexus_identity", JSON.stringify(identity));
	if (onboarding) localStorage.setItem("nexus_identity_onboarding", JSON.stringify({
		onboardingRequired: onboarding.onboardingRequired,
		onboardingStatus: onboarding.onboardingStatus,
		nextStep: onboarding.nextStep
	}));
}
function updateIdentityOnboarding(nextStep, onboardingStatus) {
	const session = getSession();
	if (!session) return;
	saveSession(session.accessToken, session.identity, {
		onboardingRequired: Boolean(nextStep && nextStep !== "COMPLETE_ONBOARDING"),
		onboardingStatus: onboardingStatus ?? session.onboardingStatus,
		nextStep
	});
}
function updateSessionIdentity(identity) {
	if (typeof window === "undefined") return;
	localStorage.setItem("nexus_identity", JSON.stringify(identity));
}
function getSession() {
	if (typeof window === "undefined") return null;
	const accessToken = localStorage.getItem("nexus_access_token");
	const identityRaw = localStorage.getItem("nexus_identity");
	if (!accessToken || !identityRaw) return null;
	try {
		const onboardingRaw = localStorage.getItem("nexus_identity_onboarding");
		const onboarding = onboardingRaw ? JSON.parse(onboardingRaw) : {};
		return {
			accessToken,
			identity: JSON.parse(identityRaw),
			...onboarding
		};
	} catch {
		return null;
	}
}
function clearSession() {
	if (typeof window === "undefined") return;
	localStorage.removeItem("nexus_access_token");
	localStorage.removeItem("nexus_identity");
	localStorage.removeItem("nexus_identity_onboarding");
	localStorage.removeItem(PERMISSION_CACHE_KEY);
}
function redirectToLogin() {
	if (typeof window !== "undefined" && window.location.pathname !== "/login") window.location.assign("/login");
}
async function logout() {
	try {
		await fetch(`${API_URL}/auth/logout`, {
			method: "POST",
			credentials: "include"
		});
	} finally {
		clearSession();
	}
}
var targets = {
	SUPER_ADMIN: [
		"SUPER_ADMIN",
		"ADMIN",
		"MASTER_DISTRIBUTOR",
		"DISTRIBUTOR",
		"RETAILER"
	],
	ADMIN: [
		"MASTER_DISTRIBUTOR",
		"DISTRIBUTOR",
		"RETAILER"
	],
	MASTER_DISTRIBUTOR: ["DISTRIBUTOR", "RETAILER"],
	DISTRIBUTOR: ["RETAILER"],
	RETAILER: []
};
function normalizeRole(role) {
	const value = role?.trim().toUpperCase().replace(/[ -]+/g, "_");
	return value && value in targets ? value : null;
}
function registrationTargets(role) {
	const normalized = normalizeRole(role);
	return normalized ? targets[normalized] : [];
}
function isManagementRole(role) {
	const normalized = normalizeRole(role);
	return normalized === "ADMIN" || normalized === "MASTER_DISTRIBUTOR" || normalized === "DISTRIBUTOR";
}
function managementBasePath(role) {
	const normalized = normalizeRole(role);
	if (normalized === "MASTER_DISTRIBUTOR") return "/master-distributor";
	if (normalized === "DISTRIBUTOR") return "/distributor";
	return "/admin";
}
function credentialsPending(identity) {
	return Boolean(identity && (!identity.passwordChangedAt || !identity.mpinChangedAt));
}
function identityVerificationPending(session) {
	if (!session || !credentialsPending(session.identity)) return false;
	return !session.identity.phoneNumber || [
		"ADD_AND_VERIFY_PHONE",
		"VERIFY_PHONE_OTP",
		"ADD_PAN"
	].includes(session.nextStep || "");
}
function signedInHome(session) {
	const role = normalizeRole(session.identity.role);
	if (role === "SUPER_ADMIN") return "/admin";
	if (isManagementRole(role)) {
		const base = managementBasePath(role);
		if (credentialsPending(session.identity)) return identityVerificationPending(session) ? `${base}/account-setup` : `${base}/settings`;
		return base;
	}
	if (role === "RETAILER") {
		if (credentialsPending(session.identity)) return identityVerificationPending(session) ? "/retailer/account-setup" : "/retailer/settings";
		return "/retailer/dashboard";
	}
	return "/login";
}
//#endregion
export { updateSessionIdentity as S, requiresDeviceVerification as _, credentialsPending as a, syncMyPermissions as b, getSession as c, logo_default as d, logout as f, registrationTargets as g, refreshSession as h, clearSession as i, identityVerificationPending as l, normalizeRole as m, authApi as n, getDeviceId as o, managementBasePath as p, authenticatedRequest as r, getEffectiveAccess as s, ApiError as t, isManagementRole as u, saveSession as v, updateIdentityOnboarding as x, signedInHome as y };
