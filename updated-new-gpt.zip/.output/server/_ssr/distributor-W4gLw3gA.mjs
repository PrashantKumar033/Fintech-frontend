import { a as DistributorDashboard } from "./router-DughR4Dc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/distributor-W4gLw3gA.js
var SplitComponent = DistributorDashboard;
//#endregion
export { SplitComponent as component };
