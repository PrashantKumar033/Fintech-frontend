import { t as AdminSettingsPage } from "./admin-settings-page-CPoJwqh8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-lEOUSRgt.js
var SplitComponent = AdminSettingsPage;
//#endregion
export { SplitComponent as component };
