import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { ft as LayoutTemplate, tn as Cable, v as Tags } from "../_libs/lucide-react.mjs";
import { t as AdminLayout } from "./admin-layout-Cf_Fn8iZ.mjs";
import { t as AdminFeatureGrid } from "./admin-feature-grid-SQgrkdcH.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sms--U329LE_.js
var import_jsx_runtime = require_jsx_runtime();
function Sms() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "sms",
		eyebrow: "Communication",
		title: "SMS settings",
		description: "Configure transactional message categories, templates and provider integrations.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminFeatureGrid, { features: [
			{
				title: "SMS categories",
				description: "Organize login, transaction and operational messages.",
				icon: Tags
			},
			{
				title: "SMS templates",
				description: "Manage approved message bodies and template identifiers.",
				icon: LayoutTemplate
			},
			{
				title: "SMS integrations",
				description: "Configure provider credentials, routing and delivery settings.",
				icon: Cable
			}
		] })
	});
}
//#endregion
export { Sms as component };
