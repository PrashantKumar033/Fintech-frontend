import { r as authenticatedRequest } from "./role-hierarchy-B8AZOwBW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/distributor-api-BY5rX4_z.js
var distributorApi = {
	balances: (identityId) => authenticatedRequest(`/wallet/balances/${encodeURIComponent(identityId)}`),
	transactions: (query = "page=1&limit=50") => authenticatedRequest(`/aeps/transactions?${query}`),
	retailers: (identityId) => authenticatedRequest(`/commission-hierarchy/parent/${encodeURIComponent(identityId)}/children`),
	audits: () => authenticatedRequest("/audit/me?page=1&limit=50"),
	commissions: () => authenticatedRequest("/commission-distributions/distributions")
};
//#endregion
export { distributorApi as t };
