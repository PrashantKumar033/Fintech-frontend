import { t as AdminSettingsPage } from "./admin-settings-page-CPoJwqh8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-CXsLIkIL.js
var SplitComponent = AdminSettingsPage;
//#endregion
export { SplitComponent as component };
