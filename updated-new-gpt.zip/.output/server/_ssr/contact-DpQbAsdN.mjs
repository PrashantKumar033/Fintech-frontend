import { r as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { O as Send, Ut as Clock3, W as Phone, it as Mail, rt as MapPin } from "../_libs/lucide-react.mjs";
import { n as SiteNav, t as SiteFooter } from "./site-footer-DjO9amhV.mjs";
import { t as useFormik } from "../_libs/formik+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/contact-DpQbAsdN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var contact_support_default = "/assets/contact-support-D_4WeYmN.png";
var contactCards = [
	{
		icon: Mail,
		title: "Email",
		value: "support@umobipay.com",
		href: "mailto:support@umobipay.com",
		note: "Write to our support desk"
	},
	{
		icon: MapPin,
		title: "Office address",
		value: "7, Residence Colony, near Axis Bank, Cheeka, Haryana 136034",
		href: "https://maps.google.com/?q=Cheeka,Haryana",
		note: "Get directions"
	},
	{
		icon: Phone,
		title: "Phone",
		value: "+91 96103 31378",
		href: "tel:+919610331378",
		note: "Call our team"
	}
];
function Contact() {
	const [sent, setSent] = (0, import_react.useState)(false);
	const formik = useFormik({
		initialValues: {
			name: "",
			email: "",
			phone: "",
			message: ""
		},
		validate: (values) => {
			const errors = {};
			if (!values.name.trim()) errors.name = "Full name is required";
			if (!values.email.trim()) errors.email = "Email is required";
			else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) errors.email = "Enter a valid email";
			if (!/^\+?[0-9\s-]{10,15}$/.test(values.phone.trim())) errors.phone = "Enter a valid phone number";
			if (values.message.trim().length < 10) errors.message = "Please provide at least 10 characters";
			return errors;
		},
		onSubmit: (_, { resetForm }) => {
			setSent(true);
			resetForm();
		}
	});
	const fieldClass = "mt-2 w-full rounded-2xl border border-white/15 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-white/40 focus:border-primary focus:outline-none";
	const error = (name) => formik.touched[name] && formik.errors[name] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-1 text-xs text-red-200",
		children: formik.errors[name]
	}) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteNav, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative overflow-hidden bg-mint",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-grid opacity-40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto grid max-w-7xl items-center gap-8 px-6 py-14 lg:grid-cols-[1.05fr_.95fr] lg:py-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-bold uppercase tracking-[.22em] text-primary",
							children: "Support & partnerships"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-4 text-4xl font-extrabold text-secondary sm:text-6xl",
							children: ["Connect with ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-primary",
								children: "UMOBIPAY"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-xl text-base leading-7 text-foreground/70 sm:text-lg",
							children: "Have a question, need service assistance, or want to grow as a retail partner? Our dedicated team is ready to help."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: contact_support_default,
						alt: "UMOBIPAY customer support representative",
						className: "mx-auto max-h-72 w-full object-contain"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-7xl px-6 py-16 sm:py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mb-12 grid gap-5 md:grid-cols-3",
					children: contactCards.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: item.href,
						className: "group rounded-3xl border border-border bg-card p-7 text-center shadow-soft transition hover:-translate-y-1 hover:border-primary/40",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-mint text-secondary transition group-hover:bg-primary group-hover:text-white",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { size: 24 })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-5 text-xl font-bold text-secondary",
								children: item.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mx-auto mt-2 max-w-xs text-sm leading-6 text-foreground/70",
								children: item.value
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-xs font-bold uppercase tracking-widest text-primary",
								children: item.note
							})
						]
					}, item.title))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-8 lg:grid-cols-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-hidden rounded-[2.5rem] border border-border bg-card shadow-soft lg:col-span-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
							title: "UMOBIPAY office location in Cheeka, Haryana",
							src: "https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d55251.18668576599!2d76.384229!3d30.059825!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3911d128898b0beb%3A0x822c5d286aae2dcb!2sCheeka%2C%20Haryana!5e0!3m2!1sen!2sin!4v1788430420557!5m2!1sen!2sin",
							className: "h-[420px] w-full border-0 lg:h-full",
							loading: "lazy",
							referrerPolicy: "strict-origin-when-cross-origin",
							allowFullScreen: true
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-[2.5rem] bg-secondary p-8 text-white sm:p-10 lg:col-span-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-3xl font-extrabold",
								children: "Send us a message"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-white/70",
								children: "Share your requirement and our team will contact you during business hours."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
								onSubmit: formik.handleSubmit,
								className: "mt-8 space-y-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "text-xs font-bold uppercase tracking-widest text-white/70",
											children: "Full name"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "name",
											value: formik.values.name,
											onChange: formik.handleChange,
											onBlur: formik.handleBlur,
											placeholder: "Your full name",
											className: fieldClass
										}),
										error("name")
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "text-xs font-bold uppercase tracking-widest text-white/70",
											children: "Email"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "email",
											type: "email",
											value: formik.values.email,
											onChange: formik.handleChange,
											onBlur: formik.handleBlur,
											placeholder: "you@company.com",
											className: fieldClass
										}),
										error("email")
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "text-xs font-bold uppercase tracking-widest text-white/70",
											children: "Phone"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											name: "phone",
											value: formik.values.phone,
											onChange: formik.handleChange,
											onBlur: formik.handleBlur,
											placeholder: "+91 98765 43210",
											className: fieldClass
										}),
										error("phone")
									] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "text-xs font-bold uppercase tracking-widest text-white/70",
											children: "Message"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
											name: "message",
											rows: 4,
											value: formik.values.message,
											onChange: formik.handleChange,
											onBlur: formik.handleBlur,
											placeholder: "Tell us how we can help...",
											className: fieldClass
										}),
										error("message")
									] }),
									sent && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										role: "status",
										className: "rounded-xl bg-emerald-400/15 p-3 text-sm text-emerald-100",
										children: "Thank you. Your enquiry has been recorded."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "submit",
										className: "inline-flex items-center gap-2 rounded-full bg-primary px-7 py-3.5 text-sm font-semibold text-white shadow-elegant",
										children: ["Send enquiry ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { size: 15 })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "flex items-center gap-2 text-xs text-white/60",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { size: 14 }), " Monday–Saturday, 9:00 AM–8:00 PM IST"]
									})
								]
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { Contact as component };
