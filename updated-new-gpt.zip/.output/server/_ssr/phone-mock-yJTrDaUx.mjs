//#region node_modules/.nitro/vite/services/ssr/assets/phone-mock-yJTrDaUx.js
var phone_mock_default = "/assets/phone-mock-BUsrpQeV.png";
//#endregion
export { phone_mock_default as t };
