import { r as AdminIdentitySetup } from "./router-DughR4Dc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-setup-C6bBx7cF.js
var SplitComponent = AdminIdentitySetup;
//#endregion
export { SplitComponent as component };
