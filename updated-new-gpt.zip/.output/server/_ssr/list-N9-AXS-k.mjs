import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { k as Search, s as Users, u as UserPlus } from "../_libs/lucide-react.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-Cf_Fn8iZ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/list-N9-AXS-k.js
var import_jsx_runtime = require_jsx_runtime();
function MemberList() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "merchants",
		eyebrow: "Network",
		title: "Member list",
		description: "Search, filter and manage platform identities from a dedicated listing workflow.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col justify-between gap-4 sm:flex-row sm:items-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative max-w-md flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
					size: 17,
					className: "absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					disabled: true,
					placeholder: "Search by login ID, name, email or phone",
					className: "w-full rounded-xl border border-border bg-muted py-3 pl-10 pr-4 text-sm"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/admin/merchants/add",
				className: "flex items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 text-xs font-extrabold text-white",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { size: 16 }), " Add member"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 grid min-h-72 place-items-center rounded-2xl border border-dashed border-border bg-muted/30 p-8 text-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-white text-secondary shadow-sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-lg font-black",
					children: "Member listing API is not exposed"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mx-auto mt-2 max-w-lg text-sm leading-6 text-muted-foreground",
					children: "The verified backend currently provides account creation only. Search, pagination, edit, status and delete controls will remain disabled until protected member-list endpoints exist."
				})
			] })
		})] })
	});
}
//#endregion
export { MemberList as component };
