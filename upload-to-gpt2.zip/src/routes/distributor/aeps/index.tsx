import { createFileRoute, Link } from "@tanstack/react-router";
import { Banknote, FileText, Landmark } from "lucide-react";
import { AdminLayout, AdminPanel } from "@/components/admin/admin-layout";

export const Route = createFileRoute("/distributor/aeps/")({ component: AepsOverview });

function AepsOverview() {
  const items = [
    [
      "Transactions",
      "Monitor all Retailer AEPS activity",
      "/distributor/aeps/transactions",
      FileText,
    ],
    [
      "Cash withdrawal",
      "Monitor Retailer cash withdrawals",
      "/distributor/aeps/cash-withdrawal",
      Banknote,
    ],
    [
      "Balance enquiry",
      "Monitor Retailer balance enquiries",
      "/distributor/aeps/balance-enquiry",
      Landmark,
    ],
    [
      "Mini statement",
      "Monitor Retailer mini statements",
      "/distributor/aeps/mini-statement",
      FileText,
    ],
  ] as const;

  return (
    <AdminLayout
      active="transactions"
      eyebrow="Assisted banking"
      title="AEPS monitoring"
      description="Monitor your Retailer network here. Customer biometric execution remains available only in the Retailer panel."
    >
      <div className="grid gap-4 md:grid-cols-2">
        {items.map(([title, text, to, Icon]) => (
          <Link to={to} key={title} className="block cursor-pointer">
            <AdminPanel className="h-full transition hover:border-primary hover:shadow-md">
              <Icon className="text-primary" />
              <h2 className="mt-4 text-lg font-black">{title}</h2>
              <p className="mt-2 text-sm text-muted-foreground">{text}</p>
            </AdminPanel>
          </Link>
        ))}
      </div>
    </AdminLayout>
  );
}
