//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BlaNyiTR.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/activity",
			"/contact",
			"/forgot-password",
			"/login",
			"/privacy",
			"/refund-policy",
			"/register",
			"/services",
			"/terms",
			"/admin/account-setup",
			"/admin/login",
			"/admin/onboarding",
			"/distributor/$",
			"/distributor/account-setup",
			"/distributor/dashboard",
			"/master-distributor/$",
			"/master-distributor/account-setup",
			"/master-distributor/dashboard",
			"/retailer/account-setup",
			"/retailer/dashboard",
			"/retailer/settings",
			"/admin/",
			"/distributor/",
			"/master-distributor/",
			"/admin/commissions/hierarchy",
			"/admin/profile/bank",
			"/admin/profile/kyc",
			"/distributor/aeps/balance-enquiry",
			"/distributor/aeps/cash-withdrawal",
			"/distributor/aeps/mini-statement",
			"/distributor/aeps/transactions",
			"/distributor/profile/bank",
			"/distributor/profile/kyc",
			"/distributor/wallet/transfer",
			"/master-distributor/profile/bank",
			"/master-distributor/profile/kyc",
			"/master-distributor/wallet/history",
			"/master-distributor/wallet/requests",
			"/master-distributor/wallet/transfer",
			"/retailer/wallet/transfer",
			"/admin/access/",
			"/admin/api-settings/",
			"/admin/banking/",
			"/admin/commissions/",
			"/admin/kyc/",
			"/admin/legal/",
			"/admin/merchants/",
			"/admin/profile/",
			"/admin/reports/",
			"/admin/settings/",
			"/admin/settlements/",
			"/admin/sms/",
			"/admin/transactions/",
			"/distributor/aeps/",
			"/distributor/commission/",
			"/distributor/profile/",
			"/distributor/reports/",
			"/distributor/retailers/",
			"/distributor/settings/",
			"/distributor/support/",
			"/distributor/wallet/",
			"/master-distributor/commission/",
			"/master-distributor/kyc/",
			"/master-distributor/notifications/",
			"/master-distributor/profile/",
			"/master-distributor/reports/",
			"/master-distributor/settings/",
			"/master-distributor/support/",
			"/master-distributor/transactions/",
			"/master-distributor/wallet/",
			"/retailer/aeps/",
			"/retailer/bank/",
			"/retailer/kyc/",
			"/retailer/transactions/",
			"/retailer/wallet/",
			"/admin/merchants/add/",
			"/admin/merchants/list/",
			"/distributor/retailers/add/",
			"/master-distributor/network/distributors/",
			"/master-distributor/network/retailers/",
			"/master-distributor/network/tree/",
			"/master-distributor/network/distributors/add/"
		],
		preloads: [
			"/assets/index-BS3cm4PF.js",
			"/assets/useRouter-Dpb7RwMI.js",
			"/assets/link-CUOYqXrb.js",
			"/assets/fileRoute-CW4_dn4B.js",
			"/assets/preload-helper-CNW_eQwo.js",
			"/assets/QueryClientProvider-D2ORKNlU.js",
			"/assets/list-CZzGFZqM.js",
			"/assets/commissions-CXqQyfr0.js",
			"/assets/account-setup-BLOG6YbP.js",
			"/assets/dashboard-C5wRv6nG.js",
			"/assets/dashboard-CJNDMczj.js",
			"/assets/merchants-C8l0CASq.js",
			"/assets/transactions-BsSSwaeb.js",
			"/assets/bank-DyeP61Qz.js",
			"/assets/kyc-B9dX82_o.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BS3cm4PF.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BCYalSQE.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/arrow-up-right-BvVdVLFn.js",
			"/assets/banknote-C6usj-O4.js",
			"/assets/tv-1gmBC7Ns.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/credit-card-maer9814.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/site-footer-CZ-mLLI2.js",
			"/assets/fingerprint-pattern-DusAVo6P.js",
			"/assets/layers-CcIsRSix.js",
			"/assets/lock-B_gNe_BY.js",
			"/assets/plus-Bdnb2ZNb.js",
			"/assets/receipt-DFDQG__6.js",
			"/assets/rocket-DQwWGqf5.js",
			"/assets/send-CbjhJMmq.js",
			"/assets/shield-BW8Z1vjs.js",
			"/assets/smartphone-BtuZSEaD.js",
			"/assets/phone-mock-Dwfrz5MA.js",
			"/assets/wallet-C_FdkSA2.js",
			"/assets/zap-BAHwXssL.js"
		]
	},
	"/about": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-CB3_76yK.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/site-footer-CZ-mLLI2.js",
			"/assets/headphones-CSMfsWDB.js",
			"/assets/rocket-DQwWGqf5.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/phone-mock-Dwfrz5MA.js",
			"/assets/zap-BAHwXssL.js",
			"/assets/about-team-DwbCHxeD.js"
		]
	},
	"/activity": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/activity.tsx",
		children: void 0,
		preloads: [
			"/assets/activity-XUjJbJnu.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-DaIzvN8r.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/audit-detail-dialog-CQm4IabV.js",
			"/assets/operations-api-CvrDDE-S.js"
		]
	},
	"/contact": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/contact.tsx",
		children: void 0,
		preloads: [
			"/assets/contact-DkXqckqN.js",
			"/assets/clock-3-CGRh6MXR.js",
			"/assets/site-footer-CZ-mLLI2.js",
			"/assets/mail-COJLXX0Q.js",
			"/assets/map-pin-DQIlFshA.js",
			"/assets/phone-DvXayWc-.js",
			"/assets/send-CbjhJMmq.js"
		]
	},
	"/forgot-password": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/forgot-password.tsx",
		children: void 0,
		preloads: [
			"/assets/forgot-password-B7PFVc-u.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-left-BjAwhohy.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/eye-off-McVPoG-a.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/site-footer-CZ-mLLI2.js",
			"/assets/key-round-CZp0iHdH.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/user-D00v0c_Y.js"
		]
	},
	"/login": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DsUwpLJF.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/eye-off-McVPoG-a.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/site-footer-CZ-mLLI2.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/lock-B_gNe_BY.js",
			"/assets/shield-BW8Z1vjs.js",
			"/assets/smartphone-BtuZSEaD.js",
			"/assets/admin-api-B3yzv6-u.js"
		]
	},
	"/privacy": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/privacy.tsx",
		children: void 0,
		preloads: [
			"/assets/privacy-IYL61ebQ.js",
			"/assets/policy-page-ZRrTr13X.js",
			"/assets/shield-check-ChgPxF7N.js"
		]
	},
	"/refund-policy": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/refund-policy.tsx",
		children: void 0,
		preloads: [
			"/assets/refund-policy-BWo72DtM.js",
			"/assets/policy-page-ZRrTr13X.js",
			"/assets/rotate-ccw-CBht_CfB.js"
		]
	},
	"/register": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/register.tsx",
		children: void 0,
		preloads: [
			"/assets/register-DnjO6WW6.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-left-BjAwhohy.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/site-footer-CZ-mLLI2.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/rocket-DQwWGqf5.js",
			"/assets/shield-check-ChgPxF7N.js"
		]
	},
	"/services": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/services.tsx",
		children: void 0,
		preloads: [
			"/assets/services-Be-u9Uvw.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/badge-check-BwLOlpyy.js",
			"/assets/banknote-C6usj-O4.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/credit-card-maer9814.js",
			"/assets/site-footer-CZ-mLLI2.js",
			"/assets/flame-vsWJXxaR.js",
			"/assets/landmark-dUYLgG_6.js",
			"/assets/receipt-text-Dgko8puo.js",
			"/assets/send-CbjhJMmq.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/smartphone-BtuZSEaD.js",
			"/assets/store-D_GWgnJN.js",
			"/assets/wifi-BXtKiUfv.js",
			"/assets/zap-BAHwXssL.js",
			"/assets/about-team-DwbCHxeD.js"
		]
	},
	"/terms": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/terms.tsx",
		children: void 0,
		preloads: [
			"/assets/terms-DbJEAWZp.js",
			"/assets/file-text-Dp5fkK0S.js",
			"/assets/policy-page-ZRrTr13X.js"
		]
	},
	"/admin/login": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DE-vMyrB.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/eye-off-McVPoG-a.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/lock-keyhole-DX4BFJYB.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/admin-api-B3yzv6-u.js"
		]
	},
	"/admin/onboarding": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/onboarding.tsx",
		children: void 0,
		preloads: [
			"/assets/onboarding-D3lEve_b.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/lock-keyhole-DX4BFJYB.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/admin-api-B3yzv6-u.js"
		]
	},
	"/distributor/$": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/$.tsx",
		children: void 0,
		preloads: ["/assets/_-QZWoycf2.js", "/assets/management-route-page-CvYYKl0H.js"]
	},
	"/distributor/account-setup": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/account-setup.tsx",
		children: void 0,
		preloads: ["/assets/account-setup-DynGcbPC.js"]
	},
	"/master-distributor/$": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/$.tsx",
		children: void 0,
		preloads: ["/assets/_-6tLb16X7.js", "/assets/management-route-page-CvYYKl0H.js"]
	},
	"/master-distributor/account-setup": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/account-setup.tsx",
		children: void 0,
		preloads: ["/assets/account-setup-CE3l6-3X.js"]
	},
	"/retailer/account-setup": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/account-setup.tsx",
		children: void 0,
		preloads: ["/assets/account-setup-CNi-y7T3.js"]
	},
	"/retailer/dashboard": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/dashboard-DTJ_30Ia.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-DaIzvN8r.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/activity-F3hX8pd-.js",
			"/assets/badge-check-BwLOlpyy.js",
			"/assets/banknote-C6usj-O4.js",
			"/assets/building-2-CatBgH1_.js",
			"/assets/tv-1gmBC7Ns.js",
			"/assets/credit-card-maer9814.js",
			"/assets/fingerprint-pattern-DusAVo6P.js",
			"/assets/flame-vsWJXxaR.js",
			"/assets/gift-ngJNahPQ.js",
			"/assets/headphones-CSMfsWDB.js",
			"/assets/indian-rupee-C3OWDxyx.js",
			"/assets/landmark-dUYLgG_6.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-BW8Z1vjs.js",
			"/assets/smartphone-BtuZSEaD.js",
			"/assets/wallet-C_FdkSA2.js",
			"/assets/wifi-BXtKiUfv.js",
			"/assets/operations-api-CvrDDE-S.js"
		]
	},
	"/retailer/settings": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-BbFGR1OU.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-DaIzvN8r.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/badge-check-BwLOlpyy.js",
			"/assets/section-tabs-6tugOLoT.js",
			"/assets/eye-off-McVPoG-a.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/key-round-CZp0iHdH.js",
			"/assets/contact-verification-center-D7koRcED.js",
			"/assets/mail-COJLXX0Q.js",
			"/assets/network-tYjdoXH5.js",
			"/assets/phone-DvXayWc-.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/shield-BW8Z1vjs.js",
			"/assets/user-D00v0c_Y.js"
		]
	},
	"/distributor/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/index.tsx",
		children: void 0,
		preloads: ["/assets/distributor-Bsk9tb23.js"]
	},
	"/master-distributor/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/index.tsx",
		children: void 0,
		preloads: ["/assets/master-distributor-DA4QtNlz.js"]
	},
	"/admin/commissions/hierarchy": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/commissions/hierarchy.tsx",
		children: void 0,
		preloads: [
			"/assets/hierarchy-xgX5XViW.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/section-tabs-6tugOLoT.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/plus-Bdnb2ZNb.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/search-De6vCcHc.js",
			"/assets/trash-2-FVXA8-WK.js",
			"/assets/admin-api-B3yzv6-u.js",
			"/assets/action-permission-notice-C2IFFJv_.js"
		]
	},
	"/admin/profile/bank": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/profile/bank.tsx",
		children: void 0,
		preloads: ["/assets/bank-BifrIiEY.js"]
	},
	"/admin/profile/kyc": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/profile/kyc.tsx",
		children: void 0,
		preloads: ["/assets/kyc-CnXlMxFe.js"]
	},
	"/distributor/aeps/balance-enquiry": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/balance-enquiry.tsx",
		children: void 0,
		preloads: ["/assets/balance-enquiry-CttjTFcq.js", "/assets/network-aeps-transactions-BKSEQqjR.js"]
	},
	"/distributor/aeps/cash-withdrawal": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/cash-withdrawal.tsx",
		children: void 0,
		preloads: ["/assets/cash-withdrawal-4ZmW7hsB.js", "/assets/network-aeps-transactions-BKSEQqjR.js"]
	},
	"/distributor/aeps/mini-statement": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/mini-statement.tsx",
		children: void 0,
		preloads: ["/assets/mini-statement-DLsdliEJ.js", "/assets/network-aeps-transactions-BKSEQqjR.js"]
	},
	"/distributor/aeps/transactions": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/transactions.tsx",
		children: void 0,
		preloads: ["/assets/transactions-jpTaMapj.js", "/assets/network-aeps-transactions-BKSEQqjR.js"]
	},
	"/distributor/profile/bank": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/profile/bank.tsx",
		children: void 0,
		preloads: ["/assets/bank-BsqlFehp.js"]
	},
	"/distributor/profile/kyc": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/profile/kyc.tsx",
		children: void 0,
		preloads: ["/assets/kyc-nid_d2et.js"]
	},
	"/distributor/wallet/transfer": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/wallet/transfer.tsx",
		children: void 0,
		preloads: [
			"/assets/transfer-BH3Om-W6.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-left-CADTCfEr.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/section-tabs-6tugOLoT.js",
			"/assets/user-round-check-Dt5Lwnve.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/indian-rupee-C3OWDxyx.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/wallet-cards-Dqz3d6ph.js",
			"/assets/distributor-api-DUCoOFFQ.js",
			"/assets/action-permission-notice-C2IFFJv_.js",
			"/assets/operations-api-CvrDDE-S.js"
		]
	},
	"/master-distributor/profile/bank": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/profile/bank.tsx",
		children: void 0,
		preloads: ["/assets/bank-J1FeaMDd.js"]
	},
	"/master-distributor/profile/kyc": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/profile/kyc.tsx",
		children: void 0,
		preloads: ["/assets/kyc-C7XOFFcJ.js"]
	},
	"/master-distributor/wallet/history": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/wallet/history.tsx",
		children: void 0,
		preloads: [
			"/assets/history-CINPwZ_p.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/module-placeholder-DUT6g6oc.js"
		]
	},
	"/master-distributor/wallet/requests": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/wallet/requests.tsx",
		children: void 0,
		preloads: [
			"/assets/requests-Dr5HSWlh.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/module-placeholder-DUT6g6oc.js"
		]
	},
	"/master-distributor/wallet/transfer": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/wallet/transfer.tsx",
		children: void 0,
		preloads: [
			"/assets/transfer-Biigkq0d.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-left-CADTCfEr.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/section-tabs-6tugOLoT.js",
			"/assets/user-round-check-Dt5Lwnve.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/indian-rupee-C3OWDxyx.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/wallet-cards-Dqz3d6ph.js",
			"/assets/master-distributor-api-BjNOy2ah.js",
			"/assets/action-permission-notice-C2IFFJv_.js",
			"/assets/operations-api-CvrDDE-S.js"
		]
	},
	"/retailer/wallet/transfer": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/wallet/transfer.tsx",
		children: void 0,
		preloads: [
			"/assets/transfer-Cmptw4Hh.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-DaIzvN8r.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-left-CADTCfEr.js",
			"/assets/arrow-right-BlfnEYNH.js",
			"/assets/section-tabs-6tugOLoT.js",
			"/assets/user-round-check-Dt5Lwnve.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/indian-rupee-C3OWDxyx.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/wallet-cards-Dqz3d6ph.js",
			"/assets/action-permission-notice-C2IFFJv_.js",
			"/assets/operations-api-CvrDDE-S.js"
		]
	},
	"/admin/api-settings/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/api-settings/index.tsx",
		children: void 0,
		preloads: [
			"/assets/api-settings-Vd9DZN7g.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/activity-F3hX8pd-.js",
			"/assets/section-tabs-6tugOLoT.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/x-BZsgst37.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/admin-api-B3yzv6-u.js"
		]
	},
	"/admin/banking/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/banking/index.tsx",
		children: void 0,
		preloads: [
			"/assets/banking-DL5qIQ-O.js",
			"/assets/section-tabs-6tugOLoT.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/landmark-dUYLgG_6.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/x-BZsgst37.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/search-De6vCcHc.js",
			"/assets/admin-api-B3yzv6-u.js"
		]
	},
	"/admin/commissions/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/commissions/index.tsx",
		children: void 0,
		preloads: [
			"/assets/commissions-BsBrlr-P.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/section-tabs-6tugOLoT.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/indian-rupee-C3OWDxyx.js",
			"/assets/layers-CcIsRSix.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/x-BZsgst37.js",
			"/assets/pen-line-DREmztiJ.js",
			"/assets/plus-Bdnb2ZNb.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/search-De6vCcHc.js",
			"/assets/admin-api-B3yzv6-u.js",
			"/assets/operations-api-CvrDDE-S.js"
		]
	},
	"/admin/kyc/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/kyc/index.tsx",
		children: void 0,
		preloads: [
			"/assets/kyc-CDQbDF-8.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/section-tabs-6tugOLoT.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/x-BZsgst37.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/admin-api-B3yzv6-u.js",
			"/assets/action-permission-notice-C2IFFJv_.js"
		]
	},
	"/admin/legal/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/legal/index.tsx",
		children: void 0,
		preloads: [
			"/assets/legal-YHXiqJd-.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/section-tabs-6tugOLoT.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/file-check-corner-Dvje3IS9.js",
			"/assets/lock-keyhole-DX4BFJYB.js",
			"/assets/admin-feature-grid-DNvxB-vq.js"
		]
	},
	"/admin/profile/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/profile/index.tsx",
		children: void 0,
		preloads: ["/assets/profile-BvTjD71h.js", "/assets/admin-profile-page-DskUrptT.js"]
	},
	"/admin/reports/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/reports/index.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-mAIdGZug.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/search-De6vCcHc.js",
			"/assets/admin-api-B3yzv6-u.js",
			"/assets/audit-detail-dialog-CQm4IabV.js"
		]
	},
	"/admin/settings/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/settings/index.tsx",
		children: void 0,
		preloads: ["/assets/settings-Du7uP6Lk.js", "/assets/admin-settings-page-Dh8Qqrdy.js"]
	},
	"/admin/settlements/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/settlements/index.tsx",
		children: void 0,
		preloads: ["/assets/settlements-CpsZN81Q.js", "/assets/admin-layout-B19J-yRG.js"]
	},
	"/admin/sms/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/sms/index.tsx",
		children: void 0,
		preloads: [
			"/assets/sms-BLuf3ajY.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/admin-feature-grid-DNvxB-vq.js"
		]
	},
	"/admin/transactions/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/transactions/index.tsx",
		children: void 0,
		preloads: [
			"/assets/transactions-CusXL8OL.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/section-tabs-6tugOLoT.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/x-BZsgst37.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/rotate-ccw-CBht_CfB.js",
			"/assets/search-De6vCcHc.js",
			"/assets/wallet-cards-Dqz3d6ph.js",
			"/assets/admin-api-B3yzv6-u.js",
			"/assets/action-permission-notice-C2IFFJv_.js",
			"/assets/idempotency-key-CMznALKj.js"
		]
	},
	"/distributor/aeps/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/aeps/index.tsx",
		children: void 0,
		preloads: [
			"/assets/aeps-DyFQugbu.js",
			"/assets/banknote-C6usj-O4.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/file-text-Dp5fkK0S.js",
			"/assets/landmark-dUYLgG_6.js"
		]
	},
	"/distributor/commission/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/commission/index.tsx",
		children: void 0,
		preloads: [
			"/assets/commission-BDV8HYOr.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/indian-rupee-C3OWDxyx.js",
			"/assets/admin-api-B3yzv6-u.js",
			"/assets/distributor-api-DUCoOFFQ.js"
		]
	},
	"/distributor/profile/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/profile/index.tsx",
		children: void 0,
		preloads: ["/assets/profile-CNdhaB-u.js", "/assets/admin-profile-page-DskUrptT.js"]
	},
	"/distributor/reports/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/reports/index.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-DHSigzgs.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/distributor-api-DUCoOFFQ.js"
		]
	},
	"/distributor/retailers/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/retailers/index.tsx",
		children: void 0,
		preloads: [
			"/assets/retailers-CWNLyywa.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/store-D_GWgnJN.js",
			"/assets/user-plus-BkWABhos.js",
			"/assets/distributor-api-DUCoOFFQ.js"
		]
	},
	"/distributor/settings/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/settings/index.tsx",
		children: void 0,
		preloads: ["/assets/settings-kvUsb3Se.js", "/assets/admin-settings-page-Dh8Qqrdy.js"]
	},
	"/distributor/support/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/support/index.tsx",
		children: void 0,
		preloads: [
			"/assets/support-Nh0J6KjL.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/headphones-CSMfsWDB.js"
		]
	},
	"/distributor/wallet/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/wallet/index.tsx",
		children: void 0,
		preloads: [
			"/assets/wallet-DRaipSru.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-left-CADTCfEr.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/fingerprint-pattern-DusAVo6P.js",
			"/assets/gift-ngJNahPQ.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/wallet-cards-Dqz3d6ph.js",
			"/assets/distributor-api-DUCoOFFQ.js",
			"/assets/operations-api-CvrDDE-S.js"
		]
	},
	"/master-distributor/commission/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/commission/index.tsx",
		children: void 0,
		preloads: [
			"/assets/commission-DvSYozUv.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/indian-rupee-C3OWDxyx.js",
			"/assets/admin-api-B3yzv6-u.js",
			"/assets/master-distributor-api-BjNOy2ah.js"
		]
	},
	"/master-distributor/kyc/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/kyc/index.tsx",
		children: void 0,
		preloads: [
			"/assets/kyc-zYWLdh32.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/module-placeholder-DUT6g6oc.js"
		]
	},
	"/master-distributor/notifications/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/notifications/index.tsx",
		children: void 0,
		preloads: [
			"/assets/notifications-DZD5S4Lp.js",
			"/assets/section-tabs-6tugOLoT.js",
			"/assets/module-placeholder-DUT6g6oc.js"
		]
	},
	"/master-distributor/profile/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/profile/index.tsx",
		children: void 0,
		preloads: ["/assets/profile-Bi3bSkU3.js", "/assets/admin-profile-page-DskUrptT.js"]
	},
	"/master-distributor/reports/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/reports/index.tsx",
		children: void 0,
		preloads: [
			"/assets/reports-DUfrdCuW.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/master-distributor-api-BjNOy2ah.js"
		]
	},
	"/master-distributor/settings/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/settings/index.tsx",
		children: void 0,
		preloads: ["/assets/settings-q-XmfiXT.js", "/assets/admin-settings-page-Dh8Qqrdy.js"]
	},
	"/master-distributor/support/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/support/index.tsx",
		children: void 0,
		preloads: [
			"/assets/support-BOieEv26.js",
			"/assets/headphones-CSMfsWDB.js",
			"/assets/module-placeholder-DUT6g6oc.js"
		]
	},
	"/master-distributor/transactions/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/transactions/index.tsx",
		children: void 0,
		preloads: ["/assets/transactions-CYYFn3uB.js", "/assets/network-aeps-transactions-BKSEQqjR.js"]
	},
	"/master-distributor/wallet/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/wallet/index.tsx",
		children: void 0,
		preloads: [
			"/assets/wallet-CRQ21DzF.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-left-CADTCfEr.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/fingerprint-pattern-DusAVo6P.js",
			"/assets/gift-ngJNahPQ.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/wallet-cards-Dqz3d6ph.js",
			"/assets/master-distributor-api-BjNOy2ah.js",
			"/assets/operations-api-CvrDDE-S.js"
		]
	},
	"/retailer/aeps/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/aeps/index.tsx",
		children: void 0,
		preloads: [
			"/assets/aeps-BgzXQh5l.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-DaIzvN8r.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/banknote-C6usj-O4.js",
			"/assets/section-tabs-6tugOLoT.js",
			"/assets/circle-check-RjH-MkqV.js",
			"/assets/clock-3-CGRh6MXR.js",
			"/assets/fingerprint-pattern-DusAVo6P.js",
			"/assets/landmark-dUYLgG_6.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/map-pin-DQIlFshA.js",
			"/assets/receipt-text-Dgko8puo.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/wallet-cards-Dqz3d6ph.js",
			"/assets/action-permission-notice-C2IFFJv_.js"
		]
	},
	"/retailer/bank/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/bank/index.tsx",
		children: void 0,
		preloads: [
			"/assets/bank-CbVtA1f2.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-DaIzvN8r.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/badge-check-BwLOlpyy.js",
			"/assets/section-tabs-6tugOLoT.js",
			"/assets/building-2-CatBgH1_.js",
			"/assets/landmark-dUYLgG_6.js",
			"/assets/pen-line-DREmztiJ.js",
			"/assets/plus-Bdnb2ZNb.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/trash-2-FVXA8-WK.js",
			"/assets/action-permission-notice-C2IFFJv_.js",
			"/assets/role-aware-account-page-D2gEgPan.js"
		]
	},
	"/retailer/kyc/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/kyc/index.tsx",
		children: void 0,
		preloads: [
			"/assets/kyc-DlM2t-81.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-DaIzvN8r.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/badge-check-BwLOlpyy.js",
			"/assets/section-tabs-6tugOLoT.js",
			"/assets/file-check-corner-Dvje3IS9.js",
			"/assets/fingerprint-pattern-DusAVo6P.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/trash-2-FVXA8-WK.js",
			"/assets/action-permission-notice-C2IFFJv_.js",
			"/assets/role-aware-account-page-D2gEgPan.js"
		]
	},
	"/retailer/transactions/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/transactions/index.tsx",
		children: void 0,
		preloads: [
			"/assets/transactions-C0BLb6Cq.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-DaIzvN8r.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/transaction-detail-dialog-DRSW17Ye.js",
			"/assets/receipt-DFDQG__6.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/search-De6vCcHc.js",
			"/assets/operations-api-CvrDDE-S.js"
		]
	},
	"/retailer/wallet/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/retailer/wallet/index.tsx",
		children: void 0,
		preloads: [
			"/assets/wallet-BvA8ULVu.js",
			"/assets/useNavigate-DT7ghfdY.js",
			"/assets/business-page-DaIzvN8r.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/arrow-right-left-CADTCfEr.js",
			"/assets/fingerprint-pattern-DusAVo6P.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/wallet-cards-Dqz3d6ph.js",
			"/assets/operations-api-CvrDDE-S.js"
		]
	},
	"/admin/merchants/add/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/merchants/add/index.tsx",
		children: void 0,
		preloads: ["/assets/add-CQL0Dkom.js"]
	},
	"/admin/merchants/list/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/admin/merchants/list/index.tsx",
		children: void 0,
		preloads: [
			"/assets/list-BwNkjE25.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/badge-check-BwLOlpyy.js",
			"/assets/section-tabs-6tugOLoT.js",
			"/assets/building-2-CatBgH1_.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/eye-CPrOtxgT.js",
			"/assets/landmark-dUYLgG_6.js",
			"/assets/loader-circle-B4JdDfse.js",
			"/assets/x-BZsgst37.js",
			"/assets/refresh-cw-C6tr3N9W.js",
			"/assets/search-De6vCcHc.js",
			"/assets/shield-check-ChgPxF7N.js",
			"/assets/wallet-cards-Dqz3d6ph.js",
			"/assets/admin-api-B3yzv6-u.js"
		]
	},
	"/distributor/retailers/add/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/distributor/retailers/add/index.tsx",
		children: void 0,
		preloads: ["/assets/add-BuoPz-y7.js"]
	},
	"/master-distributor/network/distributors/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/network/distributors/index.tsx",
		children: void 0,
		preloads: [
			"/assets/distributors-CPkS_akG.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/network-tYjdoXH5.js",
			"/assets/user-plus-BkWABhos.js",
			"/assets/master-distributor-api-BjNOy2ah.js"
		]
	},
	"/master-distributor/network/retailers/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/network/retailers/index.tsx",
		children: void 0,
		preloads: [
			"/assets/retailers-BDTsQHu1.js",
			"/assets/store-D_GWgnJN.js",
			"/assets/module-placeholder-DUT6g6oc.js"
		]
	},
	"/master-distributor/network/tree/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/network/tree/index.tsx",
		children: void 0,
		preloads: [
			"/assets/tree-DGpRwXCs.js",
			"/assets/role-hierarchy-BiaEg-EA.js",
			"/assets/section-tabs-6tugOLoT.js",
			"/assets/admin-layout-B19J-yRG.js",
			"/assets/network-tYjdoXH5.js",
			"/assets/master-distributor-api-BjNOy2ah.js"
		]
	},
	"/master-distributor/network/distributors/add/": {
		filePath: "C:/Users/hp/Desktop/Itsoft/umobipay/umobipay/wonder-ui-studio/src/routes/master-distributor/network/distributors/add/index.tsx",
		children: void 0,
		preloads: ["/assets/add-llwTvmlE.js"]
	}
} });
//#endregion
export { tsrStartManifest };
