import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { wt as HandCoins } from "../_libs/lucide-react.mjs";
import { t as MasterDistributorModulePlaceholder } from "./module-placeholder-AeYEFMVY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/requests-D0zP3z0f.js
var import_jsx_runtime = require_jsx_runtime();
function Page() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MasterDistributorModulePlaceholder, {
		active: "settlements",
		icon: HandCoins,
		title: "Fund requests",
		description: "Create and track wallet funding requests.",
		pending: "The current backend has no protected Master Distributor fund-request lifecycle endpoint."
	});
}
//#endregion
export { Page as component };
