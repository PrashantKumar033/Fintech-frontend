import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-B_1VDSsy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/module-placeholder-AeYEFMVY.js
var import_jsx_runtime = require_jsx_runtime();
function MasterDistributorModulePlaceholder({ active, icon: Icon, title, description, pending }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active,
		eyebrow: "Master Distributor service",
		title,
		description,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-12 w-12 place-items-center rounded-xl bg-primary/10 text-primary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-5 text-xl font-black",
				children: "Frontend module ready"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-sm leading-6 text-muted-foreground",
				children: pending
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-5 inline-flex rounded-full bg-amber-50 px-3 py-1.5 text-xs font-bold text-amber-800",
				children: "Backend contract pending"
			})
		] })
	});
}
//#endregion
export { MasterDistributorModulePlaceholder as t };
