import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { Mt as FileText, _t as Landmark, cn as Banknote } from "../_libs/lucide-react.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-B_1VDSsy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/aeps-V8SQgf12.js
var import_jsx_runtime = require_jsx_runtime();
function AepsOverview() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AdminLayout, {
		active: "transactions",
		eyebrow: "Assisted banking",
		title: "AEPS monitoring",
		description: "Monitor your Retailer network here. Customer biometric execution remains available only in the Retailer panel.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 md:grid-cols-2",
			children: [
				[
					"Transactions",
					"Monitor all Retailer AEPS activity",
					"/distributor/aeps/transactions",
					FileText
				],
				[
					"Cash withdrawal",
					"Monitor Retailer cash withdrawals",
					"/distributor/aeps/cash-withdrawal",
					Banknote
				],
				[
					"Balance enquiry",
					"Monitor Retailer balance enquiries",
					"/distributor/aeps/balance-enquiry",
					Landmark
				],
				[
					"Mini statement",
					"Monitor Retailer mini statements",
					"/distributor/aeps/mini-statement",
					FileText
				]
			].map(([title, text, to, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to,
				className: "block cursor-pointer",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
					className: "h-full transition hover:border-primary hover:shadow-md",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "text-primary" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 text-lg font-black",
							children: title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted-foreground",
							children: text
						})
					]
				})
			}, title))
		})
	});
}
//#endregion
export { AepsOverview as component };
