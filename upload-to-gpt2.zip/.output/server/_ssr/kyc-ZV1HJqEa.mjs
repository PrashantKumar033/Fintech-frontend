import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { c as Route$10 } from "./router-ZMSymSrp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kyc-ZV1HJqEa.js
var import_jsx_runtime = require_jsx_runtime();
function KycPage() {
	const Component = Route$10.options.component;
	return Component ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Component, {}) : null;
}
//#endregion
export { KycPage as component };
