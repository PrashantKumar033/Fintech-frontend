import { a as DistributorDashboard } from "./router-ZMSymSrp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/distributor-CIgdHkC1.js
var SplitComponent = DistributorDashboard;
//#endregion
export { SplitComponent as component };
