import { r as authenticatedRequest, t as ApiError } from "./role-hierarchy-B8AZOwBW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/operations-api-qskyEBEX.js
var queryString = (values) => {
	const query = new URLSearchParams();
	Object.entries(values).forEach(([key, value]) => {
		if (value !== void 0 && value !== "") query.set(key, String(value));
	});
	return query.toString();
};
function createIdempotencyKey() {
	if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
	if (typeof crypto !== "undefined" && typeof crypto.getRandomValues === "function") {
		const bytes = /* @__PURE__ */ new Uint8Array(16);
		crypto.getRandomValues(bytes);
		bytes[6] = bytes[6] & 15 | 64;
		bytes[8] = bytes[8] & 63 | 128;
		const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0"));
		return `${hex.slice(0, 4).join("")}-${hex.slice(4, 6).join("")}-${hex.slice(6, 8).join("")}-${hex.slice(8, 10).join("")}-${hex.slice(10).join("")}`;
	}
	return `wallet-${Date.now()}-${Math.random().toString(36).slice(2, 12)}`;
}
var operationsApi = {
	balance: (token, walletType) => authenticatedRequest(`/transactions/balance/${walletType}`, {}, token),
	balances: (token, userId) => authenticatedRequest(`/wallet/balances/${encodeURIComponent(userId)}`, {}, token),
	transfer: (token, body, idempotencyKey = createIdempotencyKey()) => authenticatedRequest("/wallet/transfer", {
		method: "POST",
		headers: { "Idempotency-Key": idempotencyKey },
		body: JSON.stringify(body)
	}, token),
	calculateCommission: (token, body) => authenticatedRequest("/wallet/calculate-commission", {
		method: "POST",
		body: JSON.stringify(body)
	}, token),
	transactions: (token, filters = {}) => authenticatedRequest(`/aeps/transactions?${queryString({
		page: filters.page ?? 1,
		limit: filters.limit ?? 20,
		operation: filters.operation,
		status: filters.status,
		provider: filters.provider,
		serviceType: filters.serviceType
	})}`, {}, token),
	networkTransactions: (token, filters = {}) => authenticatedRequest(`/aeps/network-transactions?${queryString({
		page: filters.page ?? 1,
		limit: filters.limit ?? 20,
		operation: filters.operation,
		status: filters.status,
		provider: filters.provider
	})}`, {}, token),
	transaction: (token, referenceId) => authenticatedRequest(`/aeps/transactions/${encodeURIComponent(referenceId)}`, {}, token),
	receipt: (token, referenceId) => authenticatedRequest(`/aeps/transactions/${encodeURIComponent(referenceId)}/receipt`, {}, token),
	networkTransaction: (token, referenceId) => authenticatedRequest(`/aeps/network-transactions/${encodeURIComponent(referenceId)}`, {}, token),
	networkReceipt: (token, referenceId) => authenticatedRequest(`/aeps/network-transactions/${encodeURIComponent(referenceId)}/receipt`, {}, token),
	audits: (token, filters = {}) => authenticatedRequest(`/audit/me?${queryString({
		page: filters.page ?? 1,
		limit: filters.limit ?? 20,
		service: filters.service,
		action: filters.action,
		status: filters.status
	})}`, {}, token),
	audit: (token, auditId) => authenticatedRequest(`/audit/me/${encodeURIComponent(auditId)}`, {}, token)
};
function newTransferIdempotencyKey() {
	return createIdempotencyKey();
}
function operationsMessage(error) {
	return error instanceof ApiError ? error.message : error instanceof Error ? error.message : "Request failed.";
}
//#endregion
export { operationsApi as n, operationsMessage as r, newTransferIdempotencyKey as t };
