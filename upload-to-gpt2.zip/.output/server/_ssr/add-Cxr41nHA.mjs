import { i as CreateMemberPage } from "./router-ZMSymSrp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/add-Cxr41nHA.js
var SplitComponent = CreateMemberPage;
//#endregion
export { SplitComponent as component };
