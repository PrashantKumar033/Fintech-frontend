//#region node_modules/.nitro/vite/services/ssr/assets/idempotency-key-BtLMYz3w.js
/**
* Creates an RFC 4122 v4-style idempotency key in secure and insecure browser
* contexts. `crypto.randomUUID()` is unavailable on plain LAN HTTP origins in
* some browsers, while `crypto.getRandomValues()` remains widely available.
*/
function createIdempotencyKey(prefix = "web") {
	const cryptoApi = globalThis.crypto;
	if (typeof cryptoApi?.randomUUID === "function") return cryptoApi.randomUUID();
	if (typeof cryptoApi?.getRandomValues === "function") {
		const bytes = /* @__PURE__ */ new Uint8Array(16);
		cryptoApi.getRandomValues(bytes);
		bytes[6] = bytes[6] & 15 | 64;
		bytes[8] = bytes[8] & 63 | 128;
		const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0"));
		return `${hex.slice(0, 4).join("")}-${hex.slice(4, 6).join("")}-${hex.slice(6, 8).join("")}-${hex.slice(8, 10).join("")}-${hex.slice(10).join("")}`;
	}
	return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 14)}`;
}
//#endregion
export { createIdempotencyKey as t };
