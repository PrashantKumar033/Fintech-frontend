import { r as __toESM } from "../_runtime.mjs";
import { S as updateSessionIdentity, c as getSession, h as refreshSession, l as identityVerificationPending, n as authApi, t as ApiError } from "./role-hierarchy-B8AZOwBW.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as ShieldCheck, E as Shield, K as Phone, L as RefreshCw, Lt as Eye, Q as MonitorSmartphone, Rt as EyeOff, Z as Network, l as User, ot as Mail, sn as Bell, un as BadgeCheck, vt as KeyRound } from "../_libs/lucide-react.mjs";
import { n as IdentitySecurityCenter, t as ContactVerificationCenter } from "./contact-verification-center-DSflde84.mjs";
import { t as BusinessPage } from "./business-page-BafQTwce.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-BF_tCkzv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function RetailerSettingsPage() {
	const navigate = useNavigate();
	const [session, setSession] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const stored = getSession();
		if (!stored) {
			navigate({ to: "/login" });
			return;
		}
		if (identityVerificationPending(stored)) {
			window.location.replace("/retailer/account-setup");
			return;
		}
		setSession(stored);
	}, [navigate]);
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center bg-background",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: "animate-spin text-primary" })
	});
	const updateIdentity = (identity) => {
		updateSessionIdentity(identity);
		setSession((current) => current ? {
			...current,
			identity
		} : current);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BusinessPage, {
		identity: session.identity,
		active: "settings",
		showPageHeader: false,
		children: [!session.identity.passwordChangedAt || !session.identity.mpinChangedAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: "Complete first-login security" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-amber-800/80",
				children: "Change both the temporary password and temporary MPIN once to unlock all services."
			})]
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SettingsPage, {
			identity: session.identity,
			accessToken: session.accessToken,
			onIdentityChange: updateIdentity,
			onUnlocked: () => void navigate({ to: "/retailer/dashboard" })
		})]
	});
}
function SettingsPage({ identity, accessToken, onIdentityChange, onUnlocked }) {
	const [tab, setTab] = (0, import_react.useState)(identity.passwordChangedAt && identity.mpinChangedAt ? "profile" : "security");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-bold text-primary",
					children: "ACCOUNT SETTINGS"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-3xl font-extrabold text-secondary",
					children: "Settings & preferences"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Manage your profile, security and preferences."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			"aria-label": "Settings sections",
			className: "mb-6 flex gap-1 overflow-x-auto rounded-2xl border border-border bg-card p-2 shadow-soft",
			children: [
				[
					"profile",
					User,
					"Profile"
				],
				[
					"security",
					ShieldCheck,
					"Security"
				],
				[
					"access",
					MonitorSmartphone,
					"Devices & access"
				],
				[
					"preferences",
					Bell,
					"Preferences"
				]
			].map(([key, Icon, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				onClick: () => setTab(key),
				"aria-current": tab === key ? "page" : void 0,
				className: `flex min-w-max flex-1 cursor-pointer items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold transition ${tab === key ? "bg-secondary text-secondary-foreground shadow-sm" : "text-secondary hover:bg-mint"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 17 }), label]
			}, key))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex gap-6 sm:flex-row sm:gap-6",
			children: [
				tab === "profile" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileSettings, { identity }),
				tab === "security" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecuritySettings, {
					identity,
					accessToken,
					onIdentityChange,
					onUnlocked
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContactVerificationCenter, { identity })] }),
				tab === "access" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdentitySecurityCenter, {}),
				tab === "preferences" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreferenceSettings, { identity })
			]
		})] })]
	});
}
function Panel({ title, description, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl w-full border border-border bg-card p-5 shadow-soft sm:p-7",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-extrabold text-secondary",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: description
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children
			})
		]
	});
}
function Info({ icon: Icon, label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-border bg-background p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 text-xs font-semibold text-muted-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 14 }), label]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 truncate text-sm font-bold text-secondary",
			children: value || "Not provided"
		})]
	});
}
function ProfileSettings({ identity }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		title: "Personal & business profile",
		description: "Verified registration information associated with your account.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-6 flex items-center gap-4 rounded-2xl bg-secondary p-5 text-secondary-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-14 w-14 place-items-center rounded-2xl bg-white/10 text-xl font-extrabold",
						children: identity.fullName?.[0] || "U"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-extrabold",
						children: identity.fullName
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-white/60",
						children: [
							identity.role,
							" · ",
							identity.status
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BadgeCheck, { className: "ml-auto text-emerald-300" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
						icon: User,
						label: "Full name",
						value: identity.fullName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
						icon: Mail,
						label: "Email address",
						value: identity.email
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
						icon: Phone,
						label: "Phone number",
						value: identity.phoneNumber
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
						icon: Network,
						label: "Username",
						value: identity.username
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
						icon: BadgeCheck,
						label: "Login ID",
						value: identity.loginId
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
						icon: Shield,
						label: "Account status",
						value: identity.status
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 rounded-xl bg-mint p-4 text-xs text-secondary",
				children: "To update verified personal or business details, contact the UMOBIPAY compliance desk."
			})
		]
	});
}
function SecuritySettings({ identity, accessToken, onIdentityChange, onUnlocked }) {
	const [mode, setMode] = (0, import_react.useState)(identity.passwordChangedAt ? "mpin" : "password"), [current, setCurrent] = (0, import_react.useState)(""), [next, setNext] = (0, import_react.useState)(""), [confirm, setConfirm] = (0, import_react.useState)(""), [visible, setVisible] = (0, import_react.useState)(false), [busy, setBusy] = (0, import_react.useState)(false), [message, setMessage] = (0, import_react.useState)(null);
	async function submit(e) {
		e.preventDefault();
		setMessage(null);
		if (next !== confirm) {
			setMessage({
				ok: false,
				text: `New ${mode} and confirmation do not match.`
			});
			return;
		}
		setBusy(true);
		try {
			if (mode === "password") {
				await authApi.changePassword(accessToken, {
					currentPassword: current,
					newPassword: next
				});
				const synchronized = await refreshSession();
				onIdentityChange(synchronized.identity);
				if (!synchronized.identity.mpinChangedAt) {
					setMode("mpin");
					setMessage({
						ok: true,
						text: "Password changed. Now change your temporary MPIN to finish setup."
					});
				} else {
					setMessage({
						ok: true,
						text: "Password updated successfully."
					});
					onUnlocked();
				}
			} else {
				await authApi.changeMpin(accessToken, {
					currentMpin: current,
					newMpin: next
				});
				const synchronized = await refreshSession();
				onIdentityChange(synchronized.identity);
				setMessage({
					ok: true,
					text: "MPIN changed. First-login security setup is complete."
				});
				if (synchronized.identity.passwordChangedAt && synchronized.identity.mpinChangedAt) onUnlocked();
			}
			setCurrent("");
			setNext("");
			setConfirm("");
		} catch (error) {
			setMessage({
				ok: false,
				text: error instanceof ApiError ? error.message : "Unable to update security credentials."
			});
		} finally {
			setBusy(false);
		}
	}
	const fieldType = visible ? "text" : "password";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		title: "Login & security",
		description: "On first login, replace both temporary credentials. Afterwards either credential can be updated independently.",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusCard, {
					label: "Password",
					done: !!identity.passwordChangedAt
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusCard, {
					label: "MPIN",
					done: !!identity.mpinChangedAt
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-5 flex rounded-xl bg-muted p-1",
				children: ["password", "mpin"].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						setMode(item);
						setMessage(null);
						setCurrent("");
						setNext("");
						setConfirm("");
					},
					className: `flex-1 rounded-lg py-2 text-sm font-bold capitalize ${mode === item ? "bg-card text-secondary shadow-sm" : "text-muted-foreground"}`,
					children: item
				}, item))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecureInput, {
						label: `Current ${mode}`,
						value: current,
						onChange: setCurrent,
						type: fieldType,
						maxLength: mode === "mpin" ? 4 : void 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecureInput, {
						label: `New ${mode}`,
						value: next,
						onChange: setNext,
						type: fieldType,
						maxLength: mode === "mpin" ? 4 : void 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecureInput, {
						label: `Confirm new ${mode}`,
						value: confirm,
						onChange: setConfirm,
						type: fieldType,
						maxLength: mode === "mpin" ? 4 : void 0
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setVisible(!visible),
						className: "flex items-center gap-2 text-xs font-bold text-primary",
						children: [visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { size: 15 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 15 }), visible ? "Hide values" : "Show values"]
					}),
					message && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `rounded-xl p-4 text-sm font-semibold ${message.ok ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`,
						children: message.text
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						disabled: busy,
						className: "w-full rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground disabled:opacity-60",
						children: busy ? "Updating…" : `Update ${mode}`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-3 border-t border-border pt-6 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
					icon: KeyRound,
					label: "Preferred login",
					value: identity.preferredLoginMethod
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
					icon: ShieldCheck,
					label: "Security setup",
					value: identity.passwordChangedAt && identity.mpinChangedAt ? "Complete" : "Action required"
				})]
			})
		]
	});
}
function StatusCard({ label, done }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-xl border p-3 text-sm font-bold ${done ? "border-emerald-200 bg-emerald-50 text-emerald-700" : "border-amber-200 bg-amber-50 text-amber-800"}`,
		children: [
			label,
			": ",
			done ? "Changed" : "Temporary"
		]
	});
}
function SecureInput({ label, value, onChange, type, maxLength }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-bold uppercase tracking-wider text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			required: true,
			type,
			value,
			maxLength,
			inputMode: maxLength ? "numeric" : void 0,
			minLength: maxLength || 8,
			onChange: (e) => onChange(maxLength ? e.target.value.replace(/\D/g, "") : e.target.value),
			className: "mt-1.5 w-full rounded-xl border border-border bg-background px-4 py-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/15"
		})]
	});
}
function PreferenceSettings({ identity }) {
	const [states, setStates] = (0, import_react.useState)({
		transactions: true,
		security: true,
		marketing: false
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		title: "Notifications & preferences",
		description: "Choose which account updates you want to receive.",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					title: "Transaction alerts",
					text: `Send payment and settlement updates to ${identity.email}`,
					checked: states.transactions,
					onChange: () => setStates({
						...states,
						transactions: !states.transactions
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					title: "Security alerts",
					text: "Login, password and account safety notifications",
					checked: states.security,
					onChange: () => setStates({
						...states,
						security: !states.security
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
					title: "Product updates",
					text: "New UMOBIPAY services, offers and announcements",
					checked: states.marketing,
					onChange: () => setStates({
						...states,
						marketing: !states.marketing
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 rounded-xl border border-amber-200 bg-amber-50 p-4 text-xs text-amber-800",
			children: "Preference persistence will be enabled when the notification settings API is available."
		})]
	});
}
function ToggleRow({ title, text, checked, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-4 rounded-xl border border-border p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-bold text-secondary",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: text
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: onChange,
			role: "switch",
			"aria-checked": checked,
			className: `relative h-6 w-11 rounded-full transition ${checked ? "bg-primary" : "bg-muted-foreground/30"}`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `absolute top-1 h-4 w-4 rounded-full bg-white transition ${checked ? "left-6" : "left-1"}` })
		})]
	});
}
//#endregion
export { RetailerSettingsPage as component };
