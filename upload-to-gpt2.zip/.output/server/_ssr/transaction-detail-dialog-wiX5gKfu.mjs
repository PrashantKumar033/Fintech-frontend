import { r as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { H as Printer, dt as LoaderCircle, r as X, z as ReceiptText } from "../_libs/lucide-react.mjs";
import { n as operationsApi, r as operationsMessage } from "./operations-api-qskyEBEX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/transaction-detail-dialog-wiX5gKfu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var label = (key) => key.replace(/([A-Z])/g, " $1").replace(/^./, (value) => value.toUpperCase());
var printable = (value) => value === null || value === void 0 || value === "" ? "—" : String(value);
function TransactionDetailDialog({ accessToken, referenceId, onClose, scope = "self" }) {
	const [detail, setDetail] = (0, import_react.useState)(null);
	const [receipt, setReceipt] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [receiptLoading, setReceiptLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (!referenceId) return;
		setDetail(null);
		setReceipt(null);
		setError("");
		setLoading(true);
		(scope === "network" ? operationsApi.networkTransaction(accessToken, referenceId) : operationsApi.transaction(accessToken, referenceId)).then(setDetail).catch((reason) => setError(operationsMessage(reason))).finally(() => setLoading(false));
	}, [
		accessToken,
		referenceId,
		scope
	]);
	if (!referenceId) return null;
	async function loadReceipt() {
		setReceiptLoading(true);
		setError("");
		try {
			setReceipt(await (scope === "network" ? operationsApi.networkReceipt(accessToken, referenceId) : operationsApi.receipt(accessToken, referenceId)));
		} catch (reason) {
			setError(operationsMessage(reason));
		} finally {
			setReceiptLoading(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "dialog",
		"aria-modal": "true",
		"aria-label": "Transaction details",
		className: "fixed inset-0 z-[100] grid place-items-center bg-secondary/60 p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-extrabold uppercase tracking-wider text-primary",
						children: "AEPS transaction"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 break-all text-xl font-black text-secondary",
						children: referenceId
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onClose,
						"aria-label": "Close transaction details",
						className: "rounded-lg border border-border p-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { size: 18 })
					})]
				}),
				error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "mt-4 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700",
					children: error
				}),
				loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid h-40 place-items-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin text-primary" })
				}) : detail && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
					children: Object.entries(detail).filter(([, value]) => value !== null && value !== void 0 && typeof value !== "object").map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-muted/60 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] font-extrabold uppercase text-muted-foreground",
							children: label(key)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 break-all text-xs font-bold text-secondary",
							children: printable(value)
						})]
					}, key))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						disabled: receiptLoading,
						onClick: () => void loadReceipt(),
						className: "inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-3 text-xs font-extrabold text-white disabled:opacity-50",
						children: [receiptLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
							size: 15,
							className: "animate-spin"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReceiptText, { size: 15 }), "View receipt"]
					}), receipt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => window.print(),
						className: "inline-flex items-center gap-2 rounded-xl border border-border px-4 py-3 text-xs font-extrabold",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { size: 15 }), "Print receipt"]
					})]
				}),
				receipt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					id: "transaction-receipt",
					className: "mt-5 rounded-2xl border-2 border-secondary p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-b border-border pb-4 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xl font-black",
							children: "UMOBIPAY"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs uppercase tracking-widest text-muted-foreground",
							children: "AEPS transaction receipt"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 grid gap-x-6 gap-y-3 sm:grid-cols-2",
						children: Object.entries(receipt).filter(([, value]) => value !== null && value !== void 0).map(([key, value]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-3 border-b border-dashed border-border py-2 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted-foreground",
								children: label(key)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
								className: "break-all text-right",
								children: printable(value)
							})]
						}, key))
					})]
				})
			]
		})
	});
}
//#endregion
export { TransactionDetailDialog as t };
