import { t as AdminSettingsPage } from "./admin-settings-page-Dxa-Ozp0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-CZ7GYwXF.js
var SplitComponent = AdminSettingsPage;
//#endregion
export { SplitComponent as component };
