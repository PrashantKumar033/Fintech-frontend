import { r as __toESM } from "../_runtime.mjs";
import { a as credentialsPending, c as getSession, m as normalizeRole, y as signedInHome } from "./role-hierarchy-B8AZOwBW.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { At as FingerprintPattern, D as ShieldCheck, L as RefreshCw, dt as LoaderCircle, hn as ArrowRightLeft, o as WalletCards } from "../_libs/lucide-react.mjs";
import { t as BusinessPage } from "./business-page-BafQTwce.mjs";
import { n as operationsApi, r as operationsMessage } from "./operations-api-qskyEBEX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/wallet-Dn1o_-dy.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var inr = new Intl.NumberFormat("en-IN", {
	style: "currency",
	currency: "INR",
	minimumFractionDigits: 2
});
function RetailerWalletPage() {
	const navigate = useNavigate();
	const session = getSession();
	const [balances, setBalances] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const [error, setError] = (0, import_react.useState)("");
	async function loadBalances() {
		if (!session) return;
		setLoading(true);
		setError("");
		try {
			const [main, aeps, profit] = await Promise.all([
				operationsApi.balance(session.accessToken, "MAIN"),
				operationsApi.balance(session.accessToken, "AEPS"),
				operationsApi.balance(session.accessToken, "PROFIT")
			]);
			setBalances({
				userId: session.identity.id,
				wallets: {
					main,
					aeps,
					profit
				}
			});
		} catch (requestError) {
			setError(operationsMessage(requestError));
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		if (!session) {
			navigate({ to: "/login" });
			return;
		}
		if (normalizeRole(session.identity.role) !== "RETAILER") {
			window.location.replace(signedInHome(session));
			return;
		}
		if (credentialsPending(session.identity)) {
			window.location.replace(signedInHome(session));
			return;
		}
		loadBalances();
	}, [navigate, session?.identity.id]);
	if (!session) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center bg-[#f5f8f8]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin text-primary" })
	});
	const cards = [
		[
			"Main wallet",
			balances?.wallets.main ?? 0,
			WalletCards
		],
		[
			"AEPS wallet",
			balances?.wallets.aeps ?? 0,
			FingerprintPattern
		],
		[
			"Profit wallet",
			balances?.wallets.profit ?? 0,
			ShieldCheck
		]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BusinessPage, {
		identity: session.identity,
		active: "wallet",
		eyebrow: "Wallet service",
		title: "Wallet balance",
		description: "View your live wallet balances and open the supported Retailer peer-transfer flow.",
		children: [
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-5 rounded-2xl border border-red-200 bg-red-50 p-4 text-sm font-semibold text-red-800",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 md:grid-cols-3",
				children: cards.map(([label, value, Icon]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-border bg-card p-6 shadow-soft",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-11 w-11 place-items-center rounded-xl bg-mint text-secondary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { size: 20 })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => void loadBalances(),
								disabled: loading,
								"aria-label": `Refresh ${label}`,
								className: "grid h-9 w-9 place-items-center rounded-xl border border-border bg-background text-muted-foreground transition hover:text-secondary disabled:cursor-not-allowed disabled:opacity-50",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
									className: loading ? "animate-spin" : "",
									size: 15
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-xs font-bold uppercase tracking-[.08em] text-muted-foreground",
							children: label
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-3xl font-black text-secondary",
							children: loading ? "—" : inr.format(Number(value))
						})
					]
				}, label))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mt-6 rounded-2xl border border-border bg-card p-6 shadow-soft",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-primary/10 text-primary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRightLeft, { size: 22 })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-black text-secondary",
							children: "Retailer peer transfer"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 max-w-2xl text-sm leading-6 text-muted-foreground",
							children: "Send MAIN-wallet funds to another active Retailer. Your backend enforces the same-role rule and checks the balance again before debit."
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/retailer/wallet/transfer",
						className: "inline-flex shrink-0 items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3 text-sm font-extrabold text-white shadow-md shadow-primary/20 transition hover:brightness-95",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRightLeft, { size: 17 }), "Transfer fund"]
					})]
				})
			})
		]
	});
}
//#endregion
export { RetailerWalletPage as component };
