import { r as __toESM } from "../_runtime.mjs";
import { b as syncMyPermissions, c as getSession, m as normalizeRole, s as getEffectiveAccess } from "./role-hierarchy-B8AZOwBW.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { O as ShieldAlert } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/section-tabs-DXmZfcpC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
/**
* Frontend permission contract.
*
* The Auth service stores permission codes in uppercase dot notation.
* Keep these codes in sync with the backend permission seed/catalog.
*/
var UI_PERMISSION = {
	ADMIN_DASHBOARD_VIEW: "ADMIN.DASHBOARD.VIEW",
	TRANSACTION_VIEW: "TRANSACTION.VIEW",
	TRANSACTION_RECONCILIATION_VIEW: "TRANSACTION.RECONCILIATION.VIEW",
	TRANSACTION_RECONCILIATION_RESOLVE: "TRANSACTION.RECONCILIATION.RESOLVE",
	TRANSACTION_REVERSAL_REQUEST: "TRANSACTION.REVERSAL.REQUEST",
	TRANSACTION_REVERSAL_PROCESS: "TRANSACTION.REVERSAL.PROCESS",
	TRANSACTION_FINANCIAL_RECOVERY: "TRANSACTION.FINANCIAL_RECOVERY",
	TRANSACTION_PROVIDER_INCOME_VIEW: "TRANSACTION.PROVIDER_INCOME.VIEW",
	TRANSACTION_PROVIDER_INCOME_RECONCILE: "TRANSACTION.PROVIDER_INCOME.RECONCILE",
	KYC_VIEW: "KYC.VIEW",
	KYC_MANAGE: "KYC.MANAGE",
	BANK_VIEW: "BANK.VIEW",
	BANK_MANAGE: "BANK.MANAGE",
	WALLET_VIEW: "WALLET.VIEW",
	WALLET_TRANSFER: "WALLET.TRANSFER",
	AEPS_VIEW: "AEPS.VIEW",
	AEPS_ONBOARDING: "AEPS.ONBOARDING",
	AEPS_BALANCE_ENQUIRY: "AEPS.BALANCE_ENQUIRY",
	AEPS_MINI_STATEMENT: "AEPS.MINI_STATEMENT",
	AEPS_CASH_WITHDRAWAL: "AEPS.CASH_WITHDRAWAL",
	AEPS_AADHAAR_PAY: "AEPS.AADHAAR_PAY",
	AEPS_CASH_DEPOSIT: "AEPS.CASH_DEPOSIT",
	ACCOUNT_CREATE: "ACCOUNT.CREATE",
	MEMBER_LIST: "MEMBER.LIST",
	MEMBER_VIEW: "MEMBER.VIEW",
	MEMBER_STATUS_UPDATE: "MEMBER.STATUS.UPDATE",
	MEMBER_MANAGE: "MEMBER.MANAGE",
	BANK_ACCOUNT_LIST: "BANK_ACCOUNT.LIST",
	BANK_ACCOUNT_VIEW: "BANK_ACCOUNT.VIEW",
	PROVIDER_INCOME_VIEW: "PROVIDER_INCOME.VIEW",
	PROVIDER_INCOME_RECONCILE: "PROVIDER_INCOME.RECONCILE",
	AEPS_MERCHANT_STATUS_UPDATE: "AEPS.MERCHANT.STATUS.UPDATE",
	WALLET_LEDGER_VIEW: "WALLET.LEDGER.VIEW",
	AEPS_PROVIDER_STATUS_VIEW: "AEPS.PROVIDER.STATUS.VIEW",
	AEPS_PROVIDER_SERVICE_STATUS_UPDATE: "AEPS.PROVIDER.SERVICE.STATUS.UPDATE",
	COMMISSION_RULE_VIEW: "COMMISSION.RULE.VIEW",
	COMMISSION_RULE_CREATE: "COMMISSION.RULE.CREATE",
	COMMISSION_RULE_UPDATE: "COMMISSION.RULE.UPDATE",
	COMMISSION_RULE_DEACTIVATE: "COMMISSION.RULE.DEACTIVATE",
	COMMISSION_DISTRIBUTION_VIEW: "COMMISSION.DISTRIBUTION.VIEW",
	COMMISSION_DISTRIBUTION_CREATE: "COMMISSION.DISTRIBUTION.CREATE",
	COMMISSION_DISTRIBUTION_UPDATE: "COMMISSION.DISTRIBUTION.UPDATE",
	COMMISSION_DISTRIBUTION_DEACTIVATE: "COMMISSION.DISTRIBUTION.DEACTIVATE",
	COMMISSION_HIERARCHY_VIEW: "COMMISSION.HIERARCHY.VIEW",
	COMMISSION_HIERARCHY_CREATE: "COMMISSION.HIERARCHY.CREATE",
	COMMISSION_HIERARCHY_UPDATE: "COMMISSION.HIERARCHY.UPDATE",
	COMMISSION_HIERARCHY_DELETE: "COMMISSION.HIERARCHY.DELETE",
	ROLE_VIEW: "ROLE.VIEW",
	PERMISSION_VIEW: "PERMISSION.VIEW",
	PACKAGE_VIEW: "PACKAGE.VIEW",
	ACCESS_MANAGE: "ACCESS.MANAGE",
	AUDIT_VIEW: "AUDIT.VIEW",
	REPORT_VIEW: "REPORT.VIEW",
	SETTLEMENT_VIEW: "SETTLEMENT.VIEW",
	SUPPORT_VIEW: "SUPPORT.VIEW",
	API_SETTINGS_VIEW: "API_SETTINGS.VIEW",
	LEGAL_VIEW: "LEGAL.VIEW",
	SMS_SETTINGS_VIEW: "SMS_SETTINGS.VIEW"
};
var areaRules = {
	dashboard: {},
	profile: {},
	settings: {},
	members: { anyOf: [
		UI_PERMISSION.MEMBER_LIST,
		UI_PERMISSION.MEMBER_VIEW,
		UI_PERMISSION.MEMBER_STATUS_UPDATE,
		UI_PERMISSION.MEMBER_MANAGE,
		UI_PERMISSION.ACCOUNT_CREATE
	] },
	transactions: { anyOf: [
		UI_PERMISSION.TRANSACTION_VIEW,
		UI_PERMISSION.TRANSACTION_RECONCILIATION_VIEW,
		UI_PERMISSION.TRANSACTION_RECONCILIATION_RESOLVE,
		UI_PERMISSION.TRANSACTION_REVERSAL_REQUEST,
		UI_PERMISSION.TRANSACTION_REVERSAL_PROCESS,
		UI_PERMISSION.TRANSACTION_PROVIDER_INCOME_VIEW
	] },
	banking: { anyOf: [
		UI_PERMISSION.BANK_ACCOUNT_LIST,
		UI_PERMISSION.BANK_ACCOUNT_VIEW,
		UI_PERMISSION.BANK_VIEW,
		UI_PERMISSION.BANK_MANAGE
	] },
	kyc: { anyOf: [UI_PERMISSION.KYC_VIEW, UI_PERMISSION.KYC_MANAGE] },
	aeps: { anyOf: [
		UI_PERMISSION.AEPS_VIEW,
		UI_PERMISSION.AEPS_ONBOARDING,
		UI_PERMISSION.AEPS_BALANCE_ENQUIRY,
		UI_PERMISSION.AEPS_MINI_STATEMENT,
		UI_PERMISSION.AEPS_CASH_WITHDRAWAL,
		UI_PERMISSION.AEPS_AADHAAR_PAY,
		UI_PERMISSION.AEPS_CASH_DEPOSIT,
		UI_PERMISSION.AEPS_MERCHANT_STATUS_UPDATE,
		UI_PERMISSION.AEPS_PROVIDER_STATUS_VIEW,
		UI_PERMISSION.AEPS_PROVIDER_SERVICE_STATUS_UPDATE
	] },
	wallet: { anyOf: [
		UI_PERMISSION.WALLET_VIEW,
		UI_PERMISSION.WALLET_TRANSFER,
		UI_PERMISSION.WALLET_LEDGER_VIEW
	] },
	commissions: { anyOf: [
		UI_PERMISSION.COMMISSION_RULE_VIEW,
		UI_PERMISSION.COMMISSION_DISTRIBUTION_VIEW,
		UI_PERMISSION.COMMISSION_HIERARCHY_VIEW
	] },
	settlements: { anyOf: [UI_PERMISSION.SETTLEMENT_VIEW, UI_PERMISSION.WALLET_VIEW] },
	access: { anyOf: [
		UI_PERMISSION.ACCESS_MANAGE,
		UI_PERMISSION.ROLE_VIEW,
		UI_PERMISSION.PERMISSION_VIEW,
		UI_PERMISSION.PACKAGE_VIEW
	] },
	reports: { anyOf: [UI_PERMISSION.REPORT_VIEW, UI_PERMISSION.AUDIT_VIEW] },
	api: { anyOf: [UI_PERMISSION.API_SETTINGS_VIEW] },
	legal: { anyOf: [UI_PERMISSION.LEGAL_VIEW] },
	support: { anyOf: [UI_PERMISSION.SUPPORT_VIEW] },
	sms: { anyOf: [UI_PERMISSION.SMS_SETTINGS_VIEW, UI_PERMISSION.SUPPORT_VIEW] }
};
var compatRoleAreas = {
	SUPER_ADMIN: [
		"dashboard",
		"profile",
		"members",
		"transactions",
		"banking",
		"kyc",
		"aeps",
		"wallet",
		"commissions",
		"settlements",
		"access",
		"reports",
		"api",
		"settings",
		"legal",
		"support",
		"sms"
	],
	ADMIN: [
		"dashboard",
		"profile",
		"members",
		"transactions",
		"banking",
		"kyc",
		"wallet",
		"commissions",
		"settlements",
		"reports",
		"settings"
	],
	MASTER_DISTRIBUTOR: [
		"dashboard",
		"profile",
		"members",
		"transactions",
		"kyc",
		"wallet",
		"commissions",
		"reports",
		"settings",
		"support"
	],
	DISTRIBUTOR: [
		"dashboard",
		"profile",
		"members",
		"transactions",
		"aeps",
		"wallet",
		"commissions",
		"reports",
		"settings",
		"support"
	],
	RETAILER: [
		"dashboard",
		"profile",
		"transactions",
		"banking",
		"kyc",
		"aeps",
		"wallet",
		"reports",
		"settings"
	]
};
function normalizePermissionCode(value) {
	return value.trim().toUpperCase();
}
var permissionAliases = {
	"TRANSACTION.FINANCIAL_RECOVERY": ["TRANSACTION.FINANCIAL-RECOVERY"],
	"TRANSACTION.FINANCIAL-RECOVERY": ["TRANSACTION.FINANCIAL_RECOVERY"],
	"TRANSACTION.PROVIDER-INCOME.VIEW": ["TRANSACTION.PROVIDER_INCOME.VIEW"],
	"TRANSACTION.PROVIDER-INCOME.RECONCILE": ["TRANSACTION.PROVIDER_INCOME.RECONCILE"],
	"TRANSACTION.PROVIDER_INCOME.VIEW": ["TRANSACTION.PROVIDER-INCOME.VIEW", "PROVIDER_INCOME.VIEW"],
	"PROVIDER_INCOME.VIEW": ["TRANSACTION.PROVIDER_INCOME.VIEW", "TRANSACTION.PROVIDER-INCOME.VIEW"],
	"TRANSACTION.PROVIDER_INCOME.RECONCILE": ["TRANSACTION.PROVIDER-INCOME.RECONCILE", "PROVIDER_INCOME.RECONCILE"],
	"PROVIDER_INCOME.RECONCILE": ["TRANSACTION.PROVIDER_INCOME.RECONCILE", "TRANSACTION.PROVIDER-INCOME.RECONCILE"]
};
function equivalentPermissionCodes(code) {
	const normalized = normalizePermissionCode(code);
	return [normalized, ...permissionAliases[normalized] || []];
}
function permissionEnforcementMode() {
	return String("compat").toLowerCase() === "strict" ? "strict" : "compat";
}
function hasAnyPermission(access, codes) {
	if (!access || codes.length === 0) return false;
	const granted = new Set(access.permissionCodes.map(normalizePermissionCode));
	return codes.some((code) => equivalentPermissionCodes(code).some((candidate) => granted.has(candidate)));
}
function hasAllPermissions(access, codes) {
	if (!access || codes.length === 0) return false;
	const granted = new Set(access.permissionCodes.map(normalizePermissionCode));
	return codes.every((code) => equivalentPermissionCodes(code).some((candidate) => granted.has(candidate)));
}
function canAccessUiArea(area, options) {
	if (options.dedicatedSuperAdmin) return true;
	const role = normalizeRole(options.role);
	if (!role) return false;
	if (area === "dashboard" || area === "profile" || area === "settings") return true;
	const rule = areaRules[area];
	if (options.access) {
		if (rule.allOf?.length && !hasAllPermissions(options.access, rule.allOf)) return false;
		if (!rule.anyOf?.length || hasAnyPermission(options.access, rule.anyOf)) return true;
		if (permissionEnforcementMode() === "strict") return false;
		return compatRoleAreas[role].includes(area);
	}
	if (permissionEnforcementMode() === "strict") return false;
	return compatRoleAreas[role].includes(area);
}
function permissionsForArea(area) {
	return areaRules[area].anyOf || areaRules[area].allOf || [];
}
function canUsePermission(codes, options) {
	if (options.dedicatedSuperAdmin) return true;
	const requested = typeof codes === "string" ? [codes] : codes;
	if (!requested.length) return false;
	if (options.access && hasAnyPermission(options.access, requested)) return true;
	if (permissionEnforcementMode() === "strict") return false;
	const role = normalizeRole(options.role);
	return Boolean(role && options.fallbackRoles?.includes(role));
}
function useEffectiveAccess() {
	const [access, setAccess] = (0, import_react.useState)(() => getEffectiveAccess());
	const [loading, setLoading] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const session = getSession();
		if (!session) return;
		if (access?.identity?.id === session.identity.id) return;
		let cancelled = false;
		setLoading(true);
		syncMyPermissions(session.accessToken).then((next) => {
			if (!cancelled) setAccess(next);
		}).catch(() => {}).finally(() => {
			if (!cancelled) setLoading(false);
		});
		return () => {
			cancelled = true;
		};
	}, [access?.identity?.id]);
	const currentRole = getSession()?.identity.role || null;
	return {
		access,
		loading,
		can: (0, import_react.useCallback)((codes, fallbackRoles = []) => canUsePermission(codes, {
			role: currentRole,
			access,
			fallbackRoles
		}), [access, currentRole])
	};
}
function PermissionBoundary({ area, role, access, dedicatedSuperAdmin = false, children }) {
	if (canAccessUiArea(area, {
		role,
		access,
		dedicatedSuperAdmin
	})) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
	const expected = permissionsForArea(area);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "rounded-2xl border border-amber-200 bg-amber-50 p-6 text-amber-950 shadow-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-white text-amber-700",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { size: 20 })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-black",
					children: "Access not granted"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm leading-6 text-amber-900/75",
					children: "Your active role packages do not grant this section. Ask an administrator to review your package and permission assignment."
				}),
				expected.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-xs font-bold text-amber-800",
					children: ["Expected permission: ", expected.join(" or ")]
				})
			] })]
		})
	});
}
function SectionTabs({ tabs }) {
	if (!tabs.length) return null;
	const current = typeof window === "undefined" ? "" : `${window.location.pathname}${window.location.search}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		"aria-label": "Section navigation",
		className: "mb-6 overflow-x-auto rounded-2xl border border-border bg-white p-2 shadow-sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex min-w-max items-center gap-1",
			children: tabs.map((tab, index) => {
				const active = current ? current === tab.href || !tab.href.includes("?") && current.split("?")[0] === tab.href : index === 0;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: tab.href,
					"aria-current": active ? "page" : void 0,
					className: `whitespace-nowrap rounded-xl px-4 py-2.5 text-xs font-extrabold transition sm:text-sm ${active ? "bg-primary text-white shadow-sm" : "text-secondary hover:bg-muted"}`,
					children: tab.label
				}, tab.href);
			})
		})
	});
}
//#endregion
export { useEffectiveAccess as a, canAccessUiArea as i, SectionTabs as n, UI_PERMISSION as r, PermissionBoundary as t };
