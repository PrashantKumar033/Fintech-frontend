import { r as __toESM } from "../_runtime.mjs";
import { c as getSession, m as normalizeRole, y as signedInHome } from "./role-hierarchy-B8AZOwBW.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { d as useLocation } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useEffectiveAccess, t as PermissionBoundary } from "./section-tabs-DXmZfcpC.mjs";
import { _ as Route$52, b as Route$56, d as Route$42, f as Route$43, g as Route$51, h as Route$5, i as CreateMemberPage, m as Route$46, n as AdminDashboard, p as Route$44, r as AdminIdentitySetup, s as MemberManagementOverview, t as Access, v as Route$54, y as Route$55 } from "./router-ZMSymSrp.mjs";
import { t as AdminProfilePage } from "./admin-profile-page-CK669VTM.mjs";
import { t as AdminSettingsPage } from "./admin-settings-page-Dxa-Ozp0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/management-route-page-Dg0octvk.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var fromRoute = (route) => route.options.component;
var pages = {
	"": AdminDashboard,
	profile: AdminProfilePage,
	merchants: MemberManagementOverview,
	"merchants/add": CreateMemberPage,
	"merchants/list": fromRoute(Route$5),
	transactions: fromRoute(Route$42),
	banking: fromRoute(Route$55),
	kyc: fromRoute(Route$52),
	commissions: fromRoute(Route$54),
	settlements: fromRoute(Route$44),
	access: Access,
	reports: fromRoute(Route$46),
	"api-settings": fromRoute(Route$56),
	settings: AdminSettingsPage,
	legal: fromRoute(Route$51),
	sms: fromRoute(Route$43),
	"account-setup": AdminIdentitySetup
};
var pageAreas = {
	"": "dashboard",
	profile: "profile",
	merchants: "members",
	"merchants/add": "members",
	"merchants/list": "members",
	transactions: "transactions",
	banking: "banking",
	kyc: "kyc",
	commissions: "commissions",
	settlements: "settlements",
	access: "access",
	reports: "reports",
	"api-settings": "api",
	settings: "settings",
	legal: "legal",
	sms: "sms",
	"account-setup": "settings"
};
function ManagementRoutePage({ role, base }) {
	const pathname = useLocation({ select: (location) => location.pathname });
	const session = getSession();
	const { access } = useEffectiveAccess();
	const suffix = pathname.slice(base.length).replace(/^\/+|\/+$/g, "");
	const Page = pages[suffix] || AdminDashboard;
	const area = pageAreas[suffix] || "dashboard";
	(0, import_react.useEffect)(() => {
		if (!session) return window.location.replace("/login");
		if (normalizeRole(session.identity.role) !== role) window.location.replace(signedInHome(session));
	}, [role, session]);
	if (!session || normalizeRole(session.identity.role) !== role) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PermissionBoundary, {
		area,
		role: session.identity.role,
		access,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Page, {})
	});
}
//#endregion
export { ManagementRoutePage as t };
