import { r as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { Et as GitBranch, L as RefreshCw, U as Plus, _ as Trash2, dt as LoaderCircle, j as Search } from "../_libs/lucide-react.mjs";
import { a as useEffectiveAccess, r as UI_PERMISSION } from "./section-tabs-DXmZfcpC.mjs";
import { n as adminApi, s as getAdminActor } from "./admin-api-DMRHCpV5.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-B_1VDSsy.mjs";
import { t as ActionPermissionNotice } from "./action-permission-notice-CGOJQx-x.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hierarchy-o5iMiFsm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var inputClass = "w-full rounded-xl border border-border bg-white px-3.5 py-3 text-sm outline-none focus:border-primary";
var empty = {
	parentUserId: "",
	parentRole: "ADMIN",
	childUserId: "",
	childRole: "MASTER_DISTRIBUTOR",
	serviceType: "",
	isActive: true
};
function Hierarchy() {
	const actor = getAdminActor();
	const { can } = useEffectiveAccess();
	const allowed = (code) => actor?.kind === "SUPER_ADMIN" || can(code, ["ADMIN"]);
	const canViewHierarchy = allowed(UI_PERMISSION.COMMISSION_HIERARCHY_VIEW);
	const canCreateHierarchy = allowed(UI_PERMISSION.COMMISSION_HIERARCHY_CREATE);
	const canUpdateHierarchy = allowed(UI_PERMISSION.COMMISSION_HIERARCHY_UPDATE);
	const canDeleteHierarchy = allowed(UI_PERMISSION.COMMISSION_HIERARCHY_DELETE);
	const [items, setItems] = (0, import_react.useState)([]), [draft, setDraft] = (0, import_react.useState)(empty), [query, setQuery] = (0, import_react.useState)(""), [loading, setLoading] = (0, import_react.useState)(true), [busy, setBusy] = (0, import_react.useState)(false), [error, setError] = (0, import_react.useState)(""), [notice, setNotice] = (0, import_react.useState)("");
	const [diagnosticUser, setDiagnosticUser] = (0, import_react.useState)(""), [diagnosticService, setDiagnosticService] = (0, import_react.useState)("AEPS"), [diagnosticResult, setDiagnosticResult] = (0, import_react.useState)(null);
	async function diagnose(kind) {
		if (!canViewHierarchy) return setError(`Permission ${UI_PERMISSION.COMMISSION_HIERARCHY_VIEW} is required.`);
		if (!diagnosticUser.trim()) return setError("Enter a user ID for hierarchy diagnostics.");
		setBusy(true);
		setError("");
		try {
			setDiagnosticResult(kind === "resolve" ? await adminApi.commissionHierarchy.resolve(diagnosticUser.trim(), diagnosticService.trim().toUpperCase()) : kind === "parents" ? await adminApi.commissionHierarchy.parents(diagnosticUser.trim(), diagnosticService.trim().toUpperCase() || void 0) : kind === "children" ? await adminApi.commissionHierarchy.children(diagnosticUser.trim()) : await adminApi.commissionHierarchy.get(diagnosticUser.trim()));
		} catch (e) {
			setError(e instanceof Error ? e.message : "Unable to resolve hierarchy.");
		} finally {
			setBusy(false);
		}
	}
	async function load() {
		if (!canViewHierarchy) {
			setLoading(false);
			return;
		}
		setLoading(true);
		setError("");
		try {
			setItems(await adminApi.commissionHierarchy.list());
		} catch (e) {
			setError(e instanceof Error ? e.message : "Unable to load hierarchy.");
		} finally {
			setLoading(false);
		}
	}
	(0, import_react.useEffect)(() => {
		if (canViewHierarchy) load();
		else setLoading(false);
	}, [canViewHierarchy]);
	async function submit(e) {
		e.preventDefault();
		if (!canCreateHierarchy) return setError(`Permission ${UI_PERMISSION.COMMISSION_HIERARCHY_CREATE} is required.`);
		if (draft.parentUserId.trim() === draft.childUserId.trim()) return setError("Parent and child user must be different.");
		setBusy(true);
		setError("");
		try {
			await adminApi.commissionHierarchy.create({
				...draft,
				parentUserId: draft.parentUserId.trim(),
				childUserId: draft.childUserId.trim(),
				serviceType: draft.serviceType.trim().toUpperCase() || void 0
			});
			setNotice("Commission hierarchy link created.");
			setDraft(empty);
			await load();
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to create hierarchy.");
		} finally {
			setBusy(false);
		}
	}
	async function toggle(item) {
		if (!canUpdateHierarchy) return setError(`Permission ${UI_PERMISSION.COMMISSION_HIERARCHY_UPDATE} is required.`);
		const nextActive = !item.isActive;
		setBusy(true);
		setError("");
		try {
			await adminApi.commissionHierarchy.update(item.id, { isActive: nextActive });
			setNotice(`Hierarchy link ${item.isActive ? "deactivated" : "activated"}.`);
			setItems((current) => current.map((entry) => entry.id === item.id ? {
				...entry,
				isActive: nextActive
			} : entry));
		} catch (e) {
			setError(e instanceof Error ? e.message : "Unable to update hierarchy.");
		} finally {
			setBusy(false);
		}
	}
	async function remove(item) {
		if (!canDeleteHierarchy) return setError(`Permission ${UI_PERMISSION.COMMISSION_HIERARCHY_DELETE} is required.`);
		if (!confirm("Delete this hierarchy link? Existing commission ledger records are not changed.")) return;
		setBusy(true);
		try {
			await adminApi.commissionHierarchy.remove(item.id);
			setNotice("Hierarchy link deleted.");
			setItems((current) => current.filter((entry) => entry.id !== item.id));
		} catch (e) {
			setError(e instanceof Error ? e.message : "Unable to delete hierarchy.");
		} finally {
			setBusy(false);
		}
	}
	const visible = (0, import_react.useMemo)(() => {
		const n = query.toLowerCase().trim();
		return n ? items.filter((v) => `${v.parentUserId} ${v.parentRole} ${v.childUserId} ${v.childRole} ${v.serviceType || ""}`.toLowerCase().includes(n)) : items;
	}, [items, query]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "commissions",
		eyebrow: "Commission routing",
		title: "Commission hierarchy",
		description: "Define and maintain parent-child commission paths, with optional service-specific routing.",
		children: [
			!canViewHierarchy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ActionPermissionNotice, {
					permission: UI_PERMISSION.COMMISSION_HIERARCHY_VIEW,
					title: "Commission hierarchy is not enabled"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 inline-flex rounded-xl border border-border bg-white p-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin/commissions",
						search: { view: "rules" },
						className: "rounded-lg px-4 py-2.5 text-xs font-extrabold text-muted-foreground",
						children: "Commission Rules"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/admin/commissions",
						search: { view: "distributions" },
						className: "rounded-lg px-4 py-2.5 text-xs font-extrabold text-muted-foreground",
						children: "Distribution Setup"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-lg bg-secondary px-4 py-2.5 text-xs font-extrabold text-white",
						children: "Hierarchy"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, {
				className: "mb-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-black",
						children: "Hierarchy diagnostics"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted-foreground",
						children: "Resolve the effective commission chain or inspect direct parents before changing routing."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 md:grid-cols-[1fr_180px_repeat(4,auto)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: diagnosticUser,
								onChange: (e) => setDiagnosticUser(e.target.value),
								placeholder: "Source or child user ID",
								className: inputClass
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: diagnosticService,
								onChange: (e) => setDiagnosticService(e.target.value.toUpperCase()),
								placeholder: "AEPS",
								className: inputClass
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: busy,
								onClick: () => void diagnose("resolve"),
								className: "rounded-xl bg-secondary px-4 py-3 text-xs font-extrabold text-white",
								children: "Resolve chain"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: busy,
								onClick: () => void diagnose("parents"),
								className: "rounded-xl border border-border px-4 py-3 text-xs font-extrabold",
								children: "Direct parents"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: busy,
								onClick: () => void diagnose("children"),
								className: "rounded-xl border border-border px-4 py-3 text-xs font-extrabold",
								children: "Direct children"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: busy,
								onClick: () => void diagnose("record"),
								className: "rounded-xl border border-border px-4 py-3 text-xs font-extrabold",
								children: "Record by ID"
							})
						]
					}),
					diagnosticResult !== null && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-4 max-h-72 overflow-auto rounded-xl bg-secondary p-4 text-xs text-white",
						children: JSON.stringify(diagnosticResult, null, 2)
					})
				]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mb-5 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700",
				children: error
			}),
			notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-5 rounded-xl bg-emerald-50 p-3 text-sm font-semibold text-emerald-700",
				children: notice
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-6 xl:grid-cols-[400px_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-10 w-10 place-items-center rounded-xl bg-primary/10 text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GitBranch, { size: 18 })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-black",
						children: "Add hierarchy link"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "User IDs must exist in the identity service."
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: submit,
					className: "mt-5 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Parent user ID",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								value: draft.parentUserId,
								onChange: (e) => setDraft({
									...draft,
									parentUserId: e.target.value
								}),
								className: inputClass
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Parent role",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: draft.parentRole,
								onChange: (e) => setDraft({
									...draft,
									parentRole: e.target.value
								}),
								className: inputClass,
								children: [
									"SUPER_ADMIN",
									"ADMIN",
									"MASTER_DISTRIBUTOR",
									"DISTRIBUTOR"
								].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: v }, v))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Child user ID",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								required: true,
								value: draft.childUserId,
								onChange: (e) => setDraft({
									...draft,
									childUserId: e.target.value
								}),
								className: inputClass
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Child role",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: draft.childRole,
								onChange: (e) => setDraft({
									...draft,
									childRole: e.target.value
								}),
								className: inputClass,
								children: [
									"ADMIN",
									"MASTER_DISTRIBUTOR",
									"DISTRIBUTOR",
									"RETAILER"
								].map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: v }, v))
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Service type (optional)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft.serviceType,
								onChange: (e) => setDraft({
									...draft,
									serviceType: e.target.value.toUpperCase()
								}),
								placeholder: "AEPS",
								className: inputClass
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							disabled: !canCreateHierarchy || busy,
							className: "inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-xs font-extrabold text-white",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { size: 14 }), "Create link"]
						})
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-black",
						children: "Configured hierarchy"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [items.length, " parent-child links"]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex items-center gap-2 rounded-xl border border-border px-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { size: 14 }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: query,
								onChange: (e) => setQuery(e.target.value),
								placeholder: "Search user or role",
								className: "py-2.5 text-xs outline-none"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => void load(),
							className: "rounded-xl border border-border p-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
								size: 14,
								className: loading ? "animate-spin" : ""
							})
						})]
					})]
				}), loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex justify-center py-14",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin text-primary" })
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 space-y-3",
					children: [visible.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "rounded-xl border border-border p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-4 sm:flex-row sm:items-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 flex-1",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-black",
													children: item.parentRole
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "→" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-black",
													children: item.childRole
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `rounded-full px-2 py-1 text-[9px] font-extrabold ${item.isActive ? "bg-emerald-50 text-emerald-700" : "bg-muted text-muted-foreground"}`,
													children: item.isActive ? "ACTIVE" : "INACTIVE"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-2 break-all text-xs text-muted-foreground",
											children: [
												item.parentUserId,
												" → ",
												item.childUserId
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-[10px] font-bold text-primary",
											children: item.serviceType || "ALL SERVICES"
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									disabled: !canUpdateHierarchy || busy,
									onClick: () => void toggle(item),
									className: "rounded-lg border border-border px-3 py-2 text-xs font-bold",
									children: item.isActive ? "Deactivate" : "Activate"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									disabled: !canDeleteHierarchy || busy,
									onClick: () => void remove(item),
									className: "rounded-lg border border-red-200 p-2 text-red-700",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { size: 14 })
								})
							]
						})
					}, item.id)), !visible.length && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "rounded-xl border border-dashed border-border py-12 text-center text-sm text-muted-foreground",
						children: "No hierarchy links found."
					})]
				})] })]
			})
		]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-xs font-extrabold uppercase text-muted-foreground",
			children: label
		}), children]
	});
}
//#endregion
export { Hierarchy as component };
