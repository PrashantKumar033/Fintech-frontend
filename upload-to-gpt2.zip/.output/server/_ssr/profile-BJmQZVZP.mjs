import { t as AdminProfilePage } from "./admin-profile-page-CK669VTM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-BJmQZVZP.js
var SplitComponent = AdminProfilePage;
//#endregion
export { SplitComponent as component };
