import { t as AdminSettingsPage } from "./admin-settings-page-Dxa-Ozp0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-CzNE3RwO.js
var SplitComponent = AdminSettingsPage;
//#endregion
export { SplitComponent as component };
