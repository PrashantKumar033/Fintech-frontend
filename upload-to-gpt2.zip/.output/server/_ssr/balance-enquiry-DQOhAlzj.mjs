import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as NetworkAepsTransactions } from "./network-aeps-transactions-C6zIRLfI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/balance-enquiry-DQOhAlzj.js
var import_jsx_runtime = require_jsx_runtime();
function BalanceEnquiryMonitoring() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NetworkAepsTransactions, {
		operation: "BE",
		title: "Balance enquiry monitoring",
		description: "Review balance-enquiry transactions performed by your assigned Retailers."
	});
}
//#endregion
export { BalanceEnquiryMonitoring as component };
