import { o as MasterDashboard } from "./router-ZMSymSrp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/master-distributor-BN_O1vN2.js
var SplitComponent = MasterDashboard;
//#endregion
export { SplitComponent as component };
