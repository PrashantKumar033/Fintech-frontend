import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as NetworkAepsTransactions } from "./network-aeps-transactions-C6zIRLfI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cash-withdrawal-I6L8hz1L.js
var import_jsx_runtime = require_jsx_runtime();
function CashWithdrawalMonitoring() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NetworkAepsTransactions, {
		operation: "CW",
		title: "Cash withdrawal monitoring",
		description: "Review cash-withdrawal transactions performed by your assigned Retailers."
	});
}
//#endregion
export { CashWithdrawalMonitoring as component };
