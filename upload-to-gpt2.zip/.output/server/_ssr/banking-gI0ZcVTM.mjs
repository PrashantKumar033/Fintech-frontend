import { r as __toESM } from "../_runtime.mjs";
import { i as require_react, r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { L as RefreshCw, Lt as Eye, _t as Landmark, dt as LoaderCircle, j as Search, r as X } from "../_libs/lucide-react.mjs";
import { a as useEffectiveAccess, r as UI_PERMISSION } from "./section-tabs-DXmZfcpC.mjs";
import { n as adminApi, s as getAdminActor } from "./admin-api-DMRHCpV5.mjs";
import { n as AdminPanel, t as AdminLayout } from "./admin-layout-B_1VDSsy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/banking-gI0ZcVTM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var control = "rounded-xl border border-border bg-white px-3 py-2.5 text-sm outline-none focus:border-primary";
var messageOf = (value) => value instanceof Error ? value.message : "The bank account request could not be completed.";
function AdminBankOperationsPage() {
	const actor = getAdminActor();
	const { can } = useEffectiveAccess();
	const privileged = actor?.kind === "SUPER_ADMIN";
	const canList = privileged || can(UI_PERMISSION.BANK_ACCOUNT_LIST, ["SUPER_ADMIN", "ADMIN"]);
	const canView = privileged || can(UI_PERMISSION.BANK_ACCOUNT_VIEW, ["SUPER_ADMIN", "ADMIN"]);
	const [items, setItems] = (0, import_react.useState)([]);
	const [filters, setFilters] = (0, import_react.useState)({
		search: "",
		role: "",
		status: "",
		verificationStatus: "",
		ownershipStatus: ""
	});
	const [page, setPage] = (0, import_react.useState)(1);
	const [pages, setPages] = (0, import_react.useState)(1);
	const [total, setTotal] = (0, import_react.useState)(0);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [detailLoading, setDetailLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const [detail, setDetail] = (0, import_react.useState)(null);
	const load = (0, import_react.useCallback)(async (targetPage = 1) => {
		if (!canList) return;
		setLoading(true);
		setError("");
		try {
			const query = new URLSearchParams({
				page: String(targetPage),
				limit: "20"
			});
			Object.entries(filters).forEach(([key, value]) => value.trim() && query.set(key, value.trim()));
			const response = await adminApi.operations.bankAccounts(query.toString());
			setItems(response.data || []);
			setPage(response.pagination.page || targetPage);
			setPages(Math.max(response.pagination.totalPages || 1, 1));
			setTotal(response.pagination.total || 0);
		} catch (value) {
			setError(messageOf(value));
		} finally {
			setLoading(false);
		}
	}, [canList, filters]);
	(0, import_react.useEffect)(() => {
		const timer = window.setTimeout(() => void load(1), 250);
		return () => window.clearTimeout(timer);
	}, [load]);
	async function inspect(bankId) {
		if (!canView) return setError(`Permission ${UI_PERMISSION.BANK_ACCOUNT_VIEW} is required.`);
		setDetailLoading(true);
		setError("");
		try {
			setDetail(await adminApi.operations.bankAccount(bankId));
		} catch (value) {
			setError(messageOf(value));
		} finally {
			setDetailLoading(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminLayout, {
		active: "banking",
		eyebrow: "Bank service",
		title: "Bank operations",
		description: "Search member bank accounts and inspect verification and status history without exposing full account numbers.",
		children: [
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "mb-4 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Total accounts",
						value: total
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Active on page",
						value: items.filter((item) => item.status === "ACTIVE").length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Verified on page",
						value: items.filter((item) => item.verificationStatus === "VERIFIED").length
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Pending on page",
						value: items.filter((item) => item.status === "PENDING").length
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 md:grid-cols-2 xl:grid-cols-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "relative md:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
								className: "absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground",
								size: 16
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: filters.search,
								onChange: (event) => setFilters((v) => ({
									...v,
									search: event.target.value
								})),
								placeholder: "Bank, holder, IFSC or last 4",
								className: `${control} w-full pl-9`
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
							label: "All roles",
							value: filters.role,
							values: [
								"ADMIN",
								"MASTER_DISTRIBUTOR",
								"DISTRIBUTOR",
								"RETAILER"
							],
							set: (role) => setFilters((v) => ({
								...v,
								role
							}))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
							label: "All statuses",
							value: filters.status,
							values: [
								"PENDING",
								"ACTIVE",
								"INACTIVE",
								"BLOCKED"
							],
							set: (status) => setFilters((v) => ({
								...v,
								status
							}))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
							label: "All verification",
							value: filters.verificationStatus,
							values: [
								"PENDING",
								"PROCESSING",
								"VERIFIED",
								"REJECTED",
								"FAILED"
							],
							set: (verificationStatus) => setFilters((v) => ({
								...v,
								verificationStatus
							}))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Filter, {
							label: "All ownership",
							value: filters.ownershipStatus,
							values: [
								"PENDING",
								"VERIFIED",
								"FAILED"
							],
							set: (ownershipStatus) => setFilters((v) => ({
								...v,
								ownershipStatus
							}))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex justify-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => void load(page),
						className: `${control} flex items-center gap-2 font-bold`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, {
							size: 16,
							className: loading ? "animate-spin" : ""
						}), "Refresh"]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 overflow-x-auto rounded-xl border border-border",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full min-w-[900px] text-left text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
							className: "bg-muted/60 text-xs uppercase text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: [
								"Bank account",
								"Member ID",
								"Type",
								"Status",
								"Verification",
								"Ownership",
								"Action"
							].map((label) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3",
								children: label
							}, label)) })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
							className: "divide-y divide-border",
							children: loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 7,
								className: "h-44 text-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mx-auto animate-spin text-primary" })
							}) }) : items.length ? items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "px-4 py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "font-extrabold",
										children: [
											item.bankName,
											" ····",
											item.accountNumberLast4
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-xs text-muted-foreground",
										children: [
											item.accountHolderName,
											" · ",
											item.ifsc
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3 font-mono text-xs",
									children: item.identityId
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: item.accountType
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: item.status })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: item.verificationStatus })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: item.ownershipStatus })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-4 py-3",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										disabled: !canView || detailLoading,
										onClick: () => void inspect(item.id),
										className: "cursor-pointer rounded-lg border border-border p-2",
										title: "View bank details",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 16 })
									})
								})
							] }, item.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								colSpan: 7,
								className: "h-44 text-center text-muted-foreground",
								children: "No bank accounts match these filters."
							}) })
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center justify-between text-xs font-bold",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [total, " bank accounts"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: page <= 1 || loading,
								onClick: () => void load(page - 1),
								className: control,
								children: "Previous"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Page ",
								page,
								" of ",
								pages
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								disabled: page >= pages || loading,
								onClick: () => void load(page + 1),
								className: control,
								children: "Next"
							})
						]
					})]
				})
			] }),
			detailLoading && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-[100] grid place-items-center bg-secondary/50",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin text-white" })
			}),
			detail && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed inset-0 z-[100] grid place-items-center bg-secondary/60 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-2xl bg-white p-6 shadow-xl",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-black uppercase text-primary",
								children: "Bank account detail"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "flex items-center gap-2 text-xl font-black",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Landmark, { size: 20 }),
									detail.bankName,
									" ····",
									detail.accountNumberLast4
								]
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setDetail(null),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 grid gap-4 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DetailGroup, {
								title: "Account information",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "Account holder",
										value: detail.accountHolderName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "Bank",
										value: detail.bankName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "Account number",
										value: `••••${detail.accountNumberLast4}`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "Account type",
										value: detail.accountType
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "IFSC",
										value: detail.ifsc
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "Branch",
										value: detail.branchName
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DetailGroup, {
								title: "Account status",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "Status",
										value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: detail.status })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "Verification",
										value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: detail.verificationStatus })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "Ownership",
										value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Status, { value: detail.ownershipStatus })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "Default account",
										value: detail.isDefault ? "Yes" : "No"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "Purposes",
										value: detail.purposes?.join(", ") || "—"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailRow, {
										label: "Verified on",
										value: formatDate(detail.verifiedAt)
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailHistory, {
							title: "Verification history",
							items: detail.bankAccountVerifications,
							empty: "No verification attempts recorded."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DetailHistory, {
							title: "Status history",
							items: detail.userBankStatusAudits,
							empty: "No status changes recorded."
						})
					]
				})
			})
		]
	});
}
function Filter({ label, value, values, set }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
		value,
		onChange: (event) => set(event.target.value),
		className: control,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: "",
			children: label
		}), values.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: item }, item))]
	});
}
function Status({ value }) {
	const good = ["ACTIVE", "VERIFIED"].includes(value);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-full px-2 py-1 text-[10px] font-black ${good ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}`,
		children: value
	});
}
function Metric({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AdminPanel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-xs font-bold uppercase text-muted-foreground",
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-2xl font-black",
		children: value
	})] });
}
function DetailGroup({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mb-3 font-black",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
			className: "space-y-3",
			children
		})]
	});
}
function DetailRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start justify-between gap-4 border-b border-border/60 pb-2 last:border-0 last:pb-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs font-bold text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "text-right text-sm font-semibold",
			children: value || "—"
		})]
	});
}
function DetailHistory({ title, items, empty }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-4 rounded-xl border border-border p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "font-black",
			children: title
		}), items?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 space-y-2",
			children: items.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg bg-muted p-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: String(item.status ?? item.verificationStatus ?? "Recorded") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: formatDate(item.createdAt ?? item.verifiedAt ?? item.updatedAt)
					})]
				}), Boolean(item.reason || item.remarks || item.provider) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: String(item.reason ?? item.remarks ?? item.provider)
				})]
			}, String(item.id ?? index)))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-muted-foreground",
			children: empty
		})]
	});
}
function formatDate(value) {
	if (!value) return "—";
	const date = new Date(String(value));
	return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString("en-IN");
}
var SplitComponent = AdminBankOperationsPage;
//#endregion
export { SplitComponent as component };
