import { r as AdminIdentitySetup } from "./router-ZMSymSrp.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/account-setup-Dlk9_590.js
var SplitComponent = AdminIdentitySetup;
//#endregion
export { SplitComponent as component };
