import { r as authenticatedRequest } from "./role-hierarchy-B8AZOwBW.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/master-distributor-api-I8KA1hJm.js
var masterDistributorApi = {
	balances: (id) => authenticatedRequest(`/wallet/balances/${encodeURIComponent(id)}`),
	distributors: (id) => authenticatedRequest(`/commission-hierarchy/parent/${encodeURIComponent(id)}/children`),
	transactions: (query = "page=1&limit=50") => authenticatedRequest(`/aeps/network-transactions?${query}`),
	audits: () => authenticatedRequest("/audit/me?page=1&limit=50"),
	commissions: () => authenticatedRequest("/commission-distributions/distributions")
};
//#endregion
export { masterDistributorApi as t };
