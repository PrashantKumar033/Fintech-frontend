import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as NetworkAepsTransactions } from "./network-aeps-transactions-C6zIRLfI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mini-statement-ByD20VR1.js
var import_jsx_runtime = require_jsx_runtime();
function MiniStatementMonitoring() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NetworkAepsTransactions, {
		operation: "MS",
		title: "Mini statement monitoring",
		description: "Review mini-statement transactions performed by your assigned Retailers."
	});
}
//#endregion
export { MiniStatementMonitoring as component };
