import { r as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { O as ShieldAlert } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/action-permission-notice-CGOJQx-x.js
var import_jsx_runtime = require_jsx_runtime();
function ActionPermissionNotice({ permission, title = "Action not available", text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-amber-950",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "mt-0.5 h-5 w-5 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-bold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm",
				children: text || "Your active role package does not grant this action."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs font-semibold text-amber-800",
				children: ["Required: ", permission]
			})
		] })]
	});
}
//#endregion
export { ActionPermissionNotice as t };
